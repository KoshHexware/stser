﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;

public class EmptyAsyncEnumerator<T> : IAsyncEnumerator<T>, IAsyncEnumerable<T>
{
    public T Current => default!;

    public ValueTask DisposeAsync()
    {
        GC.SuppressFinalize(this);
        return default;
    }

    public ValueTask<bool> MoveNextAsync() => new(false);

    public IAsyncEnumerator<T> GetAsyncEnumerator(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return this;
    }
}