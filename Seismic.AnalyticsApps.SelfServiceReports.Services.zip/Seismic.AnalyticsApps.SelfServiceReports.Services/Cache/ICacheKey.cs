﻿using Microsoft.Extensions.Caching.Distributed;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;

public interface ICacheKey<T> where T : class
{
    string Key { get; }
    DistributedCacheEntryOptions CacheOptions { get; }
}