﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.Common.ServiceFoundation.Abstraction;
using StackExchange.Redis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;

public class NullCacheProvider : ISeismicRedisCache
{
    public byte[] Get(string key)
    {
        return Array.Empty<byte>();
    }

    public Task<byte[]?> GetAsync(string key, CancellationToken token = new CancellationToken())
    {
        return Task.FromResult<byte[]?>(null);
    }

    public void Refresh(string key)
    {
    }

    public Task RefreshAsync(string key, CancellationToken token = new CancellationToken())
    {
        return Task.CompletedTask;
    }

    public void Remove(string key)
    {
    }

    public Task RemoveAsync(string key, CancellationToken token = new CancellationToken())
    {
        return Task.CompletedTask;
    }

    public void Set(string key, byte[] value, DistributedCacheEntryOptions options)
    {
    }

    public Task SetAsync(string key, byte[] value, DistributedCacheEntryOptions options,
        CancellationToken token = new CancellationToken())
    {
        return Task.CompletedTask;
    }

    public IAsyncEnumerable<string> GetKeys(string pattern, CancellationToken token = new CancellationToken())
    {
        return new EmptyAsyncEnumerator<string>();
    }

    public Task<int> RemoveByPattern(string pattern, CancellationToken token = new CancellationToken())
    {
        return Task.FromResult(0);
    }

    public Task<ConnectionMultiplexer> GetConnectionMultiplexer()
    {
        return Task.FromResult<ConnectionMultiplexer>(null!);
    }
}
