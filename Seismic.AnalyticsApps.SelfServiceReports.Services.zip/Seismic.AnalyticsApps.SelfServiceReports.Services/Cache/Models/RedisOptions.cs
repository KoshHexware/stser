﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Cache.Models;

public class RedisOptions(string cs, string? cert)
{
    public string? RedisConnectionString { get; set; } = cs;
    public string? RedisCertificate { get; set; } = cert;
}