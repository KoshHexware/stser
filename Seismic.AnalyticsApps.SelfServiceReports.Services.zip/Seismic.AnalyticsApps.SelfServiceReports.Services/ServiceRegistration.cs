﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;
using Polly.Retry;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders;
using Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices;
using Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices.ReportOperatorUpdate;
using Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices.ReportOperatorUpdate.Interface;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Common.ServiceFoundation.Caching;
using Seismic.Common.ServiceFoundation.Extensions.UserManagementService;
using Seismic.Common.ServiceFoundation.LaunchDarkly;
using Seismic.CustomProperty.Client;
using Seismic.Platform.Entitlement.Client;
using Serilog;
using StackExchange.Redis;
using System.Security.Cryptography.X509Certificates;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services;

public static class ServiceRegistration
{
    public static void AddMapper(this IServiceCollection services)
    {
        //services.AddAutoMapper(Assembly.GetExecutingAssembly());
        //services.AddAutoMapper(typeof(AutoMapperProfiles));
    }

    public static void AddBusinessServices(this IServiceCollection services, bool isBackgroundWorkload)
    {
        services.AddUserManagementService();
        services.AddSingleton<CustomPropertyClient>();
        services.AddSingleton<EntitlementServiceClient>();
        services.AddSingleton(sp => new LaunchDarklyClient(sp.GetService<LaunchDarklyOption>().Key));
        AddHttpClients(services);
        AddDataServices(services);
        AddHostedServices(services, isBackgroundWorkload);
        services.AddNotificationClient();

    }

    private static void AddDataServices(IServiceCollection services)
    {
        services.AddScoped<ITenantCacheBuilder, TenantCacheBuilder>();
        services.AddScoped<ITenantService, TenantService>();
        services.AddScoped<IPermissionService, PermissionService>();
        services.AddScoped<IReportService, ReportService>();
        services.AddScoped<IDataAccessor, DataAccessor>();
        services.AddSingleton<IDiscClient, DiscClient>();
        services.AddScoped<IReportRunner, ReportRunner>();
        services.AddScoped<IPicklistQueryService, PicklistQueryService>();
        services.AddScoped<IDraftReportService, DraftReportService>();
        services.AddScoped<IDraftReportFiltersService, DraftReportFiltersService>();
        services.AddScoped<IFeatureService, FeatureService>();

        services.AddSingleton<ICustomPropertyClientWrapper, CustomPropertyClientWrapper>();
        services.AddSingleton<IEntitlementServiceClientWrapper, EntitlementServiceClientWrapper>();
        services.AddSingleton<IBssHelper, BssHelper>();
        services.AddScoped<ISystemReportsService, SystemReportService>();
        services.AddScoped<ISystemFiltersService, SystemFiltersService>();
        services.AddSingleton<ISystemReportsRepository, SystemReportRepository>();
        services.AddSingleton<IFileSystemHelper, FileSystemHelper>();
        services.AddScoped<IQueryService, QueryService>();
        services.AddScoped<IUserService, UserService>();
        services.AddScoped<IOrgHierarchyService, OrgHierarchyService>();
        services.AddScoped<IUserInfoProvider, UserInfoProvider>();
        services.AddScoped<ICustomPropertyService, CustomPropertyService>();
        services.AddScoped<IFiltersMacroResolver, FiltersMacroResolver>();
        services.AddScoped<INewRelicCustomEventHelper, NewRelicCustomEventHelper>();
        services.AddScoped<ICMService, CMService>();
        services.AddScoped<IDediClient, DediClient>();
        services.AddSingleton<INotificationWrapper, NotificationWrapper>();
        services.AddScoped<IReportShareService, ReportShareService>();
        services.AddScoped<IReportDataUpdateService, ReportDataUpdateService>();
        services.AddScoped<IDataAreasService, DataAreaService>();
        services.AddScoped<ISystemDataAreaService, SystemDataAreaService>();
        services.AddScoped<IEntitlementsMigrationService, EntitlementsMigrationService>();
        services.AddScoped<ISSRConfigurationService, SSRConfigurationService>();
        services.AddScoped<IReportingAgentService, ReportingAgentService>();
    }

    private static void AddHostedServices(IServiceCollection services, bool isBackgroundWorkload)
    {
        if (isBackgroundWorkload)
        {
            services.AddHostedService<SsrsBackgroundSyncService>();
            services.AddHostedService<OrgHierarchyCacheRefreshBackgroundService>();
            services.AddHostedService<SsrsBackgroundSyncJobStatusUpdateService>();
            //services.AddHostedService<TenantDataUpdateBackgroundService>();
            //services.AddHostedService<AccessControlUpdateBackgroundService>();
        }
    }

    private static void AddHttpClients(IServiceCollection services)
    {
        //Add any http clients here.UserService
        services.AddHttpClient<IUserService, UserService>()
            .AddPolicyHandler((sp, p) => GetRetryPolicy(sp, 3));
    }

    private static AsyncRetryPolicy<HttpResponseMessage> GetRetryPolicy(IServiceProvider serviceProvider, int retryCount)
    {
        var logger = serviceProvider.GetRequiredService<ILogger>();

        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .RetryAsync(retryCount,
                onRetryAsync: async (exception, retryCount, context) =>
                {
                    var body = string.Empty;
                    if (exception?.Result?.Content != null)
                    {
                        body = await exception.Result.Content.ReadAsStringAsync();
                    }

                    logger.Error(exception?.Exception,
                        $"Retry failed. RetryCount:{retryCount} failed. StatusCode: {exception?.Result?.StatusCode} Reason: {exception?.Result?.ReasonPhrase}. body:{body} RequestMessage:{exception?.Result?.RequestMessage}, uri:{exception?.Result?.RequestMessage?.RequestUri}.");
                });
    }


    public static void AddRedisCache(this IServiceCollection services)
    {
        services.AddSingleton<ISeismicRedisCache>(sp =>
        {
            var options = sp.GetService<RedisOptions>();
            var logger = sp.GetService<ILogger>();
            if (string.IsNullOrWhiteSpace(options?.RedisConnectionString))
            {
                logger?.Warning("No Redis cache configured");
                return new NullCacheProvider();
            }

            var configurationOptions = ConfigurationOptions.Parse(options.RedisConnectionString);
            if (!string.IsNullOrWhiteSpace(options.RedisCertificate))
            {
                configurationOptions.TrustIssuer(
                    new X509Certificate2(Convert.FromBase64String(options.RedisCertificate)));
            }

            var redisConfig = new RedisCacheOptions()
            {
                ConfigurationOptions = configurationOptions
            };
            logger?.Information("Redis cache configured");
            return new SeismicRedisCache(redisConfig);
        });
        services.AddSingleton<IDistributedCache>(sp => sp.GetService<ISeismicRedisCache>() ?? throw new InvalidOperationException("Could not resolve redis cache"));
    }
}