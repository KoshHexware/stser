﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Serilog;
using System;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices
{
    public class SsrsBackgroundSyncJobStatusUpdateService(IServiceScopeFactory _scopeFactory, ILogger logger) : BackgroundService
    {
        private readonly ILogger _logger = logger.ForContext<SsrsBackgroundSyncJobStatusUpdateService>()
            .ForContext("GIT_SHA", Environment.GetEnvironmentVariable("COMMIT_HASH"))
            ?? throw new ArgumentNullException(nameof(logger));

        protected virtual int TimerIntervalSeconds => CacheConstants.REFRESH_NECCESSRY_CHECK_INTERVAL_SECONDS;

        protected override async Task ExecuteAsync(CancellationToken ct)
        {
            await Task.Yield();

            using var timer = new PeriodicTimer(new TimeSpan(0, 0, 0, TimerIntervalSeconds));

            try
            {
                while (!ct.IsCancellationRequested && await timer.WaitForNextTickAsync(ct))
                    await UpdateTenantCacheRefreshJobRunningStatus(ct);
            }
            catch(TaskCanceledException tce)
            {
                return;
            }
            catch (OperationCanceledException oce)
            {
                return;
            }
        }

        protected virtual async Task UpdateTenantCacheRefreshJobRunningStatus(CancellationToken ct)
        {
            try
            {
                if (ct.IsCancellationRequested)
                {
                    return;
                }

                using (var scope = _scopeFactory.CreateScope())
                {
                    _logger.Information("Start tenant cache refresh job status for all tenants");
                    var _dataAccessor = scope.ServiceProvider.GetRequiredService<IDataAccessor>();
                    var _tenantSvc = scope.ServiceProvider.GetRequiredService<ITenantService>();
                    var tenants = await _dataAccessor.GetAllObslateTenantCacheInfo();
                    var tenantOrgs = await _dataAccessor.GetAllObslateTenantOrgCacheInfo();
                    foreach (var tenant in tenants)
                    {
                        tenant.IsRunning = false;
                        await _tenantSvc.UpdateTenant(tenant);
                    }

                    foreach (var tenantOrg in tenantOrgs)
                    {
                        tenantOrg.IsRunning = false;
                        await _tenantSvc.UpdateTenantOrgCacheInfo(tenantOrg);
                    }

                }
                _logger.Information("End tenant cache refresh job status for all tenants");

            }
            catch (Exception e)
            {
                _logger.Error(e, "ExecuteAsync. Fatal error during updating cache refresh job status for all tenants");
            }
        }
    }
}
