﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices.ReportOperatorUpdate.Interface;

interface IReportDataUpdateService
{
    /// <summary>
    /// This method performs a systematic update of date filter operators across all reports in all tenants. 
    /// Its purpose is to convert:
    /// GreaterThanOrEqual operators to GreaterThan(shifting the date backward by one day)
    /// LessThanOrEqual operators to LessThan(shifting the date forward by one day)
    /// </summary>
    /// <returns></returns>
    public Task UpdateReportsDateFilterOperator();
}
