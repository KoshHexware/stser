﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices.ReportOperatorUpdate.Interface;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Matrix.Client;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices.ReportOperatorUpdate;


public class ReportDataUpdateService(IDataAccessor _dataAccessor, ILogger logger, ISeismicRedisCache _seismicCache) : IReportDataUpdateService
{
    private readonly ILogger _logger = logger.ForContext<ReportDataUpdateService>();

    public async Task UpdateReportsDateFilterOperator()
    {
        var allTenants = await _dataAccessor.GetAllTenants();
        foreach(var tenantId in allTenants.Distinct())
        {
            try
            {
                var reports = await _dataAccessor.GetAllCustomReportsForTheTenant(tenantId);

                foreach (var report in reports)
                {
                    try
                    {
                        bool isReportUpdated = false;
                        if (report.Filters == null || !report.Filters.Any() || !report.Filters.Any(x=> x.Operation == Operation.GreaterThanOrEqual || x.Operation == Operation.LessThanOrEqual))
                        {
                            _logger.Warning("No filters found for report {ReportId} in tenant {TenantId}", report.ReportId, tenantId);
                            continue;
                        }

                        foreach (var filter in report.Filters)
                        {
                            string dateValue = filter.Values?.FirstOrDefault() ?? string.Empty;
                    
                            if ((filter.Operation == Operation.GreaterThanOrEqual || filter.Operation == Operation.LessThanOrEqual) && DateTime.TryParse(dateValue, out DateTime parsedDate))
                            {
                                var values = filter.Operation == Operation.GreaterThanOrEqual ?
                                    new[] { parsedDate.AddDays(-1).ToString("yyyy-MM-dd") } :
                                    new[] { parsedDate.AddDays(1).ToString("yyyy-MM-dd") };
                                var operation = filter.Operation == Operation.GreaterThanOrEqual ? Operation.GreaterThan : Operation.LessThan;

                                _logger.Information("Updating filter {FilterName} in report {ReportId} in tenant {TenantId} from {OldOperation} to {NewOperation} and value from {Values} to {NewValues}",
                                    filter.FilterName, report.ReportId, tenantId, filter.Operation, operation, filter.Values, values);

                                filter.Values = values;
                                filter.Operation = operation;
                                isReportUpdated = true;
                            }
                        }

                        if (isReportUpdated)
                        {
                            await _dataAccessor.UpdateReportAsync(report);
                            _logger.Information("Updated report {ReportId} in tenant {TenantId} with new filter operations and values", report.ReportId, tenantId);
                            var cacheKey = new CustomReportCacheKey(tenantId, report.ReportId);
                            await _seismicCache.RemoveAsync(cacheKey.Key);
                        }

                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex, "Error updating report {ReportId} in tenant {TenantId}", report.ReportId, tenantId);
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error reading reports for tenant {TenantId}", tenantId);
            }

        }
    }
}
