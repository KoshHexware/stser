﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices
{
    public class SsrsBackgroundSyncService(IServiceScopeFactory _scopeFactory, ILogger logger) : BackgroundService
    {
        private readonly ILogger _logger = logger.ForContext<SsrsBackgroundSyncService>()
            .ForContext("GIT_SHA", Environment.GetEnvironmentVariable("COMMIT_HASH"))
            ?? throw new ArgumentNullException(nameof(logger));

        protected virtual int TimerIntervalSeconds => CacheConstants.REFRESH_NECCESSRY_CHECK_INTERVAL_SECONDS;

        protected override async Task ExecuteAsync(CancellationToken ct)
        {
            await Task.Yield();

            using var timer = new PeriodicTimer(new TimeSpan(0, 0, 0, TimerIntervalSeconds));

            try
            {
                while (!ct.IsCancellationRequested && await timer.WaitForNextTickAsync(ct))
                    await RefreshTenantCaches(ct);
            }
            catch(TaskCanceledException tce)
            {
                return;
            }
            catch (OperationCanceledException oce)
            {
                return;
            }
        }

        protected virtual async Task RefreshTenantCaches(CancellationToken ct)
        {
            try
            {
                if (ct.IsCancellationRequested)
                {
                    return;
                }

                var scope = _scopeFactory.CreateScope();
                var builder = scope.ServiceProvider.GetRequiredService<ITenantCacheBuilder>();

                _logger.Information("Start cache refresh for all tenants");
                await builder.RefreshTenantCaches(ct);
                _logger.Information("End cache refresh for all tenants");
            }
            catch (Exception e)
            {
                _logger.Error(e, "ExecuteAsync. Fatal error during cache refresh for all tenants");
            }
        }
    }
}
