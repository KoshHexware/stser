using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Serilog;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Impl;
using Seismic.Platform.Matrix.Client;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.HostedServices
{
    public class AccessControlUpdateBackgroundService : BackgroundService
    {

        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger _logger;

        public AccessControlUpdateBackgroundService(
        IServiceProvider serviceProvider,
        ILogger logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger.ForContext<AccessControlUpdateBackgroundService>();
        }

        protected virtual int TimerIntervalSeconds => CacheConstants.REFRESH_ACCESS_CONTROL_MIGRATION_INTERVAL_SECONDS;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Yield();
            using var timer = new PeriodicTimer(new TimeSpan(0, 0, 0, TimerIntervalSeconds));
            try
            {
                await ProcessMigrations(stoppingToken);

                while (!stoppingToken.IsCancellationRequested && await timer.WaitForNextTickAsync(stoppingToken))
                    await ProcessMigrations(stoppingToken);
            }
            catch (TaskCanceledException)
            {
                return;
            }
            catch (OperationCanceledException)
            {
                return;
            }
        }

        private async Task ProcessMigrations(CancellationToken stoppingToken)
        {
            using (var scope = _serviceProvider.CreateScope())
            {
                var _dataAccessor = scope.ServiceProvider.GetRequiredService<IDataAccessor>();
                var _systemDataAreaService = scope.ServiceProvider.GetRequiredService<ISystemDataAreaService>();
                var _userService = scope.ServiceProvider.GetRequiredService<IUserService>();

                _logger.Information("Starting access control migration process - retrieving pending migrations with row-level locking");

                var pendingMigrations = await _dataAccessor.GetExistingAccessControlWithLockAsync(stoppingToken);

                _logger.Information("Found {PendingMigrationsCount} pending migrations to process (locked by this instance)", pendingMigrations.Count());
                
                foreach (var migration in pendingMigrations)
                {
                    var ldFeatureEnabled = await IsTenantEligibleForMigration(migration.TenantId, scope);
                    if (!ldFeatureEnabled)
                    {
                        _logger.Information("Skipping migration for tenant {TenantId} as LD feature is not enabled or tenant does not exist in Matrix", migration.TenantId);
                        continue;
                    }

                    try
                    {
                        _logger.Information("Processing access control migration for tenant {TenantId}", migration.TenantId);

                        var dataAreas = _systemDataAreaService.GetAllSystemDataAreas();

                        var dataAreasToAdd = new List<DataAreaAccess>();
                        _logger.Information("Retrieved {DataAreasCount} system data areas for tenant {TenantId}", dataAreas.Count(), migration.TenantId);

                        var ssrCreatorsUg = await _userService.GetUserGroupByName(migration.TenantId, UserGroupConstants.SelfServiceReportsCreator);

                        AccessType accessType;
                        string[] userGroupIds;

                        if (ssrCreatorsUg == null)
                        {
                            accessType = AccessType.All;
                            userGroupIds = Array.Empty<string>();
                        }
                        else
                        {
                            accessType = AccessType.Excluded;
                            userGroupIds = new[] { ssrCreatorsUg.LegacyId };
                        }

                        foreach (var dataArea in dataAreas)
                        {
                            _logger.Information("Creating data area access entry for tenant {TenantId} and data area {DataAreaId}", migration.TenantId, dataArea.Id);
                            dataAreasToAdd.Add(new DataAreaAccess
                            {
                                TenantId = migration.TenantId,
                                DataAreaId = dataArea.Id,
                                IsDeleted = false,
                                AccessType = accessType,
                                CreatedOnUtc = DateTime.UtcNow,
                                ModifiedOnUtc = DateTime.UtcNow,
                                CreatedBy = "Seismic",
                                ModifiedBy = "Seismic",
                                UserGroupIds = userGroupIds,
                                UserIds = Array.Empty<string>()
                            });
                        }
                        
                        if (dataAreasToAdd.Any())
                        {
                            _logger.Information("Adding {DataAreasCount} data area access entries for tenant {TenantId}", dataAreasToAdd.Count, migration.TenantId);
                            await _dataAccessor.AddDataAreaAccessRangeAsync(dataAreasToAdd);
                        }
                        
                        _logger.Information("Successfully processed migration for tenant {TenantId} - updating status to Completed", migration.TenantId);
                        migration.Status = AccessControlStatus.Completed;

                        // Update this specific migration immediately to release the lock
                        await _dataAccessor.UpdateAccessControlMigrationRange(new[] { migration }, stoppingToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex, "Error processing data area migration for tenant {TenantId}", migration.TenantId);
                        
                        // Mark as failed and continue with next migration
                        migration.Status = AccessControlStatus.Needed;
                        try
                        {
                            await _dataAccessor.UpdateAccessControlMigrationRange(new[] { migration }, stoppingToken);
                        }
                        catch (Exception updateEx)
                        {
                            _logger.Error(updateEx, "Failed to update migration status to Failed for tenant {TenantId}", migration.TenantId);
                        }
                    }
                }
                
                _logger.Information("Completed access control migration process for all pending tenants");
            }
        }

        private async Task<bool> IsTenantEligibleForMigration(Guid tenantId, IServiceScope scope)
        {
            var _contextProvider = scope.ServiceProvider.GetRequiredService<ISeismicContextProvider>();
            var _seismicInstance = scope.ServiceProvider.GetService<ISeismicInstance>();
            var _matrixClient = scope.ServiceProvider.GetService<IMatrixClient>();

            if (_matrixClient == null || _seismicInstance == null)
            {
                _logger.Warning("Matrix client or seismic instance is not available for tenantId:{tenantId}", tenantId);
                return false;
            }

            var matrixTenant = await ValidateTenantExists(tenantId, _matrixClient);
            if (matrixTenant == null)
            {
                _logger.Warning("Tenant not found in matrix for tenantId:{tenantId}", tenantId);
                return false;
            }

            if (matrixTenant.PrimaryRegion != _seismicInstance.GlobalRegionCode)
            {
                _logger.Information("Tenant: {tenantId} has primary region which does not match the global region {globalRegionCode}.", tenantId, _seismicInstance.GlobalRegionCode);
                return false;
            }

            using var _ = SetTenantContext(matrixTenant, _seismicInstance, _contextProvider);
            var context = _contextProvider.GetContext();
            var ldFeatureEnabled = await context.IsToggleEnabled(LDConstants.EnableDomainAccessControl, false);
            if (!ldFeatureEnabled)
            {
                _logger.Warning("LD Toggle {key} not enabled for tenant:{tenantId}", LDConstants.EnableDomainAccessControl, context.TenantIdentifier.TenantUniqueId);
                return false;
            }
            return true;
        }

        private static IDisposable SetTenantContext(Tenant matrixTenant, ISeismicInstance seismicInstance, ISeismicContextProvider contextProvider)
        {
            var tenantIdentifier = TenantIdentifier.FromParts(matrixTenant.Name, matrixTenant.Id);
            var context = new SeismicContext(seismicInstance, tenantIdentifier);
            var contextScope = contextProvider.SetContextExplicitly(context);

            return contextScope;
        }

        private async Task<Tenant?> ValidateTenantExists(Guid tenantId, IMatrixClient matrixClient)
        {
            try
            {
                var matrixTenant = await matrixClient.GetTenantAsync(tenantId);
                return matrixTenant;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error validating tenant:{tenantId}", tenantId);
                return null;
            }
        }
    }
}