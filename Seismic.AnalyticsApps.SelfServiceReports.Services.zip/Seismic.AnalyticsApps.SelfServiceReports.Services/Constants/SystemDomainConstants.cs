﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class SystemDomainConstants
    {
        public const string SystemDomainCRM = "CRM";

        public const string SetupStateComplete = "Complete";
    }
}
