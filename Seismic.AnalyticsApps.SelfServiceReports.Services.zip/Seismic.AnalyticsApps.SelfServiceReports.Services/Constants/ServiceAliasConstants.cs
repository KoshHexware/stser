﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class ServiceAliasConstants
    {
        public const string CONTENTMANAGER = "cm";

        public const string ENTITLEMENT = "entitle";

        public const string DEDI = "dedi";

        public const string PNS = "pns";
    }
}
