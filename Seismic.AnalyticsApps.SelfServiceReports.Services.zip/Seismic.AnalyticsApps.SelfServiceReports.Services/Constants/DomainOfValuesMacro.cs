﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class DomainOfValuesMacro
    {
        public const string ACCESSIBLE_TEAMSITES_MACRO = "ACCESSIBLE_TEAMSITES()";

        public static readonly HashSet<string> ValidMacros =
        [
            ACCESSIBLE_TEAMSITES_MACRO
        ];
    }

}
