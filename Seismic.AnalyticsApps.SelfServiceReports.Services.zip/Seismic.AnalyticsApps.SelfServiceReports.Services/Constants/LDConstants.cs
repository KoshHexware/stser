﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{

    public static class FMSConstants
    {
        public const string SelfServiceReportsKey = "reports-self-service";
    }
    
    public static class LDConstants
    {
        public const string SelfServiceDraftReportsKey = "enable-draft-standard-reports";

        public const string SsrUseEntitlementsLDKey = "ssr-use-entitlements";

        public const string InsightsAdoptEntitlementLDKey = "insights-adopt-entitlement";

        public const string InsightsAdoptEntitlementLearningLDKey = "insights-adopt-entitlement-learning";

        public const string SeismicEnableGranularPermissionsLDKey = "settings-enable-granular-permissions";

        public const string EnableDomainAccessControl = "ssr-enable-domain-access-control";

        public const string SsrWinterFy26Release = "ssr-winter-fy26-release";

        public const string EnableDrillInFeatureLDKey = "ssr-enable-metric-drill-in";
    }
}
