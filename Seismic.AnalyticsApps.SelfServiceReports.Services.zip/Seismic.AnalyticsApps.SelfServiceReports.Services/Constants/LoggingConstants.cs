﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;

public static class LoggingConstants
{
    public const string USER_ID = "UserId";
    public const string TENANT_ID = "TenantId";
    public const string PARTITION = "Partition";
    public const string OFFSET = "Offset";
    public const string ACTION_NAME = "Action";
    public const string BACKGROUND_SERVICE_NAME = "BackgroundService";
    public const string PROGRAM_ID = "EnablementProgramId";
    public const string JOB_ID = "JobId";
    public const string SYNC_REQUEST_ID = "SyncRequestId";
    public const string QUERY_NAME = "QueryName";
    public const string QUERY_FILTER = "QueryFilter";
    public const string DURATION = "Duration";
    public const string STATUS_CODE = "StatusCode";

    public const string GIT_SHA = "GIT_SHA";
}