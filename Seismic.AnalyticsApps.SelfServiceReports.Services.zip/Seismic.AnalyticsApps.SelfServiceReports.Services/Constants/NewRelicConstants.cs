﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public class NewRelicConstants
    {
        public const string NEWRELIC_CUSTOM_EVENT_KEY = "SSRS_Events";

        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_SAVE = "save";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_EXECUTE = "execute";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_DELETE = "delete";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_EXPORT = "export";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_SAVEAS = "saveas";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_SHARE = "share";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_UNSHARE = "unshare";
        public const string NEWRELIC_CUSTOM_EVENT_OPERATION_UPDATEOWNER = "updateowner";
    }
}
