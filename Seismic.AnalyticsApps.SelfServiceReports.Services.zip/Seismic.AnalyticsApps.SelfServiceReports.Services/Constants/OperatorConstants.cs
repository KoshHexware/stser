﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class OperatorConstants
    {
        public const string EQUALS = "Equals";
        public const string EQUALS_LABEL = "Equals";

        public const string NOT_EQUALS = "NotEquals";
        public const string NOT_EQUALS_LABEL = "Not Equals";

        public const string CONTAINS = "Contains";
        public const string CONTAINS_LABEL = "Contains";

        public const string DOES_NOT_CONTAIN = "DoesNotContain";
        public const string DOES_NOT_CONTAIN_LABEL = "Does not contain";

        public const string STARTS_WITH = "StartsWith";
        public const string STARTS_WITH_LABEL = "Starts with";

        public const string ENDS_WITH = "EndsWith";
        public const string ENDS_WITH_LABEL = "Ends with";

        public const string IS_ONE_OF = "IsOneOf";
        public const string IS_ONE_OF_LABEL = "Is one of";

        public const string IS_ALL_OF = "IsAllOf";
        public const string IS_ALL_OF_LABEL = "Is all of";

        public const string IS_NOT_ONE_OF = "IsNotOneOf";
        public const string IS_NOT_ONE_OF_LABEL = "Is not one of";

        public const string GREATER_THAN = "GreaterThan";
        public const string GREATER_THAN_LABEL = "Greater than";

        public const string LESS_THAN = "LessThan";
        public const string LESS_THAN_LABEL = "Less than";

        public const string GREATER_THAN_OR_EQUAL = "GreaterThanOrEqual";
        public const string GREATER_THAN_OR_EQUAL_LABEL = "Greater than or equal";

        public const string LESS_THAN_OR_EQUAL = "LessThanOrEqual";
        public const string LESS_THAN_OR_EQUAL_LABEL = "Less than or equal";

        public const string BETWEEN = "Between";
        public const string BETWEEN_LABEL = "Between";

        public const string IS_NULL = "IsNull";
        public const string IS_NULL_LABEL = "Is blank";

        public const string IS_NOT_NULL = "IsNotNull";
        public const string IS_NOT_NULL_LABEL = "Is not blank";

        public const string IN_THE_LAST = "InTheLast";
        public const string IN_THE_LAST_LABEL = "In the last";

        public const string IN_THE_NEXT = "InTheNext";
        public const string IN_THE_NEXT_LABEL = "In the next";

        public const string NAMED_RANGE = "NamedRange";
        public const string NAMED_RANGE_LABEL = "Named range";

        public const string IS_CURRENT_USER = "IsCurrentUser";
        public const string IS_CURRENT_USER_LABEL = "Is [Current user]";

        public const string IS_MY_TEAM = "IsMyTeam";
        public const string IS_MY_TEAM_LABEL = "Is [My team]";
    }
}
