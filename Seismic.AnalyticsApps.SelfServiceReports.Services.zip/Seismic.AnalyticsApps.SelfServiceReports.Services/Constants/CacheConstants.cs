﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;

public class CacheConstants
{
    public const int REFRESH_NECCESSRY_CHECK_INTERVAL_SECONDS = 60;

    public const int REFRESH_CACHE_INTERVAL_CUSTOM_REPORTS_SECONDS = 60 * 60; //60 minutes

    public const int REFRESH_CACHE_INTERVAL_UMS_SECONDS = 60 * 60; //60 minutes

    public const int REFRESH_CACHE_INTERVAL_USER_PROPERTIES_SECONDS = 60 * 60; //60 minutes

    public const int REFRESH_CACHE_INTERVAL_TENANT_CACHE_SECONDS = 60 * 20; //20 minutes

    public const int BACKGROUND_CACHE_REFRESH_INTERVAL_SECONDS = 60 * 10; //20 minutes

    public const int REFRESH_CACHE_INTERVAL_TENANT_SSRS_ACCESSIBLE_USER = 60 * 30; //30 minutes

    public const int REFRESH_CACHE_INTERVAL_SECONDS = 60 * 60 * 3; //3 hours 

    public const int DEFAULT_TOKEN_CACHE_SECONDS = 60 * 55 * 1; //55 minutes

    public const int SHORT_TIME_CACHE = 60 * 10; // 10mins

    public const int REFRESH_CACHE_INTERVAL_MACRO_RESULTS_SECONDS = 60 * 60 * 1; //1 hour

    public const int REFRESH_CACHE_INTERVAL_USER_ACCESSIBLE_TEAMSITES_SECONDS = 60 * 60 * 1; //1 hour

    public const int REFRESH_ACCESS_CONTROL_MIGRATION_INTERVAL_SECONDS = 60 * 10; // 10 minutes
}