﻿using Parlot.Fluent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public class DateOperatorNamedRangeConstants
    {
        public const string TODAY = "today";
        public const string THIS_WEEK = "this week";
        public const string LAST_WEEK = "last week";
        public const string THIS_MONTH = "this month";
        public const string LAST_MONTH = "last month";
        public const string THIS_YEAR = "this year";
        public const string LAST_YEAR = "last year";
        public const string YEAR_TO_DATE = "year to date";
    }

    public class DateOperatorInTheLastConstants
    {
        public const string DAYS = "days";
        public const string WEEKS = "weeks";
        public const string MONTHS = "months";

    }
}
