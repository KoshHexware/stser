﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;

public static class ReportFragmentConstant
{
    public const string USER_PROPERTY_SELECT_JOIN_ON_USER_TABLE = "e4b07384-d9a0-4f3b-8a1d-5e4b5b5b5b5b";
    public const string USER_PROPERTY_FIELD_SELECT = "f5b07384-d9a0-4f3b-8a1d-5e4b5b5b5b5b";
    public const string USER_PROPERTY_FINAL_SELECT_JOIN = "d3b07384-d9a0-4f3b-8a1d-5e4b5b5b5b5b";

    public const string CONTENT_PROPERTY_SELECT_JOIN_ON_LIBRARY_CONTENT_TABLE = "e30e78ad-52ee-4381-aeb2-9ef1035a2ef0";
    public const string CONTENT_PROPERTY_FIELD_SELECT = "ac1a5c9c-09e6-45c2-86e9-9c7ec38b8c71";
    public const string CONTENT_PROPERTY_FINAL_SELECT_JOIN = "d5a84335-8d67-487d-9aa4-0bcbcbf9e29d";
}
