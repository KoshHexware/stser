﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class ReportConstants
    {
        public const string SYSTEM_DEFAULT_USER = "System";

        public const string DATE_FORMAT = "yyyy-MM-dd";

        public const string TOTAL_RECORDS_COLUMN_NAME = "totalrecords";
    }
}
