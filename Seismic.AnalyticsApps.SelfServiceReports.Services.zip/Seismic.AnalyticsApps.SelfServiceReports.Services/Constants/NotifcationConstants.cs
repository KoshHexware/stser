﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class NotifcationConstants
    {
        /// <summary>
        /// Supported scenario settings for SSRS notifications
        /// </summary>
        public const string SSRSSupportedScenarioSettings = "ReportSharedNotificationPayload";

        /// <summary>
        /// Biz category for SSRS notifications
        /// </summary>
        public const string SSRSNotificationsBizCategory = "ssrs_notifications";

        /// <summary>
        /// Biz scenario for shared SSRS reports
        /// </summary>
        public const string SSRSReportSharedBizScenario = "ssrs.report.shared";
    }
}
