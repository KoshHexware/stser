﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class CustomPropertyConstant
    {
        public const string USER_PROPERTIES = "User properties";

        public const string USER_PROPERTIES_QUERY_ALIAS = "UserProperty";

        public const string CUSTOM_PROPERTIES = "Custom properties";

        public const string CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS = "ContentCustomProperty";
    }
}
