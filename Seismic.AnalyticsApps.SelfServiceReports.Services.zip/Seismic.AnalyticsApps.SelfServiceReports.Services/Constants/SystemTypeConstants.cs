﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class SystemTypeConstants
    {
        public const string Seismic = "Seismic";

        public const string Lessonly = "Lessonly";
    }
}
