﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class PermissionConstants
    {
        public const string SelfServiceReportsViewerPermissionKey = "seismic.self-service-reports.view.report";

        public const string SelfServiceReportsManageReportsPermissionKey = "seismic.self-service-reports.manage.all.reports";

        public const string SelfServiceReportsCreatorPermissionKey = "seismic.self-service-reports.create.new.reports";

        public const string SeismicSecuritySettingManagePermissionKey = "seismic.admin-setting.security-setting.manage";

        public const string LiveInsightsManagePermissionKey = "seismic.insights.manage.liveinsights";

        public const string SnowflakeManagePermissionKey = "seismic.insights.manage.snowflake";
    }
}
