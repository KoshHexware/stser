﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class FeatureTypeConstants
    {
        public const string System = "system";

        public const string LaunchDarkly = "launchDarkly";

        public const string FMS = "fms";

        public const string Other = "other";
    }
}
