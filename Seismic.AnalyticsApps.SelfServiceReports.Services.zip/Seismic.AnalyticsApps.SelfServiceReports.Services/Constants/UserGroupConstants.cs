﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Constants
{
    public static class UserGroupConstants
    {
        public const string SelfServiceReportsViewer = "Self service reports viewer";
        
        public const string SelfServiceReportsEditor = "Self service reports editor";

        // This group is used to create new reports using shared and owned custom reports and edit existing custom reports only
        public const string SelfServiceReportsCreator = "Self service reports creator";
    }
}
