﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ReportSummary
    {
        public Guid Id { get; set; }

        public required string ReportName { get; set; }

        public Guid SystemReportId { get; set; }

        public required string SystemReportName { get; set; }

        public required string Description { get; set; }

        public string? OwnerUserName { get; set; }//may be null when user is deleted.

        public string? OwnerThumbnailUrl { get; set; }//may be null when user's avatar image doesn't exist.

        public string? OwnerUserId { get; set; }//may be null when user is deleted.

        public DateTime? LastViewed { get; set; }

        public DateTime? LastUpdated { get; set; }

        public required ReportType ReportType { get; set; }

        public bool ShowTeamsitePicker { get; set; }

        public DateTime? SharedOn { get; set; }
    }
}
