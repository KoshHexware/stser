﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class SSRUserConfiguration
    {
        public required AccessLevel AccessLevel { get; set; }

        public UserSettings? UserSettings { get; set; }

        public PagedList<ReportSummary>? ReportsList { get; set; }

        public bool HasSystemReportAccess { get; set; } = false;
    }
}
