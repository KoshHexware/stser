﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public enum AccessLevel
    {
        None,
        Viewer,
        Editor,
        CustomReportEditor
    }
}
