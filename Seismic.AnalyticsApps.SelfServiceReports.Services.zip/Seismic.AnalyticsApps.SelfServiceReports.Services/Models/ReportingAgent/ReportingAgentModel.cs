﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportingAgent
{
   
    public class StandardReport
    {
        public Guid ReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportDescription { get; set; }
        public List<ReportField> DefaultFields { get; set; }
        public List<ReportField> Metrics { get; set; }
    }

    public class ApiError
    {
        public string ErrorMessage { get; set; }
        public string WithValue { get; set; } // optional
        public string Suggestion { get; set; }

    }
    public class ApiResponse<T>
    {

        public bool Success { get; set; }
        public List<ApiError>? Errors { get; set; }  // optional, only on error
        public required T Data { get; set; }

    }

    //public class ReportField
    //{
    //    public string Name { get; set; }
    //    public string Description { get; set; }
    //    public string DataType { get; set; }
    //}
    public class CustomReportField
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string DataType { get; set; }
    }
    public class ReportMetric
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
    public class AgentReportFilter
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string DataType { get; set; }
        public List<string> AllowedOperators { get; set; }
    }
    public class ReportDetail
    { 
        public Guid ReportId {  get; set; }
        public string ReportName { get; set; }
        public string ReportDescription { get; set; }
        public List<ReportField> Fields { get; set; }
        public List<ReportField> CustomPropertyFields { get; set; }
        public List<ReportField> Metrics { get; set; }
        public List<AgentReportFilter> Filters { get; set; }
    }

    public class FilterDetail
    {
        public string FilterName { get; set; }
        public bool HasDomainOfValues { get; set; }
        public bool IsListTruncated { get; set; }
        public List<string> Values { get; set; }
    }
    public class ExecuteReportRequest
    {
        public List<string> Fields { get; set; }
        public List<AdditionalFilter> AdditionalFilters { get; set; }
        public SortBy SortBy { get; set; }
    }
    public class AdditionalFilter
    {
        public string FilterName { get; set; }
        public Operation Operation { get; set; }
        public List<string> Values { get; set; }
    }
    public class SortBy
    {
        public string FieldName { get; set; }
        public string SortOrder { get; set; }
    }
    
    public class ColumnField
    {
        public string column { get; set; }
        public string Name { get; set; }//UxLabel
        public string Description { get; set; }//field-description

    }
    public class RowData
    {
        public string FIELDSNOWFLAKENAME { get; set; }//fieldvalue
        //etc
    }
    public class ExecuteReportResult
    {
        public List<RowData> Rows { get; set; }
        public required List<ColumnField> Fields { get; set; }
        public required Pagination Pagination { get; set; }
    }
    public class ExecuteApiResponse<T>
    {
        public required bool Success { get; set; }
        public List<ApiError>? Errors { get; set; }  // optional, only on error
        public required List<ColumnField> Fields { get; set; }
        public required T Data { get; set; }
        public required Pagination Pagination { get; set; }

    }

}
