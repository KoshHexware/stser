﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ReportOwnerUpdateRequest
    {
        public Guid ReportId { get; set; }

        public required string NewOwnerId { get; set; }

        public Guid TenantId { get; set; }
    }
}