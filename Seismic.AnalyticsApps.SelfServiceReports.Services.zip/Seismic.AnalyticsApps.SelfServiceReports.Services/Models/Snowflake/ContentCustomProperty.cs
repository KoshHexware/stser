﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;

[ExcludeFromCodeCoverage]
public class ContentCustomProperty : SeismicBaseProperty
{
}
