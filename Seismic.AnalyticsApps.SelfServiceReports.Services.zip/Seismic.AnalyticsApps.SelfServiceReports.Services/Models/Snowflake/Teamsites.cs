using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;

[ExcludeFromCodeCoverage]
public class Teamsites 
{
    public required string Id { get; set; }

    public bool IsDeleted { get; set; }

    public required string Name { get; set; }
}