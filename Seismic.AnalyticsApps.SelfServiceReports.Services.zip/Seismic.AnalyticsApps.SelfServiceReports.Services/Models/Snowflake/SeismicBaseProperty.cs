using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;

[ExcludeFromCodeCoverage]
public class SeismicBaseProperty
{
    public required string Id { get; set; }

    public required string Name { get; set; }

    public required string Type { get; set; }

    public string[]? Values { get; set; }

    public string? Description { get; set; }

    /// <summary>
    /// TeamsiteIds list the content custom property associated to
    /// </summary>
    public string[]? TeamsiteIds { get; set; }

    public string? Definition { get; set; }

    public bool? AllowMultipleValues { get; set; }
}
