﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft
{
    public class DraftReport
    {
        public Guid ReportId { get; set; }

        public required string ReportName { get; set; }

        public required string Description { get; set; }

        public Guid TenantId { get; set; }

        public DateTime? LastUpdated { get; set; }

        public ReportType ReportType { get; set; }

        public required ReportDefinitionMetadata Metadata { get; set; }

        public required ReportDefinitionQuery Query { get; set; }

        public required string Template { get; set; }
    }

}
