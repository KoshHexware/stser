﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft
{
    public class CreateDraftReport
    {
        public required Guid ReportId { get; set; }
        public required string ReportName { get; set; }
        public required string Description { get; set; }
    }
}
