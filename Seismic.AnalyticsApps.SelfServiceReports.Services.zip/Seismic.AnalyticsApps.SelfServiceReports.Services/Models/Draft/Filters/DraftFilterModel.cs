﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters
{
    //This Type is used to deserialize the filters yaml
    public class DraftFilterModel
    {
        public required List<FilterTemplateModel> Filters { get; set; }
    }

    public class FilterTemplateModel
    {
        public required string FilterName { get; set; }

        public required string QueryParam { get; set; }

        public required string UxLabel { get; set; }

        public required string UxDescription { get; set; }

        public string? Category { get; set; }

        public DataType DataType { get; set; }

        public required List<FilterOperation> AllowedOperators { get; set; }

        public FilterType FilterType { get; set; }

        public string? FilterPicklistQuery { get; set; }

        public bool IsRequired { get; set; }

        public List<string>? DomainValues { get; set; }
        

        /// <summary>
        /// This field will be used to identify the default value for the filter i.e. for generic filters
        /// The value will come from fields metadata
        /// </summary>
        public string[]? FilterDefaultValues { get; set; }

        /// <summary>
        /// This field will be used to identify the default value for the generic filters comes from fields metadata
        /// </summary>
        public bool? FilterIsDefault { get; set; }

        /// <summary>
        /// This field will be used to identify the default operator for the generic filters comes from fields metadata
        /// </summary>
        public string? FilterDefaultOperator { get; set; }

        public bool? IsProperty { get; set; }

        public PropertyType? PropertyType { get; set; }

        /// <summary>
        /// user property or custom property id
        /// </summary>
        public string? PropertyId { get; set; }

        /// <summary>
        /// TeamsiteIds list the content custom property associated to
        /// </summary>
        public string[]? TeamsiteIds { get; set; } = Array.Empty<string>();

        /// <summary>
        /// Do not use this field in filters yaml
        /// To identify if the filter is generic filter or not
        /// </summary>
        public bool? IsGenericFilter { get; set; }

        public string? QueryAlias { get; set; }

        public bool? IsNullable { get; set; }

        public bool? IsDefault { get; set; }

        public bool? FilterValuesByTeamsite { get; set; }

        public string? EnableRelativeUserFilterField { get; set; }

        public string? DataAreaKey { get; set; }
    }

    public class FilterGroup
    {
        public required string UxLabel { get; set; }

        public required List<FilterTemplateModel> Filters { get; set; }
    }
}