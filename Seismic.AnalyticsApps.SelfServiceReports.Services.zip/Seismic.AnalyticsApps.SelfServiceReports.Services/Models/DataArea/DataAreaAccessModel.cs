﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.DataArea 
{
    public class DataAreaAccessModel
    {
        public string Name { get; set; } = string.Empty;
        public required Guid Id { get; set; }
        public required AccessType AccessType { get; set; } = AccessType.NoAccess; // Included | Excluded | All | NoAccess
        public required string Domain { get; set; } = string.Empty;
        public List<UserInfoModel> Users { get; set; }= [];
        public List<UserGroupModel> UserGroups { get; set; }=[] ;
    }
}
