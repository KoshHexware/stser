﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.DataArea
{
    public class UserGroupModel
    {
        public string Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty; // Optional, TBD
    }
}
