﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class Query
    {
        public required string Name { get; set; }

        public required string Sql { get; set; }

        public Dictionary<string, string>? StringParams { get; set; }
        public Dictionary<string, DateTime?>? DateParams { get; set; }
        public Dictionary<string, bool?>? BoolParams { get; set; }
        public Dictionary<string, int?>? IntParams { get; set; }
        public Dictionary<string, decimal?>? DecimalParams { get; set; }
        public Dictionary<string, string[]>? MultiStringParams { get; set; }
    }
}
