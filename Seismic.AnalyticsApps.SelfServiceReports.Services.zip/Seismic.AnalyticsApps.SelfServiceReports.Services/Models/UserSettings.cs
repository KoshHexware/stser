﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class UserSettings
    {
        public List<Teamsites> Teamsites { get; set; }

        public string ReportsFilterOption { get; set; }

        public TenantSettings TenantSettings { get; set; }

        public string OrderField { get; set; }

        public string OrderBy { get; set; }
    }

    public class TenantSettings
    {
        public bool IsOrgHierarchyEnabled { get; set; } = false;

        public bool HasOrgHierarchy { get; set; } = false;
    }
}
