﻿using System.Text.Json.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ReportSharedNotificationPayload
    {
        [JsonPropertyName("report_name")]
        public string ReportName { get; set; }

        [JsonPropertyName("shared_on")]
        public string SharedOn { get; set; }

        [JsonPropertyName("user_id")]
        public string UserId { get; set; }

        [JsonPropertyName("report_type")]
        public string ReportType { get; set; }

        [JsonPropertyName("report_url")]
        public string ReportUrl { get; set; }
    }
}
