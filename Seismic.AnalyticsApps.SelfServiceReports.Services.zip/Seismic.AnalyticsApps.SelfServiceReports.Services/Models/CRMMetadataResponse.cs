﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class CRMMetadataResponse
    {
        public List<DataSource>? DataSources { get; set; }
    }

    public class DataSource
    {
        public string? SystemDomain { get; set; }
        public string? SetupState { get; set; }
    }
}
