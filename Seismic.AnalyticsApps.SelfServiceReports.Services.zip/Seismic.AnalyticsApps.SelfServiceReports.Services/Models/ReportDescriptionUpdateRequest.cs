﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    /// <summary>
    /// Model for updating a report's description
    /// </summary>
    public class ReportDescriptionUpdateRequest
    {
        [Required]
        [StringLength(500, ErrorMessage = "Description length can't be more than 500.")]
        public string Description { get; set; } = string.Empty;
    }
}
