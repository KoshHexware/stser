﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

public class FieldGroup
{
    public required string UxLabel { get; set; }

    public required List<ReportField> Fields { get; set; }
}

public class ReportField
{
    public required string Name { get; set; }

    public DataType DataType { get; set; }

    public bool IsDefault { get; set; }

    public required string UxLabel { get; set; }

    public required string UxDescription { get; set; }

    /// <summary>
    /// This parameter will be true only if the field is a user property or custom property
    /// </summary>
    public bool? IsProperty { get; set; }

    public PropertyType? PropertyType { get; set; }

    /// <summary>
    /// user property or custom property id
    /// </summary>
    public string? PropertyId { get; set; }

    /// <summary>
    /// Teamsite Ids List for the custom property associated with.
    /// </summary>
    public string[]? TeamsiteIds { get; set; }

    public bool? HasGenericFilter { get; set; }

    public string? Formatter { get; set; }

    public bool Nullable { get; internal set; }

    public string[]? RequiredFeatureKeys { get; set; }

    public string? DataAreaKey { get; set; }

    public string? FilterName { get; set; }

    public string? FilterPicklistQuery { get; set; }

    public List<string>? FilterDomainValues { get; set; }

    public bool? FilterIsDefault { get; set; }

    public string? FilterDefaultOperator { get; set; }

    public string[]? FilterDefaultValues { get; set; }

    public string? QueryAlias { get; set; }

    public bool? FilterValuesByTeamsite { get; set; }

    public string? Definition { get; set; }

    public string? EnableRelativeUserFilterField { get; set; }

    public DrillIn? DrillIn { get; set; }
}

public enum DataType { Text, Integer, Decimal, DateTime, Boolean, Date, Csv }

public enum PropertyType
{
    None,
    UserProperty,
    ContentCustomProperty
}

public class DrillIn
{
    public Guid TargetReport { get; set; }

    public string? TargetFilter { get; set; }

    public string? SourceValue { get; set; }

    public List<OptionalFilters>? optionalFilters { get; set; }
}

public class OptionalFilters
{
    public string? TargetFilter { get; set; }

    public string? SourceValue { get; set; }
}

