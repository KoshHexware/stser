﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas
{

    public class DataAreas
    {
        public required List<DataArea> DataArea { get; set; }
    }

    public class DataArea
    {
        public required string UxLabel { get; set; }

        public required Guid Id { get; set; }

        public required string Domain { get; set; }
        public required string Key { get; set; }
    }
}