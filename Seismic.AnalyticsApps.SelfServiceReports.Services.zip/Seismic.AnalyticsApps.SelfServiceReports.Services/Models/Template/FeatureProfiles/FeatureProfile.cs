﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.FeatureProfiles;
public class FeatureProfiles 
{
    public required List<FeatureProfile> Features { get; set; }
}

public class FeatureProfile

{
    public required string Name { get; set; }

    public required string Key { get; set; }

    public required string Type { get; set; }

}