﻿using Fluid;
using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

[ExcludeFromCodeCoverage]
public class ReportFragmentDefinition
{
    public Guid FragmentId { get; set; }
    public required string FragmentName { get; set; }
    public required string QueryTemplate { get; set; }
}


[ExcludeFromCodeCoverage]
public class ReportFragmentDefinitionQuery
{
    public string FragmentName { get; set; }

    public Guid FragmentId { get; set; }

    public IFluidTemplate CompiledQuery;


    public ReportFragmentDefinitionQuery(ReportFragmentDefinition def)
    {
        FragmentName = def.FragmentName;
        FragmentId = def.FragmentId;

        var parser = new FluidParser();
        CompiledQuery = parser.Parse(def.QueryTemplate);
    }
}
