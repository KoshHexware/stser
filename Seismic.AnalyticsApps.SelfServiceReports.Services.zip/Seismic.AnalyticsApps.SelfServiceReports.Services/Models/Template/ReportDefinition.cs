﻿using Fluid;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

//All classes in this file are used in parsing report yaml, not in execution

//public class Chart
//{
//    public string Name { get; set; }
//}

// The yaml file is deserialized into this class
public class ReportDefinitionMetadata
{
    public Guid ReportId { get; set; }

    public required string ReportName { get; set; }
    
    public required string Description { get; set; }

    public string? PrimaryKeyField { get; set; }

    public string? DataAreaKey { get; set; }

    public string? OrderField { get; set; }
    
    public string? OrderBy { get; set; }

    public string[]? FilterCategoryOrder{ get; set; }

    public string[]? RequiredFeatureKeys { get; set; }

    public List<ReportFilter>? Filters { get; set; }

    public List<ReportField>? Fields { get; set; }

    public required List<FieldGroup> FieldGroups { get; set; }

    /// <summary>
    /// Note: This field is not used in the report yaml file, but is used in the API response.
    /// </summary>
    public List<FilterGroup> FilterGroup { get; set; } = [];

    /// <summary>
    /// Note: This field is not used in the report yaml file, but is used in the API response.
    /// </summary>
    public DateTime? LastModified { get; set; }

    public bool IncludeUserProperties { get; set; }

    public bool IncludeCustomProperties { get; set; }

    public bool ShowTeamsitePicker { get; set; }

    //public List<Chart> Charts { get; set; }

    public required string QueryTemplate { get; set; }
}


/// <summary>
/// The filters field in the report yaml file is deserialized into this class
/// </summary>
public class ReportFilter
{
    public required string FilterName { get; set; }

    /// <summary>
    /// This category from the report yaml file overrides the filter category in the filter yaml file.
    /// </summary>
    public string? Category { get; set; }

    public bool IsDefault { get; set; }
    
    public string? DefaultOperator { get; set; }
    
    public string[]? DefaultValues { get; set; }
}


public class ReportDefinitionQuery
{
    public string ReportName { get; set; }
    public IFluidTemplate CompiledQuery;

    public ReportDefinitionQuery(ReportDefinitionMetadata def)
    {
        ReportName = def.ReportName;

        var parser = new FluidParser();
        CompiledQuery = parser.Parse(def.QueryTemplate);
    }
}