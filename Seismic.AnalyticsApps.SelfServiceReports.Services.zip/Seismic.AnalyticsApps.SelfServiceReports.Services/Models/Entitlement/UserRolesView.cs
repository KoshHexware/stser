﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement
{
    public class UserRolesView
    {
        public string UserId { get; set; }

        public List<AssignedRoleView> Roles { get; set; }
    }
}
