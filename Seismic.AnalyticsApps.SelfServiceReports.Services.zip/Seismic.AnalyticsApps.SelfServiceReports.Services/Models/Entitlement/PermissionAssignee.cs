﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement
{
    public class PermissionAssignee
    {
        public Guid Id { get; set; }

        public Guid ApplicationId { get; set; }

        /// <summary>
        /// Type of the assignee. It can be either User or User group
        /// </summary>
        public string AssigneeType { get; set; }

        /// <summary>
        /// Id of the assignee. It can be either User Id
        /// </summary>

        public string AssigneeId { get; set; }

        /// <summary>
        /// Is there any role assigned to the assignee
        /// </summary>
        public bool IsRoleAssigned { get; set; }

        /// <summary>
        /// Username of the assignee
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Email of the assignee
        /// </summary>
        public string Email { get; set; }

    }
}
