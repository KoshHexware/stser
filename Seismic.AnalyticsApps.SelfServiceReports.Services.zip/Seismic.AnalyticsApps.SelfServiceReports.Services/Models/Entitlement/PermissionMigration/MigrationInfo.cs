﻿using System.Runtime.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement.PermissionMigration;

public class MigrationInfo
{
    public MigrationType MigrationType { get; set; }
    public List<string> UserTypes { get; set; }
    public List<string> Users { get; set; }
    public List<string> UserGroups { get; set; }
    public List<string> Permissions { get; set; }
    public Operation Operation { get; set; }
}

public enum MigrationType
{
    [EnumMember(Value = "PerUserTypes")] PerUserTypes,
    [EnumMember(Value = "PerUsersAndGroups")] PerUsersAndGroups
}


public enum Operation
{
    [EnumMember(Value = "enable")] Enable,
    [EnumMember(Value = "disable")] Disable
}

