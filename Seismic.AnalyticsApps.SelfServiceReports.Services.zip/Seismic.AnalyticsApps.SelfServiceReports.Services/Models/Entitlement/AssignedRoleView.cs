﻿using System.Text.Json.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement
{
    public class AssignedRoleView : RoleView
    {
        [JsonPropertyName("assignmentTypes")]
        public List<string> AssignmentTypes { get; set; } = new();
    }
}
