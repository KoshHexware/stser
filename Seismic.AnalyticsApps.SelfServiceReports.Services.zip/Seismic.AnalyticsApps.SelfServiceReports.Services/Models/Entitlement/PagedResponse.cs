﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement;

public class PagedResponse<T>
{
    public List<T> Items { get; set; }

    public int Count { get; set; }

    public int PageIndex { get; set; }

    public int ItemsPerPage { get; set; }

    public bool HasNextPage { get; set; }
   
}
