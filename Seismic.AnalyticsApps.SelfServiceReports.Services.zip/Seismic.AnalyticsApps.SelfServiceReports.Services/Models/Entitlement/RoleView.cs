﻿using System.Text.Json.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement
{
    public class RoleView
    {
        [JsonPropertyName("id")]
        public string Id { get; set; } = string.Empty;

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("license")]
        public string? License { get; set; }

        [JsonPropertyName("nameI18nKey")]
        public string? NameI18nKey { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("descriptionI18nKey")]
        public string? DescriptionI18nKey { get; set; }

        [JsonPropertyName("stage")]
        public int Stage { get; set; }

        [JsonPropertyName("permissions")]
        public List<string> Permissions { get; set; } = new();

        [JsonPropertyName("originalRoleId")]
        public string? OriginalRoleId { get; set; }

        [JsonPropertyName("systems")]
        public List<RoleSystemMappingView> Systems { get; set; } = new();
    }

    public class RoleSystemMappingView
    {
        [JsonPropertyName("systemType")]
        public string SystemType { get; set; } = string.Empty;
    }
}