﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class HierarchicalUserInfo
    {
        public string Id { get; set; }

        public string UserId { get; set; }

        public string ManagerUserId { get; set; }

        public string ManagerName { get; set; }

        public string ManagerEmail { get; set; }

        public string Organization { get; set; }

        public string UserName { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string DisplayName { get; set; }

        public string Email { get; set; }

        public string Title { get; set; }

        public string AvatarBlobId { get; set; }

        public int? ReportCount { get; set; }

        public HierarchyLevel HierarchyLevel { get; set; }

        public HierarchicalUserInfo? Manager { get; set; }

        public List<HierarchicalUserInfo> Teams { get; set; }

        public static HierarchicalUserInfo WithManager(HierarchicalUserInfo userInfo, HierarchicalUserInfo? manager)
        {
            ArgumentException.ThrowIfNullOrEmpty(nameof(userInfo), nameof(userInfo));

            if (manager != null && manager.UserId != userInfo.ManagerUserId)
            {
                throw new ArgumentException("Manager user id does not match!");
            }

            userInfo.Manager = manager;
            return userInfo;
        }
    }
}
