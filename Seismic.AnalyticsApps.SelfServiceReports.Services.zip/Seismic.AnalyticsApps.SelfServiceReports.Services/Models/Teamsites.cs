﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class Teamsites
    {
        public required string Id { get; set; }

        public required string Name { get; set; }

        public string? Description { get; set; }

        // This is used to determine if the team site is globally selected For reports by user
        public bool IsSelected { get; set; }
    }
}
