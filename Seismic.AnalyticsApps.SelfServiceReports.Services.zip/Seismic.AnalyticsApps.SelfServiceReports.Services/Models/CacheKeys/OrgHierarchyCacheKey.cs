﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class OrgHierarchyCacheKey(Guid tenantId) : ICacheKey<OrgHierarchy>
    {
        public string Key { get; } = CacheExtensions.GetTenantCacheKeyName(tenantId, "-org-hierarchy");

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_TENANT_CACHE_SECONDS)
        };
    }
}
