﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class UserHierarchyLevelCacheKey(Guid tenantId, string userId) : ICacheKey<string>
    {
        public string Key { get; } = CacheExtensions.GetTenantUserCacheKeyName(tenantId, userId, "user-hierarchy-level");

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_TENANT_CACHE_SECONDS)
        };
    }
}
