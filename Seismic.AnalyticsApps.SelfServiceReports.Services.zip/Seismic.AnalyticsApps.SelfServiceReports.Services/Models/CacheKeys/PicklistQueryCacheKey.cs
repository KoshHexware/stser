﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class PicklistQueryCacheKey(Guid tenantId, Guid systemReportId, string filterName, string? teamsiteIds, string? searchTerm ) : ICacheKey<List<string>>
    {
        
        private const string NAME = "picklist-query";
        public string Key => CacheExtensions.GetPicklistQueryCacheKeyName(tenantId, systemReportId, filterName, NAME, teamsiteIds, searchTerm);

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_TENANT_CACHE_SECONDS)
        };
    }
}
