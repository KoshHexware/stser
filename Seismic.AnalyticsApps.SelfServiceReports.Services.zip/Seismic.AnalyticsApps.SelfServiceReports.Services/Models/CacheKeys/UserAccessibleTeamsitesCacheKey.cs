﻿
using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class UserAccessibleTeamsitesCacheKey(Guid tenantId, string userId) : ICacheKey<List<Teamsites>>
    {
        public string Key => CacheExtensions.GetUserAccessibleTeamsitesCacheKeyName(tenantId, userId);

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_USER_ACCESSIBLE_TEAMSITES_SECONDS)
        };
    }
}