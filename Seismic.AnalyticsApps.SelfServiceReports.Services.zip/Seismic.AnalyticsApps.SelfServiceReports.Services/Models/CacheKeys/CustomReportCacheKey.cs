﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class CustomReportCacheKey(Guid tenantId, Guid reportId) : ICacheKey<Report>
    {
        public string Key => CacheExtensions.GetTenantCustomReportCacheKeyName(tenantId, "custom-report", reportId);

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_CUSTOM_REPORTS_SECONDS)
        };
    }
}
