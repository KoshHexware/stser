﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys
{
    public class UserAdminAccessCacheKey(string userId, Guid tenantId) : ICacheKey<string>
    {
        public string Key { get; } = CacheExtensions.GetTenantUserCacheKeyName(tenantId, userId, "user-admin-access");

        public DistributedCacheEntryOptions CacheOptions => new()
        {
            AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.SHORT_TIME_CACHE)
        };
    }
}
