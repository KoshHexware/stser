﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;

public class TenantSSRSAccessibleUsersKey(Guid tenantId) : ICacheKey<List<UserInfoModel>>
{
    public string Key { get; } = CacheExtensions.GetTenantCacheKeyName(tenantId, "tenant-ssrs-accessible-users");

    public DistributedCacheEntryOptions CacheOptions => new()
    {
        AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_TENANT_SSRS_ACCESSIBLE_USER)
    };
}
