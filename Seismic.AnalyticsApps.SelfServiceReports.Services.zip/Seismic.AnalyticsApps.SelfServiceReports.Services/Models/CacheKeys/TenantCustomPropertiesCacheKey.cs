﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;

public class TenantCustomPropertiesCacheKey(Guid tenantId) : ICacheKey<List<ContentCustomProperty>>
{
    public string Key { get; } = CacheExtensions.GetTenantCacheKeyName(tenantId, "tenant-custom-properties");

    public DistributedCacheEntryOptions CacheOptions => new()
    {
        AbsoluteExpirationRelativeToNow = new TimeSpan(0, 0, CacheConstants.REFRESH_CACHE_INTERVAL_USER_PROPERTIES_SECONDS)
    };
}
