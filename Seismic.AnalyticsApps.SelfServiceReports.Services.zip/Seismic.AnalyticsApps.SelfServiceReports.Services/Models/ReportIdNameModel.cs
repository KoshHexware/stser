using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;

public class ReportIdNameModel
{
    public Guid ReportId { get; set; }
    
    public string ReportName { get; set; } = string.Empty;

    public ReportType ReportType { get; set; }
}
