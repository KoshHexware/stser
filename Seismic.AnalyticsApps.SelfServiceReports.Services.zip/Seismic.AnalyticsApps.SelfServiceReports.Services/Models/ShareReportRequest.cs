﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ShareReportRequest
    {
        public string[]? NewSharedUserIds { get; set; }

        public string[]? NewSharedGroupIds { get; set; }

        public string[]? RemovedUserIds { get; set; }

        public string[]? RemovedGroupIds { get; set; }
    }
}
