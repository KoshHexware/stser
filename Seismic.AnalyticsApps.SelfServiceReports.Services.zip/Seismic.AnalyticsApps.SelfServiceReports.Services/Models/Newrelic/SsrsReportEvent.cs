﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic
{
    public class SsrsReportEvent
    {
        public Guid TenantId { get;set; }

        public required string UserId { get; set; }

        public Guid ReportId { get; set; }

        public Guid SystemReportId { get; set; }

        public required string ReportName { get; set; }

        public required string SystemReportName { get; set; }

        public bool IsSystemReport { get; set; }

        //execute(same as view), save, save as, delete, export
        public required string Operation { get; set; }

        //comma separated list of filters
        public string? Filters { get; set; }

        public string? FiltersJson { get; set; }

        //comma separated list of fields
        public required string Fields { get; set; }

        public string? SortField { get; set; }

        //asc,desc
        public string? SortOrder { get; set; }

        //helps to track any errors in logs.
        public string? CorrelationId { get; set; }

        //UTC
        public DateTime Occurred { get; set; }

        public string? OwnerId { get; set; }

        public long RequestDuration { get; set; }

        public string? SharedOn { get; set; }

        public bool? IsSavedReport { get; set; } = true;
    }
}
