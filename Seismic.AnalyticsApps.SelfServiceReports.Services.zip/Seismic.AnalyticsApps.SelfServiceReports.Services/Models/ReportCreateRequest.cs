﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using System.ComponentModel.DataAnnotations;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ReportCreateRequest
    {
        [Required]
        public Guid SystemReportId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "Name length can't be more than 100.")]
        public required string ReportName { get; set; }

        [StringLength(350, ErrorMessage = "Description length can't be more than 350.")]
        public required string Description { get; set; }

        [Required]
        public required List<ReportField> Fields { get; set; }

        public List<ReportExecutionFilter>? Filters { get; set; }

        [Required]
        public string? OrderField { get; set; }

        [Required]
        public OrderType? OrderBy { get; set; }

        public string[]? TeamsiteIds { get; set; }
    }
}
