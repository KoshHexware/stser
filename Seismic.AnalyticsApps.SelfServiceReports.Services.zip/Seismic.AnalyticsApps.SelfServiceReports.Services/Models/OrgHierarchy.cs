﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class OrgHierarchy
    {
        /// <summary>
        /// Gets or sets the collection of top-level users in the organizational hierarchy.
        /// These are users who either don't have a parent/manager assigned.
        /// </summary>
        public List<HierarchicalUserInfo> TopManagers { get; set; }

        /// <summary>
        /// Gets or sets the collection of all users in the organizational hierarchy.
        /// keyed by user ID, this includes all users in the hierarchy.
        /// values are HierarchicalUserInfo representing each user.
        /// </summary>
        public Dictionary<string, HierarchicalUserInfo> AllTeamMembers { get; set; }

        /// <summary>
        /// Gets or sets the collection of all level of managers in the organizational hierarchy.
        /// keyed by user ID (manager ID).
        /// values are lists of HierarchicalUserInfo representing to that user (manager).
        /// </summary>
        public Dictionary<string, List<HierarchicalUserInfo>> AllManagersMap { get; set; }
    }
}
