﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class RecentReport
    {
        public Guid Id { get; set; }
        
        public required string UserId { get; set; }

        public required string ReportName { get; set; }

        public required Guid SystemReportId { get; set; }

        public required string SystemReportName { get; set; }
        
        public string? OwnerThumbnailUrl { get; set; }

        public required string Description { get; set; }

        public string? Domain { get; set; }

        public string? OwnerUserName { get; set; }//may be null when user is deleted.

        public string? OwnerUserId { get; set; }//may be null when user is deleted.

        public DateTime? LastViewed { get; set; }

        public DateTime? LastUpdated { get; set; }

        public ReportType ReportType { get; set; }
    }
}
