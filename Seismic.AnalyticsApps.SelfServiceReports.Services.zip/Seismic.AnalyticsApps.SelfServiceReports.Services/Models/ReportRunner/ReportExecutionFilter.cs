﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner
{
    public enum Operation
    {
        Equals,
        NotEquals,
        GreaterThan,
        LessThan,
        GreaterThanOrEqual,
        LessThanOrEqual,
        Contains,
        StartsWith,
        EndsWith,
        Between,
        IsOneOf,
        IsNotOneOf,
        IsNull,
        IsNotNull,
        None,
        TextEquals,
        TextNotEquals,
        InTheLast,
        InTheNext,
        NamedRange,
        DoesNotContain,
        IsAllOf,
        IsCurrentUser,
        IsMyTeam
    }

    /// <summary>
    /// This is used in report execution, not in parsing yaml
    /// </summary>
    public class ReportExecutionFilter
    {
        public required string FilterName { get; set; }

        public Operation Operation { get; set; }

        public string[]? Values { get; set; }

        public bool? IsProperty { get; set; }

        public PropertyType? PropertyType { get; set; }

        /// <summary>
        /// user property or custom property id
        /// </summary>
        public string? PropertyId { get; set; }

        /// <summary>
        /// Teamsite Ids List for the custom property associated with.
        /// </summary>
        public string[]? TeamsiteIds { get; set; }

        public string? EnableRelativeUserFilterField { get; set; }

        public string? DataAreaKey { get; set; }

    }

    public enum PropertyType
    {
        None,
        UserProperty,
        ContentCustomProperty
    }
}
