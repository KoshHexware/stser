﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner
{
    public class Pagination
    {
        public int Skip { get; set; }
        public int Take { get; set; }
        public int TotalRecords { get; set; }
    }
}
