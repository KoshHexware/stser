﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;

public class ReportResult
{
    public required IList<dynamic> Data { get; set; }

    public required Pagination Pagination { get; set; }

    public Report? Report { get; set; }
}

public class ExportResult
{
    public required IList<dynamic> Rows { get; set; }

    public required IList<string> Columns { get; set; }

}