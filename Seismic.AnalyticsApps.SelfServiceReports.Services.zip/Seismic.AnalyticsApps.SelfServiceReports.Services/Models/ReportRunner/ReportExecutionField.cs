﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;

public class ReportExecutionField : IEquatable<ReportExecutionField>
{
    public required string Name { get; set; }

    public bool? IsProperty { get; set; }

    public PropertyType? PropertyType { get; set; }

    /// <summary>
    /// user property or custom property id
    /// </summary>
    public string? PropertyId { get; set; }

    public bool Equals(ReportExecutionField? other)
    {
        if(other is null)
        {
            return false;
        }
        
        if (Object.ReferenceEquals(this, other))
            return true;

        if (this.GetType() != other.GetType())
        {
            return false;
        }

        return ( this.Name == other.Name && this.IsProperty == other.IsProperty &&
            this.PropertyType == other.PropertyType &&
            this.PropertyId == other.PropertyId);

    }

    public override bool Equals(object? obj)
    {
        return Equals(obj as ReportExecutionField);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Name, IsProperty, PropertyType, PropertyId);
    }
}
