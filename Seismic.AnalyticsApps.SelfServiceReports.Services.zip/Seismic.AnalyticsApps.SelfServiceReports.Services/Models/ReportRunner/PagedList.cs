﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner
{
    public class PagedList<T> where T : class
    {
        public required List<T> Data { get; set; }
        public required int Skip { get; set; }
        public required int Take { get; set; }
        public required int TotalRecords { get; set; }
    }
}