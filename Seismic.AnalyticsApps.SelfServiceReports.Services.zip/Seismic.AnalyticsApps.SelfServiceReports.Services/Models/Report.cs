﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class Report
    {
        public Guid Id { get; set; }

        public required string ReportName { get; set; }

        public Guid SystemReportId { get; set; }

        public required string SystemReportName { get; set; }

        public string? Description { get; set; }

        public string? Domain { get; set; }

        public string? OwnerUserName { get; set; }//may be null when user is deleted.

        public string? OwnerThumbnailUrl { get; set; }

        public string? OwnerUserId { get; set; }//may be null when user is deleted.

        public DateTime? LastViewed { get; set; }

        public DateTime? LastUpdated { get; set; }

        public ReportType ReportType { get; set; }

        public string? OrderField { get; set; }

        public OrderType OrderBy { get; set; }

        public required List<ReportField> RequestedFields { get; set; } = [];

        public List<ReportExecutionFilter>? AppliedFilters { get; set; }

        public required ReportDefinitionMetadata StandardReportMetadata { get; set; }

        public List<Teamsites>? Teamsites { get; set; }

        public bool ShowTeamsitePicker { get; set; }
    }
}
