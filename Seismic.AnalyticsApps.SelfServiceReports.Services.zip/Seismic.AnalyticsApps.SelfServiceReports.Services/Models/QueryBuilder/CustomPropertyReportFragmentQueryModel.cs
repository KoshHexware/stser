﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder
{
    [ExcludeFromCodeCoverage]
    public class CustomPropertyReportFragmentQueryModel
    {
        public required string Name { get; set; }

        public required string Id { get; set; }

        public bool IsSelected { get; set; }

        public required string QueryAlias { get; set; }

        public string? FilterName { get; set; }

        public bool IsDate { get; set; }

        public string? FilterOperator { get; set; }

        public string[]? FilterValue { get; set; }

        public bool? AllowMultipleValues { get; set; }

        public bool IsFilterApplied { get; set; }

        public int? FilterValueCount { get; set; }

        public bool IsBoolean { get; set; }
    }
}
