﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder
{
    public class CreateQueryFilterModel
    {
        public required string FilterName { get; set; }

        public required string QueryParam { get; set; }

        public required Operation Operation { get; set; }

        public required DataType DataType { get; set; }

        public string[]? Values { get; set; }

        public bool IsGeneric { get; set; }

        public string? QueryAlias { get; set; }

        public bool IsNullable { get; set; }

        public bool? AllowMultipleValues { get; set; }
    }
}
