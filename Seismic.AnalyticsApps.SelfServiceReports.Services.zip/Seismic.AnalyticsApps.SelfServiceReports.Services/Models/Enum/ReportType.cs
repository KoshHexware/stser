﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    public enum ReportType
    {
        System,
        Custom,
        Draft
    }
}
