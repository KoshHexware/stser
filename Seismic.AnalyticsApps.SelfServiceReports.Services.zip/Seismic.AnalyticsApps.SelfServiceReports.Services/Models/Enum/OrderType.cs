﻿using System.ComponentModel.DataAnnotations;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    public enum OrderType
    {
        [Display(Name = "ASC")]
        ASC,

        [Display(Name = "DESC")]
        DESC,

        [Display(Name = "ASC nulls last")]
        ASC_NULLS_LAST,

        [Display(Name = "ASC nulls first")]
        ASC_NULLS_FIRST,

        [Display(Name = "DESC nulls first")]
        DESC_NULLS_FIRST,

        [Display(Name = "DESC nulls last")]
        DESC_NULLS_LAST

    }
}
