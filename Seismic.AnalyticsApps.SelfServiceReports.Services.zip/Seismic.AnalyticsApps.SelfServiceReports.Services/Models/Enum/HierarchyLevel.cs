﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    /// <summary>
    /// This is not same as access. Why?
    /// Because access is also based on user's groups. 
    /// Even if a user or manager has no access, they can be part of the hierarchy.
    /// If a middle manager is not part of access control groups, they cannot see their team's performance, 
    /// but an enabler can drill into such managers and see their team's performance.
    /// </summary>
    public enum HierarchyLevel
    {
        IC,
        Manager,
        ManagerOfManager,
    }
}
