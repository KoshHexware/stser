namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    public enum HierarchyScopeOptions
    {
        CurrentUser,
        MyDirectTeamIncludingMe,
        MyDirectTeamWithoutMe,
        MyDirectAndIndirectTeamIncludingMe,
        MyDirectAndIndirectTeamWithoutMe
    }

    public static class HierarchyScopeExtensions
    {
        public static string ToDisplayString(this HierarchyScopeOptions option)
        {
            return option switch
            {
                HierarchyScopeOptions.CurrentUser => "Current user (me)",
                HierarchyScopeOptions.MyDirectTeamIncludingMe => "My direct team including me",
                HierarchyScopeOptions.MyDirectTeamWithoutMe => "My direct team without me",
                HierarchyScopeOptions.MyDirectAndIndirectTeamIncludingMe => "My direct and indirect team including me",
                HierarchyScopeOptions.MyDirectAndIndirectTeamWithoutMe => "My direct and indirect team without me",
                _ => option.ToString()
            };
        }
    }

    public enum RelativeMyTeamFilterValues
    {
        IncludeCurrentUser,
        IncludeIndirectReports,
        IncludeDirectReports
    }

    public static class RelativeMyTeamFilterValuesExtensions
    {
        /// <summary>
        /// Converts the RelativeMyTeamFilterValues enum to a user-friendly display string.
        /// </summary>
        /// <param name="value">The RelativeMyTeamFilterValues value to convert.</param>
        /// <returns>A user-friendly display string.</returns>
        /// <exception cref="ArgumentOutOfRangeException">Thrown if the value is not recognized.</exception>
        public static string ToDisplayString(this RelativeMyTeamFilterValues value)
        {
            return value switch
            {
                RelativeMyTeamFilterValues.IncludeCurrentUser => "IncludeCurrentUser",
                RelativeMyTeamFilterValues.IncludeIndirectReports => "IncludeIndirectReports",
                RelativeMyTeamFilterValues.IncludeDirectReports => "IncludeDirectReports",
                _ => value.ToString()
            };
        }
    }
}