﻿using System.ComponentModel.DataAnnotations;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    public enum AccessType
    {
        [Display(Name = "Anyone can Access Any Report")]
        All,

        [Display(Name = "Only Invited People")]
        Included,

        [Display(Name = "Anyone except excluded people for Some reports")]
        Excluded,

        [Display(Name = "No Access")]
        NoAccess,


    }
}
