﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum
{
    public enum ReportsFilterOption
    {
        Shared,
        System,
        Owned,
        All
    }
}
