﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models
{
    public class ArchivedFilters
    {
        public Guid ReportId { get; set; }

        public required string ReportName { get; set; }

        public required List<DeletedItem> DeletedItems { get; set; }
    }

    public class DeletedItem
    {
        public required string FieldName { get; set; }
        public required string SystemFilterName { get; set; }
    }
}
