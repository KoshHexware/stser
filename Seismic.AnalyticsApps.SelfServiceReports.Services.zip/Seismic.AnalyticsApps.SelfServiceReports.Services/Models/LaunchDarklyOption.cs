﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models;

public class LaunchDarklyOption
{
    public required string Key { get; set; }
}
