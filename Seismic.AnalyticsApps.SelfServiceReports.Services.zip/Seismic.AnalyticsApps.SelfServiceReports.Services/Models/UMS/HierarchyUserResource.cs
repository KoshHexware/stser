﻿using Seismic.Foreshock.Resource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS
{
    public class HierarchyUserResource : Resource
    {
        [JsonIgnore]
        public override string Kind => "HierarchyUser";

        public string UserId { get; set; }

        public string ManagerUserId { get; set; }

        public string UserName { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Title { get; set; }

        public string AvatarBlobId { get; set; }

        public int? ReportCount { get; set; }
    }

}
