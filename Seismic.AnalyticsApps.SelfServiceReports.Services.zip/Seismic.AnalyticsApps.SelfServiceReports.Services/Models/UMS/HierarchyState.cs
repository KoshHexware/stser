﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS
{
    public class HierarchyState
    {
        public bool StateIsReady { get; set; }
}
}
