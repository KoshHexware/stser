﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS
{
    public class HierarchicalUser
    {
        public string Email { get; set; }

        public string UserName { get; set; }

        public string UserId { get; set; }

        public string ManagerUserId { get; set; }

        public HierarchyLevel HierarchyLevel { get; set; }


        public static HierarchicalUser FromHierarchicalUserInfo(HierarchicalUserInfo hierarchicalUserInfo)
        {
            return new HierarchicalUser
            {
                Email = hierarchicalUserInfo.Email,
                HierarchyLevel = hierarchicalUserInfo.HierarchyLevel,
                ManagerUserId = hierarchicalUserInfo.ManagerUserId,
                UserId = hierarchicalUserInfo.UserId,
                UserName = hierarchicalUserInfo.UserName,
            };
        }
    }
}
