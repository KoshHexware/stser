﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS
{
    public class UserAndUserGroupInfoModel : UserInfoModel
    {
        public bool IsGroup { get; set; }

        public string UserGroupId { get; set; }

        public string UserGroupName { get; set; }
    }
}
