﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;

public class UserInfoModel
{
    public string? Id { get; set; }
    public string? LegacyId { get; set; }

    public string? Username { get; set; }

    public string? Email { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? FullName { get; set; }

    public string? Title { get; set; }

    public string? Organization { get; set; }

    public ICollection<string> DirectGroupIds { get; set; } = [];
    
    public string? ThumbnailId { get; set; }

    public string? ThumbnailUrl { get; set; }

}
