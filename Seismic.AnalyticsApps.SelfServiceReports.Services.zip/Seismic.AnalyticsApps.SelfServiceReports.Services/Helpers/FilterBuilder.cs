﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using System.Text;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public class FilterBuilder
    {
        public required List<CreateQueryFilterModel> SelectedFilters { get; set; }
        public required Dictionary<string, object> TemplateParams { get; set; }
        public required Dictionary<string, string> StringParams { get; set; }
        public required Dictionary<string, DateTime?> DateParams { get; set; }
        public required Dictionary<string, bool?> BoolParams { get; set; }
        public required Dictionary<string, int?> IntParams { get; set; }
        public required Dictionary<string, decimal?> DecimalParams { get; set; }
        public required Dictionary<string, string[]> MultiStringParams { get; set; }


        private readonly static Dictionary<string, Action<FilterBuilder, CreateQueryFilterModel, Dictionary<string, object>>> AddFilterConditionFuncMap = new()
        {
                { "text" , AddTextFilterCondition },
                { "csv" , AddTextFilterCondition },
                { "integer" , AddIntFilterCondition },
                { "double" , AddDecimalFilterCondition},
                { "decimal" , AddDecimalFilterCondition},
                { "datetime" , AddDateFilterCondition},
                { "boolean" , AddBooleanFilterCondition},
                { "date" , AddDateFilterCondition},
                { "float" , AddDecimalFilterCondition}
        };

        private readonly static Dictionary<string, Action<FilterBuilder, CreateQueryFilterModel, StringBuilder>> BuildGenericFilterConditionsFuncMap = new()
        {
            { "text" , BuildGenericTextFilters },
            { "csv" , BuildGenericCsvFilters },
            { "integer" , BuildGenericIntFilters },
            { "double" , BuildGenericDecimalFilters},
            { "decimal" , BuildGenericDecimalFilters},
            { "datetime" , BuildGenericDateFilters},
            { "boolean" , BuildGenericBooleanFilters},
            { "date" , BuildGenericDateFilters},
            { "float" , BuildGenericDecimalFilters}
        };


        public void AddFilters()
        {
            // Add filter conditions and parameters
            var genericFiltersClause = new StringBuilder();

            foreach (var filter in SelectedFilters)
            {
                if (!filter.IsGeneric)
                {
                    AddFilterCondition(this, filter, TemplateParams);
                }
                else
                {
                    BuildGenericFiltersClause(this, filter, genericFiltersClause);
                }
            }

            TemplateParams.Add("generic_filter_expression", genericFiltersClause.ToString());
        }

        private static void AddFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            var dataType = filter.DataType.ToString()?.ToLower();

            if(string.IsNullOrWhiteSpace(dataType))
                throw new BadRequestException($"Filter data type {filter.DataType} is not supported.");

            if (AddFilterConditionFuncMap.TryGetValue(dataType, out var filterConditionFunc))
            {
                filterConditionFunc(builder, filter, templateParams);
            }
            else
            {
                //TODO: Add support for CSV datatype
                throw new BadRequestException($"Filter data type {filter.DataType} is not supported.");
            }
        }

        private static void AddTextFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            if(filter.Values == null || filter.Values.Length == 0)
                return;

            if (filter.Operation == Operation.IsOneOf || filter.Operation == Operation.IsNotOneOf)
            {
                if (filter.Values.Contains("(Blanks)"))
                {
                    var opearator = filter.Operation == Operation.IsOneOf ? "IS" : "IS NOT";
                    templateParams.Add($"filter_{filter.QueryParam}_has_nulls", true);
                    templateParams.Add($"filter_{filter.QueryParam}_null_operator", opearator);
                }
                builder.MultiStringParams.Add(filter.QueryParam, filter.Values);

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"({{{builder.MultiStringParams.Count - 1}}})");
                return;
            }
            if (filter.Operation == Operation.IsAllOf)
            {
                builder.MultiStringParams.Add(filter.QueryParam, filter.Values);

                builder.IntParams.Add(filter.QueryParam + "_count", filter.Values.Count());

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"({{{builder.MultiStringParams.Count - 1}}})");
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_count", $"@{filter.QueryParam}_count");
                return;
            }
            else if (filter.Operation == Operation.IsNotNull || filter.Operation == Operation.IsNull)
            {
                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                return;
            }

            builder.StringParams.Add(filter.QueryParam, AdjustParamValueForLikeOperation(filter.Operation, filter.Values[0]));

            AdjustTextFilterOperation(filter);

            templateParams.Add($"filter_{filter.QueryParam}", true);
            templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
            templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"@{filter.QueryParam}");
        }

        private static void AddDecimalFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                filter.Values = [.. filter.Values.OrderBy(x => decimal.Parse(x))];
                builder.DecimalParams.Add($"{filter.QueryParam}_start", decimal.Parse(filter.Values[0]));
                builder.DecimalParams.Add($"{filter.QueryParam}_end", decimal.Parse(filter.Values[1]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_start", $"@{filter.QueryParam}_start");
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_end", $"@{filter.QueryParam}_end");
            }
            else if (filter.Operation == Operation.IsNotNull || filter.Operation == Operation.IsNull)
            {
                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
            }
            else
            {
                builder.DecimalParams.Add(filter.QueryParam, decimal.Parse(filter.Values[0]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"@{filter.QueryParam}");
            }
        }

        private static void AddIntFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                filter.Values = [.. filter.Values.OrderBy(x => int.Parse(x))];
                builder.IntParams.Add($"{filter.QueryParam}_start", int.Parse(filter.Values[0]));
                builder.IntParams.Add($"{filter.QueryParam}_end", int.Parse(filter.Values[1]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_start", $"@{filter.QueryParam}_start");
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_end", $"@{filter.QueryParam}_end");
            }
            else if (filter.Operation == Operation.IsNotNull || filter.Operation == Operation.IsNull)
            {
                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
            }
            else
            {
                builder.IntParams.Add(filter.QueryParam, int.Parse(filter.Values[0]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"@{filter.QueryParam}");
            }
        }

        private static void AddDateFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                filter.Values = [.. filter.Values.OrderBy(x => DateTime.Parse(x))];
                builder.DateParams.Add($"{filter.QueryParam}_start", DateTime.Parse(filter.Values[0]));
                builder.DateParams.Add($"{filter.QueryParam}_end", DateTime.Parse(filter.Values[1]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_start", $"@{filter.QueryParam}_start");
                templateParams.Add($"filter_{filter.QueryParam}_filterValue_end", $"@{filter.QueryParam}_end");
            }
            else if (filter.Operation == Operation.IsNotNull || filter.Operation == Operation.IsNull)
            {
                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
            }
            else
            {
                builder.DateParams.Add(filter.QueryParam, DateTime.Parse(filter.Values[0]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"@{filter.QueryParam}");
            }
        }

        private static void AddBooleanFilterCondition(FilterBuilder builder, CreateQueryFilterModel filter, Dictionary<string, object> templateParams)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            if (filter.Operation == Operation.IsNotNull || filter.Operation == Operation.IsNull)
            {
                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
            }
            else
            {
                builder.BoolParams.Add(filter.QueryParam, bool.Parse(filter.Values[0]));

                templateParams.Add($"filter_{filter.QueryParam}", true);
                templateParams.Add($"filter_{filter.QueryParam}_operator", OperatorHelper.GetSqlOperator(filter.Operation));
                templateParams.Add($"filter_{filter.QueryParam}_filterValue", $"@{filter.QueryParam}");
            }
        }

        private static void BuildGenericFiltersClause(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (string.IsNullOrWhiteSpace(filter?.DataType.ToString()))
            {
                throw new BadRequestException($"Filter data type {filter?.DataType} is not supported.");
            }

            var dataType = filter.DataType.ToString().ToLower();

            if (BuildGenericFilterConditionsFuncMap.TryGetValue(dataType, out var buildGenericFilterConditionsFunc))
            {
                buildGenericFilterConditionsFunc(builder, filter, genericFiltersClause);
            }
            else
            {
                //TODO: Add support for CSV datatype
                throw new BadRequestException($"Filter data type {filter.DataType} is not supported.");
            }
        }

        private static void BuildGenericBooleanFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.IsNull || filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)}");
            }
            else
            {
                builder.BoolParams.Add(filter.QueryParam, bool.Parse(filter.Values[0]));
                genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}");
            }
        }

        private static void BuildGenericTextFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.IsOneOf || filter.Operation == Operation.IsNotOneOf)
            {
                builder.MultiStringParams.Add(filter.FilterName, filter.Values);
                genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} ({{{builder.MultiStringParams.Count - 1}}})");
                return;
            }
            else if (filter.Operation == Operation.IsNull)
            {
                genericFiltersClause.Append($" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} OR {fieldName} = '')");
                return;
            }
            else if (filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} AND {fieldName} != '')");
                return;
            }

            builder.StringParams.Add(filter.FilterName, AdjustParamValueForLikeOperation(filter.Operation, filter.Values[0]));

            AdjustTextFilterOperation(filter);

            genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}");
        }

        private static void BuildGenericCsvFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.IsOneOf )
            {
                builder.MultiStringParams.Add(filter.FilterName, filter.Values);
                genericFiltersClause.Append($" AND ARRAY_SIZE(ARRAY_INTERSECTION(SPLIT({fieldName}, '\x1F'),ARRAY_CONSTRUCT({{{builder.MultiStringParams.Count - 1}}}))) > 0");
                return;
            }
            else if (filter.Operation == Operation.IsNotOneOf)
            {
                builder.MultiStringParams.Add(filter.FilterName, filter.Values);
                genericFiltersClause.Append($" AND ARRAY_SIZE(ARRAY_INTERSECTION(SPLIT({fieldName}, '\x1F'),ARRAY_CONSTRUCT({{{builder.MultiStringParams.Count - 1}}}))) = 0");
                return;
            }
            else if (filter.Operation == Operation.IsAllOf)
            {
                builder.MultiStringParams.Add(filter.FilterName, filter.Values);
                genericFiltersClause.Append($" AND ARRAY_SIZE(ARRAY_INTERSECTION(SPLIT({fieldName}, '\x1F'),ARRAY_CONSTRUCT({{{builder.MultiStringParams.Count - 1}}}))) = {filter.Values.Length}");
                return;
            }
            else if (filter.Operation == Operation.IsNull)
            {
                genericFiltersClause.Append($" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} OR {fieldName} = '')");
                return;
            }
            else if (filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} AND {fieldName} != '')");
                return;
            }

            builder.StringParams.Add(filter.FilterName, AdjustParamValueForLikeOperation(filter.Operation, filter.Values[0]));

            AdjustTextFilterOperation(filter);

            genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}");
        }

        private static void AdjustTextFilterOperation(CreateQueryFilterModel filter)
        {
            filter.Operation = filter.Operation switch
            {
                Operation.Equals => Operation.TextEquals,
                Operation.NotEquals => Operation.TextNotEquals,
                _ => filter.Operation
            };
        }

        private static void BuildGenericDecimalFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                filter.Values = [.. filter.Values.OrderBy(x => decimal.Parse(x))];
                decimal value1 = decimal.Parse(filter.Values[0]);
                decimal value2 = decimal.Parse(filter.Values[1]);
                builder.DecimalParams.Add($"{filter.FilterName}_start", value1);
                builder.DecimalParams.Add($"{filter.FilterName}_end", value2);
                var filterClause = $" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}_start AND @{filter.FilterName}_end";
                if ((!filter.IsNullable) && (value1 == 0 || value2 == 0))
                {
                    filterClause = $" AND (({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}_start AND @{filter.FilterName}_end) OR {filter.QueryParam} is null)";
                }
                genericFiltersClause.Append(filterClause);
            }
            else if (filter.Operation == Operation.IsNull || filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)}");
                return;
            }
            else
            {
                decimal value = decimal.Parse(filter.Values[0]);
                decimal zeroValue = 0;
                builder.DecimalParams.Add(filter.FilterName, value);
                var filterClause = $" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}";
                // If the filter is not nullable and in the query there is use of coalesce then we need to add null check as well
                // ref - https://seismic-software.slack.com/archives/C06DB4B8VNC/p1733521449751689
                if (!filter.IsNullable && ((value == zeroValue && (filter.Operation == Operation.Equals || filter.Operation == Operation.GreaterThanOrEqual)) ||
                    (value >= zeroValue && filter.Operation == Operation.LessThanOrEqual) || (value > zeroValue && filter.Operation == Operation.LessThan)
                    || (value < zeroValue && (filter.Operation == Operation.GreaterThan || filter.Operation == Operation.GreaterThanOrEqual))))
                {
                    filterClause = $" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName} OR {fieldName} is null)";
                }
                genericFiltersClause.Append(filterClause);
            }
        }

        private static void BuildGenericIntFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                BuildGenericFilterForBetweenOperator(builder, filter, genericFiltersClause);
            }
            else if (filter.Operation == Operation.IsNull || filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)}");
                return;
            }
            else
            {
                int value = int.Parse(filter.Values[0]);
                builder.IntParams.Add(filter.FilterName, value);
                var filterClause = $" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}";
                // If the filter is not nullable and in the query there is use of coalesce then we need to add null check as well
                // ref - https://seismic-software.slack.com/archives/C06DB4B8VNC/p1733521449751689
                if (!filter.IsNullable && ((value == 0 && (filter.Operation == Operation.Equals || filter.Operation == Operation.GreaterThanOrEqual)) ||
                    (value >= 0 && filter.Operation == Operation.LessThanOrEqual) || (value > 0 && filter.Operation == Operation.LessThan)
                    || (value < 0 && (filter.Operation == Operation.GreaterThan || filter.Operation == Operation.GreaterThanOrEqual))))
                {
                    filterClause = $" AND ({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName} OR {fieldName} is null)";
                }
                genericFiltersClause.Append(filterClause);
            }
        }

        private static void BuildGenericFilterForBetweenOperator(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length != 2)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            filter.Values = [.. filter.Values.OrderBy(x => int.Parse(x))];
            int value1 = int.Parse(filter.Values[0]);
            int value2 = int.Parse(filter.Values[1]);
            builder.IntParams.Add($"{filter.FilterName}_start", value1);
            builder.IntParams.Add($"{filter.FilterName}_end", value2);
            var filterClause = $" AND {fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}_start AND @{filter.FilterName}_end";
            if (!filter.IsNullable && (value1 == 0 || value2 == 0))
            {
                filterClause = $" AND (({fieldName} {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}_start AND @{filter.FilterName}_end) OR {fieldName} is null)";
            }
            genericFiltersClause.Append(filterClause);
        }

        private static void BuildGenericDateFilters(FilterBuilder builder, CreateQueryFilterModel filter, StringBuilder genericFiltersClause)
        {
            if (filter.Values == null || filter.Values.Length == 0)
                return;

            var fieldName = filter.QueryAlias != null ? $"{filter.QueryAlias}.{filter.QueryParam}" : filter.QueryParam;

            if (filter.Operation == Operation.Between && filter.Values.Length == 2)
            {
                filter.Values = [.. filter.Values.OrderBy(DateTime.Parse)];
                builder.DateParams.Add($"{filter.FilterName}_start", DateTime.Parse(filter.Values[0]));
                builder.DateParams.Add($"{filter.FilterName}_end", DateTime.Parse(filter.Values[1]));
                genericFiltersClause.Append($" AND date({fieldName}) {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}_start AND @{filter.FilterName}_end");
            }
            else if (filter.Operation == Operation.IsNull || filter.Operation == Operation.IsNotNull)
            {
                genericFiltersClause.Append($" AND date({fieldName}) {OperatorHelper.GetSqlOperator(filter.Operation)}");
                return;
            }
            else
            {
                builder.DateParams.Add(filter.FilterName, DateTime.Parse(filter.Values[0]));
                genericFiltersClause.Append($" AND date({fieldName}) {OperatorHelper.GetSqlOperator(filter.Operation)} @{filter.FilterName}");
            }
        }

        public static string AdjustParamValueForLikeOperation(Operation operation, string paramValue)
        {
            return operation switch
            {
                Operation.Contains => $"%{paramValue}%",
                Operation.DoesNotContain => $"%{paramValue}%",
                Operation.StartsWith => $"{paramValue}%",
                Operation.EndsWith => $"%{paramValue}",
                _ => paramValue
            };
        }

    }
}
