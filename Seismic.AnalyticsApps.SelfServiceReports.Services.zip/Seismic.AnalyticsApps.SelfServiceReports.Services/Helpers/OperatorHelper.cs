﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class OperatorHelper
    {
        public static string GetSqlOperator(Models.ReportRunner.Operation operation)
        {
            return operation switch
            {
                Models.ReportRunner.Operation.Equals => "=",
                Models.ReportRunner.Operation.TextEquals => "ILIKE",
                Models.ReportRunner.Operation.TextNotEquals => "NOT ILIKE",
                Models.ReportRunner.Operation.NotEquals => "!=",
                Models.ReportRunner.Operation.GreaterThan => ">",
                Models.ReportRunner.Operation.LessThan => "<",
                Models.ReportRunner.Operation.GreaterThanOrEqual => ">=",
                Models.ReportRunner.Operation.LessThanOrEqual => "<=",
                Models.ReportRunner.Operation.Contains => "ILIKE",
                Models.ReportRunner.Operation.DoesNotContain => "NOT ILIKE",
                Models.ReportRunner.Operation.StartsWith => "ILIKE",
                Models.ReportRunner.Operation.EndsWith => "ILIKE",
                Models.ReportRunner.Operation.Between => "BETWEEN",
                Models.ReportRunner.Operation.IsOneOf => "IN",
                Models.ReportRunner.Operation.IsNotOneOf => "NOT IN",
                Models.ReportRunner.Operation.IsNull => "IS NULL",
                Models.ReportRunner.Operation.IsNotNull => "IS NOT NULL",
                Models.ReportRunner.Operation.IsAllOf => "IS ALL OF",
                _ => throw new BadRequestException($"Operator {operation} is not supported.")
            };
        }

        public static List<FilterOperation> GetAllowedOperatorsByDataType(Models.Template.DataType dataType, bool hasDomainValues, bool isNullable, bool allowMultipleValues, bool includeRelativeHierarchyFilters)
        {
            List<FilterOperation> operators = dataType switch
            {
                Models.Template.DataType.Text or Models.Template.DataType.Csv =>
                hasDomainValues ?
                    allowMultipleValues || Models.Template.DataType.Csv == dataType ?
                        [
                        new FilterOperation { Name = OperatorConstants.IS_ONE_OF, UxLabel = OperatorConstants.IS_ONE_OF_LABEL},
                        new FilterOperation { Name = OperatorConstants.IS_NOT_ONE_OF, UxLabel = OperatorConstants.IS_NOT_ONE_OF_LABEL},
                        new FilterOperation { Name = OperatorConstants.IS_ALL_OF, UxLabel = OperatorConstants.IS_ALL_OF_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.CONTAINS, UxLabel = OperatorConstants.CONTAINS_LABEL},
                        new FilterOperation { Name = OperatorConstants.DOES_NOT_CONTAIN, UxLabel = OperatorConstants.DOES_NOT_CONTAIN_LABEL }
                        ] :
                        [
                        new FilterOperation { Name = OperatorConstants.IS_ONE_OF, UxLabel = OperatorConstants.IS_ONE_OF_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_ONE_OF, UxLabel = OperatorConstants.IS_NOT_ONE_OF_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.CONTAINS, UxLabel = OperatorConstants.CONTAINS_LABEL},
                        new FilterOperation { Name = OperatorConstants.DOES_NOT_CONTAIN, UxLabel = OperatorConstants.DOES_NOT_CONTAIN_LABEL }
                            ] :
                        [
                        new FilterOperation { Name = OperatorConstants.EQUALS, UxLabel = OperatorConstants.EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.NOT_EQUALS, UxLabel = OperatorConstants.NOT_EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.CONTAINS, UxLabel = OperatorConstants.CONTAINS_LABEL},
                        new FilterOperation { Name = OperatorConstants.DOES_NOT_CONTAIN, UxLabel = OperatorConstants.DOES_NOT_CONTAIN_LABEL },
                        new FilterOperation { Name = OperatorConstants.STARTS_WITH, UxLabel = OperatorConstants.STARTS_WITH_LABEL},
                        new FilterOperation { Name = OperatorConstants.ENDS_WITH, UxLabel = OperatorConstants.ENDS_WITH_LABEL},
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL }
                        ],
                Models.Template.DataType.Integer or Models.Template.DataType.Decimal =>
                    isNullable ?
                    [
                        new FilterOperation { Name = OperatorConstants.EQUALS, UxLabel = OperatorConstants.EQUALS_LABEL },
                        new FilterOperation { Name = OperatorConstants.NOT_EQUALS, UxLabel = OperatorConstants.NOT_EQUALS_LABEL },
                        new FilterOperation { Name = OperatorConstants.GREATER_THAN, UxLabel = OperatorConstants.GREATER_THAN_LABEL },
                        new FilterOperation { Name = OperatorConstants.LESS_THAN, UxLabel = OperatorConstants.LESS_THAN_LABEL },
                        new FilterOperation { Name = OperatorConstants.GREATER_THAN_OR_EQUAL, UxLabel = OperatorConstants.GREATER_THAN_OR_EQUAL_LABEL },
                        new FilterOperation { Name = OperatorConstants.LESS_THAN_OR_EQUAL, UxLabel = OperatorConstants.LESS_THAN_OR_EQUAL_LABEL },
                        new FilterOperation { Name = OperatorConstants.BETWEEN, UxLabel = OperatorConstants.BETWEEN_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL }
                    ] :
                    [
                        new FilterOperation { Name = OperatorConstants.EQUALS, UxLabel = OperatorConstants.EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.NOT_EQUALS, UxLabel = OperatorConstants.NOT_EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.GREATER_THAN, UxLabel = OperatorConstants.GREATER_THAN_LABEL},
                        new FilterOperation { Name = OperatorConstants.LESS_THAN, UxLabel = OperatorConstants.LESS_THAN_LABEL},
                        new FilterOperation { Name = OperatorConstants.GREATER_THAN_OR_EQUAL, UxLabel = OperatorConstants.GREATER_THAN_OR_EQUAL_LABEL},
                        new FilterOperation { Name = OperatorConstants.LESS_THAN_OR_EQUAL, UxLabel = OperatorConstants.LESS_THAN_OR_EQUAL_LABEL},
                        new FilterOperation { Name = OperatorConstants.BETWEEN, UxLabel = OperatorConstants.BETWEEN_LABEL},
                    ],
                Models.Template.DataType.DateTime or Models.Template.DataType.Date => [
                        new FilterOperation { Name = OperatorConstants.BETWEEN, UxLabel = OperatorConstants.BETWEEN_LABEL},
                        new FilterOperation { Name = OperatorConstants.LESS_THAN, UxLabel = OperatorConstants.LESS_THAN_LABEL},
                        new FilterOperation { Name = OperatorConstants.GREATER_THAN, UxLabel = OperatorConstants.GREATER_THAN_LABEL},
                        new FilterOperation { Name = OperatorConstants.EQUALS, UxLabel = OperatorConstants.EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.NOT_EQUALS, UxLabel = OperatorConstants.NOT_EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.IN_THE_LAST, UxLabel = OperatorConstants.IN_THE_LAST_LABEL},
                        new FilterOperation { Name = OperatorConstants.IN_THE_NEXT, UxLabel = OperatorConstants.IN_THE_NEXT_LABEL},
                        new FilterOperation { Name = OperatorConstants.NAMED_RANGE, UxLabel = OperatorConstants.NAMED_RANGE_LABEL},
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL }
                        ],
                Models.Template.DataType.Boolean => [
                        new FilterOperation { Name = OperatorConstants.EQUALS, UxLabel = OperatorConstants.EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.NOT_EQUALS, UxLabel = OperatorConstants.NOT_EQUALS_LABEL},
                        new FilterOperation { Name = OperatorConstants.IS_NULL, UxLabel = OperatorConstants.IS_NULL_LABEL },
                        new FilterOperation { Name = OperatorConstants.IS_NOT_NULL, UxLabel = OperatorConstants.IS_NOT_NULL_LABEL },
                        ],
                _ => [],
            };

            if (includeRelativeHierarchyFilters)
            {
                if (operators.Count >= 2)
                {
                    // Insert the IS_CURRENT_USER at the 3rd position (index 2)
                    operators.Insert(2, new FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                    // Insert the IS_MY_TEAM at the 4th position (index 3)
                    operators.Insert(3, new FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
                }
                else
                {
                    // If there are less than 2 items, just add them to the end
                    operators.Add(new FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                    operators.Add(new FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
                }
            }

            return operators;
        }
    }
}
