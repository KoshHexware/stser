﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using static Seismic.AnalyticsApps.SelfServiceReports.Services.Models.TextReportTool.ReportTool;
//using static Seismic.AnalyticsApps.SelfServiceReports.Services.Models.TextReportTool.ReportFieldsFiltersRecommendation;
namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    /// <summary>
    /// ssrs+parseutil
    /// </summary>
    public enum FieldDetailLevel
    {
        None = 0,

        NamesOnly = 1,
        NamesAndDescriptions = 2,
        KeyNamesOnly = 3,
        KeyNamesAndDescriptions = 4,
        NamesAndDescriptionsAndFilters = 5
    }

    public enum MetricDetailLevel
    {
        None = 0,
        NamesOnly = 1,
        NamesAndDescriptions = 2
    }

    public enum FilterDetailLevel
    {
        None = 0,
        NamesOnly = 1,
        NamesAndDescriptions = 2,
        NamesDescriptionsAndOperations = 3
    }


    public static class ReportMetadataHelper
    {
        public const int MaxFilterValues = 50;

        private static Dictionary<string, object> ToDict(object? obj) =>
            obj as Dictionary<string, object> ??
            (obj as IDictionary<string, object>)?.ToDictionary(k => k.Key, v => v.Value)
            ?? new Dictionary<string, object>();

        private static bool ToBool(object? v)
        {
            if (v is bool b) return b;
            if (v is string s && bool.TryParse(s, out var parsed)) return parsed;
            return false;
        }

        // _get_regular_fields
        public static List<Dictionary<string, object>> GetRegularFields(IDictionary<string, object> report)
        {
            var srm = report.TryGetValue("standardReportMetadata", out var srmObj)
                ? srmObj as IDictionary<string, object>
                : null;

            var fieldGroups = srm?.TryGetValue("fieldGroups", out var fgObj) == true
                ? (fgObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                : Enumerable.Empty<object>();

            var result = new List<Dictionary<string, object>>();
            foreach (var fg in fieldGroups.Select(ToDict))
            {
                var fields = fg.TryGetValue("fields", out var fieldsObj)
                    ? (fieldsObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                    : Enumerable.Empty<object>();

                foreach (var f in fields.Select(ToDict))
                {
                    if (!ToBool(f.TryGetValue("isProperty", out var isProp) ? isProp : null))
                        result.Add(f);
                }
            }
            return result;
        }

        // _get_metrics
        public static List<Dictionary<string, object>> GetMetrics(IDictionary<string, object> report)
        {
            var srm = report.TryGetValue("standardReportMetadata", out var srmObj)
                ? srmObj as IDictionary<string, object>
                : null;

            var fieldGroups = srm?.TryGetValue("fieldGroups", out var fgObj) == true
                ? (fgObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                : Enumerable.Empty<object>();

            foreach (var group in fieldGroups.Select(ToDict))
            {
                var uxLabel = group.TryGetValue("uxLabel", out var lbl) ? lbl?.ToString() : null;
                if (string.Equals(uxLabel, "KPI and metrics", StringComparison.Ordinal))
                {
                    var fields = group.TryGetValue("fields", out var fieldsObj)
                        ? (fieldsObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                        : Enumerable.Empty<object>();
                    return fields.Select(ToDict).ToList();
                }
            }
            return new List<Dictionary<string, object>>();
        }

        // _get_filter_groups
        public static List<Dictionary<string, object>> GetFilterGroups(IDictionary<string, object> report)
        {
            var srm = report.TryGetValue("standardReportMetadata", out var srmObj)
                ? srmObj as IDictionary<string, object>
                : null;

            var groups = srm?.TryGetValue("filterGroup", out var gObj) == true
                ? (gObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                : Enumerable.Empty<object>();

            return groups.Select(ToDict).ToList();
        }

        // _get_all_metadata_fields
        public static List<Dictionary<string, object>> GetAllMetadataFields(IDictionary<string, object> reportMetadata)
        {
            var srm = reportMetadata.TryGetValue("standardReportMetadata", out var srmObj)
                ? srmObj as IDictionary<string, object>
                : null;

            var fieldGroups = srm?.TryGetValue("fieldGroups", out var fgObj) == true
                ? (fgObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                : Enumerable.Empty<object>();

            var result = new List<Dictionary<string, object>>();
            foreach (var fg in fieldGroups.Select(ToDict))
            {
                var fields = fg.TryGetValue("fields", out var fieldsObj)
                    ? (fieldsObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                    : Enumerable.Empty<object>();

                foreach (var f in fields.Select(ToDict))
                {
                    if (!ToBool(f.TryGetValue("isProperty", out var isProp) ? isProp : null))
                        result.Add(f);
                }
            }
            return result;
        }

        // filters_that_are_not_fields
        public static List<(string Label, string? Description, string DataType, List<string> AllowedOps)>
            FiltersThatAreNotFields(IDictionary<string, object> report)
        {
            var regularFields = GetRegularFields(report);
            var filterGroups = GetFilterGroups(report);

            var notFieldFilters = new List<(string, string?, string, List<string>)>();

            foreach (var g in filterGroups)
            {
                var filters = g.TryGetValue("filters", out var filtersObj)
                    ? (filtersObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                    : Enumerable.Empty<object>();

                foreach (var f in filters.Select(ToDict))
                {
                    if (ToBool(f.TryGetValue("isProperty", out var isProp) ? isProp : null))
                        continue;

                    var fLabel = f.TryGetValue("uxLabel", out var lblObj) ? lblObj?.ToString() ?? "" : "";
                    var maybeFields = regularFields.Where(field =>
                        string.Equals(field.TryGetValue("uxLabel", out var fl) ? fl?.ToString() ?? "?" : "?", fLabel, StringComparison.Ordinal));

                    if (!maybeFields.Any())
                    {
                        var description = f.TryGetValue("uxDescription", out var descObj) ? descObj?.ToString() : null;
                        var dataType = f.TryGetValue("dataType", out var dtObj) ? dtObj?.ToString() ?? "Unknown" : "Unknown";
                        var ops = f.TryGetValue("allowedOperators", out var opsObj)
                            ? (opsObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                            : Enumerable.Empty<object>();

                        var opNames = ops.Select(o => (o as IDictionary<string, object>)?.TryGetValue("name", out var nObj) == true ? nObj?.ToString() : null)
                                         .Where(s => !string.IsNullOrEmpty(s))
                                         .ToList()!;
                        notFieldFilters.Add((fLabel, description, dataType, opNames));
                    }
                }
            }

            return notFieldFilters;
        }

        // field_descriptions
        public static string FieldDescriptions(IDictionary<string, object> report, FieldDetailLevel detailLevel)
        {
            if (detailLevel == FieldDetailLevel.None)
                return string.Empty;

            var regularFields = GetRegularFields(report);
            var metrics = GetMetrics(report);
            var metricsSet = new HashSet<string>(metrics.Select(m => m.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "" : ""));

            var keyFields = regularFields
                .Where(field => ToBool(field.TryGetValue("isDefault", out var d) ? d : null) &&
                                !metricsSet.Contains(field.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "" : ""))
                .ToList();

            if (detailLevel == FieldDetailLevel.KeyNamesOnly)
            {
                var names = string.Join(", ", keyFields.Select(field => field.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "" : ""));
                return $"\nKey Fields: {names}";
            }

            if (detailLevel == FieldDetailLevel.KeyNamesAndDescriptions)
            {
                var summary = "\nKey Fields:";
                foreach (var field in keyFields)
                {
                    var name = field.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Field" : "Unknown Field";
                    var desc = field.TryGetValue("uxDescription", out var d) ? d?.ToString() ?? "No description available." : "No description available.";
                    summary += $"\n  {name}: {desc}";
                }
                return summary;
            }

            if (detailLevel == FieldDetailLevel.NamesAndDescriptions)
            {
                var summary = "\nReport Fields:";
                foreach (var rf in regularFields)
                {
                    var fieldLabel = rf.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Field" : "Unknown Field";
                    var fieldDesc = rf.TryGetValue("uxDescription", out var d) ? d?.ToString() ?? "No description available." : "No description available.";
                    summary += $"\n  {fieldLabel}: {fieldDesc}";
                }
                return summary;
            }

            if (detailLevel == FieldDetailLevel.NamesAndDescriptionsAndFilters)
            {
                var summary = "\nReport Fields:";
                foreach (var rf in regularFields)
                {
                    var fieldLabel = rf.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Field" : "Unknown Field";
                    var fieldDesc = rf.TryGetValue("uxDescription", out var d) ? d?.ToString() ?? "No description available." : "No description available.";
                    var fieldDataType = rf.TryGetValue("dataType", out var dt) ? dt?.ToString() ?? "Unknown" : "Unknown";
                    var hasGenericFilters = rf.TryGetValue("hasGenericFilters", out var hgf) ? ToBool(hgf) : true;
                    summary += $"\n  {fieldLabel} [{fieldDataType}]: {fieldDesc}";
                    if (!hasGenericFilters) summary += " (No generic filters available)";
                }
                return summary;
            }

            var allNames = string.Join(", ", regularFields.Select(field => field.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Field" : "Unknown Field"));
            return $"\nFields: {allNames}";
        }

        // metric_descriptions
        public static string MetricDescriptions(IDictionary<string, object> report, MetricDetailLevel detailLevel)
        {
            if (detailLevel == MetricDetailLevel.None)
                return string.Empty;

            var metrics = GetMetrics(report);

            if (detailLevel == MetricDetailLevel.NamesOnly)
            {
                var names = string.Join(", ", metrics.Select(m => m.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Metric" : "Unknown Metric"));
                return "\nMetrics: " + names;
            }

            if (detailLevel == MetricDetailLevel.NamesAndDescriptions)
            {
                var summary = "\nMetrics:";
                foreach (var metric in metrics)
                {
                    var name = metric.TryGetValue("uxLabel", out var l) ? l?.ToString() ?? "Unknown Metric" : "Unknown Metric";
                    var desc = metric.TryGetValue("uxDescription", out var d) ? d?.ToString() ?? "No description available." : "No description available.";
                    summary += $"\n  {name}: {desc}";
                }
                return summary;
            }

            return string.Empty;
        }

        // filter_descriptions
        public static string FilterDescriptions(IDictionary<string, object> report, FilterDetailLevel detailLevel)
        {
            if (detailLevel == FilterDetailLevel.None)
                return string.Empty;

            var filters = FiltersThatAreNotFields(report);

            if (detailLevel == FilterDetailLevel.NamesOnly)
            {
                var names = string.Join(", ", filters.Select(f => f.Label));
                return $"\nAdditional Filters: {names}";
            }

            if (detailLevel == FilterDetailLevel.NamesAndDescriptions)
            {
                var summary = "\nAdditional Filters:";
                foreach (var f in filters) summary += $"\n  {f.Label}: {f.Description}";
                return summary;
            }

            if (detailLevel == FilterDetailLevel.NamesDescriptionsAndOperations)
            {
                var summary = "\nAdditional Filters:";
                foreach (var f in filters)
                {
                    var ops = string.Join(", ", f.AllowedOps);
                    summary += $"\n  {f.Label} [{f.DataType}]: {f.Description} (Allowed operations: {ops})";
                }
                return summary;
            }

            return string.Empty;
        }

        // report_summary
        public static string ReportSummary(
            IDictionary<string, object> report,
            FieldDetailLevel fieldDetails = FieldDetailLevel.NamesAndDescriptions,
            MetricDetailLevel metricDetails = MetricDetailLevel.NamesAndDescriptions,
            FilterDetailLevel filterDetails = FilterDetailLevel.NamesAndDescriptions)
        {
            var reportName = report.TryGetValue("ReportName", out var rn) ? rn?.ToString() : null;
            var reportId = report.TryGetValue("id", out var id) ? id?.ToString() : null;
            var descriptionRaw = report.TryGetValue("Description", out var desc) ? desc?.ToString() : null;
            var reportDescription = string.IsNullOrWhiteSpace(descriptionRaw) ? "No description available." : descriptionRaw!.Trim();

            var summary = $"Report Name: {reportName}\nReport Id: {reportId}\nReport Description: {reportDescription}";
            summary += FieldDescriptions(report, fieldDetails);
            summary += MetricDescriptions(report, metricDetails);
            summary += FilterDescriptions(report, filterDetails);
            summary += "\n";

            return summary;
        }

        // fix_fields_for_execute
        public static List<string> FixFieldsForExecute(IDictionary<string, object> reportMetadata, IEnumerable<string> fields)
        {
            var fieldNames = new List<string>();
            var metaFields = GetAllMetadataFields(reportMetadata);

            foreach (var givenField in fields)
            {
                foreach (var metaField in metaFields)
                {
                    var uxLabel = metaField.TryGetValue("UxLabel", out var l) ? l?.ToString() : null;
                    if (string.Equals(givenField, uxLabel, StringComparison.Ordinal))
                    {
                        var internalName = metaField.TryGetValue("Name", out var n) ? n?.ToString() : null;
                        if (!string.IsNullOrEmpty(internalName))
                        {
                            fieldNames.Add(internalName!);
                        }
                        break;
                    }
                }
            }
            return fieldNames;
        }

        // Support interface for filters (matches python expectation)
        public interface IFilterInput
        {
            string FilterName { get; }              // UX label
            IReadOnlyList<string> FilterValues { get; }
            string GetOperation();
        }

        // fix_filters_for_execute
        public static List<Dictionary<string, object>> FixFiltersForExecute(IDictionary<string, object> reportMetadata, IEnumerable<IFilterInput> filters)
        {
            try
            {
                var correctedFilters = new List<Dictionary<string, object>>();
                var filterGroups = GetFilterGroups(reportMetadata);

                foreach (var givenFilter in filters)
                {
                    foreach (var metaFilterGroup in filterGroups)
                    {
                        var metaFilters = metaFilterGroup.TryGetValue("Filters", out var mfObj)
                            ? (mfObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                            : Enumerable.Empty<object>();

                        foreach (var metaFilter in metaFilters.Select(ToDict))
                        {
                            var uxLabel = metaFilter.TryGetValue("UxLabel", out var l) ? l?.ToString() : null;
                            if (!string.Equals(givenFilter.FilterName, uxLabel, StringComparison.Ordinal)) continue;

                            var operation = givenFilter.GetOperation();

                            var values = new List<string>();
                            foreach (var v in givenFilter.FilterValues)
                            {
                                if (string.Equals(v, "true", StringComparison.OrdinalIgnoreCase) ||
                                    string.Equals(v, "false", StringComparison.OrdinalIgnoreCase))
                                {
                                    values.Add(char.ToUpperInvariant(v[0]) + v.Substring(1).ToLowerInvariant());
                                }
                                else
                                {
                                    values.Add(v);
                                }
                            }

                            var newFilter = new Dictionary<string, object>
                            {
                                { "filterName", metaFilter.TryGetValue("FilterName", out var fname) ? fname?.ToString() ?? givenFilter.FilterName : givenFilter.FilterName },
                                { "operation", operation },
                                { "values", values }
                            };
                            correctedFilters.Add(newFilter);
                            break;
                        }
                    }
                }

                if (correctedFilters.Count != filters.Count())
                {
                    throw new ArgumentException($"Expected {filters.Count()} filters, but got {correctedFilters.Count}");
                }

                return correctedFilters;
            }
            catch (Exception)
            {
                // Mimic python behavior: log and return empty; here we return empty to avoid logging dependency.
                return new List<Dictionary<string, object>>();
            }
        }

        // extract_ssrs_filter_values
        public static async Task<(bool Success, object ValuesOrMessage)> ExtractSsrsFilterValuesAsync(
            IDictionary<string, object> report,
            string filterUxName,
            Func<string, Task<IReadOnlyList<object>>> getValuesCallback)
        {
            var reportId = report.TryGetValue("id", out var idObj) ? idObj?.ToString() : null;
            var filterGroups = GetFilterGroups(report);

            foreach (var group in filterGroups)
            {
                var filters = group.TryGetValue("filters", out var filtersObj)
                    ? (filtersObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                    : Enumerable.Empty<object>();

                foreach (var filter in filters.Select(ToDict))
                {
                    var uxLabel = filter.TryGetValue("uxLabel", out var l) ? l?.ToString() : null;
                    if (!string.Equals(uxLabel, filterUxName, StringComparison.Ordinal)) continue;

                    var filterName = filter.TryGetValue("filterName", out var fn) ? fn?.ToString() ?? string.Empty : string.Empty;
                    var filterType = filter.TryGetValue("filterType", out var ft) ? ft?.ToString() : null;

                    if (string.Equals(filterType, "domainOfValues", StringComparison.Ordinal))
                    {
                        var domainValues = filter.TryGetValue("domainValues", out var dvObj)
                            ? (dvObj as IEnumerable<object>) ?? Enumerable.Empty<object>()
                            : Enumerable.Empty<object>();
                        return (true, domainValues.ToList());
                    }

                    var hasPicklistQuery = filter.TryGetValue("filterPicklistQuery", out var pq) && pq != null;
                    if (hasPicklistQuery)
                    {
                        var values = await getValuesCallback(filterName);
                        if (values != null && values.Count > 0)
                        {
                            if (values.Count > MaxFilterValues)
                            {
                                var examples = string.Join(", ", values.Take(MaxFilterValues));
                                return (false, $"Filter {filterUxName} in report {reportId} has more values than can be returned. Here are some example values: {examples}.");
                            }
                            return (true, values);
                        }
                        return (false, $"Error: Filter {filterUxName} in report {reportId} did not return any values for its domain.");
                    }

                    return (false, $"Filter {filterUxName} in report {reportId} has no domain of values. Any value is acceptable.");
                }
            }

            return (false, $"Error: Filter `{filterUxName}` not found in report {reportId} metadata.");
        }

        // fields_to_ux_name_pairs
        public static List<Dictionary<string, string>> FieldsToUxNamePairs(IDictionary<string, object> reportMetadata, IReadOnlyList<string> fields)
        {
            var pairs = new List<Dictionary<string, string>>();
            if (fields == null || fields.Count == 0) return pairs;

            var metaFields = GetAllMetadataFields(reportMetadata);
            var byUx = metaFields
                .Where(mf => mf.TryGetValue("uxLabel", out var l) && !string.IsNullOrEmpty(l?.ToString()))
                .ToDictionary(mf => mf["uxLabel"].ToString()!, mf => mf);

            foreach (var key in fields)
            {
                var uxLabel = key ?? string.Empty;
                var meta = byUx.TryGetValue(uxLabel, out var mf) ? mf : null;
                var internalName = meta?.TryGetValue("name", out var nameObj) == true ? nameObj?.ToString() ?? uxLabel : uxLabel;
                var uxDescription = meta?.TryGetValue("uxDescription", out var descObj) == true ? descObj?.ToString() ?? "" : "";

                pairs.Add(new Dictionary<string, string>
                {
                    { "ux_name", uxLabel },
                    { "name", internalName },
                    { "ux_description", uxDescription }
                });
            }

            return pairs;
        }

        // filters_to_ux_name_pairs
        public static List<Dictionary<string, string>> FiltersToUxNamePairs(IDictionary<string, object> reportMetadata, IReadOnlyList<string> filters)
        {
            var pairs = new List<Dictionary<string, string>>();
            if (filters == null || filters.Count == 0) return pairs;

            var filterGroups = GetFilterGroups(reportMetadata);
            var metaFilters = filterGroups
                .SelectMany(g => (g.TryGetValue("filters", out var fObj) ? (fObj as IEnumerable<object>) ?? Enumerable.Empty<object>() : Enumerable.Empty<object>()))
                .Select(ToDict)
                .ToList();

            var byUx = metaFilters
                .Where(mf => mf.TryGetValue("uxLabel", out var l) && !string.IsNullOrEmpty(l?.ToString()))
                .ToDictionary(mf => mf["uxLabel"].ToString()!, mf => mf);

            foreach (var key in filters)
            {
                var uxLabel = key ?? string.Empty;
                var meta = byUx.TryGetValue(uxLabel, out var mf) ? mf : null;
                var internalName = meta?.TryGetValue("filterName", out var nObj) == true ? nObj?.ToString() ?? uxLabel : uxLabel;

                pairs.Add(new Dictionary<string, string>
                {
                    { "ux_name", uxLabel },
                    { "name", internalName }
                });
            }

            return pairs;
        }
    }

}
