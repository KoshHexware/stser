﻿using System.Net;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;

public static class HttpHelper
{
    public static Version DefaultRequestVersion => HttpVersion.Version20;

    public static HttpRequestMessage CreateHttpRequestMessage(HttpMethod method, Uri? requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri)
        {
            Version = DefaultRequestVersion,
            VersionPolicy = HttpVersionPolicy.RequestVersionOrLower // allow lower versions just in case
        };
        return request;
    }

    public static HttpRequestMessage CreateHttpRequestMessage(HttpMethod method, string? requestUri)
    {
        return CreateHttpRequestMessage(method,
            string.IsNullOrWhiteSpace(requestUri) ? null : new Uri(requestUri, UriKind.RelativeOrAbsolute));
    }

    public static HttpRequestMessage CreateHttpRequestMessage()
    {
        return CreateHttpRequestMessage(HttpMethod.Get, (Uri?)null);
    }
}
