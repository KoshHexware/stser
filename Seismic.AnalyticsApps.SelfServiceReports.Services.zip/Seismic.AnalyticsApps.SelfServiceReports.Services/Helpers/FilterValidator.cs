﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class FilterValidator
    {
        public static List<ReportExecutionFilter> DeserializeFilters(string? jsonStringFilters)
        {
            return string.IsNullOrWhiteSpace(jsonStringFilters) ? []
                : JsonSerializer.Deserialize<List<ReportExecutionFilter>>(jsonStringFilters, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase) ?? [];
        }

        public static List<CreateQueryFilterModel> ValidateFilters(List<ReportExecutionFilter> selectedFilters, List<FilterTemplateModel> selectedFiltersMetadata, string reportName)
        {
            if (selectedFilters == null || selectedFilters.Count == 0)
            {
                return [];
            }
            else if (selectedFilters.Any(f => f.FilterName == null || f.Values == null))
            {
                throw new BadRequestException($"Invalid filters applied in report {reportName}");
            }
            var validFilters = new List<CreateQueryFilterModel>();
            foreach (var filter in selectedFilters)
            {
                if (filter?.Operation == null || filter.Values == null || filter.Values.Length == 0 )
                {
                    continue; // Removing filters with no values or opeation
                }

                var filterMetadata = selectedFiltersMetadata.FirstOrDefault(sfm => string.Compare(sfm.FilterName, filter.FilterName, true) == 0)
                    ?? throw new BadRequestException($"Invalid filter {filter.FilterName} applied in report {reportName}");
               
                if (!Enum.IsDefined(typeof(Operation), filter.Operation))
                {
                    throw new BadRequestException($"Invalid operation applied on filter {filter.FilterName} in report {reportName}");
                }
                ValidateOperator(filterMetadata, filter.Operation, reportName);
                
                var operation = filter.Operation;
                var values = filter.Values;


                // Process date filters with special operations
                bool isDateType = filterMetadata.DataType == SelfServiceReports.DataAccess.Entities.DataType.Date 
                    || filterMetadata.DataType == SelfServiceReports.DataAccess.Entities.DataType.DateTime;

                if (isDateType)
                {
                    // Handle special date operators
                    if (operation.ToString() == OperatorConstants.IN_THE_LAST ||
                        operation.ToString() == OperatorConstants.IN_THE_NEXT ||
                        operation.ToString() == OperatorConstants.NAMED_RANGE)
                    {
                        (operation, values) = ProcessDateOperator(operation, values);
                    }
                }

                validFilters.Add(new CreateQueryFilterModel
                {
                    FilterName = filter.FilterName,
                    Operation = operation,
                    Values = values,
                    QueryParam = filterMetadata.QueryParam,
                    DataType = (Models.Template.DataType)filterMetadata.DataType,
                    IsGeneric = filterMetadata.IsGenericFilter ?? false,
                    IsNullable = filterMetadata.IsNullable ?? false,
                    QueryAlias = filterMetadata.QueryAlias
                });
            }
            return validFilters;
        }

        private static void ValidateOperator(FilterTemplateModel filterMetadata, Operation operation, string reportName)
        {
            if (!filterMetadata.AllowedOperators.Any(op => op.Name == operation.ToString()))
            {
                throw new BadRequestException($"The operation {operation} is not allowed on filter {filterMetadata.FilterName} for report:{reportName}");
            }
        }

        private static (Operation operation, string[] values) ProcessDateOperator(Operation currentOperation, string[] currentValues)
        {
            DateTime now = DateTime.UtcNow.Date;
            DateTime startDate;
            DateTime endDate;

            switch (currentOperation.ToString())
            {
                case OperatorConstants.IN_THE_LAST:
                    if (currentValues.Length == 0)
                        return (Operation.Between, [now.ToString("yyyy-MM-dd"), now.ToString("yyyy-MM-dd")]);

                    try
                    {
                        if (!int.TryParse(currentValues[0]?.ToString(), out int value))
                        {
                            value = 0;
                        }
                        string unit = currentValues[1]?.ToString()?.ToLowerInvariant() ?? DateOperatorInTheLastConstants.DAYS;

                        startDate = unit switch
                        {
                            DateOperatorInTheLastConstants.DAYS => now.AddDays(-value),
                            DateOperatorInTheLastConstants.WEEKS => now.AddDays(-value * 7),
                            DateOperatorInTheLastConstants.MONTHS => now.AddMonths(-value),
                            _ => now.AddDays(-value) // Default to days
                        };
                        endDate = now;
                    }
                    catch
                    {
                        // If parsing fails, default to today's date
                        startDate = now;
                        endDate = now;
                    }
                    break;

                case OperatorConstants.IN_THE_NEXT:
                    if (currentValues.Length == 0)
                        return (Operation.Between, [now.ToString("yyyy-MM-dd"), now.ToString("yyyy-MM-dd")]);

                    try
                    {
                        if (!int.TryParse(currentValues[0]?.ToString(), out int value))
                        {
                            value = 0;
                        }
                        string unit = currentValues[1]?.ToString()?.ToLowerInvariant() ?? DateOperatorInTheLastConstants.DAYS;

                        startDate = now;
                        endDate = unit switch
                        {
                            DateOperatorInTheLastConstants.DAYS => now.AddDays(value),
                            DateOperatorInTheLastConstants.WEEKS => now.AddDays(value * 7),
                            DateOperatorInTheLastConstants.MONTHS => now.AddMonths(value),
                            _ => now.AddDays(value) // Default to days
                        };
                    }
                    catch
                    {
                        // If parsing fails, default to today's date
                        startDate = now;
                        endDate = now;
                    }
                    break;

                case OperatorConstants.NAMED_RANGE:
                    if (currentValues.Length == 0)
                        return (Operation.Between, [now.ToString("yyyy-MM-dd"), now.ToString("yyyy-MM-dd")]);

                    string rangeType = currentValues[0].ToLowerInvariant();

                    (startDate, endDate) = rangeType switch
                    {
                        DateOperatorNamedRangeConstants.TODAY => (now, now),
                        DateOperatorNamedRangeConstants.THIS_WEEK => GetWeekRange(now, 0),
                        DateOperatorNamedRangeConstants.LAST_WEEK => GetWeekRange(now, -1),
                        DateOperatorNamedRangeConstants.THIS_MONTH => GetMonthRange(now, 0),
                        DateOperatorNamedRangeConstants.LAST_MONTH => GetMonthRange(now, -1),
                        DateOperatorNamedRangeConstants.THIS_YEAR => GetYearRange(now.Year),
                        DateOperatorNamedRangeConstants.LAST_YEAR => GetYearRange(now.Year - 1),
                        DateOperatorNamedRangeConstants.YEAR_TO_DATE => (new DateTime(now.Year, 1, 1), now),
                        _ => (now, now) // Default to today if unrecognized
                    };
                    break;

                default:
                    return (currentOperation, currentValues);
            }

            // Return the new Between operation with formatted dates
            return (Operation.Between, [startDate.ToString("yyyy-MM-dd"), endDate.ToString("yyyy-MM-dd")]);
        }

        private static (DateTime startDate, DateTime endDate) GetWeekRange(DateTime date, int weekOffset)
        {
            // Set the first day of week to Saturday
            DayOfWeek firstDayOfWeek = DayOfWeek.Saturday;

            // Calculate days since first day of week (Saturday)
            int diff = (7 + (date.DayOfWeek - firstDayOfWeek)) % 7;

            // Find start and end of week with the offset applied
            var startOfWeek = date.AddDays(-diff).AddDays(weekOffset * 7);
            var endOfWeek = startOfWeek.AddDays(6);

            return (startOfWeek, endOfWeek);
        }


        private static (DateTime startDate, DateTime endDate) GetMonthRange(DateTime date, int monthOffset)
        {
            var targetMonth = date.AddMonths(monthOffset);
            var startOfMonth = new DateTime(targetMonth.Year, targetMonth.Month, 1);
            var endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

            return (startOfMonth, endOfMonth);
        }

        private static (DateTime startDate, DateTime endDate) GetYearRange(int year)
        {
            return (new DateTime(year, 1, 1), new DateTime(year, 12, 31));
        }
    }
}