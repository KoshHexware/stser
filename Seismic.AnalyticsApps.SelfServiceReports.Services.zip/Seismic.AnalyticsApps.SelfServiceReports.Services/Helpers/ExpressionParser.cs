﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using System.Globalization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class ExpressionParser
    {
        private const string FUNCTION_TODAY = "TODAY()";

        private static readonly char[] OPERATORS = ['-', '+'];

        /// <summary>
        /// Supports parsing operations of kind "TODAY() + 60" AND "TODAY() - 30" AND "TODAY()"
        /// Other expressions not supported and returned as is.
        /// </summary>
        /// <param name="relativeDateString"></param>
        /// <returns></returns>
        public static string GetValidDateString(string? relativeDateString)
        {
            if (string.IsNullOrWhiteSpace(relativeDateString))
            {
                return string.Empty;
            }

            relativeDateString = relativeDateString.Trim();

            if (!relativeDateString.StartsWith(FUNCTION_TODAY))
            {
                return relativeDateString;
            }

            if (relativeDateString == FUNCTION_TODAY)
            {
                return DateTime.UtcNow.ToString(ReportConstants.DATE_FORMAT, CultureInfo.InvariantCulture);
            }

            //remove first 7 chars for TODAY() and cleanup whitespaces
            var unprocessed = relativeDateString.Substring(FUNCTION_TODAY.Length).Trim();

            if (string.IsNullOrWhiteSpace(unprocessed))
            {
                return DateTime.UtcNow.ToString(ReportConstants.DATE_FORMAT, CultureInfo.InvariantCulture);
            }

            if (!OPERATORS.Contains(unprocessed[0]))
            {
                return relativeDateString;
            }

            //next char is the operator
            char operation = unprocessed[0];

            //skip the operation char and cleanup whitespaces
            unprocessed = unprocessed.Substring(1).Trim();

            //parse the remaining string as a number
            if (!int.TryParse(unprocessed, out int days))
            {
                return relativeDateString;
            }

            if (operation == '+')
            {
                return DateTime.UtcNow.AddDays(days).ToString(ReportConstants.DATE_FORMAT, CultureInfo.InvariantCulture);
            }
            else if (operation == '-')
            {
                return DateTime.UtcNow.AddDays(-days).ToString(ReportConstants.DATE_FORMAT, CultureInfo.InvariantCulture);
            }

            return relativeDateString;
        }

    }
}
