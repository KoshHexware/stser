﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;
using Seismic.Common.ServiceFoundation.NewRelic;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class NewRelicHelper
    {
        public static void RecordNewRelicCustomEventObject(this INewRelicAdapter newRelicAdapter, string eventKey, SsrsReportEvent customEventModel)
        {
            newRelicAdapter.RecordCustomEvent(eventKey, GetNewRelicCustomEventObject(customEventModel));
        }

        private static Dictionary<string, object?> GetNewRelicCustomEventObject(SsrsReportEvent customEventModel)
        {
            Dictionary<string, object?> keyValuePairs = [];

            customEventModel.GetType().GetProperties().ToList().ForEach(p => {

                var value = p.GetValue(customEventModel);

                if (value != null && value is string[] stringArray)
                {
                    keyValuePairs.Add(p.Name, string.Join(",", stringArray));
                }
                else keyValuePairs.Add(p.Name, value);
            });

            return keyValuePairs;
        }
    }
}
