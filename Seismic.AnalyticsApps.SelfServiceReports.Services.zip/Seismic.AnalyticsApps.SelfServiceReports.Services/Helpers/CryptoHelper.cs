﻿using System.Text;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public class CryptoHelper

    {
        public static string ComputeSha256Hash(string inputString)
        {
            var inputBytes = Encoding.UTF8.GetBytes(inputString);
            var hashBytes = System.Security.Cryptography.SHA256.HashData(inputBytes);
            return Convert.ToBase64String(hashBytes);
        }
    }
}
