﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class DataTypeHelper
    {
        private readonly static Dictionary<string, Models.Template.DataType> DataTypeMap = new()
        {
            {"string" , Models.Template.DataType.Text },
            { "integer" , Models.Template.DataType.Integer },
            { "double" , Models.Template.DataType.Decimal},
            { "decimal" , Models.Template.DataType.Decimal},
            { "datetime" , Models.Template.DataType.Date},
            { "boolean" , Models.Template.DataType.Boolean},
            { "date" , Models.Template.DataType.Date},
            { "float" , Models.Template.DataType.Decimal},
            { "any" , Models.Template.DataType.Text},
        };

        /// <summary>
        /// Use this to map data types for custom properties. Do not use this for inbuilt properties
        /// Custom property type for date fields as returned by custom property API is dateTime.
        /// But library UI only allows entering date, not time. So all data should be mapped as date, not datetime.
        /// This helps in formatting the date values for custom props in frontend and also in export
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public static Models.Template.DataType GetDataType(string type)
        {
            if (DataTypeMap.TryGetValue(type.ToLower(), out var dataType))
            {
                return dataType;
            }
            throw new ArgumentException("Invalid custom property data type", nameof(type));
        }

    }
}
