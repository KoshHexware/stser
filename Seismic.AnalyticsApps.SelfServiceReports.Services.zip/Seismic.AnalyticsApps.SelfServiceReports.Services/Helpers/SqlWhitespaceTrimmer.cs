﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class SqlWhitespaceTrimmer
    {
        public static string RemoveEmptyLines(this string input)
        {
            var lines = input.Split([Environment.NewLine, "\r", "\n"], StringSplitOptions.RemoveEmptyEntries);

            //keep such lines for readability.
            //lines = lines.Where(l => !string.IsNullOrWhiteSpace(l));

            return string.Join(Environment.NewLine, lines);
        }
    }
}
