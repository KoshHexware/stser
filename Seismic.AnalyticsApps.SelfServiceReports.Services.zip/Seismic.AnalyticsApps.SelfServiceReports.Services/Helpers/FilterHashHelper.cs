﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class FilterHashHelper
    {
        public static string GetFilterHashValues(List<ReportExecutionFilter>? filters, List<FilterTemplateModel> filterMetadata)
        {
            if (filters == null || filters.Count == 0)
                return string.Empty;

            List<ReportExecutionFilter> result = [];
            foreach (var item in filters)
            {
                var metadata = filterMetadata?.FirstOrDefault(f => f.FilterName == item.FilterName);

                if (metadata == null)
                {
                    continue;
                }

                var filterValues = item.Values;
                if (metadata.DataType == DataType.Text || metadata.DataType == DataType.Csv)
                {
                    filterValues = [];
                    if (item.Operation == Models.ReportRunner.Operation.IsCurrentUser || item.Operation == Models.ReportRunner.Operation.IsMyTeam)
                    {
                        filterValues = item.Values;
                    }
                }

                result.Add(new ReportExecutionFilter()
                {
                    FilterName = item.FilterName,
                    Operation = item.Operation,
                    Values = filterValues,
                    IsProperty = item.IsProperty,
                    PropertyType = item.PropertyType,
                    PropertyId = item.PropertyId
                });
            }
            return JsonSerializer.Serialize(result, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase);
        }

        public static string GetFilterHashValues(List<DataAccess.Entities.ReportFilter>? filters, List<FilterTemplateModel> filterMetadata)
        {
            List<DataAccess.Entities.ReportFilter> result = [];

            if (filters != null)
            {
                foreach (var item in filters)
                {
                    var metadata = filterMetadata?.FirstOrDefault(f => f.FilterName == item.FilterName);

                    if (metadata == null)
                    {
                        continue;
                    }

                    var filterValues = item.Values;
                    if (metadata.DataType == DataType.Text || metadata.DataType == DataType.Csv)
                    {
                        filterValues = [];
                        if (item.Values != null && item.Values.Length > 0 &&
                            (item.Values.Contains(RelativeMyTeamFilterValues.IncludeCurrentUser.ToDisplayString()) ||
                             item.Values.Contains(RelativeMyTeamFilterValues.IncludeIndirectReports.ToDisplayString()) ||
                             item.Values.Contains(RelativeMyTeamFilterValues.IncludeDirectReports.ToDisplayString())))
                        {
                            filterValues = item.Values;
                        }
                    }

                    result.Add(new DataAccess.Entities.ReportFilter()
                    {
                        FilterName = item.FilterName,
                        Operation = item.Operation,
                        Values = filterValues,
                        IsProperty = item.IsProperty,
                        PropertyType = item.PropertyType,
                        PropertyId = item.PropertyId
                    });
                }
            }
            return JsonSerializer.Serialize(result, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase);
        }
    }
}
