﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class UserDataMapper
    {
        public static List<HierarchicalUserInfo> MergeUserData(List<HierarchyUserResource> users)
        {
            var result = new List<HierarchicalUserInfo>();
            if (users == null)
            {
                return result;
            }

            foreach (var item in users)
            {
                var manager = users.Where(p => p.UserId == item.ManagerUserId).FirstOrDefault();
                var user = new HierarchicalUserInfo()
                {
                    Email = item.Email,
                    Id = item.Id,
                    ManagerUserId = item.ManagerUserId,
                    ReportCount = item.ReportCount,
                    UserId = item.UserId,
                    UserName = item.UserName,
                    HierarchyLevel = HierarchyLevel.IC, // to be updated later
                };

                result.Add(user);
            }

            return result;
        }

        public static string GetDisplayName(HierarchicalUserInfo? user)
        {
            return GetDisplayName(user?.FirstName, user?.LastName, user?.UserName);
        }

        public static string GetDisplayName(HierarchyUserResource? user)
        {
            return GetDisplayName(user?.FirstName, user?.LastName, user?.UserName);
        }

        public static string GetDisplayName(string? firstName, string? lastName, string? userName)
        {
            var result = $"{firstName} {lastName}".Trim();
            if (string.IsNullOrWhiteSpace(result))
            {
                result = userName;
            }
            return result ?? string.Empty;
        }

    }
}
