﻿using YamlDotNet.Core;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public static class YamlHelper
    {
        public static readonly ISerializer serializer = new SerializerBuilder()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();

        private static readonly IDeserializer deserializer = new DeserializerBuilder()
                .IgnoreUnmatchedProperties()
                .WithNamingConvention(CamelCaseNamingConvention.Instance)
                .Build();

        public static string Serialize<T>(T model)
        {
            return serializer.Serialize(model);
        }

        public static T Deserialize<T>(string yaml)
        {
            //MergingParser is used to support Anchor and Reference in the Yaml
            var parsedYaml = new MergingParser(new Parser(new StringReader(yaml)));
            return deserializer.Deserialize<T>(parsedYaml);
        }
    }
}
