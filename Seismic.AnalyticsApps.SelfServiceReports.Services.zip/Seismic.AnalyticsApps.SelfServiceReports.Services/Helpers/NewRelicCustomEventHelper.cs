﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;
using Seismic.Common.ServiceFoundation.NewRelic;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers
{
    public class NewRelicCustomEventHelper(INewRelicAdapter _newRelicAdapter, ILogger logger) : INewRelicCustomEventHelper
    {
        private readonly ILogger _logger = logger.ForContext<NewRelicCustomEventHelper>();

        public bool RecordCustomEvent(string customEventKey, SsrsReportEvent customEventModel)
        {
            try
            {
                _newRelicAdapter.RecordNewRelicCustomEventObject(customEventKey, customEventModel);
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to record new relic custom event. EventKey:{CustomEventKey}", customEventKey);
                return false;
            }
        }
    }
}
