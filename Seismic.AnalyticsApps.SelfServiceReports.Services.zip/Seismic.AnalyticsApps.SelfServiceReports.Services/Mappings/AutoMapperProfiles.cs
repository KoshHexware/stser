﻿//using AutoMapper;
//using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

//namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Mappings
//{
//    public class AutoMapperProfiles : Profile
//    {
//        public AutoMapperProfiles()
//        {
//            var config1 = new MapperConfiguration(cfg => {
//                cfg.CreateMap<Report, Models.Report>();
//                cfg.ReplaceMemberName("ReportId", "Id"); 
//            });
//            var config2 = new MapperConfiguration(cfg => {
//                cfg.CreateMap<Models.Report, Report>();
//                cfg.ReplaceMemberName("Id", "ReportId");
//            });
//        }
//    }
//}
