﻿using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Impl;
using Seismic.Platform.Matrix.Client;
using Serilog;
using Serilog.Context;
using System.Diagnostics;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders
{
    public class TenantCacheBuilder(ITenantService _tenantSvc, 
        ISeismicInstance _seismicInstance, IMatrixClient _matrixClient, 
        ISeismicContextProvider _contextProvider, IDataAccessor _dataAccessor,
        IUserInfoProvider _userInfoProvider, IUserService _userService, ILogger logger, ICustomPropertyService _customPropertyService, IReportShareService _reportShareService,
        IOrgHierarchyService _orgHierarchyService, IEntitlementServiceClientWrapper _entitlementService) : ITenantCacheBuilder
    {
        private readonly ILogger _logger = logger.ForContext<TenantCacheBuilder>();

        public async Task RefreshTenantCaches(CancellationToken stoppingToken)
        {
            var tenantInfo = await _dataAccessor.GetAndClaimTenantCacheInfoJobAsync(stoppingToken);
            
            if (tenantInfo == null)
            {
                _logger.Information("No tenant found");
                return;
            }

            using (LogContext.PushProperty(CorrelationConstants.CORRELATION_ID, Guid.NewGuid().ToString()))
            using (LogContext.PushProperty(LoggingConstants.GIT_SHA, Environment.GetEnvironmentVariable("COMMIT_HASH")))
            {
                await RefreshTenantCache(tenantInfo);
            }
        }

        public async Task RefreshTenantOrgCaches(CancellationToken stoppingToken)
        {
            var tenantInfo = await _dataAccessor.GetAndClaimTenantOrgCacheInfoJobAsync(stoppingToken);

            if (tenantInfo == null)
            {
                _logger.Information("No tenant found");
                return;
            }

            using (LogContext.PushProperty(CorrelationConstants.CORRELATION_ID, Guid.NewGuid().ToString()))
            using (LogContext.PushProperty(LoggingConstants.GIT_SHA, Environment.GetEnvironmentVariable("COMMIT_HASH")))
            {
                await RefreshTenantOrgCache(tenantInfo);
            }
        }

        private async Task<bool> RefreshTenantCache(TenantCacheInfo tenantInfo)
        {
            try
            {
                _logger.Information("Start cache refresh for tenant:{tenant}", tenantInfo.TenantId);
                var matrixTenant = await ValidateTenantExists(tenantInfo.TenantId);
                if (matrixTenant == null)
                {
                    _logger.Warning("Tenant not found in matrix for tenantId:{tenantId}", tenantInfo.TenantId);
                    return false;
                }
                using var _ = SetTenantContext(matrixTenant);
                
                var localContext = _contextProvider.GetContext();
                var appEnabled = await _tenantSvc.CheckFMSAndLDFLagsEnabled();

                if (!appEnabled)
                {
                    await _tenantSvc.RemoveTenant(matrixTenant.Id);
                    return false;
                }
                var sw = Stopwatch.StartNew();
                var success = await RefreshCacheItems(matrixTenant);
                sw.Stop();
                _logger.Information("End cache refresh for tenant:{tenant},  elapsed: {elapsed}ms.", tenantInfo.TenantId, sw.ElapsedMilliseconds);
                return await UpdateCacheRefreshTimestamp(tenantInfo, success);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error refreshing cache for tenant {tenantId},", tenantInfo.TenantId);
            }
            return false;
        }

        private async Task<bool> RefreshTenantOrgCache(TenantOrgCacheInfo tenantInfo)
        {
            try
            {
                _logger.Information("Start org cache refresh for tenant:{tenant}", tenantInfo.TenantId);
                var matrixTenant = await ValidateTenantExists(tenantInfo.TenantId);
                if (matrixTenant == null)
                {
                    _logger.Warning("Tenant not found in matrix for tenantId:{tenantId}", tenantInfo.TenantId);
                    return false;
                }
                using var _ = SetTenantContext(matrixTenant);

                var localContext = _contextProvider.GetContext();
                var appEnabled = await _tenantSvc.CheckFMSAndLDFLagsEnabled();

                if (!appEnabled)
                {
                    await _tenantSvc.RemoveTenant(matrixTenant.Id);
                    return false;
                }
                var sw = Stopwatch.StartNew();
                var success = await RefreshOrgHierarchy(matrixTenant.Id);
                
                sw.Stop();
                _logger.Information("End org cache refresh for tenant:{tenant},  elapsed: {elapsed}ms.", tenantInfo.TenantId, sw.ElapsedMilliseconds);
                return await UpdateOrgCacheRefreshTimestamp(tenantInfo, success);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error refreshing org cache for tenant {tenantId},", tenantInfo.TenantId);
            }
            return false;
        }

        private IDisposable SetTenantContext(Tenant matrixTenant)
        {
            var tenantIdentifier = TenantIdentifier.FromParts(matrixTenant.Name, matrixTenant.Id);

            var context = new SeismicContext(_seismicInstance, tenantIdentifier);
            var contextScope = _contextProvider.SetContextExplicitly(context);

            var localContext = _contextProvider.GetContext();

            return contextScope;
        }

        private async Task<bool> RefreshCacheItems(Tenant matrixTenant)
        {
            try
            {
                var userPropertyTask = RefreshTenantUserProperties(matrixTenant.Id);
                var contentPropertyTask = RefreshTenantContentCustomProperties(matrixTenant.Id);
                var userInfoTask = RefreshUserInfoForTenant(matrixTenant.Id);
                var ssrsAccessibleUsersTask = RefreshSSRSAccessibleUsers(matrixTenant.Id);
               
                await Task.WhenAll(userPropertyTask, userInfoTask, contentPropertyTask, ssrsAccessibleUsersTask);

                return userPropertyTask.Result && userInfoTask.Result && contentPropertyTask.Result && ssrsAccessibleUsersTask.Result;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error refreshing cache items for tenantId:{tenantId}, tenantName:{tenantName}", matrixTenant.Id, matrixTenant.Name);
                return false;
            }
        }


        private async Task<bool> RefreshOrgHierarchy(Guid tenantId)
        {
            try
            {
                _logger.Information("Start ssrs RefreshOrgHierarchy, tenantId:{TenantId}", tenantId);
                var sw = Stopwatch.StartNew();

                var setting = await _orgHierarchyService.GetTenantOrgHierarchySettings(tenantId);
                if (!setting.IsOrgHierarchyEnabled)
                {
                    _logger.Warning("Org hierarchy is not enabled for tenant:{TenantId}", tenantId);
                    return true;
                }
                var context = _contextProvider.GetContext();
                var useEntitlements = await _contextProvider.GetContext().IsToggleEnabled(LDConstants.SsrUseEntitlementsLDKey);

                HashSet<string> distinctUserIds = [];
                if (useEntitlements) // TO DO replce conditionwith this for entitlesupport - centralizedPermissionsEnabled 
                {
                    _logger.Information("Using entitlement based permission model for tenant:", tenantId);
                    var viewerPermissionUsersTask = _entitlementService.GetUsersWithSsrAccess(PermissionConstants.SelfServiceReportsViewerPermissionKey, tenantId);
                    var editorPermissionUsersTask = _entitlementService.GetUsersWithSsrAccess(PermissionConstants.SelfServiceReportsCreatorPermissionKey, tenantId);

                    await Task.WhenAll(viewerPermissionUsersTask, editorPermissionUsersTask);
                    var viewerPermissionUsers = viewerPermissionUsersTask.Result;
                    var editorPermissionUsers = editorPermissionUsersTask.Result;

                    distinctUserIds = editorPermissionUsers.Concat(viewerPermissionUsers).DistinctBy(x => x.AssigneeId).Select(x => x.AssigneeId).ToHashSet();
                }
                else
                {
                    var ssrViewerUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsViewer);
                    var ssrEditorUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsEditor);
                    var ssrCreatorsUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsCreator);

                    await Task.WhenAll(ssrViewerUgTask, ssrEditorUgTask, ssrCreatorsUgTask);

                    var ssrViewerUg = ssrViewerUgTask.Result;
                    var ssrEditorUg = ssrEditorUgTask.Result;
                    var ssrCreatorsUg = ssrCreatorsUgTask.Result;

                    var ssrViewerUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsViewer);
                    var ssrEditorUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsEditor);
                    var ssrCreatorsUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsCreator);

                    await Task.WhenAll(ssrViewerUgMemberTask, ssrEditorUgMemberTask, ssrCreatorsUgMemberTask);

                    var ssrViewerUgMembers = ssrViewerUgMemberTask.Result;
                    var ssrEditorUgMembers = ssrEditorUgMemberTask.Result;
                    var ssrCreatorsUgMembers = ssrCreatorsUgMemberTask.Result;
                    distinctUserIds.UnionWith(ssrViewerUgMembers.Select(u => u.LegacyId));
                    distinctUserIds.UnionWith(ssrEditorUgMembers.Select(u => u.LegacyId));
                    distinctUserIds.UnionWith(ssrCreatorsUgMembers.Select(u => u.LegacyId));
                }

                foreach(var id in distinctUserIds)
                {
                    await _orgHierarchyService.GetDirectReportsForManager(tenantId, id, true);
                    await _orgHierarchyService.GetAllReportsForManager(tenantId, id, true);
                }

                _logger.Information("End ssrs RefreshOrgHierarchy, tenantId:{TenantId}", tenantId);
                sw.Stop();
                _logger.Information("Time taken to refresh org hierarchy for tenantId:{tenantId} is {elapsed}ms", tenantId, sw.ElapsedMilliseconds);
            }
              
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in RefreshOrgHierarchy, tenantId:{TenantId}", tenantId);
                return false;
            }
            return true;
        }

        private async Task<bool> RefreshUserInfoForTenant(Guid tenantId)
        {
            try
            {
                var sw = Stopwatch.StartNew();
                _logger.Information("Start RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                var userIds = await _dataAccessor.GetAllReportOwnerUsers(tenantId);
                await _userInfoProvider.RefreshUsersDetails(tenantId, userIds);
                _logger.Information("End RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                sw.Stop();
                _logger.Information("Time taken to refresh user info for tenantId:{tenantId} is {elapsed}ms", tenantId, sw.ElapsedMilliseconds);
            }
            catch(Exception ex)
            {
                _logger.Error(ex, "Error in RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                return false;
            }
            return true;
        }

        private async Task<bool> RefreshSSRSAccessibleUsers(Guid tenantId)
        {
            try
            {
                var sw = Stopwatch.StartNew();
                _logger.Information("Start RefreshSSRSAccessibleUsers, tenantId:{tenantId}", tenantId);
                var userProperties = await _reportShareService.RefreshSSRSAccessibleUsers(tenantId);
                _logger.Information("End RefreshSSRSAccessibleUsers, tenantId:{tenantId}", tenantId);
                sw.Stop();
                _logger.Information("Time taken to refresh ssrs accessible users for tenantId:{tenantId} is {elapsed}ms", tenantId, sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in RefreshSSRSAccessibleUsers, tenantId:{tenantId}", tenantId);
                return false;
            }
            return true;
        }

        private async Task<bool> RefreshTenantUserProperties(Guid tenantId)
        {
            
            try
            {
                var sw = Stopwatch.StartNew();
                _logger.Information("Start RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                var userProperties = await _customPropertyService.RefreshUserCustomProperties(tenantId);
                _logger.Information("End RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                sw.Stop();
                _logger.Information("Time taken to refresh user properties for tenantId:{tenantId} is {elapsed}ms", tenantId, sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in RefreshUserInfoForTenant, tenantId:{tenantId}", tenantId);
                return false;
            }
           
            return true;
        }

        private async Task<bool> RefreshTenantContentCustomProperties(Guid tenantId)
        {
            try
            {
                var sw = Stopwatch.StartNew();
                _logger.Information("Start RefreshTenantContentCustomProperties, tenantId:{tenantId}", tenantId);
                var userProperties = await _customPropertyService.RefreshContentCustomProperties(tenantId);
                _logger.Information("End RefreshTenantContentCustomProperties, tenantId:{tenantId}", tenantId);
                sw.Stop();
                _logger.Information("Time taken to refresh content properties for tenantId:{tenantId} is {elapsed}ms", tenantId, sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in RefreshTenantContentCustomProperties, tenantId:{tenantId}", tenantId);
                return false;
            }
            return true;
        }

        private async Task<bool> UpdateCacheRefreshTimestamp(TenantCacheInfo tenantInfo, bool success)
        {
            if (success)
            {
                tenantInfo.CacheRefreshedAt = DateTime.UtcNow;
                tenantInfo.IsRunning = false;
                await _tenantSvc.UpdateTenant(tenantInfo);
                _logger.Information("cache refresh successful for tenant:{tenant}", tenantInfo.TenantId);
                return true;
            }
            else
            {
                // if we don't do this, it blocks cache refresh for other tenants.
                tenantInfo.CacheRefreshedAt = DateTime.UtcNow.AddMinutes(20);
                tenantInfo.IsRunning = false;
                await _tenantSvc.UpdateTenant(tenantInfo);
                _logger.Warning("Setting last cached timestamp for tenant as 20 minutes from now, as it is erroring out. tenantId:{tenantId}", tenantInfo.TenantId);
            }
            return true;
        }

        private async Task<bool> UpdateOrgCacheRefreshTimestamp(TenantOrgCacheInfo tenantInfo, bool success)
        {
            if (success)
            {
                tenantInfo.CacheRefreshedAt = DateTime.UtcNow;
                tenantInfo.IsRunning = false;
                await _tenantSvc.UpdateTenantOrgCacheInfo(tenantInfo);
                _logger.Information("Org cache refresh successful for tenant:{tenant}", tenantInfo.TenantId);
                return true;
            }
            else
            {
                // if we don't do this, it blocks cache refresh for other tenants.
                tenantInfo.CacheRefreshedAt = DateTime.UtcNow.AddMinutes(20);
                tenantInfo.IsRunning = false;
                await _tenantSvc.UpdateTenantOrgCacheInfo(tenantInfo);
                _logger.Warning("Setting last org cached timestamp for tenant as 20 minutes from now, as it is erroring out. tenantId:{tenantId}", tenantInfo.TenantId);
            }
            return true;
        }

        private async Task<Tenant?> ValidateTenantExists(Guid tenantId)
        {
            try
            {
                var matrixTenant = await _matrixClient.GetTenantAsync(tenantId);
                return matrixTenant;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error refreshing AppConfig cache for tenant:{tenantId}", tenantId);
                return null;
            }
        }

    }
}
