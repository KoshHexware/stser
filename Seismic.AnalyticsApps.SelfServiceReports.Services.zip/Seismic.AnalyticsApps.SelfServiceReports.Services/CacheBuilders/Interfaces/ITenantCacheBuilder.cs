﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.CacheBuilders.Interfaces
{
    public interface ITenantCacheBuilder
    {
        public Task RefreshTenantCaches(CancellationToken stoppingToken);

        Task RefreshTenantOrgCaches(CancellationToken stoppingToken);
    }
}
