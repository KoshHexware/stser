﻿using Newtonsoft.Json.Linq;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Platform.UserManagement.Model;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Utils;

public static class UserInfoModelBuilder
{
    public static UserInfoModel Build(UserResource userResource)
    {
        var toReturn = new UserInfoModel
        {
            Id = userResource.Id,
            LegacyId = userResource.LegacyId,
            Username = userResource.Name,
            DirectGroupIds = userResource.DirectGroupIds
        };

        if (userResource.Data != null && userResource.Data.TryGetValue("profile", out var profile) && profile != null)
        {
            toReturn.Title = profile.Value<string>("title");
            toReturn.Organization = profile.Value<string>("organization");
            toReturn.Email = profile.SelectToken("emails")?.FirstOrDefault()?.SelectToken("value")?.Value<string>();

            var nameToken = profile.SelectToken("name");
            if (nameToken != null && nameToken.HasValues)
            {
                toReturn.FirstName = nameToken.Value<string>("givenName");
                toReturn.LastName = nameToken.Value<string>("familyName");
                toReturn.FullName = string.IsNullOrWhiteSpace($"{toReturn.FirstName?.Trim()} {toReturn.LastName?.Trim()}".Trim()) ? userResource.Name : $"{toReturn.FirstName?.Trim()} {toReturn.LastName?.Trim()}".Trim();
            }
            else 
            {
                toReturn.FullName = userResource.Name;
            }

            var photos = profile.SelectToken("photos");
            if (photos is JArray photoItems)
            {
                var photoItem = photoItems.FirstOrDefault();
                if (photoItem != null)
                {
                    toReturn.ThumbnailId = photoItem.Value<string>("value");
                }
            }
        }


        return toReturn;
    }
}

