﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions
{
    public class ForbiddenException(string message) : Exception(message)
    {
    }
}
