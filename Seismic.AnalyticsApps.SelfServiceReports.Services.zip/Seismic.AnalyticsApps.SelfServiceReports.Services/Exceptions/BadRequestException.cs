﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions
{
    public class BadRequestException(string message) : Exception(message)
    {
    }
}
