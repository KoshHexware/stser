﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportingAgent;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IReportingAgentService
    {
        Task<ApiResponse<List<StandardReport>>> GetAllStandardReportsAsync(Guid tenantId, string? userId = null);
        Task<ApiResponse<List<ReportDetail>>> FetchMetadataByReportNameAsync(Guid tenantId, List<string> reportNames, string userId, bool listCustomProperties);
        Task<ExecuteApiResponse<List<RowData>>> ExecuteReportAsync(Guid tenantId, Guid reportId, string reportName, string userId, List<string>? fields, List<AdditionalFilter>? filters, string? orderField, string? orderBy, string? teamsiteIds, int skip, int take, bool isSavedReport = true);
        Task<List<FilterDetail>> GetFilterDomainValuesAsync(Guid tenantId, string userId,Guid reportId, string reportName, List<string> filterNames, string? searchTerm = null);


    } 
}
