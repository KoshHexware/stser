﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IDraftReportFiltersService
    {
        Task<DraftFilterModel> GetDraftFiltersAsync();

        Task<DraftFilterModel> GetDraftFilterByNameAsync(string filterName);

        Task<DraftFilterModel> UpdateDraftFiltersAsync(DraftFilterModel draftReportFilters);

        Task<FilterTemplateModel> UpdateDraftFilterAsync(string filterName, FilterTemplateModel draftReportFilters);

        Task<DraftFilterModel> CreateDraftFilterAsync( DraftFilterModel draftReportFilters);

        Task DeleteDraftFilterAsync(string filterName);
    }
}
