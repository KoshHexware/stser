﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IFileSystemHelper
    {
        IEnumerable<string> GetReportTemplateFiles();

        IEnumerable<string> GetFilterTemplateFiles();

        IEnumerable<string> GetReportFragmentTemplateFiles();

        IEnumerable<string> GetFeatureProfiles();

        IEnumerable<string> GetArchivedFilters();

        IEnumerable<string> GetTextFiles();

        IEnumerable<string> GetDataAreas();

        string ReadTextFile(string filePath);

        string GetBasePath();
    }
}
