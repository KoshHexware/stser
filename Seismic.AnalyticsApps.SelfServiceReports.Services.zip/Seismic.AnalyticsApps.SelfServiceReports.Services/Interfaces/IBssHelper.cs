﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IBssHelper
    {
        Task<IEnumerable<(string UserId, string Url)>> GetImageURLsAsync(Guid tenantId, IEnumerable<(string UserId, string BlobId)> items);
    }
}
