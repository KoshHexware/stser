﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IReportRunner
    {
        Task<Query> GetQuery(Guid reportId, Guid tenantId, int skip, int take, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? selectedTeamsites = null);

        Task<ReportResult> RunReport(Guid reportId, Guid tenantId, int skip, int take, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? selectedTeamsites = null, bool? showTeamsitePicker = false);

        Task<ExportResult> ExportReport(
            Guid reportId, 
            Guid tenantId, 
            string userId, 
            string? filters = null, 
            string? fields = null, 
            string? orderField = null, 
            string? orderBy = null,
            string? timezoneId = null,
            string? selectedTeamsites = null,
            bool? showTeamsitePicker = false,
            bool? isDrillIn = false 
        );

        Task<(ReportResult Result, Report Report)> ExecuteReportWithDefaults(
            Report report,
            Guid tenantId,
            int? skip,
            int? take,
            string userId,
            string? filters = null,
            string? fields = null,
            string? orderField = null,
            string? orderBy = null,
            string? selectedTeamsites = null,
            bool? showTeamsitePicker = false,
            bool? isDrillIn = false
        );
    }
}
