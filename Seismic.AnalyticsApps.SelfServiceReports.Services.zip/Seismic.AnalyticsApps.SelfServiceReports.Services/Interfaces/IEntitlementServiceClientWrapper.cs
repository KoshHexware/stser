﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement;
using Seismic.Platform.Entitlement.Client.Model;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;

public interface IEntitlementServiceClientWrapper
{
    Task<List<PermissionResource>> GetUserPermissionsAsync(string userId, Guid tenantId);

    Task<List<PermissionAssignee>> GetUsersWithSsrAccess(string permissionKey, Guid tenantId);

    Task<ResourceResponse<CheckPermissionResultResource>> CheckUserPermissionAsync(string userId, string permissionKey, Guid tenantId);

    Task<List<UserRolesView>?> GetUserRolesByUserIdsAsync(Guid tenantId, List<string> userIds, string platformToken);
}
