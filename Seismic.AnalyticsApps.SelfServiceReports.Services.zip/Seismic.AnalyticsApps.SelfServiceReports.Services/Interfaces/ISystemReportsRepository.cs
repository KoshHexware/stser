﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.FeatureProfiles;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;

public interface ISystemReportsRepository
{
    bool IsSystemReport(Guid reportId);

    List<DeletedItem>? GetArchivedFilters(Guid reportId);

    IEnumerable<ReportDefinitionMetadata> GetAllReportDefinitions();

    ReportDefinitionMetadata? GetReportDefinition(Guid id);

    ReportDefinitionQuery? GetQueryDefinition(Guid id);

    IEnumerable<FilterTemplateModel> GetAllFilters();

    FilterTemplateModel? GetFilterByName(string filterName);

    ReportFragmentDefinition? GetReportFragmentDefinition(Guid reportId);

    ReportFragmentDefinitionQuery? GetFragmentQueryDefinition(Guid reportId);

    IEnumerable<ReportFragmentDefinitionQuery> GetFragmentQueryDefinition(List<Guid> reportIds);

    /// <summary>
    /// Get all feature profiles
    /// </summary>
    /// <returns></returns>
    IEnumerable<FeatureProfile> GetAllFeatureProfiles();

    /// <summary>
    /// Get feature profiles by feature keys
    /// </summary>
    /// <param name="featureKeys"></param>
    /// <returns></returns>
    IEnumerable<FeatureProfile> GetFeatureProfiles(List<string> featureKeys);

    /// <summary>
    /// Get feature profile by feature key
    /// </summary>
    /// <param name="featureKey"></param>
    /// <returns></returns>
    public FeatureProfile? GetFeatureProfile(string featureKey);

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public IEnumerable<DataArea> GetAllSystemDataAreas();

    /// <summary>
    /// Get data area by id(key)
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public DataArea GetDataArea(Guid id);
}
