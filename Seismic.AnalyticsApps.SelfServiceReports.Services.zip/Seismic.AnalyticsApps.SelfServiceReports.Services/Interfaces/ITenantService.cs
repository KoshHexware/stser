﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ITenantService
    {
        Task<int> AddTenant(Guid tenantId);

        Task<int> AddTenants(HashSet<Guid> tenantIds);

        Task<int> RemoveTenant(Guid tenantId);

        Task<TenantCacheInfo?> GetTenantForCacheRefresh();

        Task<TenantCacheInfo?> UpdateTenant(TenantCacheInfo tenant);

        Task<TenantOrgCacheInfo?> UpdateTenantOrgCacheInfo(TenantOrgCacheInfo tenant);

        Task<bool> CheckHasAccess();

        Task<bool> CheckFMSAndLDFLagsEnabled();

        Task<bool> IsLDFlagEnabled(string flagKey);

        Task<bool> CheckSsrWinterFy26ReleaseLDFlagEnabled();
    }
}
