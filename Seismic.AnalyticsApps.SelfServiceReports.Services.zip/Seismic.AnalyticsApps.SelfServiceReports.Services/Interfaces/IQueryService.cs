﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IQueryService
    {
        Task<Query> CreateQuery(ReportDefinitionMetadata reportMetadata, List<CreateQueryFilterModel> filters,
            IList<UserProperty> userProperties, IList<ContentCustomProperty> contentCustomProperties,
            int skip, int take, string? orderField = null, string? orderBy = null, List<ReportExecutionField>? requestedFieldsList = null, string[]? selectedTeamsites = null, bool includePrimaryKeyField = false );
    }
}
