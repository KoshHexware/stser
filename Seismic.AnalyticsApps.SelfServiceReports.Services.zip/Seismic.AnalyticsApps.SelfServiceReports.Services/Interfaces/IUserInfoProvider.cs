﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IUserInfoProvider
    {
        Task<List<UserInfoModel>> GetUsersDetails(Guid tenantId, IEnumerable<string?> userIds);

        Task<List<UserInfoModel>> RefreshUsersDetails(Guid tenantId, IEnumerable<string?> userIds);
    }
}
