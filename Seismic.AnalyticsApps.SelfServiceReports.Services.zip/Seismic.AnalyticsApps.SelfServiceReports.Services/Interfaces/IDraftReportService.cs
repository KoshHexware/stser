﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IDraftReportService
    {
        Task<List<DraftReport>> GetAllDraftReports(Guid tenantId, string? searchText = null);

        Task<DraftReport?> GetDraftReportYamlById(Guid reportId, Guid tenantId);

        Task<Guid> CreateDraftReport(CreateDraftReport report, string templateText, Guid tenantId);

        Task<Guid> UpdateDraftReport(Guid draftReportId, CreateDraftReport report, string templateText, Guid tenantId);

        Task<Guid> DeleteDraftReport(Guid draftReportId, Guid tenantId);
    }
}
