﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Platform.Notification.Client;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface INotificationWrapper
    {
        Task<IEnumerable<NotificationRequestResponseResource>> SendNotificationRequestAsync(ReportSharedNotificationPayload notificationCreateRequest, 
            string[] newSharedUserIds, Guid tenantId);
    }
}
