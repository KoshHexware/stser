﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ISystemDataAreaService
    {
        IEnumerable<DataArea> GetAllSystemDataAreas();
    }
}
