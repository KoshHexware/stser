﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;

public interface IFeatureService
{
    Task<IList<string>> GetFeaturesEnabledInTenantAsync(List<string> launchDarklyKeys);
}
