﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ISystemFiltersService
    {
        Task<FilterTemplateModel?> GetFilterByNameAsync(string filterName, List<FieldGroup>? fieldGroups = null);

        Task<IEnumerable<FilterTemplateModel>> GetAllFiltersAsync(List<FieldGroup> fieldGroups, List<string> reportDefinitionFilters, bool showTeamsitePicker, bool isCustomReport, string[]? customReportSelectedTeamsiteIds);
    }
}
