﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ISSRConfigurationService
    {
        Task<SSRUserConfiguration> GetSSRConfigurationAsync(Guid tenantId, string userId);
    }
}
