﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IReportShareService
    {
        Task<List<UserInfoModel>> GetSsrAccessibleUsers(string? searchKeyword, Guid tenantId, bool refreshCache = false);

        Task<UserInfoModel> GetReportOwnerDetails(Guid reportId, Guid tenantId, string contextUserId);

        Task<List<UserInfoModel>> GetSharedReportUserList(Guid reportId, Guid tenantId);

        Task<List<UserAndUserGroupInfoModel>> GetSharedReportUserAndUserGroupList(Guid reportId, Guid tenantId);

        Task CreateOrUpdateSharedReport(Guid reportId, ShareReportRequest request, string userId, Guid tenantId);

        Task CreateOrUpdateSharedReportWithUsersAndGroups(Guid reportId, ShareReportRequest shareRequest, string userId, Guid tenantId);

        Task<List<UserInfoModel>> RefreshSSRSAccessibleUsers(Guid tenantId);
    }
}
