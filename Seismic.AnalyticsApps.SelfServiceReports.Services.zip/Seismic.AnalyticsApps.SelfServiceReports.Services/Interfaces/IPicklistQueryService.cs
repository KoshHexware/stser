﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IPicklistQueryService
    {
        Task<List<string>> GetFilterValues(string filterName, Guid systemReportId, string? searchTerm, string? teamsiteIds, Guid tenantId);
    }
}
