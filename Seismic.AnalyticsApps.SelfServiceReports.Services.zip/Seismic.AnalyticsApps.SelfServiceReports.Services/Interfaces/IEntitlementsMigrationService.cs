﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement.PermissionMigration;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IEntitlementsMigrationService
    {
        Task<List<MigrationInfo>> GetMigrationInfoForTenant(Guid tenantId, string platformToken);
    }
}
