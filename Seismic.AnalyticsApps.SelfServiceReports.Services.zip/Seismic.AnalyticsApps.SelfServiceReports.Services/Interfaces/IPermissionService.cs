﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IPermissionService
    {
        Task<bool> CheckContextUserAccess(bool forceRefresh = false);

        Task<AccessLevel> GetContextUserAccess(bool forceRefresh = false);

        Task<bool> HasAdminAccess(bool forceRefresh = false);
    }
}
