﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Platform.UserManagement.Model;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IUserService
    {
        Task<List<UserResource>> GetMultipleUsersInTenant(Guid tenantId, string[] userIds);

        Task<GroupResource> GetUserGroupByName(Guid tenantId, string groupName);

        Task<UserResource> GetUserById(Guid tenantId, string userId);

        Task<List<UsersBasicInfoResource>> GetGroupMembers(Guid tenantId, string groupName);

        Task<IEnumerable<CustomPropertyResource>> GetCustomUserProperties(Guid tenantId);

        Task<UserSettings> GetUserSettingsAsync(Guid tenantId, string userId);

        /// <summary>
        /// Create or update user teamsites
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="userId"></param>
        /// <param name="teamsiteIds"></param>
        /// <returns></returns>
        Task<List<Teamsites>> UpdateUserPreferredTeamsitesAsync(Guid tenantId, string userId, string[] teamsiteIds);

        Task CreateOrUpdateReportsFilterOption(Guid tenantId, string userId, string filterOption);

        Task<IEnumerable<GroupResource>> GetGroupsByGroupIdsAsync(Guid tenantId, string[] groupIds);

        Task<ResourceResponse<IEnumerable<string>>> GetUserIdsByGroupIdAsync(string tenantId, string userGroupId);
    }
}
