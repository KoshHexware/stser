﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.CustomProperty.Algorithm.Validators.TeamSiteRule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ICMService
    {
        Task<List<Teamsites>> GetUserAccessibleTeamsitesAsync(Guid tenantId, string userId, bool refreshCache = false);

        Task<List<Teamsites>> RefreshUserAccessibleTeamsitesCacheAsync(Guid tenantId, string userId);
    }
}
