﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IDiscClient
    {
        Task<IList<T>> ExecuteQuery<T>(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
            Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null) where T : class;

        Task<QueryResult> ExecuteGenericQuery(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
            Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null);

        Task<string> ExecuteQueryToCsv(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
            Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null);

    }
}
