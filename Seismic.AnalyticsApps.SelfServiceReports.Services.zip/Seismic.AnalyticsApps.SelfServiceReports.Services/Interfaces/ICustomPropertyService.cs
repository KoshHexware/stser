﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;


namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;

public interface ICustomPropertyService
{
    Task<IList<UserProperty>> GetUserCustomProperties(Guid tenantId, bool refreshCache = false);

    Task<IList<UserProperty>> RefreshUserCustomProperties(Guid tenantId);

    Task<IList<ContentCustomProperty>> GetContentCustomProperties(Guid tenantId, bool refreshCache = false);

    Task<IList<ContentCustomProperty>> RefreshContentCustomProperties(Guid tenantId);


    /// <summary>
    /// Content custom properies which have teamsiteId in user accessible teamsites
    /// </summary>
    /// <param name="tenantId"></param>
    /// <param name="userTeamsites"></param>
    /// <param name="customReportSelectedTeamsiteIds"></param>
    /// <param name="isCustomReport"></param>
    /// <returns>Returns Custom content Properties which have teamsiteId in user accessible teamsites </returns>
    Task<IList<ContentCustomProperty>> GetFilteredContentPropertiesByUserTeamsites(Guid tenantId, List<Models.Teamsites> userTeamsites);
}
