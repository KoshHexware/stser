﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.Platform.UserManagement.Model;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ISystemReportsService
    {
        Task<IEnumerable<ReportDefinitionMetadata>> GetAllReports(bool includeDrafts = true);

        Task<IEnumerable<ReportDefinitionMetadata>> GetUserAccessibleSystemReports(bool includeDrafts = true);

        IEnumerable<ReportDefinitionMetadata> GetAllSystemReportDefinitions();
        Task<IEnumerable<Guid>> GetUserAccessibleSystemReportIds(List<string> reportNames, bool includeDrafts = true);
        List<DeletedItem>? GetArchivedFilters(Guid reportId);

        Task<ReportDefinitionMetadata?> GetReportDefinition(Guid reportId, bool includeAccessibleFieldAndFilter = true);

        Task<ReportDefinitionQuery> GetQueryDefinition(Guid reportId);

        IEnumerable<ReportFragmentDefinitionQuery> GetReportFragmentQueryDefinition(List<Guid> reportIds);

        bool HasAccessToDataArea(UserResource user, IEnumerable<DataArea> defaultDataAreas, IEnumerable<DataAccess.Entities.DataAreaAccess> dataAccesses, string? dataAreaKey);
    }
}
