﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IFiltersMacroResolver
    {
        Task<string[]> GetMacroValues(string macroName, Guid tenantId, string userId);
    }
}
