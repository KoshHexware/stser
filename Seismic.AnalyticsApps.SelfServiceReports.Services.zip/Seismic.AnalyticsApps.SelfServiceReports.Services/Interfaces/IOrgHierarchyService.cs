﻿

using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Platform.UserManagement.Model;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IOrgHierarchyService
    {
        /// <summary>
        /// Returns a list of all direct and indirect repoters for a manager. Cached for 20 min
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="managerUserId"></param>
        /// <param name="forceRefresh"></param>
        /// <returns></returns>
        Task<List<HierarchyUserResource>> GetAllReportsForManager(Guid tenantId, string managerUserId, bool forceRefresh = false);

        /// <summary>
        /// Returns a list of all direct repoters for a manager. Cached for 20 min
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="managerUserId"></param>
        /// <param name="forceRefresh"></param>
        /// <returns></returns>
        Task<List<HierarchyUserResource>> GetDirectReportsForManager(Guid tenantId, string managerUserId, bool forceRefresh = false);

        Task<TenantSettings> GetTenantOrgHierarchySettings(Guid tenantId);

        Task<UserResource> GetUserById(Guid tenantId, string userId, bool forceRefresh = false);

        Task<HierarchyLevel> GetCurrentUserHierarchyLevel(Guid tenantId, string userId);
    }
}
