﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.DataArea;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.Platform.UserManagement.Model;
namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces    
{
    public interface IDataAreasService
    {
        Task<List<DataAreaAccessModel>> GetAllDataAreasAccess(Guid tenantId, string? searchText = null, string? dataAreaId = null, string? domainNames = null, string? userOruserGroupIds = null);
        
        Task<List<DataAreaAccessModel>> UpdateAccessForAllDataAreas(AccessType DataAccessType, string userId, Guid tenantId);
        
        Task<List<DataAreaAccessModel>> UpdateDataAreas(List<DataAreaAccessModel> dataAreas, string userId, Guid tenantId);
        
        Task<bool> ResetAllAccess(string userId, Guid tenantId);

        bool HasAccessToDataArea(UserResource user, IEnumerable<DataArea> defaultDataAreas, IEnumerable<DataAccess.Entities.DataAreaAccess> dataAccesses, string? dataAreaKey);
    }
}
