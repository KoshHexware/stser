﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface INewRelicCustomEventHelper
    {
        public bool RecordCustomEvent(string customEventKey, SsrsReportEvent customEventModel);
    }
}
