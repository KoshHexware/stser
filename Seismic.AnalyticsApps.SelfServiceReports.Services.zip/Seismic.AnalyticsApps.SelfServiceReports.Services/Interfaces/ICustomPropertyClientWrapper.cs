﻿using Seismic.CustomProperty.Model;
using Seismic.CustomProperty.Client;
using Seismic.Foreshock.Value;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface ICustomPropertyClientWrapper
    {
        Task<ResourceResponse<ResourceList<CustomPropertyResource>>> GetAllCustomPropertiesAsync(string tenantId, FilterExpression options);
    }
}
