﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IDediClient
    {
        public Task<CRMMetadataResponse?> GetCRMMetadataAsync(Guid tenantId, string platformToken, bool refreshCache);
    }
}
