﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IReportService
    {
        Task<PagedList<ReportSummary>> GetAllReports(Guid tenantId, string userId, string? reportType = null, string? searchText = null,
            int take = 200, int skip = 0, string? orderField = null, string? orderBy = null, bool includeDrafts = true);
        Task<List<ReportIdNameModel>> GetSystemAndOwnedReports(Guid tenantId, string userId, string? searchText = null,
            bool includeDrafts = true, bool ownedReportsOnly = false);

        Task<Report> GetReportById(Guid reportId, Guid tenantId, string userId, bool forceRefresh = false);

        Task<(ReportDefinitionMetadata, string)> GetReportDefinition(Guid reportId, Guid tenantId);

        Task<PagedList<RecentReport>> GetRecentReports(string userId, Guid tenantId, string? reportType = null, string? searchText = null,
            int take = 200, int skip = 0, string? orderField = null, string? orderBy = null);

        Task AddToRecentReports(Guid reportId, DateTime openDate, string userId, Guid tenantId);

        Task<Report> CreateReport(ReportCreateRequest report, string userId, Guid tenantId);

        Task<Report> UpdateReport(ReportUpdateRequest report, string userId, Guid tenantId);

        Task DeleteCustomReportById(Guid reportId, string userId, Guid tenantId);

        Task<List<FilterTemplateModel>> GetReportFilters(Guid reportId, Guid tenantId);

        Task UpdateReportName(Guid reportId, string reportName, string userId, Guid tenantId);
        Task UpdateReportDescription(Guid reportId, string description, string userId, Guid tenantId);
        Task UpdateReportOwner(Guid reportId, string proposedOwnerId, Guid tenantId);
    }
}
