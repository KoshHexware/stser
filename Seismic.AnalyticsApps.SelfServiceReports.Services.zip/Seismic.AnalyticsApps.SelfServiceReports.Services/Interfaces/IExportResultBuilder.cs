﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces
{
    public interface IExportResultBuilder
    {
        ExportResult Build(IList<UserProperty> userProperties, IList<ContentCustomProperty> contentCustomProperties, ReportDefinitionMetadata reportMetadata,
            QueryResult queryResult, List<ReportExecutionField> fields, int totalRecordsColumnIndex, string? timezoneId);
    }
}
