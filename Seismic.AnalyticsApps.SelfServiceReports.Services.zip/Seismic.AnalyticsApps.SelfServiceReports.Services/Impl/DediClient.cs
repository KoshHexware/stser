﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Matrix.Client;
using Serilog;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;

public class DediClient(HttpClient _httpClient, IMatrixClient _matrixClient, ISeismicRedisCache _cache, ILogger logger): IDediClient
{
    private readonly ILogger _logger = logger.ForContext<DediClient>();

    public async Task<CRMMetadataResponse?> GetCRMMetadataAsync(Guid tenantId, string platformToken, bool refreshCache)
    {
        var cacheKey = new TenantCRMMetadataKey(tenantId);
        if (!refreshCache)
        {
            var cached = await _cache.GetAsync(cacheKey);
            if (cached != null)
            {
                return cached;
            }
        }

        var serviceUrl = await _matrixClient.GetServiceEndpointByTenantAsync(ServiceAliasConstants.DEDI, tenantId);

        if (string.IsNullOrWhiteSpace(serviceUrl))
        {
            _logger.Warning("Failed to get service url for DEDI. TenantId:{tenantId}", tenantId);
            return null;
        }

        var relativeUrl = $"/api/services/disc/v1/Metadata/tenants/{tenantId}";
        var uri = new Uri(new Uri(serviceUrl), relativeUrl);
        var url = uri.AbsoluteUri;

        _httpClient.DefaultRequestHeaders.Clear();
        _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {platformToken}");

        _logger.Information("Begin crm metadata call. Url:{url}", url);

        var response = await _httpClient.GetAsync(url);

        if (!response.IsSuccessStatusCode)
        {
            _logger.Warning("Failed to get CRM metadata. Url:{url} StatusCode:{statusCode}", url, response.StatusCode);
            return null;
        }
        response.EnsureSuccessStatusCode();

        if(response.Content == null)
        {
            _logger.Warning("Error in crm metadata call. content is null, Url:{url} StatusCode:{statusCode}", url, response.StatusCode);
            return null;
        }

        var content = await response.Content.ReadAsStringAsync();
        _logger.Information("End EDI call to get CRM metadata. Url:{url}s", url);
        var responseObj = JsonSerializer.Deserialize<CRMMetadataResponse>(content, JsonSerializerCustomOptions.Default);
        if (responseObj != null)
        {
            await _cache.SetAsync(cacheKey, responseObj);
        }
        
        return responseObj;
    }
}
