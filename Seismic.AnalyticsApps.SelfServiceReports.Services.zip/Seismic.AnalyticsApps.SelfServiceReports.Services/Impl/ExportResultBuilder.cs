﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Serilog;
using System.Diagnostics;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class ExportResultBuilder(ILogger logger) : IExportResultBuilder
    {
        private readonly ILogger _logger = logger.ForContext<ExportResultBuilder>();

        public ExportResult Build(IList<UserProperty> userProperties,
            IList<ContentCustomProperty> contentCustomProperties, ReportDefinitionMetadata reportMetadata,
            QueryResult queryResult, List<ReportExecutionField> fields, int totalRecordsColumnIndex, string? timezoneId)
        {
            var inputOutputColumnIndexesMap = BuildInputOutputColumnsMap(fields, queryResult, totalRecordsColumnIndex);

            var result = new ExportResult() { Columns = [], Rows = [] };

            var sw = Stopwatch.StartNew();


            var allowedFields = reportMetadata.FieldGroups.SelectMany(fg => fg.Fields);

            var allowedFieldNames = fields?.Select(f => f.Name).ToHashSet(StringComparer.OrdinalIgnoreCase) ?? new HashSet<string>();
            var requestedFields = reportMetadata.FieldGroups
                .SelectMany(fg => fg.Fields)
                .Where(f => allowedFieldNames.Contains(f.Name))
                .ToList();


            //rebuild rows - place items at the desired index based on the order of the field names
            foreach (var item in queryResult.Rows)
            {
                ConvertTimeZones(queryResult.Columns, timezoneId, item, requestedFields, sw);

                var row = new string[queryResult.Columns.Count - 1];

                foreach (var kvp in inputOutputColumnIndexesMap)
                {
                    if (kvp.Key == totalRecordsColumnIndex)
                    {
                        continue;
                    }
                    var sourceLocation = kvp.Key; //this is the location in the data coming from snowflake.

                    //this is the location in the output row
                    var targetLocation = kvp.Value > totalRecordsColumnIndex ? kvp.Value - 1 : kvp.Value;

                    row[targetLocation] = item[sourceLocation] ?? string.Empty;
                }

                result.Rows.Add(row);
            }

            _logger.Information("Time taken to convert timezones: {time}", sw.Elapsed);

            var reportFieldNameAndLabelDictionary = allowedFields.ToDictionary(field => field.Name.ToLowerInvariant(), field => field.UxLabel);

            var (userPropertyQueryAliases, contentCustomPropertyQueryAliases) = UpdateColumnLabelsForExport(reportMetadata, queryResult.Columns,
                reportFieldNameAndLabelDictionary, userProperties, contentCustomProperties);

            reportFieldNameAndLabelDictionary.Add(ReportConstants.TOTAL_RECORDS_COLUMN_NAME, "TOTALRECORDS");

            //the labels are needed in export but not in the execute query.
            result.Columns = GetOrderedFieldLabelsList(userPropertyQueryAliases, contentCustomPropertyQueryAliases, reportFieldNameAndLabelDictionary, fields.Select(x => x.Name).ToList());

            return result;
        }

        public static void ConvertTimeZones(IList<Column> columns, string? timezoneId, string[] item, List<ReportField> fields, Stopwatch sw)
        {
            if (timezoneId == null)
            {
                return;
            }
            sw.Start();
            for (int i = 0; i < item.Length; i++)
            {
                if ((columns[i].DataType == "TIMESTAMP_TZ" || columns[i].DataType == "DATE") && !string.IsNullOrWhiteSpace(item[i]))
                {
                    var field = fields.Where(x => x.Name.ToLowerInvariant() == columns[i].Name.ToLowerInvariant()).FirstOrDefault();
                    //If a date-related field in the DataGrid is hidden but applied as a filter, it should not be included in the exported file.
                    if (field != null)
                    {
                        if (DateTime.TryParse(item[i], out var dt))
                        {
                            item[i] = field.DataType == DataType.Date ? dt.ToString("yyyy-MM-dd")
                                : TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dt, timezoneId).ToString("yyyy-MM-dd hh:mm:ss tt");
                        }
                    }
                }
            }
            sw.Stop();
        }

        private Dictionary<int, int> BuildInputOutputColumnsMap(List<ReportExecutionField> fields, QueryResult queryResult, int totalRecordsColumnIndex)
        {
            var fieldNamesLower = GetFieldNamesLower(queryResult, fields, totalRecordsColumnIndex);

            var columnIndexColNameMap = queryResult.Columns.Select((c, index) => new { c, index }).ToDictionary(x => x.c.Name.ToLowerInvariant(), x => x.index);

            var customFields = fields.Where(f => f.PropertyType == Models.ReportRunner.PropertyType.UserProperty || f.PropertyType == Models.ReportRunner.PropertyType.ContentCustomProperty)
                .ToDictionary(x => x.Name.ToLowerInvariant(), x => x);

            var inputOutputColumnIndexesMap = new Dictionary<int, int>();
            var notFoundColumns = new Dictionary<string, int>();

            for (int i = 0; i < fieldNamesLower.Count; i++)
            {
                var item = fieldNamesLower[i];

                if (columnIndexColNameMap.TryGetValue(item, out var index))
                {
                    inputOutputColumnIndexesMap.Add(index, i);
                }
                else if (customFields.TryGetValue(item, out var cf) && cf != null)
                {
                    var key = (cf.PropertyType + cf.PropertyId?.Replace("-", ""))?.ToLowerInvariant();
                    if (key != null && columnIndexColNameMap.TryGetValue(key, out var target))
                    {
                        var fieldIndex = fieldNamesLower.IndexOf(cf.Name.ToLowerInvariant());
                        inputOutputColumnIndexesMap.Add(target, fieldIndex);
                    }
                    else
                    {
                        notFoundColumns.Add(item, i);
                    }
                }
                else
                {
                    notFoundColumns.Add(item, i);
                }
            }

            if (notFoundColumns.Count > 0)
            {
                //should not come here.
                _logger.Warning("Export warning - Fields not found in query result: {fields}", string.Join(",", notFoundColumns));
            }

            return inputOutputColumnIndexesMap;
        }

        private static List<string> GetFieldNamesLower(QueryResult queryResult, List<ReportExecutionField> fields, int totalRecordsColumnIndex)
        {
            var fieldNamesLower = fields.Select(x => x.Name.ToLowerInvariant()).ToList();

            if (totalRecordsColumnIndex > -1)
            {
                if (totalRecordsColumnIndex == 0 || (fieldNamesLower.Count == (queryResult.Columns.Count - 1)))
                {
                    fieldNamesLower.Insert(totalRecordsColumnIndex, ReportConstants.TOTAL_RECORDS_COLUMN_NAME);
                }
                else if (totalRecordsColumnIndex > 0)
                {
                    if (fieldNamesLower.Count > (queryResult.Columns.Count - 1))
                    {
                        //number of fields requested is more than number of columns - don't know which field was not provided
                        fieldNamesLower.Insert(totalRecordsColumnIndex, ReportConstants.TOTAL_RECORDS_COLUMN_NAME);
                    }
                    else if (fieldNamesLower.Count < (queryResult.Columns.Count - 1))
                    {
                        //number of fields requested is less than number of columns - don't know which field was added in the query.
                        // so add at the end.
                        fieldNamesLower.Add(ReportConstants.TOTAL_RECORDS_COLUMN_NAME);
                    }
                }
            }

            return fieldNamesLower;
        }

        private static (List<ReportField>, List<ReportField>) UpdateColumnLabelsForExport(ReportDefinitionMetadata reportMetadata, IList<Column> columns,
    Dictionary<string, string> reportFieldNameAndLabelDictionary, IList<UserProperty> userProperties, IList<ContentCustomProperty> contentCustomProperties)
        {
            var userPropertyQueryAliases = new List<ReportField>();
            var contentCustomPropertyQueryAliases = new List<ReportField>();
            var userPropertiesDict = userProperties.ToDictionary(up => (CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS + up.Id.Replace("-", "")).ToLowerInvariant(), up => up);
            var customPropertiesDict = contentCustomProperties.ToDictionary(cp => (CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS + cp.Id.Replace("-", "")).ToLowerInvariant(), cp => cp);

            //column rename for export only.
            for (int i = 0; i < columns.Count; i++)
            {
                var found = reportFieldNameAndLabelDictionary.TryGetValue(columns[i].Name.ToLowerInvariant(), out var fieldLabel);
                if (found && !string.IsNullOrWhiteSpace(fieldLabel))
                {
                    columns[i].Name = fieldLabel;
                }
                else if (reportMetadata.IncludeUserProperties && userProperties?.Count > 0 && columns[i].Name.StartsWith(CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS, StringComparison.OrdinalIgnoreCase))
                {
                    UpdateColumnLabelForUserProps(columns[i], userPropertiesDict, userPropertyQueryAliases);
                }
                else if (reportMetadata.IncludeCustomProperties && contentCustomProperties?.Count > 0 && columns[i].Name.StartsWith(CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS, StringComparison.OrdinalIgnoreCase))
                {
                    UpdateColumnLabelForContentCustomProps(columns[i], customPropertiesDict, contentCustomPropertyQueryAliases);
                }
            }

            return (userPropertyQueryAliases, contentCustomPropertyQueryAliases);
        }

        private static void UpdateColumnLabelForContentCustomProps(Column col, Dictionary<string, ContentCustomProperty> propsMap, List<ReportField> properties)
        {
            if (propsMap.TryGetValue(col.Name.ToLowerInvariant(), out var prop) && prop != null)
            {
                col.Name = prop.Name;
                properties.Add(new ReportField
                {
                    Name = prop.Name,
                    PropertyId = prop.Id,
                    UxLabel = prop.Name,
                    UxDescription = prop.Description ?? string.Empty,
                    Definition = prop.Definition ?? string.Empty,
                });
            }
        }

        private static void UpdateColumnLabelForUserProps(Column col, Dictionary<string, UserProperty> propsMap, List<ReportField> properties)
        {
            if (propsMap.TryGetValue(col.Name.ToLowerInvariant(), out var prop) && prop != null)
            {
                col.Name = prop.Name;
                properties.Add(new ReportField
                {
                    Name = prop.Name,
                    PropertyId = prop.Id,
                    UxLabel = prop.Name,
                    UxDescription = prop.Description ?? string.Empty,
                    Definition = prop.Definition ?? string.Empty,
                });
            }
        }

        private static List<string> GetOrderedFieldLabelsList(List<ReportField> userPropertyQueryAliases, List<ReportField> contentCustomPropertyQueryAliases,
            Dictionary<string, string> reportFieldNameAndLabelDictionary, List<string> requestedFields)
        {
            var orderedFieldLabels = requestedFields.ToDictionary(x => x, x => x);
            foreach (var field in requestedFields)
            {
                if (reportFieldNameAndLabelDictionary.ContainsKey(field.ToLower()))
                {
                    orderedFieldLabels[field] = reportFieldNameAndLabelDictionary[field.ToLower()];
                }
                else
                {
                    var newKey = userPropertyQueryAliases.SingleOrDefault(x => (x.Name + x.PropertyId).Replace("-", "").Equals(field, StringComparison.CurrentCultureIgnoreCase));
                    if (newKey != null)
                    {
                        orderedFieldLabels[field] = newKey.UxLabel;
                    }
                    else
                    {
                        var newContentKey = contentCustomPropertyQueryAliases.SingleOrDefault(x => (x.Name + x.PropertyId).Replace("-", "").Equals(field, StringComparison.CurrentCultureIgnoreCase));
                        if (newContentKey != null)
                        {
                            orderedFieldLabels[field] = newContentKey.UxLabel;
                        }
                    }
                }
            }

            return orderedFieldLabels.Values.ToList();
        }
    }
}
