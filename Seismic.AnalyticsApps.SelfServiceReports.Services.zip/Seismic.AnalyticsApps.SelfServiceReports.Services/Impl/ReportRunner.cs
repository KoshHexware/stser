using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Serilog;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class ReportRunner(IDiscClient _discClient, IQueryService _queryService, IReportService _reportService, ILogger logger,
        ICustomPropertyService _customPropertyService, ISeismicRedisCache _cache, ISeismicContextProvider _contextProvider, ICMService _cmService, IOrgHierarchyService _orgHierarchyService) : IReportRunner
    {
        private const int MAX_ROWS_EXPORT = 250000;

        private readonly ILogger _logger = logger.ForContext<ReportRunner>();

        public async Task<Query> GetQuery(Guid reportId, Guid tenantId, int skip, int take, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? selectedTeamsites = null)
        {
            //Get system report with available fields and filter only
            var (reportToRun, reportName) = await _reportService.GetReportDefinition(reportId, tenantId);
            var selectedTeamsitesArray = DeserializeSelectedTeamsites(selectedTeamsites);
            if (reportToRun.ShowTeamsitePicker)
            {
                await EnsureTeamsitesAccessible(selectedTeamsitesArray);
            }
            var (validFilters, abortExecution) = await ValidateFilters(tenantId, filters, reportId, reportName, userId);
            if (abortExecution)
            {
                throw new ArgumentException($"Report {reportId} cannot be executed as it contains relative user filters that are not applicable for the current user context.");
            }
            var validFields = DeserializeFields(fields);

            var userProperties = await _customPropertyService.GetUserCustomProperties(tenantId);
            var contentCustomProperties = await _customPropertyService.GetContentCustomProperties(tenantId);

            var result = await _queryService.CreateQuery(reportToRun, validFilters, userProperties, contentCustomProperties, skip, take, orderField, orderBy, validFields, selectedTeamsitesArray);
            result.Sql = result.Sql.RemoveEmptyLines();
            return result;
        }

        public async Task<ReportResult> RunReport(Guid reportId, Guid tenantId, int skip, int take, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? selectedTeamsites = null, bool? showTeamsitePicker = false)
        {
            var selectedTeamsitesArray = DeserializeSelectedTeamsites(selectedTeamsites);
            if (showTeamsitePicker.HasValue && showTeamsitePicker.Value)
            {
                await EnsureTeamsitesAccessible(selectedTeamsitesArray);
            }

            
            // here get system report with available fields and filter only

            var (reportToRun, reportName) = await _reportService.GetReportDefinition(reportId, tenantId);
            var (validFilters, abortExecution) = await ValidateFilters(tenantId, filters, reportId, reportName, userId);
            if (abortExecution)
            {
                return new ReportResult
                {
                    Pagination = new Pagination
                    {
                        Skip = skip,
                        Take = take,
                        TotalRecords = 0
                    },
                    Data = []
                };
            }
            var validFields = DeserializeFields(fields);

            var userProperties = await _customPropertyService.GetUserCustomProperties(tenantId);
            var contentCustomProperties = await _customPropertyService.GetContentCustomProperties(tenantId);

            var query = await _queryService.CreateQuery(reportToRun, validFilters, userProperties, contentCustomProperties, skip, take, orderField, orderBy, validFields, selectedTeamsitesArray, true);

            var queryResult = await _discClient.ExecuteGenericQuery(query.Sql, reportName, query.StringParams, query.DateParams, query.BoolParams, query.IntParams, query.DecimalParams, query.MultiStringParams);

            var result = await BuildReportResult(reportId, reportToRun, tenantId, queryResult, skip, take, validFields);

            return result;
        }


        public async Task<(ReportResult Result, Report Report)> ExecuteReportWithDefaults(Report report, Guid tenantId, int? skip, int? take, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? selectedTeamsites = null, bool? showTeamsitePicker = false, bool? isDrillIn = false)
        {
            var validFields = DeserializeFields(fields);
            string fieldsForExecution = fields;

            // Use provided fields or fall back to report's configured fields
            if (validFields.Count != 0)
            {
                foreach (var field in validFields)
                {
                    var reportField = report.RequestedFields.FirstOrDefault(f => f.Name.Equals(field.Name, StringComparison.InvariantCultureIgnoreCase));
                    if (reportField != null)
                    {
                        field.IsProperty = reportField.IsProperty;
                        field.PropertyType = (Models.ReportRunner.PropertyType?)reportField.PropertyType;
                        field.PropertyId = reportField.PropertyId;
                    }
                }

                fieldsForExecution = JsonSerializer.Serialize(validFields);
            }
            else
            {
                fieldsForExecution = JsonSerializer.Serialize(report.RequestedFields.Where(f => f.IsDefault).Select(f => new
                {
                    name = f.Name,
                    isproperty = f.IsProperty,
                    propertytype = f.PropertyType,
                    propertyid = f.PropertyId
                }).ToList());
            }

            // If no fields and filters are provided, use the report's configured filters
            string filtersForExecution = filters;
            if (validFields.Count == 0 && string.IsNullOrWhiteSpace(filters) && report.AppliedFilters != null)
            {
                filtersForExecution = JsonSerializer.Serialize(report.AppliedFilters.Select(f => new
                {
                    filtername = f.FilterName,
                    operation = f.Operation,
                    values = f.Values,
                    isproperty = f.IsProperty,
                    propertytype = f.PropertyType,
                    propertyid = f.PropertyId,
                    teamsiteids = f.TeamsiteIds
                }).ToList());
            }

            // Use provided order field/direction or fall back to report's configuration
            string reportOrderField = orderField ?? report.OrderField;
            string reportOrderBy = orderBy ?? report.OrderBy.ToString();

            // If no order field is specified, default to the first field in the report
            int skipValue = skip ?? 0;
            int takeValue = take ?? 1000;

            // If no Teamsites are specified, use the report's configured Teamsites
            string? selectedTeamsiteIds = null;
            if (showTeamsitePicker ?? false)
            {
                if (string.IsNullOrWhiteSpace(selectedTeamsites))
                {
                    //if drill-in, select all teamsites user has access to, else select only user selected teamsites
                    selectedTeamsiteIds = !(isDrillIn.HasValue && isDrillIn.Value) ? JsonSerializer.Serialize(report.Teamsites?.Where(x => x.IsSelected).Select(t => t.Id)) :
                            JsonSerializer.Serialize(report.Teamsites?.Select(t => t.Id));
                }
                
                else
                {
                    //select all report teamsitesand make the isSelected porp of each teamsite true which is in selectedTeamsites
                    var selectedTeamsiteIdsArray = DeserializeSelectedTeamsites(selectedTeamsites);
                    if (showTeamsitePicker.HasValue && showTeamsitePicker.Value)
                    {
                        await EnsureTeamsitesAccessible(selectedTeamsiteIdsArray);
                        selectedTeamsiteIds = JsonSerializer.Serialize(selectedTeamsiteIdsArray);
                    }

                }
            }

            //Report will only have RequestedFields, AppliedFilters, OrderField, OrderBy and Teamsites  that are executed
            var appliedFields = DeserializeFields(fieldsForExecution);
            var appliedFilters = FilterValidator.DeserializeFilters(filtersForExecution);
            var fieldsToBeExecuted = appliedFields
            .Select(af => report.StandardReportMetadata.FieldGroups
                .SelectMany(fg => fg.Fields)
                .FirstOrDefault(f => string.Compare(af.Name, f.Name, StringComparison.OrdinalIgnoreCase) == 0))
            .Where(f => f != null)
            .Select(f =>
            {
                f.IsDefault = true; // Set IsDefault to true for all fields in the result
                return f;
            })
            .ToList();

            var teamsites = report.Teamsites?.Select(t => new Models.Teamsites
            {
                Id = t.Id,
                Name = t.Name,
                Description = t.Description,
                IsSelected = DeserializeSelectedTeamsites(selectedTeamsiteIds).Contains(t.Id)
            }).ToList();
            report.RequestedFields = fieldsToBeExecuted;
            report.AppliedFilters = appliedFilters;
            report.OrderField = reportOrderField;
            report.OrderBy = (OrderType)Enum.Parse(typeof(OrderType), reportOrderBy, true);
            report.Teamsites = teamsites;

            var result = await RunReport(report.Id, tenantId, skipValue, takeValue, userId, filtersForExecution, fieldsForExecution, reportOrderField, reportOrderBy, selectedTeamsiteIds, showTeamsitePicker);

            return (result, report);
        }

        public async Task<ExportResult> ExportReport(Guid reportId, Guid tenantId, string userId, string? filters = null, string? fields = null, string? orderField = null, string? orderBy = null, string? timezoneId = null, string? selectedTeamsites = null, bool? showTeamsitePicker = false, bool? isDrillIn = false)
        {
            var selectedTeamsitesArray = DeserializeSelectedTeamsites(selectedTeamsites);
            if (showTeamsitePicker.HasValue && showTeamsitePicker.Value)
            {
                await EnsureTeamsitesAccessible(selectedTeamsitesArray);

                //if drill-in, select all teamsites user has access to
                if (isDrillIn.HasValue && isDrillIn.Value)
                {
                    var accessibleTeamsites = await _cmService.GetUserAccessibleTeamsitesAsync(tenantId, userId);
                    selectedTeamsitesArray = accessibleTeamsites.Select(t => t.Id).ToArray();
                }
               
            }

            // here get system report with available fields and filter only
            var (reportToRun, reportName) = await _reportService.GetReportDefinition(reportId, tenantId);
            var (validFilters, abortExecution) = await ValidateFilters(tenantId, filters, reportId, reportName, userId);

            var validFields = DeserializeFields(fields);

            var userProperties = await _customPropertyService.GetUserCustomProperties(tenantId);
            var contentCustomProperties = await _customPropertyService.GetContentCustomProperties(tenantId);

            if (abortExecution)
            {
                _logger.Warning("Report {reportId} cannot be executed as it contains relative user filters that are not applicable for the current user context.", reportId);
                var result = new QueryResult() { Columns = [], Rows = [], TotalRowCount = 0 };
                var totalRecordsColumnIndex1 = GetTotalRecordsColumn(reportId, tenantId, result, out var _);
                return new ExportResultBuilder(_logger).Build(userProperties, contentCustomProperties, reportToRun, result, validFields, totalRecordsColumnIndex1, timezoneId);
            }

            var query = await _queryService.CreateQuery(reportToRun, validFilters, userProperties, contentCustomProperties, 0, MAX_ROWS_EXPORT, orderField, orderBy, validFields, selectedTeamsitesArray);

            var queryResult = await _discClient.ExecuteGenericQuery(query.Sql, reportName, query.StringParams, query.DateParams, query.BoolParams, query.IntParams, query.DecimalParams, query.MultiStringParams);

            var totalRecordsColumnIndex = GetTotalRecordsColumn(reportId, tenantId, queryResult, out var _);
            return new ExportResultBuilder(_logger).Build(userProperties, contentCustomProperties, reportToRun, queryResult, validFields, totalRecordsColumnIndex, timezoneId);
        }

        /// <summary>
        /// Ensures that the requested or selected teamsites are accessible by the user
        /// </summary>
        /// <param name="selectedTeamsites"></param>
        /// <returns></returns>
        /// <exception cref="ForbiddenException"></exception>
        private async Task EnsureTeamsitesAccessible(string[]? selectedTeamsites)
        {
            if (selectedTeamsites == null || selectedTeamsites.Length == 0)
            {
                return;
            }
            var context = _contextProvider.GetContext();
            var accessibleTeamsites = await _cmService.GetUserAccessibleTeamsitesAsync(context.TenantIdentifier.TenantUniqueId, context.UserId);
            var inaccessibleTeamsites = selectedTeamsites.Except(accessibleTeamsites.Select(t => t.Id));
            if (inaccessibleTeamsites?.Count() > 0)
            {
                _logger.Error("User:{userId} does not have access to teamsites:{teamsites}", context.UserId, string.Join(",", inaccessibleTeamsites));
                throw new ForbiddenException($"User {context.UserId} does not have access to requested teamsites.");
            }
        }

        private async Task<(List<UserProperty>, List<ContentCustomProperty>)> GetUserAndContentCustomProps(ReportDefinitionMetadata reportMetadata, Guid tenantId)
        {
            var userProperties = new List<UserProperty>();
            var contentCustomProperties = new List<ContentCustomProperty>();
            if (reportMetadata.IncludeUserProperties || reportMetadata.IncludeCustomProperties)
            {
                var userPropertiesTask = _customPropertyService.GetUserCustomProperties(tenantId);
                var contentCustomPropertiesTask = _customPropertyService.GetContentCustomProperties(tenantId);
                await Task.WhenAll(userPropertiesTask, contentCustomPropertiesTask);
                userProperties = userPropertiesTask.Result?.ToList() ?? [];
                contentCustomProperties = contentCustomPropertiesTask.Result?.ToList() ?? [];
            }

            return (userProperties, contentCustomProperties);
        }


        private async Task<(List<CreateQueryFilterModel>, bool)> ValidateFilters(Guid tenantId, string? filters, Guid requestedReportId, string reportName, string userId)
        {
            var appliedFilters = FilterValidator.DeserializeFilters(filters);
            appliedFilters = [.. appliedFilters.Where(f => f.Operation != Operation.None)];
            var reportFiltersMetadata = await _reportService.GetReportFilters(requestedReportId, tenantId);

            // Check for if user has selected only MyTeam operator and user is indiviusal contributor
            var isMyTeamOperatorSelected = appliedFilters.Any(x => x.Operation == Operation.IsMyTeam && (x.Values?.Length == 1 &&
            (x.Values[0] == RelativeMyTeamFilterValues.IncludeIndirectReports.ToDisplayString()
            || x.Values[0] == RelativeMyTeamFilterValues.IncludeDirectReports.ToDisplayString())));

            var orgHierarchySettings = await _orgHierarchyService.GetTenantOrgHierarchySettings(tenantId);
            if (isMyTeamOperatorSelected && (!orgHierarchySettings.IsOrgHierarchyEnabled || !orgHierarchySettings.HasOrgHierarchy))
            {
                _logger.Error("Report {ReportName} cannot be executed as it contains relative user filters that are not applicable for the current user context.", reportName);
                throw new ArgumentException($"Report {reportName} cannot be executed as it contains relative user filters that are not applicable for the current user context.");
            }

            var isCurrentUserOperationSelected = appliedFilters.Any(x => x.Operation == Operation.IsCurrentUser);
            var hierarchyLevel = orgHierarchySettings.IsOrgHierarchyEnabled ? await _orgHierarchyService.GetCurrentUserHierarchyLevel(tenantId, userId) : HierarchyLevel.IC;
            if ((hierarchyLevel == HierarchyLevel.IC) && isMyTeamOperatorSelected && !isCurrentUserOperationSelected)
            {
                return (new List<CreateQueryFilterModel>(), true);
            }
            appliedFilters = await ReplaceFilterWithRelativeUserFilterFieldAsync(appliedFilters, reportFiltersMetadata);
            var selectedFiltersMetadata = reportFiltersMetadata.Where(f => appliedFilters.Any(sf => string.Compare(sf.FilterName, f.FilterName, true) == 0)).ToList();
            return (FilterValidator.ValidateFilters(appliedFilters, selectedFiltersMetadata, reportName), false);
        }

        private async Task<List<ReportExecutionFilter>> ReplaceFilterWithRelativeUserFilterFieldAsync(List<ReportExecutionFilter> appliedFilters, List<FilterTemplateModel> reportFiltersMetadata)
        {
            if (appliedFilters == null || appliedFilters.Count == 0 || reportFiltersMetadata == null || reportFiltersMetadata.Count == 0)
            {
                return appliedFilters;
            }

            var allRelativeUserFilters = appliedFilters.Where(f => f.Operation == Operation.IsCurrentUser || f.Operation == Operation.IsMyTeam);

            if (allRelativeUserFilters.Count() == 0)
            {
                return appliedFilters;
            }

            var nonRelativeUserFilters = appliedFilters.Where(f => f.Operation != Operation.IsCurrentUser && f.Operation != Operation.IsMyTeam).ToList();


            //map EnableRelativeUserFilterField in allRelativeUserFilters from reportFiltersMetadata
            foreach (var filter in allRelativeUserFilters)
            {
                var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == filter.FilterName);
                if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                {
                    filter.EnableRelativeUserFilterField = filterMetadata.EnableRelativeUserFilterField;
                }
            }

            // get all distict EnableRelativeUserFilterField values from the applied relative user filter
            var distinctEnableRelativeUserFilterField = allRelativeUserFilters.Where(f => !string.IsNullOrWhiteSpace(f.EnableRelativeUserFilterField)).Select(f => f.EnableRelativeUserFilterField).Distinct().ToList();

            // Keep the exact same sequence of filter checks for priority order to select most narrow option

            foreach (var enableRelativeUserFilterField in distinctEnableRelativeUserFilterField)
            {
                // STEP 1: Check for current user filter first
                var currentUserOperationSelectedFilter = allRelativeUserFilters.FirstOrDefault(f => f.Operation == Operation.IsCurrentUser && f.EnableRelativeUserFilterField == enableRelativeUserFilterField);
                if (currentUserOperationSelectedFilter != null)
                {
                    var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == currentUserOperationSelectedFilter.FilterName);
                    if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                    {
                        nonRelativeUserFilters = await ReplaceFilterWithValues(
                            nonRelativeUserFilters,
                            currentUserOperationSelectedFilter,
                            filterMetadata.EnableRelativeUserFilterField,
                            HierarchyScopeOptions.CurrentUser);

                        continue;
                    }
                }

                // STEP 2: Check for direct team without me
                var myDirectTeamFilter = allRelativeUserFilters.FirstOrDefault(f => f.Operation == Operation.IsMyTeam
                    && f.EnableRelativeUserFilterField == enableRelativeUserFilterField
                    && (f?.Values?.Length == 0 
                        || (f?.Values?.Length == 1 && f.Values[0] == RelativeMyTeamFilterValues.IncludeDirectReports.ToDisplayString()))
                    );
                if (myDirectTeamFilter != null)
                {
                    var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == myDirectTeamFilter.FilterName);
                    if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                    {
                        nonRelativeUserFilters = await ReplaceFilterWithValues(
                            nonRelativeUserFilters,
                            myDirectTeamFilter,
                            filterMetadata.EnableRelativeUserFilterField,
                            HierarchyScopeOptions.MyDirectTeamWithoutMe);

                        continue;
                    }
                }

                // STEP 3: Check for direct team including me
                var myDirectTeamIncludingMeFilter = allRelativeUserFilters.FirstOrDefault(f => f.Operation == Operation.IsMyTeam
                    && f.EnableRelativeUserFilterField == enableRelativeUserFilterField
                    && f?.Values?.Length == 1
                    && f.Values[0] == RelativeMyTeamFilterValues.IncludeCurrentUser.ToDisplayString());
                if (myDirectTeamIncludingMeFilter != null)
                {
                    var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == myDirectTeamIncludingMeFilter.FilterName);
                    if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                    {
                        nonRelativeUserFilters = await ReplaceFilterWithValues(
                            nonRelativeUserFilters,
                            myDirectTeamIncludingMeFilter,
                            filterMetadata.EnableRelativeUserFilterField,
                            HierarchyScopeOptions.MyDirectTeamIncludingMe);

                        continue;
                    }
                }

                // STEP 4: Check for direct and indirect team without me
                var myDirectAndIndirectTeamWithoutMeFilter = allRelativeUserFilters.FirstOrDefault(f => f.Operation == Operation.IsMyTeam
                    && f.EnableRelativeUserFilterField == enableRelativeUserFilterField
                    && f?.Values?.Length == 1
                    && f.Values[0] == RelativeMyTeamFilterValues.IncludeIndirectReports.ToDisplayString());
                if (myDirectAndIndirectTeamWithoutMeFilter != null)
                {
                    var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == myDirectAndIndirectTeamWithoutMeFilter.FilterName);
                    if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                    {
                        nonRelativeUserFilters = await ReplaceFilterWithValues(
                            nonRelativeUserFilters,
                            myDirectAndIndirectTeamWithoutMeFilter,
                            filterMetadata.EnableRelativeUserFilterField,
                            HierarchyScopeOptions.MyDirectAndIndirectTeamWithoutMe);

                        continue;
                    }
                }

                // STEP 5: Check for direct and indirect team including me
                var myDirectAndIndirectTeamIncludingMeFilter = allRelativeUserFilters.FirstOrDefault(f => f.Operation == Operation.IsMyTeam
                    && f.EnableRelativeUserFilterField == enableRelativeUserFilterField
                    && f?.Values?.Length == 2);
                if (myDirectAndIndirectTeamIncludingMeFilter != null)
                {
                    var filterMetadata = reportFiltersMetadata.SingleOrDefault(rfm => rfm.FilterName == myDirectAndIndirectTeamIncludingMeFilter.FilterName);
                    if (filterMetadata != null && !string.IsNullOrWhiteSpace(filterMetadata.EnableRelativeUserFilterField))
                    {
                        nonRelativeUserFilters = await ReplaceFilterWithValues(
                            nonRelativeUserFilters,
                            myDirectAndIndirectTeamIncludingMeFilter,
                            filterMetadata.EnableRelativeUserFilterField,
                            HierarchyScopeOptions.MyDirectAndIndirectTeamIncludingMe);

                        continue;
                    }
                }
            }

            return nonRelativeUserFilters;
        }

        private async Task<List<ReportExecutionFilter>> ReplaceFilterWithValues(
            List<ReportExecutionFilter> nonRelativeUserFilters,
            ReportExecutionFilter filterToReplace,
            string targetFieldName,
            HierarchyScopeOptions userScopeOption)
        {
            var newAppliedFilters = nonRelativeUserFilters
                .Where(f => f.Operation != Operation.IsCurrentUser && f.Operation != Operation.IsMyTeam && f.FilterName != targetFieldName)
                .ToList();

            filterToReplace.Operation = Operation.IsOneOf;
            filterToReplace.FilterName = targetFieldName;
            filterToReplace.Values = await ExtractTeamFiltersValuesAsync(userScopeOption);

            newAppliedFilters.Add(filterToReplace);
            return newAppliedFilters;
        }
        private async Task<string[]> ExtractTeamFiltersValuesAsync(HierarchyScopeOptions teamsToExtract)
        {
            var teamFilteredValues = new List<string>();
            var context = _contextProvider.GetContext();

            switch (teamsToExtract)
            {
                case var t when t == HierarchyScopeOptions.CurrentUser:
                    {
                        try
                        {
                            var user = await _orgHierarchyService.GetUserById(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            if (user != null)
                            {
                                teamFilteredValues.Add(user.Name);
                            }
                        }
                        catch
                        {
                            _logger.Error("Error extracting current user info for userId:{userId}", context.UserId);
                        }
                        break;
                    }
                case var t when t == HierarchyScopeOptions.MyDirectTeamIncludingMe:
                    {

                        try
                        {
                            var directTeamMembers = await _orgHierarchyService.GetDirectReportsForManager(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            var user = await _orgHierarchyService.GetUserById(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            if (user != null)
                            {
                                teamFilteredValues.Add(user.Name);
                            }
                            teamFilteredValues.AddRange(directTeamMembers.Select(member => member.UserName));
                        }
                        catch
                        {
                            _logger.Error("Error extracting direct team members for userId:{userId}", context.UserId);
                        }
                        break;
                    }
                case var t when t == HierarchyScopeOptions.MyDirectTeamWithoutMe:
                    {

                        try
                        {
                            var directTeamMembers = await _orgHierarchyService.GetDirectReportsForManager(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            teamFilteredValues.AddRange(directTeamMembers.Select(member => member.UserName));
                        }
                        catch
                        {
                            _logger.Error("Error extracting direct team members for userId:{userId}", context.UserId);
                        }
                        break;
                    }
                case var t when t == HierarchyScopeOptions.MyDirectAndIndirectTeamIncludingMe:
                    {
                        try
                        {
                            var teamMembers = await _orgHierarchyService.GetAllReportsForManager(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            var user = await _orgHierarchyService.GetUserById(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            if (user != null)
                            {
                                teamFilteredValues.Add(user.Name);
                            }
                            teamFilteredValues.AddRange(teamMembers.Select(member => member.UserName));
                        }
                        catch
                        {
                            _logger.Error("Error extracting direct and indirect team members for userId:{userId}", context.UserId);
                        }
                        break;
                    }
                case var t when t == HierarchyScopeOptions.MyDirectAndIndirectTeamWithoutMe:
                    {
                        try
                        {
                            var teamMembers = await _orgHierarchyService.GetAllReportsForManager(context.TenantIdentifier.TenantUniqueId, context.UserId);
                            teamFilteredValues.AddRange(teamMembers.Select(member => member.UserName));
                        }
                        catch
                        {
                            _logger.Error("Error extracting direct and indirect team members for userId:{userId}", context.UserId);
                        }
                        break;
                    }
                default:
                    _logger.Warning("Unknown user scope option team:{team}", teamsToExtract);
                    break;
            }
            return teamFilteredValues.ToArray();
        }

        private async Task<ReportResult> BuildReportResult(Guid reportId, ReportDefinitionMetadata reportMetadata, Guid tenantId, QueryResult queryResult, int skip, int take, List<ReportExecutionField> validFields)
        {
            var totalRecordsColumnIndex = GetTotalRecordsColumn(reportId, tenantId, queryResult, out var recordCount);

            var (userProperties, contentCustomProperties) = await GetUserAndContentCustomProps(reportMetadata, tenantId);

            var result = new ReportResult()
            {
                Pagination = new Pagination
                {
                    Skip = skip,
                    Take = take,
                    TotalRecords = recordCount
                },
                Data = []
            };

            var userPropertiesDict = userProperties.ToDictionary(up => (CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS + up.Id.Replace("-", "")).ToLowerInvariant(), up => up);
            var customPropertiesDict = contentCustomProperties.ToDictionary(cp => (CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS + cp.Id.Replace("-", "")).ToLowerInvariant(), cp => cp);

            result.Data = BuildResultDataRows(reportMetadata, queryResult, totalRecordsColumnIndex, userProperties, contentCustomProperties, validFields);

            return result;
        }

        private int GetTotalRecordsColumn(Guid reportId, Guid tenantId, QueryResult queryResult, out int recordCount)
        {
            var totalRecordsColumn = queryResult.Columns.Where(c => c.Name.Equals(ReportConstants.TOTAL_RECORDS_COLUMN_NAME, StringComparison.InvariantCultureIgnoreCase)).SingleOrDefault();

            recordCount = 0;
            var totalRecordsColumnIndex = -1;
            if (totalRecordsColumn == null)
            {
                _logger.Warning("total records not found in reportId:{reportId}, tenantId:{tenantId}", reportId, tenantId);
                //throw new Exception("TotalRecords column not found in query result");
            }
            else
            {
                totalRecordsColumnIndex = queryResult.Columns.ToList().IndexOf(totalRecordsColumn);
                if (queryResult.Rows.FirstOrDefault() != null)
                {
                    recordCount = Convert.ToInt32(queryResult.Rows.First()[totalRecordsColumnIndex]);
                }
            }

            return totalRecordsColumnIndex;
        }

        private static List<dynamic> BuildResultDataRows(ReportDefinitionMetadata reportMetadata, QueryResult queryResult, int totalRecordsColumnIndex, List<UserProperty>? userProperties, List<ContentCustomProperty>? contentCustomProperties, List<ReportExecutionField> validFields)
        {
            var result = new List<dynamic>();
            foreach (var item in queryResult.Rows)
            {
                var row = new Dictionary<string, string>();
                for (int i = 0; i < queryResult.Columns.Count; i++)
                {
                    // Skip if column is total records
                    if (i == totalRecordsColumnIndex)
                    {
                        continue;
                    }

                    string originalColumnName = queryResult.Columns[i].Name;
                    bool isPropertyColumn = false;

                    // Transform user property column names if needed
                    if (reportMetadata.IncludeUserProperties && userProperties?.Count > 0)
                    {
                        foreach (var userProperty in userProperties)
                        {
                            string propertyAlias = (CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS + userProperty.Id).Replace("-", "");
                            if (propertyAlias.Equals(originalColumnName, StringComparison.InvariantCultureIgnoreCase))
                            {
                                queryResult.Columns[i].Name = (userProperty.Name + userProperty.Id).Replace("-", "").ToUpper();
                                isPropertyColumn = true;
                                break;
                            }
                        }
                    }

                    // Transform content custom property column names if needed
                    if (!isPropertyColumn && reportMetadata.IncludeCustomProperties && contentCustomProperties?.Count > 0)
                    {
                        foreach (var customProperty in contentCustomProperties)
                        {
                            string propertyAlias = (CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS + customProperty.Id).Replace("-", "");
                            if (propertyAlias.Equals(originalColumnName, StringComparison.InvariantCultureIgnoreCase))
                            {
                                queryResult.Columns[i].Name = (customProperty.Name + customProperty.Id).Replace("-", "").ToUpper();
                                isPropertyColumn = true;
                                break;
                            }
                        }
                    }

                 
                    if (queryResult.Columns[i].Name.Equals(reportMetadata.PrimaryKeyField, StringComparison.InvariantCultureIgnoreCase) && !string.IsNullOrWhiteSpace(reportMetadata.PrimaryKeyField))
                    {
                        row.Add("PRIMARYKEYFIELD", item[i] ?? string.Empty);
                    }
                    
                        // Include column if it's in validFields OR if it's a property column
                     bool includeColumn = isPropertyColumn ||
                            validFields.Any(f => f.Name.Equals(queryResult.Columns[i].Name, StringComparison.InvariantCultureIgnoreCase));

                    if (!includeColumn)
                    {
                        continue;
                    }

                    row.Add(queryResult.Columns[i].Name, item[i] ?? string.Empty);
                }
                result.Add(row);
            }
            return result;
        }

        private List<ReportExecutionField> DeserializeFields(string? jsonStringFields)
        {
            try
            {
                return string.IsNullOrWhiteSpace(jsonStringFields) ? []
                : JsonSerializer.Deserialize<List<ReportExecutionField>>(jsonStringFields, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase) ?? [];
            }
            catch (JsonException ex)
            {
                _logger.Error(ex, "Error deserializing fields:{fields}", jsonStringFields);
                return [];
            }
        }

        private string[] DeserializeSelectedTeamsites(string? selectedTeamsites)
        {
            if (string.IsNullOrWhiteSpace(selectedTeamsites))
                return [];

            var sanitizedTeamsites = selectedTeamsites.Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
            try
            {
                return string.IsNullOrWhiteSpace(sanitizedTeamsites) ? []
                : JsonSerializer.Deserialize<List<string>>(sanitizedTeamsites, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase)?.ToArray() ?? [];
            }
            catch (JsonException ex)
            {
                _logger.Error(ex, "Error deserializing selected Teamsites:{selectedTeamsites}", sanitizedTeamsites);
                return [];

            }
        }
    }
}
