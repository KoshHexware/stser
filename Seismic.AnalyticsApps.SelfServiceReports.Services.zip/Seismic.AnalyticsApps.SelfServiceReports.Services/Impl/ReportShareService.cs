﻿using Microsoft.AspNetCore.Http;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Matrix.Client;
using Seismic.Platform.UserManagement.Client;
using Seismic.Platform.UserManagement.Model;
using Serilog;
using System.Diagnostics;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class ReportShareService(IUserService _userService, IEntitlementServiceClientWrapper _entitlementService,
        IUserManagementClient _umsClient, IUserInfoProvider _userInfoProvider, INotificationWrapper _notificationWrapper,
        IDataAccessor _dataAccessor, IMatrixClient _matrixClient, ISeismicContextProvider _contextProvider, ILogger logger,
        ISeismicRedisCache _cache, IHttpContextAccessor _httpContextAccessor, INewRelicCustomEventHelper _newRelicCustomEventHelper,
        IReportService _reportService) : IReportShareService
    {
        private readonly ILogger _logger = logger.ForContext<ReportShareService>();

        private readonly string ICON_HOSTING_FORMAT = "custom-report";

        public async Task<List<UserInfoModel>> GetSsrAccessibleUsers(string? searchKeyword, Guid tenantId, bool refreshCache = false)
        {
            var cacheKey = new TenantSSRSAccessibleUsersKey(tenantId);
            if (!refreshCache)
            {
                var cached = await _cache.GetAsync(cacheKey);
                if (cached != null)
                {
                    return cached;
                }
            }

            IEnumerable<string> distinctUserIds;

            var context = _contextProvider.GetContext();
            var useEntitlements = await _contextProvider.GetContext().IsToggleEnabled(LDConstants.SsrUseEntitlementsLDKey);

            if (useEntitlements)
            {
                _logger.Information("Using entitlement based permission model for tenant:", tenantId);
                var viewerPermissionUsersTask = _entitlementService.GetUsersWithSsrAccess(PermissionConstants.SelfServiceReportsViewerPermissionKey, tenantId);
                var editorPermissionUsersTask = _entitlementService.GetUsersWithSsrAccess(PermissionConstants.SelfServiceReportsCreatorPermissionKey, tenantId);

                await Task.WhenAll(viewerPermissionUsersTask, editorPermissionUsersTask);
                var viewerPermissionUsers = viewerPermissionUsersTask.Result;
                var editorPermissionUsers = editorPermissionUsersTask.Result;

                distinctUserIds = editorPermissionUsers.Concat(viewerPermissionUsers).DistinctBy(x => x.AssigneeId).Select(x => x.AssigneeId);
            }
            else
            {
                _logger.Information("Using legacy user group based permission model for tenant:", tenantId);

                var ssrViewerUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsViewer);
                var ssrEditorUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsEditor);
                var ssrCreatorsUgTask = _userService.GetUserGroupByName(tenantId, UserGroupConstants.SelfServiceReportsCreator);

                await Task.WhenAll(ssrViewerUgTask, ssrEditorUgTask, ssrCreatorsUgTask);

                var ssrViewerUg = ssrViewerUgTask.Result;
                var ssrEditorUg = ssrEditorUgTask.Result;
                var ssrCreatorsUg = ssrCreatorsUgTask.Result;

                // Lists to collect user IDs
                var allUsersIds = new List<string>();

                // Process each user group
                var userGroups = new Dictionary<string, GroupResource?>
                {
                    { UserGroupConstants.SelfServiceReportsViewer, ssrViewerUg },
                    { UserGroupConstants.SelfServiceReportsEditor, ssrEditorUg },
                    { UserGroupConstants.SelfServiceReportsCreator, ssrCreatorsUg },
                };

                // Process each user group
                foreach (var (groupName, group) in userGroups)
                {
                    if (group == null)
                    {
                        _logger.Warning("{GroupName} user group not found for tenant {TenantId}", groupName, tenantId);
                        continue;
                    }

                    var result = await _umsClient.GetUserIdsByGroupIdAsync(tenantId.ToString(), group.LegacyId);

                    allUsersIds.AddRange(result.Resource);
                }

                // Get distinct users from collections
                distinctUserIds = allUsersIds.Distinct();
            }

            var userInfoList = await _userInfoProvider.GetUsersDetails(tenantId, distinctUserIds);
            if (!string.IsNullOrWhiteSpace(searchKeyword))
            {
                userInfoList = userInfoList.Where(p => !string.IsNullOrWhiteSpace(p?.FullName) && p.FullName.Contains(searchKeyword, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            await _cache.SetAsync(cacheKey, userInfoList);
            return userInfoList;
        }

        public async Task<UserInfoModel> GetReportOwnerDetails(Guid reportId, Guid tenantId, string contextUserId)
        {
            var reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId) ??
                throw new BadRequestException($"Report not found. report id:{reportId}");

            // Check if the user is the owner
            if (string.IsNullOrWhiteSpace(reportEntity.OwnerUserId) || reportEntity.OwnerUserId != contextUserId)
            {
                _logger.Error("User {ContextUserId} is not the owner of the report {ReportId}. The actual owner is {OwnerUserId}.", contextUserId, reportId, reportEntity.OwnerUserId);
                throw new ForbiddenException($"User {contextUserId} is not the owner of the report {reportId}");
            }

            var userDetails = await _userInfoProvider.GetUsersDetails(tenantId, [reportEntity.OwnerUserId]);

            if (userDetails.Count == 0)
            {
                _logger.Error("Report owner not found. user id:{OwnerUserId}", reportEntity.OwnerUserId);
                throw new BadRequestException($"Report owner not found. user id:{reportEntity.OwnerUserId}");
            }

            return userDetails[0];
        }

        public async Task<List<UserInfoModel>> GetSharedReportUserList(Guid reportId, Guid tenantId)
        {
            var sharedReportUserIds = await _dataAccessor.GetSharedReportUsersAsync(reportId, tenantId);
            return await _userInfoProvider.GetUsersDetails(tenantId, sharedReportUserIds);
        }

        public async Task<List<UserAndUserGroupInfoModel>> GetSharedReportUserAndUserGroupList(Guid reportId, Guid tenantId)
        {
            var sharedReports = await _dataAccessor.GetSharedReportWithUsersAndGroupsAsync(reportId, tenantId);

            if (sharedReports == null || sharedReports.Count == 0)
            {
                return [];
            }

            // Single pass to extract both user IDs and group IDs
            var sharedReportUserIds = new List<string>();
            var sharedReportGroupIds = new List<string>();

            foreach (var sr in sharedReports)
            {
                if (!string.IsNullOrEmpty(sr.UserId))
                    sharedReportUserIds.Add(sr.UserId);
                if (!string.IsNullOrEmpty(sr.UserGroupId))
                    sharedReportGroupIds.Add(sr.UserGroupId);
            }

            // Remove duplicates efficiently
            var distinctUserIds = sharedReportUserIds.Distinct().ToList();
            var distinctGroupIds = sharedReportGroupIds.Distinct().ToArray();

            // Execute both async calls in parallel only if there are items to fetch
            var tasks = new List<Task>();
            Task<List<UserInfoModel>>? usersTask = null;
            Task<IEnumerable<GroupResource>>? userGroupsTask = null;

            if (distinctUserIds != null && distinctUserIds.Count > 0)
            {
                usersTask = _userInfoProvider.GetUsersDetails(tenantId, distinctUserIds);
                tasks.Add(usersTask);
            }

            if (distinctGroupIds != null && distinctGroupIds.Length > 0)
            {
                userGroupsTask = _userService.GetGroupsByGroupIdsAsync(tenantId, distinctGroupIds);
                tasks.Add(userGroupsTask);
            }

            if (tasks.Count > 0)
            {
                await Task.WhenAll(tasks);
            }

            var users = usersTask != null ? usersTask.Result : [];
            var userGroups = userGroupsTask != null ? userGroupsTask.Result : [];

            var userAndUserGroupInfoList = users.Select(
                user => new UserAndUserGroupInfoModel
                {
                    Id = user.Id,
                    LegacyId = user.LegacyId,
                    Username = user.Username,
                    Email = user.Email,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    FullName = user.FullName,
                    Title = user.Title,
                    Organization = user.Organization,
                    DirectGroupIds = user.DirectGroupIds,
                    ThumbnailId = user.ThumbnailId,
                    ThumbnailUrl = user.ThumbnailUrl,
                    IsGroup = false,
                    UserGroupId = string.Empty,
                    UserGroupName = string.Empty
                }).ToList();

            // Add groups with all properties populated
            foreach (var group in userGroups)
            {
                userAndUserGroupInfoList.Add(new UserAndUserGroupInfoModel
                {
                    IsGroup = true,
                    UserGroupId = group.LegacyId,
                    UserGroupName = group.Name,
                });
            }

            return userAndUserGroupInfoList;
        }

        public async Task CreateOrUpdateSharedReport(Guid reportId, ShareReportRequest shareRequest, string userId, Guid tenantId)
        {
            var report = await _dataAccessor.GetReportAsync(reportId, tenantId) ??
                throw new BadRequestException($"Report not found. report id:{reportId}");

            if (report.OwnerUserId != userId)
            {
                throw new ForbiddenException("You do not have permission to share this report.");
            }

            bool save = false;
            var sw = Stopwatch.StartNew();
            shareRequest.NewSharedUserIds = shareRequest.NewSharedUserIds.Where(id => id != report.OwnerUserId).ToArray();
            var userIdsToNotify = new HashSet<string>();
            if (shareRequest.NewSharedUserIds != null && shareRequest.NewSharedUserIds.Length > 0)
            {
                foreach (var newShareUserId in shareRequest.NewSharedUserIds)
                {
                    var isReportShared = await _dataAccessor.IsReportShared(reportId, newShareUserId, tenantId);
                    if (!isReportShared)
                    {
                        var sharedReport = new SharedReportWithUser
                        {
                            ReportId = reportId,
                            UserId = newShareUserId,
                            SharedAtUtc = DateTime.UtcNow,
                            TenantId = tenantId,
                            CreatedOnUtc = DateTime.UtcNow,
                            ModifiedOnUtc = DateTime.UtcNow
                        };
                        await _dataAccessor.SaveSharedReportWithUserAsync(sharedReport, false);
                        userIdsToNotify.Add(newShareUserId);
                        save = true;
                    }
                }
                await SendReportSharedNotificationAsync(reportId, userIdsToNotify.ToArray(), userId, tenantId, report);
                sw.Stop();
                var result = await _reportService.GetReportById(reportId, tenantId, userId);
                RecordCustomNewRelicEvent(report, sw, result, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_SHARE, tenantId, userId);
            }

            if (shareRequest.RemovedUserIds != null && shareRequest.RemovedUserIds.Length > 0)
            {
                var rsw = Stopwatch.StartNew();
                foreach (var removeUserId in shareRequest.RemovedUserIds)
                {
                    var sharedReport = await _dataAccessor.GetSharedReportWithUserAsync(reportId, removeUserId, tenantId, null);
                    if (sharedReport != null)
                    {
                        sharedReport.IsDeleted = true;
                        sharedReport.DeletedOnUtc = DateTime.UtcNow;
                        await _dataAccessor.UpdateSharedReportAsync(sharedReport, false);
                    }
                }
                save = true;
                rsw.Stop();
                var result = await _reportService.GetReportById(reportId, tenantId, userId);
                RecordCustomNewRelicEvent(report, rsw, result, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_UNSHARE, tenantId, userId);
            }

            if (save)
                await _dataAccessor.SaveChangesAsync();
        }

        public async Task CreateOrUpdateSharedReportWithUsersAndGroups(Guid reportId, ShareReportRequest shareRequest, string userId, Guid tenantId)
        {
            var report = await _dataAccessor.GetReportAsync(reportId, tenantId) ??
                throw new BadRequestException($"Report not found. report id:{reportId}");

            if (report.OwnerUserId != userId)
            {
                throw new ForbiddenException("You do not have permission to share this report.");
            }

            bool save = false;
            var sw = Stopwatch.StartNew();
            var userIdsToNotify = new HashSet<string>();
            shareRequest.NewSharedUserIds = shareRequest.NewSharedUserIds.Where(id => id != report.OwnerUserId).ToArray();
            if (shareRequest.NewSharedUserIds != null && shareRequest.NewSharedUserIds.Length > 0)
            {
                foreach (var newShareUserId in shareRequest.NewSharedUserIds)
                {
                    var isReportShared = await _dataAccessor.IsReportSharedWithUser(reportId, newShareUserId, tenantId);
                    if (!isReportShared)
                    {
                        var sharedReport = new SharedReportWithUser
                        {
                            ReportId = reportId,
                            UserId = newShareUserId,
                            UserGroupId = string.Empty,
                            SharedAtUtc = DateTime.UtcNow,
                            TenantId = tenantId,
                            CreatedOnUtc = DateTime.UtcNow,
                            ModifiedOnUtc = DateTime.UtcNow
                        };
                        await _dataAccessor.SaveSharedReportWithUserAsync(sharedReport, false);
                        userIdsToNotify.Add(newShareUserId);
                        save = true;
                    }

                }
                sw.Stop();
                var result = await _reportService.GetReportById(reportId, tenantId, userId);
                RecordCustomNewRelicEvent(report, sw, result, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_SHARE, tenantId, userId);
            }

            if (shareRequest.NewSharedGroupIds != null && shareRequest.NewSharedGroupIds.Length > 0)
            {
                var groupSw = Stopwatch.StartNew();
                var sharedGroupIds = new HashSet<string>();
                foreach (var newShareGroupId in shareRequest.NewSharedGroupIds)
                {
                    var isReportShared = await _dataAccessor.IsReportSharedWithUserGroup(reportId, newShareGroupId, tenantId);
                    if (!isReportShared)
                    {
                        var sharedReport = new SharedReportWithUser
                        {
                            ReportId = reportId,
                            UserId = string.Empty,
                            UserGroupId = newShareGroupId,
                            SharedAtUtc = DateTime.UtcNow,
                            TenantId = tenantId,
                            CreatedOnUtc = DateTime.UtcNow,
                            ModifiedOnUtc = DateTime.UtcNow
                        };
                        await _dataAccessor.SaveSharedReportWithUserAsync(sharedReport, false);
                        sharedGroupIds.Add(newShareGroupId);
                        save = true;
                    }
                }
                if (sharedGroupIds.Count > 0)
                {
                    var distinctUserIds = await GetUserIdsOfUserGroups(sharedGroupIds, tenantId);
                    if (distinctUserIds.Length > 0)
                    {
                        foreach (var id in distinctUserIds)
                        {
                            if (report.OwnerUserId == id)
                            {
                                continue;
                            }
                            userIdsToNotify.Add(id);
                        }
                    }

                }
                groupSw.Stop();
                var result = await _reportService.GetReportById(reportId, tenantId, userId);
                RecordCustomNewRelicEvent(report, groupSw, result, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_SHARE, tenantId, userId);
            }

            if (userIdsToNotify.Count > 0)
            {
                await SendReportSharedNotificationAsync(reportId, userIdsToNotify.ToArray(), userId, tenantId, report);
            }

            var unshareStopwatch = Stopwatch.StartNew();
            var hasRemovals = false;
            var currentTime = DateTime.UtcNow;

            if (shareRequest.RemovedUserIds != null && shareRequest.RemovedUserIds.Length > 0)
            {
                foreach (var removeUserId in shareRequest.RemovedUserIds)
                {
                    var sharedReport = await _dataAccessor.GetSharedReportWithUsersAsync(reportId, removeUserId, tenantId);
                    if (sharedReport != null)
                    {
                        sharedReport.IsDeleted = true;
                        sharedReport.DeletedOnUtc = currentTime;
                        await _dataAccessor.UpdateSharedReportAsync(sharedReport, false);
                        hasRemovals = true;
                    }
                }
            }

            if (shareRequest.RemovedGroupIds != null && shareRequest.RemovedGroupIds.Length > 0)
            {
                foreach (var removeGroupId in shareRequest.RemovedGroupIds)
                {
                    var sharedReport = await _dataAccessor.GetSharedReportWithUserGroupAsync(reportId, removeGroupId, tenantId);
                    if (sharedReport != null)
                    {
                        sharedReport.IsDeleted = true;
                        sharedReport.DeletedOnUtc = currentTime;
                        await _dataAccessor.UpdateSharedReportAsync(sharedReport, false);
                        hasRemovals = true;
                    }
                }
            }

            if (hasRemovals)
            {
                save = true;
                unshareStopwatch.Stop();
                var result = await _reportService.GetReportById(reportId, tenantId, userId);
                RecordCustomNewRelicEvent(report, unshareStopwatch, result, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_UNSHARE, tenantId, userId);
            }

            if (save)
                await _dataAccessor.SaveChangesAsync();
        }

        public async Task<List<UserInfoModel>> RefreshSSRSAccessibleUsers(Guid tenantId)
        {
            return await GetSsrAccessibleUsers(string.Empty, tenantId, true);
        }

        private async Task<string[]> GetUserIdsOfUserGroups(HashSet<string> shareGroupIds, Guid tenantId)
        {
            // Ensure NewSharedGroupIds is not null before using Select
            var userIdTasks = shareGroupIds.Count > 0
                ? shareGroupIds.Select(ugId => _userService.GetUserIdsByGroupIdAsync(tenantId.ToString(), ugId))
                : [];

            var userIdResults = await Task.WhenAll(userIdTasks);

            var allUsersIds = userIdResults
                .SelectMany(result => result.Resource)
                .Distinct()
                .ToList();

            var users = await _userInfoProvider.GetUsersDetails(tenantId, allUsersIds);
            var userIdsOfUserGroups = users
                .Where(x => x.LegacyId != null)
                .Select(x => x.LegacyId!)
                .ToHashSet();
            var distinctUserIds = userIdsOfUserGroups.Distinct().ToArray();
            return distinctUserIds;
        }

        private void RecordCustomNewRelicEvent(DataAccess.Entities.Report report, Stopwatch sw, Models.Report result, string operationEvent, Guid tenantId, string userId)
        {
            var filtersMetadata = result?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = tenantId,
                UserId = userId,
                ReportId = report.ReportId,
                SystemReportId = report.SystemReportId,
                ReportName = report.ReportName,
                SystemReportName = result.SystemReportName ?? string.Empty,
                IsSystemReport = false,
                Operation = operationEvent,
                Filters = string.Join(",", report.Filters?.Select(f => f.FilterName) ?? []),
                FiltersJson = FilterHashHelper.GetFilterHashValues(report.Filters, filtersMetadata),
                Fields = string.Join(",", report.Fields.Select(f => f.Name)),
                SortField = report.OrderByField,
                SortOrder = report.OrderBy.ToString(),
                CorrelationId = _httpContextAccessor.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = report.OwnerUserId,
                RequestDuration = sw.ElapsedMilliseconds,
                SharedOn = DateTime.UtcNow.ToString(),
            };

            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
        }

        private string GetFqdnForTenant(Dictionary<string, object> customSettings, string tenantName)
        {
            if (customSettings.TryGetValue("library", out var librarySettingsObj) && librarySettingsObj is Dictionary<string, string> librarySettings)
            {
                if (librarySettings.TryGetValue("fqdn", out var fqdn))
                    return fqdn;
            }
            _logger.Error("Could not find fqdn for tenant:{TenantName}", tenantName);
            return tenantName + ".seismic.com";
        }

        private async Task SendReportSharedNotificationAsync(Guid reportId, string[] sharedReportUserIds, string userId, Guid tenantId, DataAccess.Entities.Report report)
        {
            var tenantInfo = await _matrixClient.GetTenantAsync(tenantId);

            var tenantUrl = GetFqdnForTenant(tenantInfo.CustomSettings, tenantInfo.Subdomain);
            var reportUrl = $"https://{tenantUrl}/app#/selfservicereports/report/view/{reportId}?skip=0&take=1000";
            var reportShared = new ReportSharedNotificationPayload()
            {
                ReportName = report.ReportName,
                ReportType = ICON_HOSTING_FORMAT,
                SharedOn = DateTime.UtcNow.ToString(),
                ReportUrl = reportUrl,
                UserId = userId
            };
            await _notificationWrapper.SendNotificationRequestAsync(reportShared, sharedReportUserIds, tenantId);
        }
    }
}
