﻿using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.Common.ServiceFoundation;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class DraftReportFiltersService(IDataAccessor _dataAccessor,  ISystemReportsRepository _systemReportsRepository,
        ILogger _logger, ISeismicContextProvider _contextProvider) : IDraftReportFiltersService
    {
        private readonly ILogger _logger = _logger.ForContext<DraftReportFiltersService>();

        private Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        public async Task<DraftFilterModel> GetDraftFiltersAsync()
        {
            try
            {
                var filters = await _dataAccessor.GetDraftReportFilters(TenantId);
                var draftFilters = new List<FilterTemplateModel>();
                foreach (var filter in filters)
                {
                    draftFilters.Add(MapDraftReportFilterEntityToModel(filter));
                }
                return new DraftFilterModel
                {
                    Filters = draftFilters
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while fetching all draft filters.");
                throw;
            }
        }

        public async Task<DraftFilterModel> GetDraftFilterByNameAsync(string filterName)
        {
            try
            {
                var draftReportFilter = await _dataAccessor.GetDraftReportFilterByName(TenantId,filterName)
                    ?? throw new NotFoundException($"DraftReportFilters with FilterName '{filterName}' not found.");
                var filter = MapDraftReportFilterEntityToModel(draftReportFilter);

                return new DraftFilterModel
                {
                    Filters = [filter]
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while fetching draft filter {FilterName}.", filterName.ToSanitizedString());
                throw;
            }
        }

        public async Task<FilterTemplateModel> UpdateDraftFilterAsync(string filterName, FilterTemplateModel draftReportFilter)
        {
            try
            {
                if (filterName != draftReportFilter.FilterName)
                {
                    throw new BadRequestException("FilterName in the URL does not match FilterName in the body.");
                }

                var filterEntity = await _dataAccessor.GetDraftReportFilterByName(TenantId, filterName) 
                    ?? throw new NotFoundException($"DraftReportFilters with FilterName '{filterName}' not found.");
                
                filterEntity.Category = draftReportFilter.Category;
                filterEntity.FilterName = draftReportFilter.FilterName;
                filterEntity.QueryParam = draftReportFilter.QueryParam;
                filterEntity.UxLabel = draftReportFilter.UxLabel;
                filterEntity.UxDescription = draftReportFilter.UxDescription;
                filterEntity.AllowedOperators = draftReportFilter.AllowedOperators;
                filterEntity.DataType = draftReportFilter.DataType;
                filterEntity.FilterType = draftReportFilter.FilterType;
                filterEntity.FilterPicklistQuery = draftReportFilter.FilterPicklistQuery;
                filterEntity.DomainValues = draftReportFilter.DomainValues;
                filterEntity.IsRequired = draftReportFilter.IsRequired;
                filterEntity.ModifiedOnUtc = DateTime.UtcNow;
                filterEntity.EnableRelativeUserFilterField = draftReportFilter.EnableRelativeUserFilterField;
                
                _dataAccessor.UpdateDraftReportFilter(filterEntity);
                await _dataAccessor.SaveChangesAsync();
                return MapDraftReportFilterEntityToModel(filterEntity);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while updating draft filter {FilterName}.", filterName.ToSanitizedString());
                throw new BadRequestException($"Error occurred while updating DraftFilter. {ex.Message}");
            }
        }


        public async Task<DraftFilterModel> UpdateDraftFiltersAsync(DraftFilterModel draftReportFilter)
        {
            if (draftReportFilter == null)
            {
                throw new BadRequestException("Please upload a valid yaml file");
            }

            var result = new DraftFilterModel
            {
                Filters = []
            };

            foreach (var filter in draftReportFilter.Filters)
            {
                if (string.IsNullOrWhiteSpace(filter.FilterName))
                {
                    throw new BadRequestException("FilterName is required.");
                }

                var systemReportFilters = _systemReportsRepository.GetFilterByName(filter.FilterName);
                if (systemReportFilters != null && string.Compare(filter.FilterName, systemReportFilters.FilterName, true) == 0)
                {
                    _logger.Warning("DraftReportFilter with filterName:{filterName}' already exists as a system filter", filter.FilterName);
                    continue;
                }

                var existingDraftReportFilters = await _dataAccessor.GetDraftReportFilterByName(TenantId, filter.FilterName);
                if (existingDraftReportFilters != null)
                {
                    _logger.Information("DraftReportFilter with filterName:{filterName}' already exists as a draft filter. Updating it", filter.FilterName);

                    var updated = await UpdateDraftFilterAsync(filter.FilterName, filter);
                    result.Filters.Add(updated);
                }
                else
                {
                    var draftReportFilterEntity = new DraftReportFilter
                    {
                        Category = filter.Category,
                        FilterName = filter.FilterName,
                        QueryParam = filter.QueryParam,
                        UxLabel = filter.UxLabel,
                        UxDescription = filter.UxDescription,
                        AllowedOperators = filter.AllowedOperators,
                        DataType = filter.DataType,
                        FilterType = filter.FilterType,
                        FilterPicklistQuery = filter.FilterPicklistQuery,
                        DomainValues = filter.DomainValues,
                        CreatedOnUtc = DateTime.UtcNow,
                        ModifiedOnUtc = DateTime.UtcNow,
                        TenantId = TenantId,
                        IsRequired = filter.IsRequired,
                        EnableRelativeUserFilterField = filter.EnableRelativeUserFilterField
                    };

                    _dataAccessor.AddDraftReportFilter(draftReportFilterEntity);
                    await _dataAccessor.SaveChangesAsync();
                    result.Filters.Add(MapDraftReportFilterEntityToModel(draftReportFilterEntity));
                }       
            }

            return result;
        }


        public async Task<DraftFilterModel> CreateDraftFilterAsync(DraftFilterModel draftReportFilter)
        {
            try
            {
                if (draftReportFilter == null)
                {
                    throw new BadRequestException("Please upload a valid yaml file");
                }

                var mappedFilters = new List<FilterTemplateModel>();

                foreach (var filter in draftReportFilter.Filters)
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterName))
                    {
                        throw new BadRequestException("FilterName is required.");
                    }

                    var existingDraftReportFilters = await _dataAccessor.GetDraftReportFilterByName(TenantId, filter.FilterName);
                    if (existingDraftReportFilters != null)
                    {
                        throw new BadRequestException($"DraftReportFilters with FilterName '{filter.FilterName}' already exists.");
                    }
                    var systemReportFilters = _systemReportsRepository.GetFilterByName(filter.FilterName);
                    if (systemReportFilters != null && string.Compare(filter.FilterName, systemReportFilters.FilterName, true) == 0)
                    {
                        throw new BadRequestException($"SystemReportFilters with FilterName '{filter.FilterName}' already exists.");
                    }

                    var draftReportFilterEntity = new DraftReportFilter
                    {
                        Category = filter.Category,
                        FilterName = filter.FilterName,
                        QueryParam = filter.QueryParam,
                        UxLabel = filter.UxLabel,
                        UxDescription = filter.UxDescription,
                        AllowedOperators = filter.AllowedOperators,
                        DataType = filter.DataType,
                        FilterType = filter.FilterType,
                        FilterPicklistQuery = filter.FilterPicklistQuery,
                        DomainValues = filter.DomainValues,
                        CreatedOnUtc = DateTime.UtcNow,
                        ModifiedOnUtc = DateTime.UtcNow,
                        TenantId = TenantId,
                        IsRequired = filter.IsRequired,
                        EnableRelativeUserFilterField = filter.EnableRelativeUserFilterField
                    };

                    _dataAccessor.AddDraftReportFilter(draftReportFilterEntity);
                    await _dataAccessor.SaveChangesAsync();
                    mappedFilters.Add(MapDraftReportFilterEntityToModel(draftReportFilterEntity));
                }

                return new DraftFilterModel
                {
                    Filters = mappedFilters
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while creating draft filter.");
                throw new BadRequestException($"Error occurred while creating DraftFilter. {ex.Message}");
            }
        }

        public async Task DeleteDraftFilterAsync(string filterName)
        {
            try
            {
                var draftReportFilter = await _dataAccessor.GetDraftReportFilterByName(TenantId, filterName)
                    ?? throw new NotFoundException($"DraftReportFilters with FilterName '{filterName}' not found.");
                await _dataAccessor.DeleteDraftReportFilterAsync(draftReportFilter);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while deleting draft filter.");
                throw;
            }
        }

        private static FilterTemplateModel MapDraftReportFilterEntityToModel(DraftReportFilter draftReportFilter)
        {
            return new FilterTemplateModel
            {
                Category = draftReportFilter.Category,
                FilterName = draftReportFilter.FilterName,
                QueryParam = draftReportFilter.QueryParam,
                UxLabel = draftReportFilter.UxLabel,
                UxDescription = draftReportFilter.UxDescription,
                AllowedOperators = MapAllowedOperators(draftReportFilter.AllowedOperators, draftReportFilter.EnableRelativeUserFilterField),
                DataType = draftReportFilter.DataType,
                FilterType = draftReportFilter.FilterType,
                FilterPicklistQuery = draftReportFilter.FilterPicklistQuery,
                DomainValues = draftReportFilter.DomainValues,
                IsRequired = draftReportFilter.IsRequired,
                EnableRelativeUserFilterField = draftReportFilter.EnableRelativeUserFilterField
            };
        }

        private static List<DataAccess.Entities.FilterOperation> MapAllowedOperators(List<DataAccess.Entities.FilterOperation> allowedOperators, string? enableRelativeUserFilterField)
        {
            if (string.IsNullOrWhiteSpace(enableRelativeUserFilterField))
            {
                return allowedOperators;
            }
            if (allowedOperators.Count(x => x.Name == OperatorConstants.IS_CURRENT_USER || x.Name == OperatorConstants.IS_MY_TEAM) == 0)
            { 
                if (allowedOperators.Count >= 2)
                {
                    // Insert the IS_CURRENT_USER at the 3rd position (index 2)
                    allowedOperators.Insert(2, new FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                    // Insert the IS_MY_TEAM at the 4th position (index 3)
                    allowedOperators.Insert(3, new FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
                }
                else
                {
                    // If there are less than 2 items, just add them to the end
                    allowedOperators.Add(new FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                    allowedOperators.Add(new FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
                }
            }

            return allowedOperators;
        }
    }
}