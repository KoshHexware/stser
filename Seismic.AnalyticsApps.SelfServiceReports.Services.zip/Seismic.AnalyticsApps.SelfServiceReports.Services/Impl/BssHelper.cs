﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Platform.BlobStorageService.Client.Interfaces;
using Seismic.Platform.Matrix.Client;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class BssHelper(IMatrixClient _matrixClient, IBlobStorageServiceClient _blobStorageServiceClient, ILogger _logger) : IBssHelper
    {
        private readonly IMatrixClient _matrixClient = _matrixClient;
        private readonly ILogger _logger = _logger.ForContext<BssHelper>();

        private const int DEFAULT_IMAGE_EXPIRATION_MINUTES = 24 * 60;

        public async Task<IEnumerable<(string UserId, string Url)>> GetImageURLsAsync(Guid tenantId,
            IEnumerable<(string UserId, string BlobId)> items)
        {
            var baseUrl = await _matrixClient.GetServiceEndpointByTenantAsync("bss", tenantId);
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                _logger.Warning("MatrixClient failed to return bss server url for tenantId:{tenantId}", tenantId);
                return [];
            }

            var tenant = await _matrixClient.GetTenantAsync(tenantId);
            var container = tenant.Name;
            if (tenant.CustomSettings.TryGetValue("bss", out var bssSettingsObj))
            {
                if (bssSettingsObj is Dictionary<string, string> bssSettings && bssSettings.TryGetValue("blob.containerName", out var containerName))
                {
                    container = containerName;
                }
                else
                {
                    _logger.Warning("Could not read blob.containerName from matrix for tenantId:{tenantId}", tenantId);
                }
            }
            else
            {
                _logger.Warning("Could not read bss settings from matrix for tenantId:{tenantId}", tenantId);
            }

            var result = items.Select(async p =>
            {
                var blobUrl = await GetBlobUrl(p.UserId, p.BlobId, tenant.Name, container);
                return (p.UserId, blobUrl);
            });
            return result.Select(r => r.Result).ToList();
        }

        private async Task<string> GetBlobUrl(string userId, string blobId, string tenantName, string containerName)
        {
            try
            {
                var bssResponse = await _blobStorageServiceClient.GetTempDownloadResizedImageUrlAsync(tenantName, containerName, blobId, 
                    Platform.BlobStorageService.Client.Dto.ImageRequestSize.Small, null, DEFAULT_IMAGE_EXPIRATION_MINUTES);
                if (bssResponse.IsSuccessResponse)
                {
                    return bssResponse.Value;
                }
                _logger.Warning("Error in GetBlobUrl. userId:{userId}, blobId:{blobId}, tenantName:{tenantName}, status:{status}, error:{error}", userId, blobId, tenantName, bssResponse.StatusCode, bssResponse.ErrorInfo?.ErrorMessage);
            }
            catch(Exception ex)
            {
                _logger.Error(ex, "Error in GetBlobUrl. userId:{userId}, blobId:{blobId}, tenantName:{tenantName}", userId, blobId, tenantName);
            }
            return string.Empty;
        }
    }
}
