﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.CustomProperty.Model;
using Seismic.CustomProperty.Client;
using Seismic.Foreshock.Value;
using Seismic.Platform.UserManagement.Client;
using Serilog;
using System.Net;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;

public class CustomPropertyService(ISeismicRedisCache _cache, ICustomPropertyClientWrapper _customPropertyClient, 
    IUserService _userService, IDiscClient _discClient, ILogger _logger) : ICustomPropertyService
{
    public async Task<IList<UserProperty>> RefreshUserCustomProperties(Guid tenantId)
    {
        return await GetUserCustomProperties(tenantId, true);
    }

    public async Task<IList<UserProperty>> GetUserCustomProperties(Guid tenantId, bool refreshCache = false)
    {
        var cacheKey = new TenantUserPropertiesCacheKey(tenantId);
        if (!refreshCache)
        {
            var cached = await _cache.GetAsync(cacheKey);
            if (cached != null)
            {
                return cached;
            }
        }

        _logger.Information("Custom property service. Cache miss for GetUserCustomProperties for tenant:{tenantId}", tenantId);
        
        const string userCustomPropertyQuery = "SELECT * FROM userproperties";
        var sfUserPropertiesTask =  _discClient.ExecuteQuery<UserProperty>(userCustomPropertyQuery, "GetCustomUserProperties", null, null, null, null, null);
        var umsUserPropertiesTask =  _userService.GetCustomUserProperties(tenantId);

        await Task.WhenAll(sfUserPropertiesTask, umsUserPropertiesTask);

        _logger.Information("Custom property service. sfUserPropertiesTask for tenant:{tenantId}, completed. result:{result}", tenantId, sfUserPropertiesTask.IsCompletedSuccessfully);
        _logger.Information("Custom property service. umsUserPropertiesTask for tenant:{tenantId}, completed. result:{result}", tenantId, umsUserPropertiesTask.IsCompletedSuccessfully);

        var sfUserProperties = sfUserPropertiesTask.IsCompletedSuccessfully ? sfUserPropertiesTask.Result.ToList() : [];
        var umsUserProperties = umsUserPropertiesTask.IsCompletedSuccessfully ? umsUserPropertiesTask.Result.ToList(): [];

        foreach(var property in umsUserProperties)  
        {
            if (!property.HasDomainOfValues)
            {
                continue;
            }
            var sfProperty = sfUserProperties.Where(x => x.Id == property.LegacyId).FirstOrDefault();
            if (sfProperty != null)
            {
                sfProperty.Values = property.DomainOfValues.Select(x=> x.Value.ToString()).ToArray();
                sfProperty.Definition = string.Empty;
            }
        }

        await _cache.SetAsync(cacheKey, sfUserProperties);
        return sfUserProperties;
    }


    public async Task<IList<ContentCustomProperty>> GetContentCustomProperties(Guid tenantId, bool refreshCache = false)
    {
        var cacheKey = new TenantCustomPropertiesCacheKey(tenantId);
        if (!refreshCache)
        {
            var cached = await _cache.GetAsync(cacheKey);
            if (cached != null)
            {
                return cached;
            }
        }

        _logger.Information("Custom property service. Cache miss for GetContentCustomProperties for tenant:{tenantId}", tenantId);

        const string customPropertyQuery = "SELECT * FROM CustomProperties";
        const string teamsitesQuery = "SELECT * FROM Teamsites WHERE IsDeleted = false;";
        var sfCustomPropertiesTask = _discClient.ExecuteQuery<ContentCustomProperty>(customPropertyQuery, "getCustomProperties");
        var teamsitesTask = _discClient.ExecuteQuery<Teamsites>(teamsitesQuery, "getAllTeamsites");

        await Task.WhenAll(sfCustomPropertiesTask, teamsitesTask);

        _logger.Information("Custom property service. sfCustomPropertiesTask for tenant:{tenantId}, completed. result:{result}", tenantId, sfCustomPropertiesTask.IsCompletedSuccessfully);
        _logger.Information("Custom property service. teamsitesTask for tenant:{tenantId}, completed. result:{result}", tenantId, teamsitesTask.IsCompletedSuccessfully);

        var sfCustomProperties = sfCustomPropertiesTask.IsCompletedSuccessfully ? sfCustomPropertiesTask.Result.ToList() : [];
        var sfCustomPropertyIds = sfCustomProperties.Select(x => x.Id).ToList();
        var customProperties = await GetCustomPropertiesAsync(tenantId, sfCustomPropertyIds);

        var teamsites = teamsitesTask.IsCompletedSuccessfully ? teamsitesTask.Result : [];

        var customPropertyIds = customProperties.Items.Select(x => x.Id).ToList();
        var filteredSfCustomProperties = sfCustomProperties.Where(x => customPropertyIds.Contains(x.Id.ToShortGuid())).ToList();

        var teamsiteDictionary = teamsites.ToDictionary(t => t.Id, t => t.Name);

        foreach (var property in customProperties.Items)
        {
            var sfProperty = filteredSfCustomProperties.FirstOrDefault(x => x.Id.ToShortGuid() == property.Id);
            if (sfProperty != null)
            {
                var propSpaceIds = property.SpaceIds.Select(x => x.ToLegacyId());
                var teamsiteName = string.Join(", ", propSpaceIds.Select(id => teamsiteDictionary.GetValueOrDefault(id))).Trim();
                var teamsitesString = propSpaceIds?.Count() > 1 ? $"Belongs to multiple Teamsites." : $"Belongs to Teamsite {teamsiteName}.";

                sfProperty.Values = property.PossibleValues.Select(x => WebUtility.HtmlDecode(x.Value.ToString())).ToArray();
                sfProperty.Description = string.IsNullOrWhiteSpace(property.Hint)
                        ? $"A custom content property for your organization. {teamsitesString}"
                        : property.Hint.TrimEnd() + (property.Hint.EndsWith('.') ? " " : ". ") + teamsitesString;
                sfProperty.TeamsiteIds = propSpaceIds?.ToArray() ?? [];
                sfProperty.Definition = string.Empty;
                sfProperty.AllowMultipleValues = property.AllowMultipleValues;
            }
        }

        await _cache.SetAsync(cacheKey, filteredSfCustomProperties);
        return filteredSfCustomProperties;
    }

    public async Task<IList<ContentCustomProperty>> RefreshContentCustomProperties(Guid tenantId)
    {
        return await GetContentCustomProperties(tenantId, true);
    }

    public async Task<IList<ContentCustomProperty>> GetFilteredContentPropertiesByUserTeamsites(Guid tenantId, List<Models.Teamsites> userTeamsites)
    {
        var contentCustomProps = await GetContentCustomProperties(tenantId);
        var userTeamsiteIds = userTeamsites.Select(x => x.Id);

        contentCustomProps = contentCustomProps.Where(x => x.TeamsiteIds.Any(y => userTeamsiteIds.Contains(y))).ToList();
        return contentCustomProps ?? [];
    }

    public async Task<ResourceList<CustomPropertyResource>> GetCustomPropertiesAsync(Guid tenantId, List<string>? ids)
    {
        try
        {
            var allResources = new List<CustomPropertyResource>();
            if (ids == null || ids.Count == 0)
            {
                var response = await _customPropertyClient.GetAllCustomPropertiesAsync(tenantId.ToString(), BuildFilterForTenant(ids));
                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    _logger.Error("Failed to get custom properties for tenant: {TenantId}, status: {StatusCode}, Error.StatusCode:{ErrorStatusCode} kind:{ResponseErrorKind}"
                        , tenantId, response.StatusCode, response.Error?.StatusCode, response.Error?.Kind);
                }
                return response.Resource;
            }

            const int batchSize = 1000;
            for (int i = 0; i < ids.Count; i += batchSize)
            {
                var batchIds = ids.Skip(i).Take(batchSize).ToList();
                var response = await _customPropertyClient.GetAllCustomPropertiesAsync(tenantId.ToString(), BuildFilterForTenant(batchIds));
                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    _logger.Error("Failed to get custom properties for tenant: {TenantId}, status: {StatusCode}, Error.StatusCode:{ErrorStatusCode} kind:{ResponseErrorKind}"
                        , tenantId, response.StatusCode, response.Error?.StatusCode, response.Error?.Kind);
                    continue;
                }
                if (response.Resource?.Items != null)
                {
                    allResources.AddRange(response.Resource.Items);
                }
            }

            return new ResourceList<CustomPropertyResource> { Items = allResources };
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Error getting custom properties for tenantId : {TenantId}", tenantId);
            throw;
        }
    }

    public static FilterExpression BuildFilterForTenant(List<string>? customPropertyIds)
    {
        var filterExpression = new FilterExpressionBuilder();
        filterExpression.AddCondition(new AttributeExpression("scopes"), ConditionOperator.ArrayContains, ValueObject.Create("content"));
        if (customPropertyIds != null && customPropertyIds.Count > 0)
        {
            var shortCustomPropertyIds = customPropertyIds.Select(i => ShortGuidUtil.GuidToShortGuid(i)).ToList();
            filterExpression.AddCondition(new AttributeExpression("customPropertyId"), ConditionOperator.In, ValueObject.Create(shortCustomPropertyIds));
        }

        return filterExpression.Build(null);
    }

}
