﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class FileSystemHelper(ILogger logger) : IFileSystemHelper
    {
        private const string TemplatesRootDirName = "standard-report-templates";
        private const string ReportsDirName = "reports";
        private const string FiltersDirName = "filters";
        private const string ReportFragmentDirName = "report-fragment";
        private const string FeatureProfilesDirName = "feature_master";
        private const string ArchivedDirName = "archived";
        private const string DataAreaDirName = "data_area";

        private readonly ILogger _logger = logger.ForContext<FileSystemHelper>();

        public IEnumerable<string> GetReportTemplateFiles()
        {
            return GetFiles(ReportsDirName);
        }

        public IEnumerable<string> GetFeatureProfiles()
        {
            return GetFiles(FeatureProfilesDirName);
        }

        public IEnumerable<string> GetReportFragmentTemplateFiles()
        {
            return GetFiles(ReportFragmentDirName);
        }

        public IEnumerable<string> GetFilterTemplateFiles()
        {
            return GetFiles(FiltersDirName);
        }

        public IEnumerable<string> GetArchivedFilters()
        {
            return GetJsonFiles(ArchivedDirName);
        }

        public IEnumerable<string> GetTextFiles()
        {
            return GetTextFile(ReportsDirName);
        }

        public IEnumerable<string> GetDataAreas()
        {
            return GetFiles(DataAreaDirName);
        }

        public string ReadTextFile(string filePath)
        {
            return File.ReadAllText(filePath, System.Text.Encoding.UTF8);
        }

        public virtual string GetBasePath()
        {
            return Environment.CurrentDirectory;
        }

        private IEnumerable<string> GetFiles(string dirName)
        {
            var templatesDir = Path.Combine(GetBasePath(), TemplatesRootDirName, dirName);
            var options = new EnumerationOptions
            {
                RecurseSubdirectories = false, // ignore the reports/wip folder
                MatchCasing = MatchCasing.CaseInsensitive,
                MatchType = MatchType.Simple,
                IgnoreInaccessible = true
            };
            return Directory.GetFiles(templatesDir, "*.*", options).Where(x => x.ToLowerInvariant().EndsWith(".yaml") || x.ToLowerInvariant().EndsWith(".yml"));
        }

        private IEnumerable<string> GetJsonFiles(string dirName)
        {
            var templatesDir = Path.Combine(GetBasePath(), TemplatesRootDirName, dirName);
            var options = new EnumerationOptions
            {
                RecurseSubdirectories = false,
                MatchCasing = MatchCasing.CaseInsensitive,
                MatchType = MatchType.Simple,
                IgnoreInaccessible = true
            };
            return Directory.GetFiles(templatesDir, "*.*", options).Where(x => x.ToLowerInvariant().EndsWith(".json"));
        }

        private IEnumerable<string> GetTextFile(string dirName)
        {
            var templatesDir = Path.Combine(GetBasePath(), TemplatesRootDirName, dirName);
            var options = new EnumerationOptions
            {
                RecurseSubdirectories = false,
                MatchCasing = MatchCasing.CaseInsensitive,
                MatchType = MatchType.Simple,
                IgnoreInaccessible = true
            };
            return Directory.GetFiles(templatesDir, "*.*", options).Where(x => x.ToLowerInvariant().EndsWith(".txt"));
        }
    }
}
