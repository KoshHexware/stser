﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Matrix.Client;
using System.Collections.Concurrent;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;

public class FeatureService(ISeismicContextProvider _contextProvider, IMatrixClient _matrixClient, IDediClient _dediService) : IFeatureService
{
    public async Task<IList<string>> GetFeaturesEnabledInTenantAsync(List<string> launchDarklyKeys)
    {
        var context = _contextProvider.GetContext();

        var enabledLDTogglesTask = GetAllEnabledLaunchDarklyKeys(context, launchDarklyKeys);
        var enabledFeaturesListTask = GetEnabledFmsFeatures(context);
        var crmSystemDomainTask = IsCrmEnabled(context);

        await Task.WhenAll(enabledLDTogglesTask, enabledFeaturesListTask, crmSystemDomainTask);

        if (crmSystemDomainTask.Result ?? false)
        {
            enabledFeaturesListTask.Result.Add(SystemDomainConstants.SystemDomainCRM);
        }

        // Merge enabled feature list with enabled toggles
        return [.. enabledFeaturesListTask.Result, .. enabledLDTogglesTask.Result];
    }

    private async Task<bool?> IsCrmEnabled(ISeismicContext context)
    {
        //CRM System Domain
        var platformToken = await context.GetPlatformToken();
        var crmMetadata = await _dediService.GetCRMMetadataAsync(context.TenantIdentifier.TenantUniqueId, platformToken, false);
        return crmMetadata?.DataSources?.Any(x => x.SystemDomain == SystemDomainConstants.SystemDomainCRM && x.SetupState == SystemDomainConstants.SetupStateComplete);
    }

    private async Task<List<string>> GetEnabledFmsFeatures(ISeismicContext context)
    {
        var fmsFeaturesTask = context.GetFeaturesForTenantAsync();
        var enabledFeaturesList = new List<string>();

        var tenantInfo = await _matrixClient.GetTenantAsync(context.TenantIdentifier.TenantUniqueId);

        // Check for specific systems and add corresponding features
        if (tenantInfo.Systems.Any(x => x.Type == SystemType.Seismic))
        {
            enabledFeaturesList.Add(SystemTypeConstants.Seismic);
        }

        if (tenantInfo.Systems.Any(x => x.Type == SystemType.Lessonly))
        {
            enabledFeaturesList.Add(SystemTypeConstants.Lessonly);
        }

        await fmsFeaturesTask;

        foreach (var feature in fmsFeaturesTask.Result)
        {
            if (feature.Toggle?.Value == true)
            {
                enabledFeaturesList.Add(feature.Key);
            }
        }

        return enabledFeaturesList;
    }

    private static async Task<List<string>> GetAllEnabledLaunchDarklyKeys(ISeismicContext context, List<string> ldKeys)
    {
        if (ldKeys == null || ldKeys.Count == 0)
            return [];

        if (context == null)
            return [];

        ldKeys = [.. ldKeys.Distinct()];

        var enabledLaunchDarklyFlags = new ConcurrentBag<string>();
        var tasks = ldKeys.Select(async key =>
        {
            if (await context.IsToggleEnabled(key))
            {
                enabledLaunchDarklyFlags.Add(key);
            }
        });

        await Task.WhenAll(tasks);
        return [.. enabledLaunchDarklyFlags];
    }
}
