﻿using Microsoft.AspNetCore.Http;
using NewRelic.Api.Agent;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Extension;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.UserManagement.Model;
using Serilog;
using System.Diagnostics;
using EntityPropertyType = Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities.PropertyType;
using ExecutionPropertyType = Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner.PropertyType;
using ModelPropertyType = Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.PropertyType;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class ReportService(ISystemReportsService _systemReportsSvc, ISystemFiltersService _systemFiltersService,
        IDataAccessor _dataAccessor, IUserService _userService,
        IUserInfoProvider _userInfoProvider, IHttpContextAccessor _httpContextAccessor, ISeismicRedisCache _seismicCache,
        INewRelicCustomEventHelper _newRelicCustomEventHelper, ILogger logger, IPermissionService _permissionService,
        ISystemDataAreaService _systemDataAreaService, ITenantService _tenantService) : IReportService
    {
        private readonly ILogger _logger = logger.ForContext<ReportService>();

        public async Task<PagedList<Models.ReportSummary>> GetAllReports(Guid tenantId, string userId, string? reportType = null,
            string? searchText = null, int take = 200, int skip = 0, string? orderField = null, string? orderBy = null, bool includeDrafts = true)
        {
            reportType = string.IsNullOrWhiteSpace(reportType) ? "all" : reportType.ToLowerInvariant();
            List<ReportSummary> reports = reportType switch
            {
                "owned" => await GetAllCustomReports(tenantId, userId, searchText, true),
                "system" => await GetSystemReports(tenantId, userId, searchText, includeDrafts),
                "custom" => await GetAllCustomReports(tenantId, userId, searchText),
                "shared" => await GetAllSharedReports(tenantId, userId, searchText),
                "all" => await GetAllOwnedSystemAndSharedReports(tenantId, userId, searchText, includeDrafts, true),
                _ => throw new ArgumentException($"Invalid report type: {reportType}", nameof(reportType)),
            };
            return await GetSortedAndPaginatedReports(take, skip, orderField, orderBy, reports, tenantId, userId);
        }

        public async Task<List<ReportIdNameModel>> GetSystemAndOwnedReports(Guid tenantId, string userId, string? searchText = null, bool includeDrafts = true, bool ownedReportsOnly = false)
        {
            return await RetrieveSystemAndOwnedReportMetadata(tenantId, userId, searchText, includeDrafts, ownedReportsOnly);
        }

        private async Task<PagedList<ReportSummary>> GetSortedAndPaginatedReports(int take, int skip, string? orderField,
            string? orderBy, List<ReportSummary> reports, Guid tenantId, string userId)
        {
            if (!string.IsNullOrWhiteSpace(orderField) && !string.IsNullOrWhiteSpace(orderBy))
            {
                var userSettings = await _dataAccessor.GetUserSettingsAsync(tenantId, userId);
                if (userSettings != null)
                {
                    userSettings.OrderField = orderField;
                    userSettings.OrderBy = orderBy;
                    await _dataAccessor.UpdateUserSettingsAsync(userSettings);
                }
                else
                {
                    userSettings = new DataAccess.Entities.UserSettings
                    {
                        TenantId = tenantId,
                        UserId = userId,
                        OrderField = orderField,
                        OrderBy = orderBy
                    };
                    await _dataAccessor.AddUserSettingsAsync(userSettings);
                }
            }

            if (string.IsNullOrWhiteSpace(orderField))
                return new PagedList<ReportSummary>
                {
                    Data = reports.Skip(skip).Take(take).ToList(),
                    Skip = skip,
                    Take = take,
                    TotalRecords = reports.Count
                };

            if (string.IsNullOrWhiteSpace(orderBy))
                orderBy = "asc";

            var sorted = orderField.ToLower() switch
            {
                "reportname" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.ReportName).ToList() : reports.OrderByDescending(r => r.ReportName).ToList(),
                "systemreportname" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.SystemReportName).ToList() : reports.OrderByDescending(r => r.SystemReportName).ToList(),
                "ownerusername" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.OwnerUserName).ToList() : reports.OrderByDescending(r => r.OwnerUserName).ToList(),
                "lastviewed" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.LastViewed).ToList() : reports.OrderByDescending(r => r.LastViewed).ToList(),
                "lastupdated" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.LastUpdated).ToList() : reports.OrderByDescending(r => r.LastUpdated).ToList(),
                "sharedon" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? reports.OrderBy(r => r.SharedOn).ToList() : reports.OrderByDescending(r => r.SharedOn).ToList(),
                _ => reports,
            };

            var paginatedReports = sorted
                .Skip(skip)
                .Take(take)
                .ToList();

            return new PagedList<ReportSummary>
            {
                Data = paginatedReports,
                Skip = skip,
                Take = take,
                TotalRecords = reports.Count
            };
        }

        private async Task<List<ReportSummary>> GetSystemReports(Guid tenantId, string userId, string? searchText = null, bool includeDrafts = true)
        {
            var access = await _permissionService.GetContextUserAccess(false);
            var isDomainAccessControlEnabled = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDomainAccessControl);
            if ((access == AccessLevel.Viewer) || !((isDomainAccessControlEnabled && AccessLevel.CustomReportEditor == access) || access == AccessLevel.Editor))
            {
                throw new BadRequestException("User does not have access to view system reports");
            }

            var allSystemReports = isDomainAccessControlEnabled ? await _systemReportsSvc.GetUserAccessibleSystemReports(includeDrafts) :
                                    await _systemReportsSvc.GetAllReports(includeDrafts);

            var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);

            if (userSettings == null || userSettings.Teamsites == null || userSettings.Teamsites.Count == 0)
            {
                allSystemReports = allSystemReports.Where(x => x.ShowTeamsitePicker != true);
            }

            var reportIds = allSystemReports.Select(report => report.ReportId).ToList();
            var systemRecentReports = await _dataAccessor.GetRecentReportsForUserByReportIdsAsync(userId, tenantId, reportIds);

            var systemReports = allSystemReports
                .Select(systemReport =>
                {
                    var report = systemRecentReports.FirstOrDefault(r => r.ReportId == systemReport.ReportId);
                    return new ReportSummary
                    {
                        Id = systemReport.ReportId,
                        SystemReportId = systemReport.ReportId,
                        ReportName = systemReport.ReportName,
                        SystemReportName = systemReport.ReportName,
                        Description = systemReport.Description,
                        OwnerUserId = ReportConstants.SYSTEM_DEFAULT_USER,
                        LastViewed = report?.OpenDate,
                        ReportType = ReportType.System,
                        OwnerUserName = ReportConstants.SYSTEM_DEFAULT_USER,
                        ShowTeamsitePicker = systemReport.ShowTeamsitePicker,
                        LastUpdated = systemReport.LastModified,
                    };
                })
                .Where(x => string.IsNullOrWhiteSpace(searchText) || x.ReportName.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                || x.Description.Contains(searchText, StringComparison.CurrentCultureIgnoreCase))
                .ToList();

            return systemReports;
        }

        private async Task<List<ReportSummary>> GetAllCustomReports(Guid tenantId, string userId, string? searchText = null, bool ownedReportsOnly = false)
        {
            var entities = await _dataAccessor.GetAllReportsAsync(tenantId, userId, searchText, ownedReportsOnly);

            var allSystemReports = await _systemReportsSvc.GetAllReports();
            var systemReportIds = allSystemReports.Select(r => r.ReportId).ToHashSet();
            var customReports = entities
               .Where(report => systemReportIds.Contains(report.SystemReportId))
               .Select(report => new ReportSummary
               {
                   Id = report.ReportId,
                   ReportName = report.ReportName,
                   Description = report.Description,
                   OwnerUserId = report.OwnerUserId,
                   LastViewed = report.LastViewed,
                   LastUpdated = report.LastUpdated,
                   SystemReportId = report.SystemReportId,
                   ReportType = (ReportType)report.ReportType,
                   SystemReportName = report.SystemReportName
               })
               .ToList();

            var userIds = customReports.Select(entity => entity.OwnerUserId);

            var usersInfo = await _userInfoProvider.GetUsersDetails(tenantId, userIds);

            var reports = new List<ReportSummary>();

            foreach (var entity in customReports)
            {
                var user = usersInfo?.Where(u => u.LegacyId == entity.OwnerUserId).SingleOrDefault();
                var systemReport = allSystemReports.Where(r => r.ReportId == entity.SystemReportId).Single();

                reports.Add(new ReportSummary()
                {
                    Id = entity.Id,
                    OwnerUserId = entity.OwnerUserId,
                    LastViewed = entity.LastViewed == DateTime.MinValue ? null : entity.LastViewed,
                    LastUpdated = entity.LastUpdated,
                    ReportName = entity.ReportName,
                    Description = entity.Description,
                    OwnerUserName = GetUserName(user),
                    OwnerThumbnailUrl = user?.ThumbnailUrl,
                    ReportType = ReportType.Custom,
                    SystemReportName = systemReport.ReportName,
                    SystemReportId = systemReport.ReportId,
                    ShowTeamsitePicker = systemReport.ShowTeamsitePicker
                });
            }

            return reports;
        }

        private async Task<List<ReportSummary>> GetAllSharedReports(Guid tenantId, string userId, string? searchText = null)
        {
            var reports = new List<ReportSummary>();

            var allSystemReports = await _systemReportsSvc.GetAllReports();

            var sharedReports = await GetAllSharedReports(tenantId, userId, searchText, allSystemReports);

            var sharedReportUserIds = sharedReports.Select(entity => entity.OwnerUserId);

            var sharedReportUsersInfo = await _userInfoProvider.GetUsersDetails(tenantId, sharedReportUserIds);

            foreach (var entity in sharedReports)
            {
                var user = sharedReportUsersInfo?.Where(u => u.LegacyId == entity.OwnerUserId).SingleOrDefault();
                var systemReport = allSystemReports.Where(r => r.ReportId == entity.SystemReportId).Single();

                reports.Add(new ReportSummary()
                {
                    Id = entity.Id,
                    OwnerUserId = entity.OwnerUserId,
                    LastViewed = entity.LastViewed == DateTime.MinValue ? null : entity.LastViewed,
                    LastUpdated = entity.LastUpdated,
                    ReportName = entity.ReportName,
                    Description = entity.Description,
                    OwnerUserName = GetUserName(user),
                    OwnerThumbnailUrl = user?.ThumbnailUrl,
                    ReportType = ReportType.Custom,
                    SystemReportName = systemReport.ReportName,
                    SystemReportId = systemReport.ReportId,
                    ShowTeamsitePicker = systemReport.ShowTeamsitePicker,
                    SharedOn = entity.SharedOn
                });
            }
            return reports;
        }

        private async Task<List<ReportSummary>> GetAllSharedReports(Guid tenantId, string userId, string? searchText, IEnumerable<ReportDefinitionMetadata> allSystemReports)
        {
            var userMetadata = await _userService.GetUserById(tenantId, userId);
            var sharedReportEntities = await _dataAccessor.GetSharedReportsForUserAsync(searchText, userId, tenantId, userMetadata?.DirectGroupLegacyIds);

            var sharedReports = sharedReportEntities
                .Select(x => new ReportSummary
                {
                    Id = x.ReportId,
                    ReportName = x.ReportName,
                    Description = x.Description,
                    OwnerUserId = x.OwnerUserId,
                    LastViewed = x.OpenDate,
                    LastUpdated = x.ModifiedOnUtc,
                    SystemReportId = x.SystemReportId,
                    ReportType = ReportType.Custom,
                    SystemReportName = allSystemReports.Where(p => p.ReportId == x.SystemReportId).Single().ReportName,
                    SharedOn = x.SharedAtUtc,
                }).ToList();
            return sharedReports;
        }

        private async Task<List<ReportSummary>> GetAllOwnedSystemAndSharedReports(Guid tenantId, string userId, string? searchText = null, bool includeDrafts = true, bool ownedReportsOnly = false)
        {
            var isDomainAccessControlEnabled = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDomainAccessControl);
            var userAccessibleSystemReports = isDomainAccessControlEnabled ? await _systemReportsSvc.GetUserAccessibleSystemReports(includeDrafts) :
                                              await _systemReportsSvc.GetAllReports(includeDrafts);
            var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);

            var reportIds = userAccessibleSystemReports.Select(report => report.ReportId).ToList();
            var systemRecentReports = await _dataAccessor.GetRecentReportsForUserByReportIdsAsync(userId, tenantId, reportIds);

            var systemReports = userAccessibleSystemReports
                .Select(systemReport =>
                {
                    var report = systemRecentReports.SingleOrDefault(r => r.ReportId == systemReport.ReportId);
                    return new ReportSummary
                    {
                        Id = systemReport.ReportId,
                        SystemReportId = systemReport.ReportId,
                        ReportName = systemReport.ReportName,
                        SystemReportName = systemReport.ReportName,
                        Description = systemReport.Description,
                        OwnerUserId = ReportConstants.SYSTEM_DEFAULT_USER,
                        LastViewed = report?.OpenDate,
                        ReportType = ReportType.System,
                        OwnerUserName = ReportConstants.SYSTEM_DEFAULT_USER,
                        ShowTeamsitePicker = systemReport.ShowTeamsitePicker
                    };
                })
                .Where(x => string.IsNullOrWhiteSpace(searchText) || x.ReportName.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                || x.Description.Contains(searchText, StringComparison.CurrentCultureIgnoreCase))
                .ToList();

            if (userSettings == null || userSettings.Teamsites == null || userSettings.Teamsites.Count == 0)
            {
                systemReports = systemReports.Where(x => x.ShowTeamsitePicker != true).ToList();
            }

            var ownedReportEntities = await _dataAccessor.GetAllReportsAsync(tenantId, userId, searchText, ownedReportsOnly);
            var allSystemReports = isDomainAccessControlEnabled ? await _systemReportsSvc.GetAllReports(includeDrafts) : userAccessibleSystemReports;
            var systemReportIds = allSystemReports.Select(r => r.ReportId).ToHashSet();

            var ownedReports = ownedReportEntities
               .Where(report => systemReportIds.Contains(report.SystemReportId))
               .Select(report => new ReportSummary
               {
                   Id = report.ReportId,
                   ReportName = report.ReportName,
                   Description = report.Description,
                   OwnerUserId = report.OwnerUserId,
                   LastViewed = report.LastViewed,
                   LastUpdated = report.LastUpdated,
                   SystemReportId = report.SystemReportId,
                   ReportType = (ReportType)report.ReportType,
                   SystemReportName = report.SystemReportName
               })
               .ToList();

            var userIds = ownedReports.Select(entity => entity.OwnerUserId);

            var usersInfo = await _userInfoProvider.GetUsersDetails(tenantId, userIds);

            var reports = new List<ReportSummary>();

            foreach (var entity in ownedReports)
            {
                var user = usersInfo?.Where(u => u.LegacyId == entity.OwnerUserId).SingleOrDefault();
                var systemReport = allSystemReports.Where(r => r.ReportId == entity.SystemReportId).Single();

                reports.Add(new ReportSummary()
                {
                    Id = entity.Id,
                    OwnerUserId = entity.OwnerUserId,
                    LastViewed = entity.LastViewed == DateTime.MinValue ? null : entity.LastViewed,
                    LastUpdated = entity.LastUpdated,
                    ReportName = entity.ReportName,
                    Description = entity.Description,
                    OwnerUserName = GetUserName(user),
                    OwnerThumbnailUrl = user?.ThumbnailUrl,
                    ReportType = ReportType.Custom,
                    SystemReportName = systemReport.ReportName,
                    SystemReportId = systemReport.ReportId,
                    ShowTeamsitePicker = systemReport.ShowTeamsitePicker
                });
            }

            var sharedReports = await GetAllSharedReports(tenantId, userId, searchText, allSystemReports);

            var sharedReportUserIds = sharedReports.Select(entity => entity.OwnerUserId);

            var sharedReportUsersInfo = await _userInfoProvider.GetUsersDetails(tenantId, sharedReportUserIds);

            foreach (var entity in sharedReports)
            {
                var user = sharedReportUsersInfo?.Where(u => u.LegacyId == entity.OwnerUserId).SingleOrDefault();
                var systemReport = allSystemReports.Where(r => r.ReportId == entity.SystemReportId).Single();

                reports.Add(new ReportSummary()
                {
                    Id = entity.Id,
                    OwnerUserId = entity.OwnerUserId,
                    LastViewed = entity.LastViewed == DateTime.MinValue ? null : entity.LastViewed,
                    LastUpdated = entity.LastUpdated,
                    ReportName = entity.ReportName,
                    Description = entity.Description,
                    OwnerUserName = GetUserName(user),
                    OwnerThumbnailUrl = user?.ThumbnailUrl,
                    ReportType = ReportType.Custom,
                    SystemReportName = systemReport.ReportName,
                    SystemReportId = systemReport.ReportId,
                    ShowTeamsitePicker = systemReport.ShowTeamsitePicker,
                });
            }

            var access = await _permissionService.GetContextUserAccess(false);
            if (access == AccessLevel.Editor || (isDomainAccessControlEnabled && access == AccessLevel.CustomReportEditor))
            {
                return reports.Concat(systemReports).ToList();
            }

            //non editors do not get access to system reports
            return reports.ToList();
        }

        /// <summary>
        /// Retrieves only the IDs and names of reports owned by the user and system reports
        /// </summary>
        /// <param name="tenantId">The tenant ID</param>
        /// <param name="userId">The user ID</param>
        /// <param name="searchText">Optional text to search within report names</param>
        /// <param name="includeDrafts">Whether to include draft reports</param>
        /// <param name="ownedReportsOnly">Whether to include only reports owned by the user</param>
        /// <returns>List of report IDs and names</returns>
        private async Task<List<ReportIdNameModel>> RetrieveSystemAndOwnedReportMetadata(
            Guid tenantId,
            string userId,
            string? searchText = null,
            bool includeDrafts = true,
            bool ownedReportsOnly = false)
        {
            var allSystemReports = await _systemReportsSvc.GetAllReports(includeDrafts);
            var isDomainAccessControlEnabled = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDomainAccessControl);
            var systemReports = allSystemReports
                .Select(systemReport =>
                {
                    return new ReportIdNameModel
                    {
                        ReportId = systemReport.ReportId,
                        ReportName = systemReport.ReportName,
                        ReportType = ReportType.System
                    };
                })
                .Where(x => string.IsNullOrWhiteSpace(searchText) || x.ReportName.Contains(searchText, StringComparison.CurrentCultureIgnoreCase))
                .ToList();

            var ownedReportEntities = await _dataAccessor.GetAllReportsAsync(tenantId, userId, searchText, ownedReportsOnly);

            var systemReportIds = allSystemReports.Select(r => r.ReportId).ToHashSet();

            var ownedReports = ownedReportEntities
               .Where(report => systemReportIds.Contains(report.SystemReportId))
               .Select(report => new ReportIdNameModel
               {
                   ReportId = report.ReportId,
                   ReportName = report.ReportName,
                   ReportType = ReportType.Custom
               })
               .ToList();

            var access = await _permissionService.GetContextUserAccess(false);
            if (access == AccessLevel.Editor || (isDomainAccessControlEnabled && AccessLevel.CustomReportEditor == access))
            {
                return [.. systemReports, .. ownedReports];
            }

            //non editors do not get access to system reports
            return [.. ownedReports];
        }

        public async Task<Report> GetReportById(Guid reportId, Guid tenantId, string userId, bool forceRefresh = false)
        {
            // Get only user accessible field and filter system report
            var report = await _systemReportsSvc.GetReportDefinition(reportId);
            var allFilterTemplates = new List<FilterTemplateModel>().AsEnumerable();
            var systemReportFields = report?.FieldGroups.SelectMany(f => f.Fields).Where(f => f.IsDefault).ToList();
            var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);
            List<string> allReportDefinitionfilters = [];
            var filterGroups = new List<FilterGroup>();

            if (report != null)
            {
                var access = await _permissionService.GetContextUserAccess(false);
                var isDomainAccessControlEnabled = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDomainAccessControl);
                if ((access == AccessLevel.Viewer) || !((isDomainAccessControlEnabled && AccessLevel.CustomReportEditor == access) || access == AccessLevel.Editor))
                {
                    throw new BadRequestException("User does not have access to view system reports");
                }

                allReportDefinitionfilters = report.Filters?.Select(f => f.FilterName).ToList() ?? [];
                allFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(report.FieldGroups, allReportDefinitionfilters, report.ShowTeamsitePicker, false, []);
                report.Filters = AddGenericFiltersToReportDefinitionMetadata(report.Filters ?? [], allFilterTemplates);
                var allowedFilterTemplates = allFilterTemplates.Where(filter => (report.Filters ?? []).Any(rf => string.Compare(rf.FilterName, filter.FilterName, true) == 0)).ToList();
                SetDefaultToTemplates(report, allowedFilterTemplates);
                var filtersToUse = SubstituteDynamicValuesInFilters(report.Filters ?? [], allowedFilterTemplates);
                filterGroups = MapFilterGroups(report.Filters, allowedFilterTemplates);
                var standardReportMetadata = SubstituteDynamicValuesInReport(report, filtersToUse);
                standardReportMetadata.FilterGroup = filterGroups;

                return new Report()
                {
                    Id = report.ReportId,
                    SystemReportId = report.ReportId,
                    ReportName = report.ReportName,
                    SystemReportName = report.ReportName,
                    Description = report.Description,
                    OwnerUserId = ReportConstants.SYSTEM_DEFAULT_USER,
                    OwnerUserName = ReportConstants.SYSTEM_DEFAULT_USER,
                    ReportType = ReportType.System,
                    OrderBy = EnumExtension.GetEnumValueFromDisplayName<OrderType>(report.OrderBy),
                    OrderField = report.OrderField,
                    RequestedFields = systemReportFields ?? [],
                    AppliedFilters = filtersToUse,
                    StandardReportMetadata = standardReportMetadata,
                    ShowTeamsitePicker = report.ShowTeamsitePicker,
                    Teamsites = userSettings.Teamsites,
                };
            }

            //var cacheKey = new CustomReportCacheKey(tenantId, reportId);
            //var cached = await _seismicCache.GetAsync(cacheKey);

            DataAccess.Entities.Report reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId) ?? throw new NotFoundException($"Report not found. report id:{reportId}");
            var customReportSelectedTeamsiteIds = reportEntity.Teamsites ?? [];


            if (customReportSelectedTeamsiteIds == null || customReportSelectedTeamsiteIds.Count() == 0)
            {
                customReportSelectedTeamsiteIds = userSettings.Teamsites.Where(x => x.IsSelected).Select(x => x.Id).ToArray();
            }

            var customReportSelectedTeamsites = reportEntity.Teamsites != null && reportEntity.Teamsites.Count() > 0
                ? userSettings.Teamsites.Select(ut => new Teamsites
                {
                    Id = ut.Id,
                    Name = ut.Name,
                    Description = ut.Description,
                    IsSelected = reportEntity?.Teamsites?.Contains(ut.Id) ?? false
                }).ToList() : userSettings.Teamsites.Select(ut => new Teamsites
                {
                    Id = ut.Id,
                    Name = ut.Name,
                    Description = ut.Description,
                    IsSelected = customReportSelectedTeamsiteIds.Contains(ut.Id)
                }).ToList();


            // Get report with all accessible fields and filters to validate existing custom reports filter.
            var systemReportWithAllFieldsAndFilters = (await _systemReportsSvc.GetReportDefinition(reportEntity.SystemReportId, false)) ?? throw new NotFoundException($"System report not found. reportId:{reportId}, system reportId:{reportEntity.SystemReportId}");

            var systemReportWithOnlyAccessibleFieldsAndFilters = (await _systemReportsSvc.GetReportDefinition(reportEntity.SystemReportId)) ?? throw new NotFoundException($"System report not found. reportId:{reportId}, system reportId:{reportEntity.SystemReportId}");


            await ValidateReportAccess(reportId, tenantId, userId, reportEntity.OwnerUserId, systemReportWithAllFieldsAndFilters.ShowTeamsitePicker, customReportSelectedTeamsiteIds, userSettings);
            if (systemReportWithAllFieldsAndFilters.ShowTeamsitePicker)
            {
                ValidateReportsFieldAndFiltersAccessibilityByTeamsites(systemReportWithAllFieldsAndFilters.FieldGroups, reportEntity.Fields, reportEntity.Filters, userSettings, userId);
            }

            allReportDefinitionfilters = systemReportWithAllFieldsAndFilters?.Filters?.Select(f => f.FilterName).ToList() ?? [];
            allFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(systemReportWithAllFieldsAndFilters.FieldGroups, allReportDefinitionfilters, systemReportWithAllFieldsAndFilters.ShowTeamsitePicker, true, customReportSelectedTeamsiteIds);
            systemReportWithAllFieldsAndFilters.Filters = AddGenericFiltersToReportDefinitionMetadata(systemReportWithAllFieldsAndFilters.Filters ?? [], allFilterTemplates);
            var allfilterMetadata = allFilterTemplates.Where(filter => (systemReportWithAllFieldsAndFilters.Filters ?? []).Any(rf => string.Compare(rf.FilterName, filter.FilterName, true) == 0)).ToList();


            var userAccessibleReportDefinitionfilters = systemReportWithOnlyAccessibleFieldsAndFilters?.Filters?.Select(f => f.FilterName).ToList() ?? [];
            var userAccessibleFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(systemReportWithOnlyAccessibleFieldsAndFilters.FieldGroups, userAccessibleReportDefinitionfilters, systemReportWithAllFieldsAndFilters.ShowTeamsitePicker, true, customReportSelectedTeamsiteIds);
            systemReportWithOnlyAccessibleFieldsAndFilters.Filters = AddGenericFiltersToReportDefinitionMetadata(systemReportWithOnlyAccessibleFieldsAndFilters.Filters ?? [], userAccessibleFilterTemplates);
            var accessibleFilterMetadata = userAccessibleFilterTemplates.Where(filter => (systemReportWithOnlyAccessibleFieldsAndFilters.Filters ?? []).Any(rf => string.Compare(rf.FilterName, filter.FilterName, true) == 0)).ToList();


            SetDefaultToTemplates(systemReportWithOnlyAccessibleFieldsAndFilters, allfilterMetadata);

            systemReportFields = [.. systemReportWithOnlyAccessibleFieldsAndFilters.FieldGroups.SelectMany(f => f.Fields)];

            UserResource owner = null;
            try
            {
                owner = await _userService.GetUserById(tenantId, reportEntity.OwnerUserId);
            }
            catch (Exception ex)
            {
                _logger.Warning(ex, "Error while fetching owner user details for report {ReportId}, reportOwnerUserId {OwnerUserId}", reportId, reportEntity.OwnerUserId);

            }

            List<ReportField>? fields = MapFields(reportEntity, systemReportWithOnlyAccessibleFieldsAndFilters, systemReportFields);
            var appliedFilters = MapFilters(reportEntity, allfilterMetadata, systemReportWithOnlyAccessibleFieldsAndFilters);

            //Validating here is important to support deleted system filter which is replaced with generic filter
            await ValidateUserAccessibleFilters(appliedFilters, tenantId, userId);

            filterGroups = MapFilterGroups(systemReportWithOnlyAccessibleFieldsAndFilters.Filters, accessibleFilterMetadata);

            systemReportWithOnlyAccessibleFieldsAndFilters.FilterGroup = filterGroups;

            var result = new Report()
            {
                Domain = reportEntity.Domain,
                Id = reportEntity.ReportId,
                OwnerUserId = reportEntity.OwnerUserId,
                LastUpdated = reportEntity.ModifiedOnUtc,
                ReportName = reportEntity.ReportName,
                Description = reportEntity.Description,
                OwnerUserName = owner?.Name,
                ReportType = ReportType.Custom,
                OrderField = reportEntity.OrderByField,
                OrderBy = (OrderType)reportEntity.OrderBy,
                RequestedFields = fields,
                AppliedFilters = appliedFilters,
                SystemReportName = systemReportWithOnlyAccessibleFieldsAndFilters.ReportName,
                SystemReportId = systemReportWithOnlyAccessibleFieldsAndFilters.ReportId,
                StandardReportMetadata = systemReportWithOnlyAccessibleFieldsAndFilters,
                ShowTeamsitePicker = systemReportWithOnlyAccessibleFieldsAndFilters.ShowTeamsitePicker,
                Teamsites = customReportSelectedTeamsites
            };

            //return await _seismicCache.SetAsync(cacheKey, result);
            return result;
        }

        private async Task<bool> ValidateUserAccessibleFilters(List<ReportExecutionFilter>? filters, Guid tenantId, string userId)
        {
            var dataAreas = await _dataAccessor.GetAllDataAreasAccessAsync(tenantId);
            var defaultDataAreas = _systemDataAreaService.GetAllSystemDataAreas() ?? [];
            var user = await _userService.GetUserById(tenantId, userId);

            foreach (var filter in filters)
            {
                if (!_systemReportsSvc.HasAccessToDataArea(user, defaultDataAreas, dataAreas, filter.DataAreaKey))
                {
                    var sanitizedUserId = userId?.Replace("\r", "").Replace("\n", "");
                    var sanitizedFilterName = filter.FilterName?.Replace("\r", "").Replace("\n", "");
                    _logger.Error("User:{userId} does not have access to required data area for applied filter {filterName}.", sanitizedUserId, sanitizedFilterName);
                    throw new ForbiddenException($"User {sanitizedUserId} does not have access to required data area.");
                }
            }

            return true;
        }


        public async Task<(ReportDefinitionMetadata, string)> GetReportDefinition(Guid reportId, Guid tenantId)
        {
            ReportDefinitionMetadata? reportToRun;

            var reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId);

            if (reportEntity == null)
            {
                // here get system report with available fields and filter only
                reportToRun = await _systemReportsSvc.GetReportDefinition(reportId);
            }
            else
            {
                // here get system report with available fields and filter only
                reportToRun = await _systemReportsSvc.GetReportDefinition(reportEntity.SystemReportId);
            }

            if (reportToRun == null)
            {
                throw new NotFoundException($"Report not found. report id:{reportId}");
            }

            return (reportToRun, reportEntity == null ? reportToRun.ReportName : reportEntity.ReportName);
        }

        private async Task ValidateReportAccess(Guid reportId, Guid tenantId, string userId, string ownerUserId, bool showTeamSitePicker, string[] teamsites, Models.UserSettings userSettings)
        {
            if (ownerUserId != userId)
            {
                var userDetail = await _userService.GetUserById(tenantId, userId);
                var sharedReport = await _dataAccessor.GetSharedReportWithUserAsync(reportId, userId, tenantId, userDetail.DirectGroupLegacyIds) ??
                    throw new ForbiddenException($"User {userId} does not have access to report {reportId}");

                //Check if the user have access to all the teamsites that belong to the custom report
                if (showTeamSitePicker)
                {
                    var userAccessibleTeamsiteIds = userSettings.Teamsites.Select(x => x.Id).ToList();
                    var inaccessibleTeamsites = teamsites.Except(userAccessibleTeamsiteIds).ToList();
                    if (inaccessibleTeamsites.Count != 0)
                    {
                        throw new ForbiddenException($"User does not have access to the Report {reportId} due to an inaccessible Teamsites");
                    }
                }
            }
        }

        private void ValidateReportsFieldAndFiltersAccessibilityByTeamsites(List<FieldGroup> systemReportFieldGroups, List<DataAccess.Entities.ReportField> reportFields, List<DataAccess.Entities.ReportFilter> reportFilters, UserSettings userSettings, string userId)
        {
            var systemReportFields = systemReportFieldGroups.SelectMany(x => x.Fields);
            var userAccessibleTeamsiteIds = userSettings.Teamsites.Select(x => x.Id).ToList();
            var inaccessibleSystemReportFields = systemReportFields.Where(f => f?.IsProperty == true && f?.PropertyType == Models.Template.PropertyType.ContentCustomProperty && (f.TeamsiteIds != null && !f.TeamsiteIds.Any(t => userAccessibleTeamsiteIds.Contains(t)))).ToList();
            var inaccessibleSystemReportFieldsProperyIds = inaccessibleSystemReportFields.Select(f => f.PropertyId).ToList();

            var inaccessibleReportFields = reportFields.Where(rf => inaccessibleSystemReportFieldsProperyIds.Contains(rf.PropertyId));
            var inaccessibleReportFilters = reportFilters.Where(rf => inaccessibleSystemReportFieldsProperyIds.Contains(rf.PropertyId));

            if (inaccessibleReportFields.Any() || inaccessibleReportFilters.Any())
            {
                var inaccessibleFields = inaccessibleReportFields.Select(f => f.Name).ToList();
                var inaccessibleFilters = inaccessibleReportFilters.Select(f => f.FilterName).ToList();
                var sanitizedUserId = userId.Replace(Environment.NewLine, "").Replace("\r", "").Replace("\n", "");
                logger.Warning("User {UserId} does not have access to the Report due to inaccessible fields: {Fields} and filters: {Filters}", sanitizedUserId, string.Join(", ", inaccessibleFields), string.Join(", ", inaccessibleFilters));
                throw new ForbiddenException($"User {userId} does not have access to the Report due to inaccessible fields: {string.Join(", ", inaccessibleFields)} and filters: {string.Join(", ", inaccessibleFilters)}");
            }
        }

        private static List<ReportFilter> AddGenericFiltersToReportDefinitionMetadata(List<ReportFilter> reportFilters, IEnumerable<FilterTemplateModel> allFilterTemplates)
        {
            return [
                .. reportFilters ??[],
                .. allFilterTemplates
                .Where(f => f.IsGenericFilter ?? false)
                .Where(f => false == reportFilters?.Any(rf => rf.FilterName.Equals(f.FilterName, StringComparison.OrdinalIgnoreCase)))
                .Select(f =>
                    new ReportFilter
                    {
                        FilterName = f.FilterName,
                        Category = f.Category,
                        IsDefault = f.FilterIsDefault ?? false,
                        DefaultOperator = f.FilterDefaultOperator,
                        DefaultValues = f.FilterDefaultValues
                    }
                ),
            ];
        }

        private static void SetDefaultToTemplates(ReportDefinitionMetadata? report, List<FilterTemplateModel> allowedFilterTemplates)
        {
            allowedFilterTemplates.ForEach(ft =>
            {
                var filter = report?.Filters?.FirstOrDefault(f => string.Compare(f.FilterName, ft.FilterName, true) == 0);
                if (filter != null)
                {
                    ft.IsDefault = filter.IsDefault;
                }
            });
        }

        private List<ReportExecutionFilter>? MapFilters(DataAccess.Entities.Report reportEntity, IEnumerable<FilterTemplateModel> systemFilters, ReportDefinitionMetadata systemReport)
        {

            //this is a bug where user property filter name is saved without appending the id. so here we are updating the filter name with the system filter name
            var reportUserTypeFilters = reportEntity.Filters?.Where(f => f.IsProperty.HasValue && f.IsProperty.Value && f.PropertyType == EntityPropertyType.UserProperty).ToList() ?? [];
            foreach (var filter in reportUserTypeFilters)
            {
                var userPropertySystemFilter = systemFilters.SingleOrDefault(f => f.IsProperty.HasValue && f.IsProperty.Value && f.PropertyType == EntityPropertyType.UserProperty && f.PropertyId == filter.PropertyId);
                if (userPropertySystemFilter != null && filter.FilterName != userPropertySystemFilter.FilterName)
                {
                    _logger.Warning("User property filter name mismatch found for Report Name: {ReportName}, ReportId: {ReportId} for tenant : {TenantId}", reportEntity.ReportName, reportEntity.ReportId, reportEntity.TenantId);
                    filter.FilterName = userPropertySystemFilter.FilterName;
                }
            }

            List<FilterTemplateModel>? systemUserPropertyFilters = null;
            if (systemReport.IncludeUserProperties)
            {
                systemUserPropertyFilters = systemFilters.Where(f => f.IsProperty.HasValue && f.IsProperty.Value && f.PropertyType.HasValue && f.PropertyType.Value == EntityPropertyType.UserProperty).ToList();
            }

            List<FilterTemplateModel>? systemContentCustomPropertyFilters = null;
            if (systemReport.IncludeCustomProperties)
            {
                systemContentCustomPropertyFilters = systemFilters.Where(f => f.IsProperty.HasValue && f.IsProperty.Value && f.PropertyType.HasValue && f.PropertyType.Value == EntityPropertyType.ContentCustomProperty).ToList();
            }

            return CreateFilters(reportEntity, systemFilters, systemUserPropertyFilters, systemContentCustomPropertyFilters);
        }

        private List<ReportExecutionFilter> CreateFilters(DataAccess.Entities.Report reportEntity, IEnumerable<FilterTemplateModel> systemFilters, List<FilterTemplateModel>? systemUserPropertyFilters, List<FilterTemplateModel>? systemContentCustomPropertyFilters)
        {
            var filters = new List<ReportExecutionFilter>();

            if (reportEntity.Filters == null || reportEntity.Filters.Count == 0)
            {
                return filters;
            }

            var archivedFilters = _systemReportsSvc.GetArchivedFilters(reportEntity.SystemReportId);
            foreach (var f in reportEntity.Filters)
            {
                var systemFilter = systemFilters?.FirstOrDefault(sf => string.Compare(sf.FilterName, f.FilterName, true) == 0);
                var filterName = f.FilterName;

                // Support for backward compatibility of deletion of system filters and converted to generic generic filter
                // And skip filters that are not available in the system filters due to required feature key is not enabled for this tenant
                if (systemFilter == null)
                {
                    // Step 1: Check if this is an archived system filter that was converted to a generic filter
                    var archivedFilter = archivedFilters?.SingleOrDefault(af =>
                        af.SystemFilterName.Equals(f.FilterName, StringComparison.OrdinalIgnoreCase));

                    if (archivedFilter != null)
                    {
                        // Step 2: Try to find a matching generic filter using the archived filter's field name
                        var genericFilter = systemFilters?.SingleOrDefault(sf =>
                            sf.IsGenericFilter == true &&
                            string.Compare(sf.FilterName, archivedFilter.FieldName, true) == 0);

                        if (genericFilter != null)
                        {
                            // Found matching generic filter - use the archived field name
                            _logger.Warning("System filter '{FilterName}' was archived and converted to a generic filter. Using '{FieldName}' as the new filter name.", f.FilterName, archivedFilter.FieldName);
                            filterName = archivedFilter.FieldName;
                        }
                        else
                        {
                            // Filter was archived but has no generic equivalent
                            // Skip it since the required feature key is not enabled for this tenant
                            continue;
                        }
                    }
                    else
                    {
                        // Neither a system filter nor an archived filter - skip it
                        // This filter was likely removed due to required feature key is not enabled for this tenant
                        continue;
                    }
                }

                var newFilter = new ReportExecutionFilter()
                {
                    FilterName = filterName,
                    Operation = (Operation)f.Operation,
                    Values = f.Values,
                    IsProperty = f.IsProperty,
                    PropertyId = f.PropertyId,
                    PropertyType = f.PropertyType.HasValue ? (ExecutionPropertyType)f.PropertyType.Value : ExecutionPropertyType.None,
                    DataAreaKey = systemFilter?.DataAreaKey
                };

                filters.Add(newFilter);
                if (f.IsProperty.HasValue && f.IsProperty.Value && (f.PropertyType == EntityPropertyType.UserProperty || f.PropertyType == EntityPropertyType.ContentCustomProperty))
                {
                    var userProperty = systemUserPropertyFilters?.SingleOrDefault(filter => filter.PropertyId == f.PropertyId);
                    var customProperty = systemContentCustomPropertyFilters?.SingleOrDefault(filter => filter.PropertyId == f.PropertyId);
                    if (userProperty != null)
                    {
                        newFilter.FilterName = userProperty.FilterName;
                    }
                    else if (customProperty != null)
                    {
                        newFilter.FilterName = customProperty.FilterName;
                        newFilter.TeamsiteIds = customProperty.TeamsiteIds;
                    }
                    else
                    {
                        filters.Remove(newFilter);
                    }
                }
            }
            return filters;
        }

        private static List<ReportField> MapFields(DataAccess.Entities.Report reportEntity, ReportDefinitionMetadata systemReport, List<ReportField> systemReportFields)
        {
            var fields = new List<ReportField>();

            // Exclude custom report fields that are not present in the system report's due to required feature keys and data area permission
            reportEntity.Fields = reportEntity.Fields.Where(f => systemReportFields.Any(sf => string.Compare(sf.Name, f.Name, true) == 0)).ToList();

            var customPropertyFields = systemReport.FieldGroups.Where(fg => fg.UxLabel == CustomPropertyConstant.CUSTOM_PROPERTIES).SelectMany(fg => fg.Fields).ToList();

            foreach (var field in reportEntity.Fields)
            {
                var systemField = systemReportFields?.FirstOrDefault(f => f.Name.Equals(field.Name, StringComparison.OrdinalIgnoreCase));
                if (systemField != null)
                {

                    var newField = new ReportField()
                    {
                        Name = field.Name,
                        DataType = systemField.DataType,
                        IsDefault = field.IsDefault,
                        UxLabel = systemField.UxLabel,
                        UxDescription = systemField.UxDescription,
                        IsProperty = field.IsProperty,
                        PropertyType = field.PropertyType.HasValue ? (ModelPropertyType)field.PropertyType : ModelPropertyType.None,
                        PropertyId = field.PropertyId,
                        Formatter = systemField.Formatter,
                        Definition = systemField.Definition,
                        EnableRelativeUserFilterField = systemField.EnableRelativeUserFilterField,
                    };

                    fields.Add(newField);
                    if (field.IsProperty.HasValue && (field.PropertyType == EntityPropertyType.UserProperty || field.PropertyType == EntityPropertyType.ContentCustomProperty))
                    {
                        var customProperty = customPropertyFields?.SingleOrDefault(f => f.PropertyId == field.PropertyId);

                        if (customProperty != null)
                        {
                            newField.UxLabel = customProperty.UxLabel;
                            newField.UxDescription = customProperty.UxDescription;
                            newField.DataType = customProperty.DataType;
                            newField.Name = customProperty.Name;
                            newField.TeamsiteIds = customProperty.TeamsiteIds;
                        }
                        else
                        {
                            fields.Remove(newField);
                        }
                    }
                }
            }

            return fields;
        }

        public async Task<PagedList<RecentReport>> GetRecentReports(string userId, Guid tenantId, string? reportType = null,
            string? searchText = null, int take = 200, int skip = 0, string? orderField = null, string? orderBy = null)
        {
            var recentReports = await _dataAccessor.GetRecentReportsAsync(userId, tenantId);

            var recentSystemReports = recentReports
                .Where(report => report.ReportType == DataAccess.Enum.ReportType.System);

            var allSystemReports = await _systemReportsSvc.GetAllReports();
            var systemReportIds = allSystemReports.Select(r => r.ReportId).ToHashSet();
            var systemReports = GetSystemReportsForRecentReports(recentSystemReports, allSystemReports);

            var recentCustomReports = recentReports
                .Where(report => (ReportType)report.ReportType != ReportType.System && systemReportIds.Contains(report.SystemReportId))
                .Select(report => new RecentReport
                {
                    Id = report.ReportId,
                    ReportName = report.ReportName,
                    Description = report.Description,
                    Domain = report.Domain,
                    OwnerUserId = report.OwnerUserId,
                    LastViewed = report.LastViewed,
                    LastUpdated = report.LastUpdated,
                    ReportType = (ReportType)report.ReportType,
                    UserId = report.UserId,
                    SystemReportId = report.SystemReportId,
                    SystemReportName = report.SystemReportName
                }).ToList();


            await PopulateUserInfo(tenantId, allSystemReports, recentCustomReports);

            recentCustomReports.AddRange(systemReports);
            recentCustomReports = OrderRecentReports(orderField, orderBy, recentCustomReports);

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                recentCustomReports = recentCustomReports.Where(r => r.ReportName.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                || r.Description.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)).ToList();
            }

            var paginatedReports = recentCustomReports
                .Skip(skip)
                .Take(take)
                .ToList();

            return new PagedList<RecentReport>
            {
                Data = paginatedReports,
                Skip = skip,
                Take = take,
                TotalRecords = recentCustomReports.Count
            };
        }

        public async Task AddToRecentReports(Guid reportId, DateTime openDate, string userId, Guid tenantId)
        {
            var existingReport = await _dataAccessor.GetRecentReportAsync(reportId, userId, tenantId);

            if (existingReport != null)
            {
                existingReport.OpenDate = openDate;
                existingReport.ModifiedOnUtc = DateTime.UtcNow;
                await _dataAccessor.UpdateRecentReportAsync(existingReport);
            }
            else
            {
                var newReport = new DataAccess.Entities.RecentReport
                {
                    ReportId = reportId,
                    UserId = userId,
                    OpenDate = openDate,
                    TenantId = tenantId,
                    CreatedOnUtc = DateTime.UtcNow,
                    ModifiedOnUtc = DateTime.UtcNow
                };
                await _dataAccessor.AddRecentReportAsync(newReport);
            }
        }

        [Trace]
        public async Task<Report> CreateReport(ReportCreateRequest request, string userId, Guid tenantId)
        {
            if (request == null)
            {
                throw new BadRequestException("Request cannot be null");
            }

            var sw = Stopwatch.StartNew();
            try
            {
                (bool isUniqueName, string errorMessage) = await IsReportNameUniqueForOwner(request.ReportName, tenantId, userId);

                if (!isUniqueName)
                {
                    throw new BadRequestException(errorMessage);
                }
                // here get system report with available fields and filter only
                var systemReport = await _systemReportsSvc.GetReportDefinition(request.SystemReportId)
                    ?? throw new NotFoundException($"System report not found. reportId:{request.SystemReportId}");

                var systemReportFields = systemReport.FieldGroups?.SelectMany(x => x.Fields).ToList();

                var fields = request.Fields?.Select(field => new DataAccess.Entities.ReportField
                {
                    Name = field.Name,
                    IsDefault = field.IsDefault,
                    IsProperty = field.IsProperty,
                    PropertyType = field.PropertyType.HasValue ? (EntityPropertyType)field.PropertyType : EntityPropertyType.None,
                    PropertyId = field.PropertyId,
                }).ToList();

                var filters = request.Filters?.Select(filter => new DataAccess.Entities.ReportFilter
                {
                    FilterName = filter.FilterName,
                    Operation = (DataAccess.Entities.Operation)filter.Operation,
                    Values = filter.Values,
                    IsProperty = filter.IsProperty,
                    PropertyType = filter.PropertyType.HasValue ? (EntityPropertyType)filter.PropertyType.Value : EntityPropertyType.None,
                    PropertyId = filter.PropertyId
                }).ToList();

                var reportEntity = new DataAccess.Entities.Report
                {
                    ReportId = Guid.NewGuid(),
                    SystemReportId = request.SystemReportId,
                    TenantId = tenantId,
                    ReportName = request.ReportName,
                    Description = request.Description,
                    OwnerUserId = userId,
                    Fields = fields ?? [],
                    Filters = filters ?? [],
                    OrderByField = request.OrderField ?? systemReport.OrderField,
                    OrderBy = request.OrderBy.HasValue ? (DataAccess.Enum.OrderType)request.OrderBy :
                    (systemReport.OrderBy != null ? Enum.Parse<DataAccess.Enum.OrderType>(systemReport.OrderBy) : DataAccess.Enum.OrderType.ASC),
                    CreatedOnUtc = DateTime.UtcNow,
                    ModifiedOnUtc = DateTime.UtcNow,
                    Teamsites = request.TeamsiteIds ?? [],
                };

                List<string> reportDefinitionfilters = systemReport.Filters?.Select(f => f.FilterName).ToList() ?? [];
                var allFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(systemReport.FieldGroups, reportDefinitionfilters, systemReport.ShowTeamsitePicker, true, request.TeamsiteIds ?? []);
                systemReport.Filters = AddGenericFiltersToReportDefinitionMetadata(systemReport.Filters ?? [], allFilterTemplates);

                var reportFiltersMetadata = allFilterTemplates
                    .Where(filter => systemReport.Filters.Any(f => string.Compare(f.FilterName, filter.FilterName, true) == 0))
                    .ToList();

                var updated = await _dataAccessor.SaveReportAsync(reportEntity);
                var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);
                var result = EntityToModel(reportEntity, systemReport, reportFiltersMetadata, userSettings.Teamsites);
                sw.Stop();
                RecordCustomNewRelicEvent(userId, tenantId, result, sw.ElapsedMilliseconds, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_SAVEAS);

                //var cacheKey = new CustomReportCacheKey(tenantId, result.Id);
                // return await _seismicCache.SetAsync(cacheKey, result);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while creating the report.");
                throw;
            }
        }

        public async Task<Report> UpdateReport(ReportUpdateRequest request, string userId, Guid tenantId)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                DataAccess.Entities.Report reportEntity = await _dataAccessor.GetReportAsync(request.Id, tenantId)
                    ?? throw new NotFoundException($"Report not found. report id:{request.Id}");

                if (reportEntity.OwnerUserId != userId)
                {
                    throw new ForbiddenException("You do not have permission to edit this report.");
                }

                //if name has changed
                if (!string.Equals(request.ReportName, reportEntity.ReportName, StringComparison.OrdinalIgnoreCase))
                {
                    //check for name duplication
                    var existing = await _dataAccessor.GetReportByNameAsync(request.ReportName, tenantId, userId);
                    if (existing != null && existing.ReportId != request.Id)
                    {
                        throw new BadRequestException($"Report with name {request.ReportName} already exists");
                    }
                }

                reportEntity.ReportName = request.ReportName;
                reportEntity.Description = request.Description;

                reportEntity.Fields = request.Fields?.Count > 0
                    ? request.Fields.Select(field => new DataAccess.Entities.ReportField
                    {
                        Name = field.Name,
                        IsDefault = field.IsDefault,
                        IsProperty = field.IsProperty,
                        PropertyType = field.PropertyType.HasValue ? (EntityPropertyType)field.PropertyType : EntityPropertyType.None,
                        PropertyId = field.PropertyId
                    }).ToList()
                    : reportEntity.Fields;

                reportEntity.Filters = request.Filters?.Count > 0
                    ? request.Filters.Select(filter => new DataAccess.Entities.ReportFilter
                    {
                        FilterName = filter.FilterName,
                        Operation = (DataAccess.Entities.Operation)filter.Operation,
                        Values = filter.Values,
                        IsProperty = filter.IsProperty,
                        PropertyId = filter.PropertyId,
                        PropertyType = filter.PropertyType.HasValue ? (EntityPropertyType)filter.PropertyType.Value : EntityPropertyType.None
                    }).ToList()
                    : [];

                reportEntity.OrderByField = request.OrderField ?? reportEntity.OrderByField;
                reportEntity.OrderBy = request.OrderBy.HasValue ? (DataAccess.Enum.OrderType)request.OrderBy : reportEntity.OrderBy;
                reportEntity.Teamsites = request.TeamsiteIds ?? reportEntity.Teamsites;
                reportEntity.ModifiedOnUtc = DateTime.UtcNow;


                // here get system report with available fields and filter only
                var systemReport = await _systemReportsSvc.GetReportDefinition(reportEntity.SystemReportId)
                    ?? throw new NotFoundException($"System report not found. reportId:{request.Id}, system reportId:{reportEntity.SystemReportId}");

                List<string> reportDefinitionfilters = systemReport.Filters?.Select(f => f.FilterName).ToList() ?? [];
                var allFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(systemReport.FieldGroups, reportDefinitionfilters, systemReport.ShowTeamsitePicker, true, reportEntity.Teamsites ?? []);
                systemReport.Filters = AddGenericFiltersToReportDefinitionMetadata(systemReport.Filters ?? [], allFilterTemplates);
                var reportFiltersMetadata = allFilterTemplates
                    .Where(filter => systemReport.Filters.Any(f => string.Compare(f.FilterName, filter.FilterName, true) == 0))
                    .ToList();

                //Update report
                await _dataAccessor.UpdateReportAsync(reportEntity);

                var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);
                var result = EntityToModel(reportEntity, systemReport, reportFiltersMetadata, userSettings.Teamsites);
                sw.Stop();
                RecordCustomNewRelicEvent(userId, tenantId, result, sw.ElapsedMilliseconds, NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_SAVE);

                //var cacheKey = new CustomReportCacheKey(tenantId, result.Id);
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while updating the report: {Id}.", request.Id);
                throw;
            }
        }

        public async Task UpdateReportName(Guid reportId, string reportName, string userId, Guid tenantId)
        {
            try
            {
                DataAccess.Entities.Report reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId)
                        ?? throw new NotFoundException($"Report not found. report id:{reportId}");
                if (reportEntity.OwnerUserId != userId)
                {
                    throw new ForbiddenException("You do not have permission to edit this report.");
                }
                //if name has changed
                if (!string.Equals(reportName, reportEntity.ReportName, StringComparison.OrdinalIgnoreCase))
                {
                    //check for name duplication
                    (bool isUniqueName, string errorMessage) = await IsReportNameUniqueForOwner(reportName, tenantId, userId);
                    if (!isUniqueName)
                    {
                        throw new BadRequestException(errorMessage);
                    }
                }
                reportEntity.ReportName = reportName;
                reportEntity.ModifiedOnUtc = DateTime.UtcNow;
                //Update report
                await _dataAccessor.UpdateReportAsync(reportEntity);

                var cacheKey = new CustomReportCacheKey(tenantId, reportId);
                var cached = await _seismicCache.GetAsync(cacheKey);
                if (cached != null)
                {
                    cached.ReportName = reportName;
                    await _seismicCache.SetAsync(cacheKey, cached);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while updating the report name: {ReportId}.", reportId);
                throw;
            }
        }

        public async Task UpdateReportDescription(Guid reportId, string description, string userId, Guid tenantId)
        {
            try
            {
                DataAccess.Entities.Report reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId)
                        ?? throw new NotFoundException($"Report not found. report id:{reportId}");
                if (reportEntity.OwnerUserId != userId)
                {
                    throw new ForbiddenException("You do not have permission to edit this report.");
                }
                reportEntity.Description = description;
                reportEntity.ModifiedOnUtc = DateTime.UtcNow;
                //Update report
                await _dataAccessor.UpdateReportAsync(reportEntity);

                var cacheKey = new CustomReportCacheKey(tenantId, reportId);
                var cached = await _seismicCache.GetAsync(cacheKey);
                if (cached != null)
                {
                    cached.Description = description;
                    await _seismicCache.SetAsync(cacheKey, cached);
                }
            }
            catch (NotFoundException)
            {
                throw;
            }
            catch (ForbiddenException)
            {
                throw;
            }
            catch (Exception ex)
            {
                logger.Error(ex, "An error occurred while updating the report description for report {ReportId}", reportId);
                throw;
            }
        }

        public async Task DeleteCustomReportById(Guid reportId, string userId, Guid tenantId)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                var report = await _dataAccessor.GetReportAsync(reportId, tenantId)
                    ?? throw new NotFoundException($"Report not found. report id:{reportId}");

                if (report.OwnerUserId != userId)
                {
                    throw new ForbiddenException($"User {userId} is not the owner of the report {reportId}");
                }
                else
                {
                    var customReport = await GetReportById(reportId, tenantId, userId);
                    report.IsDeleted = true;
                    report.DeletedOnUtc = DateTime.UtcNow;
                    await _dataAccessor.UpdateReportAsync(report);
                    sw.Stop();
                    var filtersMetadata = customReport?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
                    var ssrsReportEvent = new SsrsReportEvent()
                    {
                        TenantId = tenantId,
                        UserId = userId,
                        ReportId = report.ReportId,
                        SystemReportId = report.SystemReportId,
                        ReportName = report.ReportName,
                        SystemReportName = customReport?.SystemReportName ?? string.Empty,
                        IsSystemReport = false,
                        Operation = NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_DELETE,
                        Filters = string.Join(",", report.Filters?.Select(f => f.FilterName) ?? []),
                        FiltersJson = FilterHashHelper.GetFilterHashValues(report.Filters, filtersMetadata),
                        Fields = string.Join(",", report.Fields.Select(f => f.Name)),
                        SortField = report.OrderByField,
                        SortOrder = report.OrderBy.ToString(),
                        CorrelationId = _httpContextAccessor.GetCorrelationId(),
                        Occurred = DateTime.UtcNow,
                        OwnerId = report.OwnerUserId,
                        RequestDuration = sw.ElapsedMilliseconds
                    };
                    _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);

                    var cacheKey = new CustomReportCacheKey(tenantId, reportId);
                    await _seismicCache.RemoveAsync(cacheKey);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while deleting the report: {ReportId}.", reportId);
                throw;
            }
        }

        public async Task<List<FilterTemplateModel>> GetReportFilters(Guid reportId, Guid tenantId)
        {
            try
            {
                var isCustomReport = false;
                string[] customReportSelectedTeamsiteIds = [];
                var systemReport = await _systemReportsSvc.GetReportDefinition(reportId);

                if (systemReport == null)
                {
                    var reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId)
                        ?? throw new NotFoundException($"Report not found. report id:{reportId}");

                    isCustomReport = true;
                    customReportSelectedTeamsiteIds = reportEntity.Teamsites ?? [];
                    systemReport = await _systemReportsSvc.GetReportDefinition(reportEntity.SystemReportId)
                        ?? throw new NotFoundException($"System report not found. report id:{reportEntity.SystemReportId}");
                }

                List<string> reportDefinitionfilters = systemReport.Filters?.Select(f => f.FilterName).ToList() ?? [];
                var allFilterTemplates = await _systemFiltersService.GetAllFiltersAsync(systemReport.FieldGroups, reportDefinitionfilters, systemReport.ShowTeamsitePicker, isCustomReport, customReportSelectedTeamsiteIds);
                systemReport.Filters = AddGenericFiltersToReportDefinitionMetadata(systemReport.Filters ?? [], allFilterTemplates);

                var reportFiltersTemplates = allFilterTemplates
                    .Where(filter => systemReport.Filters.Any(srf => string.Compare(srf.FilterName, filter.FilterName, true) == 0))
                    .ToList();

                return reportFiltersTemplates;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching filters for report: {ReportId}.", reportId);
                throw;
            }
        }

        public async Task UpdateReportOwner(Guid reportId, string proposedOwnerId, Guid tenantId)
        {
            try
            {
                // Get the report and validate tenant
                DataAccess.Entities.Report reportEntity = await _dataAccessor.GetReportAsync(reportId, tenantId) ??
                    throw new NotFoundException($"Report not found. report id:{reportId}, tenantId:{tenantId}");

                // Validate the new owner
                var ownerUser = await _userService.GetUserById(tenantId, proposedOwnerId) ??
                    throw new NotFoundException($"User with id {proposedOwnerId} not found in tenant {tenantId}");

                // Check if same name report exists of that new user id
                var isReportExist = await _dataAccessor.GetReportByNameAsync(reportEntity.ReportName, tenantId, proposedOwnerId);
                if (isReportExist != null)
                {
                    throw new BadRequestException($"A report with the name \"{reportEntity.ReportName}\" already exists for the new owner. Please rename the report before transferring ownership.");
                }

                var sw = Stopwatch.StartNew();
                reportEntity.OwnerUserId = proposedOwnerId;
                reportEntity.ModifiedOnUtc = DateTime.UtcNow;
                //Update report owner
                await _dataAccessor.UpdateReportAsync(reportEntity);
                sw.Stop();


                var cacheKey = new CustomReportCacheKey(tenantId, reportId);
                var cached = await _seismicCache.GetAsync(cacheKey);
                if (cached != null)
                {
                    cached.OwnerUserId = proposedOwnerId;
                    await _seismicCache.SetAsync(cacheKey, cached);
                }

                // Record custom event for New Relic
                //await RecordCustomEventForOwnerUpdate(reportId, proposedOwnerId, tenantId, reportEntity, sw);
            }
            catch (NotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error updating report owner. ReportId: {ReportId}", reportId.ToString());
                throw;
            }
        }

        private async Task RecordCustomEventForOwnerUpdate(Guid reportId, string proposedOwnerId, Guid tenantId, DataAccess.Entities.Report reportEntity, Stopwatch sw)
        {
            var customReport = await GetReportById(reportId, tenantId, proposedOwnerId);
            var filtersMetadata = customReport?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = tenantId,
                UserId = proposedOwnerId,
                ReportId = reportEntity.ReportId,
                SystemReportId = reportEntity.SystemReportId,
                ReportName = reportEntity.ReportName,
                SystemReportName = customReport?.SystemReportName ?? string.Empty,
                IsSystemReport = reportEntity.OwnerUserId == ReportConstants.SYSTEM_DEFAULT_USER,
                Operation = NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_UPDATEOWNER,
                Filters = string.Join(",", reportEntity.Filters?.Select(f => f.FilterName) ?? []),
                FiltersJson = FilterHashHelper.GetFilterHashValues(reportEntity.Filters, filtersMetadata),
                Fields = string.Join(",", reportEntity.Fields.Select(f => f.Name)),
                SortField = reportEntity.OrderByField,
                SortOrder = reportEntity.OrderBy.ToString(),
                CorrelationId = _httpContextAccessor.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = reportEntity.OwnerUserId,
                RequestDuration = sw.ElapsedMilliseconds
            };
            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
        }


        /// <summary>
        /// Checks if the report name is unique for the owner.
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="tenantId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<(bool isUnique, string errorMessage)> IsReportNameUniqueForOwner(string reportName, Guid tenantId, string userId)
        {
            // Check if name exists in system reports
            var allSystemReports = await _systemReportsSvc.GetAllReports();
            if (allSystemReports != null && allSystemReports.Any(r => r.ReportName.Trim().Equals(reportName.Trim(), StringComparison.InvariantCultureIgnoreCase)))
            {
                return (false, $"\"{reportName}\" is a Standard report name. Please select an alternative name.");
            }

            // Check if name exists in owner's reports
            var existingReport = await _dataAccessor.GetReportByNameAsync(reportName, tenantId, userId);
            if (existingReport != null)
            {
                return (false, $"\"{reportName}\" already exists in your reports. Please select an alternative name.");
            }

            return (true, string.Empty);
        }


        private static Report EntityToModel(DataAccess.Entities.Report reportEntity, ReportDefinitionMetadata systemReport, List<FilterTemplateModel> filterMetadata, List<Teamsites> userTeamsites)
        {
            SetDefaultToTemplates(systemReport, filterMetadata);
            var teamsites = userTeamsites.Select(ut => new Teamsites
            {
                Id = ut.Id,
                Name = ut.Name,
                Description = ut.Description,
                IsSelected = reportEntity.Teamsites.Contains(ut.Id)
            }).ToList();

            var fields = new List<ReportField>();
            if (reportEntity.Fields != null)
            {
                foreach (var field in reportEntity.Fields)
                {
                    var systemField = systemReport.FieldGroups.SelectMany(f => f.Fields).FirstOrDefault(f => f.Name.Equals(field.Name, StringComparison.OrdinalIgnoreCase));
                    if (systemField != null)
                    {
                        fields.Add(new ReportField()
                        {
                            Name = field.Name,
                            DataType = systemField.DataType,
                            IsDefault = field.IsDefault,
                            UxLabel = systemField.UxLabel,
                            UxDescription = systemField.UxDescription,
                            IsProperty = field.IsProperty,
                            PropertyType = field.PropertyType.HasValue ? (ModelPropertyType)field.PropertyType : ModelPropertyType.None,
                            PropertyId = field.PropertyId,
                            Formatter = systemField.Formatter,
                            TeamsiteIds = systemField.TeamsiteIds,
                            Definition = systemField.Definition,
                        });
                    }
                }
            }

            var filtersToUse = reportEntity.Filters?.Select(filter => new ReportExecutionFilter()
            {
                FilterName = filter.FilterName,
                Operation = (Operation)filter.Operation,
                Values = filter.Values,
            }).ToList() ?? [];
            var filterGroups = MapFilterGroups(systemReport.Filters, filterMetadata);
            systemReport.FilterGroup = filterGroups;

            return new Report()
            {
                Id = reportEntity.ReportId,
                ReportName = reportEntity.ReportName,
                Description = reportEntity.Description,
                ReportType = ReportType.Custom,
                OwnerUserId = reportEntity.OwnerUserId,

                RequestedFields = fields,
                AppliedFilters = filtersToUse,

                OrderBy = (OrderType)reportEntity.OrderBy,
                OrderField = reportEntity.OrderByField,
                StandardReportMetadata = systemReport,

                SystemReportName = systemReport.ReportName,
                SystemReportId = systemReport.ReportId,
                ShowTeamsitePicker = systemReport.ShowTeamsitePicker,
                Teamsites = teamsites
            };
        }

        private static List<RecentReport> OrderRecentReports(string? orderField, string? orderBy, List<RecentReport> recentCustomReports)
        {
            foreach (var report in recentCustomReports)
            {
                if (report.ReportType == ReportType.System)
                {
                    report.SystemReportName = string.Empty;
                }
            }

            if (!string.IsNullOrWhiteSpace(orderField))
            {
                if (string.IsNullOrWhiteSpace(orderBy))
                    orderBy = "asc";

                recentCustomReports = orderField.ToLower() switch
                {
                    "userid" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.UserId).ToList() : recentCustomReports.OrderByDescending(r => r.UserId).ToList(),
                    "reportname" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.ReportName).ToList() : recentCustomReports.OrderByDescending(r => r.ReportName).ToList(),
                    "systemreportname" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.SystemReportName).ToList() : recentCustomReports.OrderByDescending(r => r.SystemReportName).ToList(),
                    "ownerusername" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.OwnerUserName).ToList() : recentCustomReports.OrderByDescending(r => r.OwnerUserName).ToList(),
                    "lastviewed" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.LastViewed).ToList() : recentCustomReports.OrderByDescending(r => r.LastViewed).ToList(),
                    "lastupdated" => orderBy.Equals(OrderType.ASC.ToString(), StringComparison.CurrentCultureIgnoreCase) ? recentCustomReports.OrderBy(r => r.LastUpdated).ToList() : recentCustomReports.OrderByDescending(r => r.LastUpdated).ToList(),
                    _ => recentCustomReports.OrderByDescending(r => r.LastViewed).ToList(),
                };
            }

            return recentCustomReports;
        }

        private async Task PopulateUserInfo(Guid tenantId, IEnumerable<ReportDefinitionMetadata> allSystemReports, List<RecentReport> recentCustomReports)
        {
            var userIds = recentCustomReports.Select(entity => entity.OwnerUserId);

            var usersInfo = await _userInfoProvider.GetUsersDetails(tenantId, userIds);

            foreach (var item in recentCustomReports)
            {
                var user = usersInfo?.Where(u => u.LegacyId == item.OwnerUserId).SingleOrDefault();
                var systemReport = allSystemReports.Where(r => r.ReportId == item.SystemReportId).Single();
                item.OwnerUserName = GetUserName(user);
                item.OwnerThumbnailUrl = user?.ThumbnailUrl;
                item.SystemReportName = systemReport.ReportName;
                item.SystemReportId = systemReport.ReportId;
            }
        }

        private static string? GetUserName(UserInfoModel? user)
        {
            if (user == null)
            {
                return string.Empty;
            }
            var result = user.FullName?.Trim();

            if (string.IsNullOrWhiteSpace(result))
                return user.Username;

            else return result;
        }

        private static IEnumerable<RecentReport> GetSystemReportsForRecentReports(IEnumerable<RecentReportModel> recentSystemReports,
            IEnumerable<ReportDefinitionMetadata> allSystemReports)
        {
            return allSystemReports
                            .Where(systemReport => recentSystemReports.Any(r => r.ReportId == systemReport.ReportId))
                            .Select(systemReport =>
                            {
                                var recentReport = recentSystemReports.First(r => r.ReportId == systemReport.ReportId);
                                return new RecentReport
                                {
                                    Id = systemReport.ReportId,
                                    ReportName = systemReport.ReportName,
                                    Description = systemReport.Description,
                                    OwnerUserId = ReportConstants.SYSTEM_DEFAULT_USER,
                                    LastViewed = recentReport.LastViewed,
                                    LastUpdated = recentReport.LastUpdated == DateTime.MinValue ? null : recentReport.LastUpdated,
                                    ReportType = ReportType.System,
                                    OwnerUserName = ReportConstants.SYSTEM_DEFAULT_USER,
                                    UserId = recentReport.UserId,
                                    SystemReportName = systemReport.ReportName,
                                    SystemReportId = systemReport.ReportId
                                };
                            });
        }


        private static ReportDefinitionMetadata SubstituteDynamicValuesInReport(ReportDefinitionMetadata report, List<ReportExecutionFilter> parsedFilters)
        {
            if (parsedFilters == null || parsedFilters.Count == 0 || report.Filters == null)
            {
                return report;
            }

            foreach (var f in report.Filters)
            {
                var pf = parsedFilters.Where(p => p.FilterName == f.FilterName).SingleOrDefault();
                if (pf == null)
                {
                    continue;
                }

                f.DefaultValues = pf.Values;
            }

            return report;
        }


        private List<ReportExecutionFilter> SubstituteDynamicValuesInFilters(List<ReportFilter> filters, List<FilterTemplateModel> templateFilters)
        {
            var defaultFilters = filters.Where(f => f.IsDefault);

            List<ReportExecutionFilter> result = [];

            foreach (var item in defaultFilters)
            {
                var match = templateFilters.Where(f => f.FilterName.Equals(item.FilterName, StringComparison.OrdinalIgnoreCase)).SingleOrDefault();
                if (match == null)
                {
                    _logger.Warning("Filter {FilterName} not found in filter metadata", item.FilterName);
                    continue;
                }
                result.Add(new ReportExecutionFilter()
                {
                    FilterName = item.FilterName,
                    Operation = !string.IsNullOrWhiteSpace(item.DefaultOperator) ? Enum.Parse<Operation>(item.DefaultOperator, true) : Operation.None,
                    Values = item.DefaultValues?.Length > 0 ? GetAbsoluteFilterValues(match.DataType, item.DefaultValues) : [],
                    IsProperty = match.IsProperty,
                    PropertyId = match.PropertyId,
                    PropertyType = match.PropertyType.HasValue ? (ExecutionPropertyType)match.PropertyType.Value : ExecutionPropertyType.None,
                    TeamsiteIds = match.TeamsiteIds ?? []
                });
            }

            return result;
        }


        private static string[] GetAbsoluteFilterValues(DataAccess.Entities.DataType dataType, string[]? defaultValues)
        {
            if (defaultValues == null || defaultValues.Length == 0)
                return [];

            if (dataType != DataAccess.Entities.DataType.DateTime && dataType != DataAccess.Entities.DataType.Date)
                return defaultValues;

            var result = new string[defaultValues.Length];
            for (int i = 0; i < defaultValues.Length; i++)
            {
                var value = defaultValues[i].Trim();
                result[i] = ExpressionParser.GetValidDateString(value);
            }
            return result;
        }

        private static List<FilterGroup> MapFilterGroups(List<ReportFilter>? reportFilters, List<FilterTemplateModel> templateFilters)
        {
            if (reportFilters != null && reportFilters.Count > 0)
            {
                var overrides = reportFilters.Where(r => !string.IsNullOrWhiteSpace(r.Category)).ToDictionary(f => f.FilterName, f => f.Category, StringComparer.OrdinalIgnoreCase);

                foreach (var item in templateFilters)
                {
                    if (overrides.TryGetValue(item.FilterName, out var category))
                    {
                        item.Category = category;
                    }
                }
            }

            //TODO - fix. enforce category not null in templates.
            var filterGroups = templateFilters
                .GroupBy(f => f.Category)
                .Select(g => new FilterGroup
                {
                    UxLabel = g.Key,
                    Filters = [.. g]
                })
                .ToList();

            return filterGroups;
        }

        private void RecordCustomNewRelicEvent(string userId, Guid tenantId, Report result, long elapsedMilliseconds, string newRelicCustomEventOperation)
        {
            var filtersMetadata = result?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = tenantId,
                UserId = userId,
                ReportId = result.Id,
                SystemReportId = result.SystemReportId,
                ReportName = result.ReportName,
                SystemReportName = result.SystemReportName,
                IsSystemReport = false,
                Operation = newRelicCustomEventOperation,
                Filters = string.Join(",", result.AppliedFilters?.Select(f => f.FilterName) ?? []),
                FiltersJson = FilterHashHelper.GetFilterHashValues(result.AppliedFilters, filtersMetadata),
                Fields = string.Join(",", result.RequestedFields.Select(f => f.Name)),
                SortField = result.OrderField,
                SortOrder = result.OrderBy.ToString(),
                CorrelationId = _httpContextAccessor.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = result.OwnerUserId,
                RequestDuration = elapsedMilliseconds
            };

            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
        }
    }
}
