﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class DraftReportService(IDataAccessor _dataAccessor, ISystemReportsRepository _systemReportsRepository,  ILogger logger) : IDraftReportService
    {
        private readonly ILogger _logger = logger.ForContext<DraftReportService>();

        public async Task<List<DraftReport>> GetAllDraftReports(Guid tenantId, string? searchText = null)
        {
            try
            {
                var allReports = await _dataAccessor.GetAllDraftReports(tenantId, searchText);
                List<DraftReport> draftReports = [];
                foreach (var report in allReports)
                {
                    var reportModel = EntityToModel(report);
                    if (reportModel != null)
                    {
                        draftReports.Add(reportModel);
                    }
                }

                return draftReports;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while fetching all draft reports.");
                throw;
            }
        }

        public async Task<DraftReport?> GetDraftReportYamlById(Guid reportId, Guid tenantId)
        {
            try
            {
                var draftReportEntity = await _dataAccessor.GetDraftReportById(reportId, tenantId);

                if(draftReportEntity == null)
                {
                    return null;
                }
                return EntityToModel(draftReportEntity);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while fetching draft report: {ReportId}.", reportId);
                throw;
            }
        }


        public async Task<Guid> CreateDraftReport(CreateDraftReport report, string fileText, Guid tenantId)
        {
            try
            {
                //check if report already exists
                var isUnique = await _dataAccessor.IsDraftReportNameUniqueAsync(tenantId, report.ReportName, report.ReportId);
                if (!isUnique)
                {
                    throw new BadRequestException($"Draft report with name {report.ReportName} or Id {report.ReportId} already exists.");
                }

                if (_systemReportsRepository.GetAllReportDefinitions()
                    .Any(r => (r.ReportId == report.ReportId) || (string.Compare(r.ReportName, report.ReportName, true) == 0)))
                {
                    throw new BadRequestException($"System report with id {report.ReportId} or name {report.ReportName} already exists.");
                }

                var draftReportEntity = new DataAccess.Entities.DraftReport
                {
                    ReportId = report.ReportId,
                    TenantId = tenantId,
                    ReportName = report.ReportName,
                    Description = report.Description,
                    Template = fileText,
                    IsDeleted = false,
                    CreatedOnUtc = DateTime.UtcNow,
                    ModifiedOnUtc = DateTime.UtcNow,
                };

                await _dataAccessor.SaveDraftReportAsync(draftReportEntity);
                return draftReportEntity.ReportId;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while creating draft report.");
                throw new BadRequestException($"Error occurred while creating DraftReport. {ex.Message}");
            }
        }

        public async Task<Guid> UpdateDraftReport(Guid draftReportId, CreateDraftReport report, string fileText, Guid tenantId)
        {
            try
            {
                //check for reportId mismatch
                if (draftReportId != report.ReportId)
                {
                    throw new BadRequestException("ReportId mismatch.");
                }

                //check if report exists
                var existingDraftReport = await _dataAccessor.GetDraftReportById(draftReportId, tenantId)
                    ?? throw new BadRequestException($"Draft report with Id {draftReportId} not found.");

                var isUnique = await _dataAccessor.IsDraftReportNameUniqueAsync(tenantId, report.ReportName, report.ReportId);
                if (!isUnique)
                {
                    throw new BadRequestException($"Draft report with name {report.ReportName} already exists.");
                }


                if (_systemReportsRepository.GetAllReportDefinitions()
                    .Any(r => (r.ReportId != report.ReportId) && (string.Compare(r.ReportName, report.ReportName, true) == 0)))
                {
                    throw new BadRequestException($"System report with id {report.ReportId} or name {report.ReportName} already exists.");
                }

                existingDraftReport.ReportName = report.ReportName;
                existingDraftReport.Description = report.Description;
                existingDraftReport.Template = fileText;
                existingDraftReport.ModifiedOnUtc = DateTime.UtcNow;

                await _dataAccessor.UpdateDraftReportAsync(existingDraftReport);
                return report.ReportId;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while updating draft report: {DraftReportId}.", draftReportId);
                throw new BadRequestException($"Error occurred while updating DraftReport. {ex.Message}");
            }
        }

        public async Task<Guid> DeleteDraftReport(Guid draftReportId, Guid tenantId)
        {
            try
            {
                var draftReport = await _dataAccessor.GetDraftReportById(draftReportId, tenantId)
                    ?? throw new NotFoundException($"Draft report with Id {draftReportId} not found.");
                draftReport.IsDeleted = true;
                draftReport.DeletedOnUtc = DateTime.UtcNow;

                var allCustomReports = await _dataAccessor.GetAllReportsBySystemReportIdAsync(draftReportId, tenantId);
                
                var recentReportsToDelete = allCustomReports.Select(r => r.ReportId).ToList();
                recentReportsToDelete.Add(draftReportId);
                var recentReports = await _dataAccessor.GetRecentReportsByReportIdsAsync(tenantId, recentReportsToDelete);
                
                //Delete all recent reports and mark all custom reports as deleted that are created from this draft report
                foreach (var recentReport in recentReports)
                {
                    recentReport.IsDeleted = true;
                    recentReport.DeletedOnUtc = DateTime.UtcNow;
                }

                foreach (var customReport in allCustomReports)
                {
                    customReport.IsDeleted = true;
                    customReport.DeletedOnUtc = DateTime.UtcNow;
                }

                await _dataAccessor.UpdateDraftReportAsync(draftReport);
                await _dataAccessor.UpdateRecentReportsAsync(recentReports);
                await _dataAccessor.UpdateReportsAsync(allCustomReports);
                return draftReportId;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error occurred while deleting draft report: {DraftReportId}.", draftReportId);
                throw;
            }
        }

        private DraftReport? EntityToModel(DataAccess.Entities.DraftReport draftReportEntity)
        {
            try
            {
                var reportDefinition = YamlHelper.Deserialize<ReportDefinitionMetadata>(draftReportEntity.Template);

                return new DraftReport
                {
                    ReportId = draftReportEntity.ReportId,
                    ReportName = draftReportEntity.ReportName + " (Draft)",
                    Description = draftReportEntity.Description,
                    LastUpdated = draftReportEntity.ModifiedOnUtc,
                    ReportType = ReportType.Draft,
                    TenantId = draftReportEntity.TenantId,
                    Template = draftReportEntity.Template,
                    Query = BuildReportDefinitionQuery(draftReportEntity, reportDefinition),
                    Metadata = new ReportDefinitionMetadata()
                    {
                        ReportId = draftReportEntity.ReportId,
                        ReportName = draftReportEntity.ReportName,
                        Description = draftReportEntity.Description,
                        Filters = reportDefinition.Filters,
                        FieldGroups = reportDefinition.FieldGroups,
                        OrderField = reportDefinition.OrderField,
                        PrimaryKeyField = reportDefinition.PrimaryKeyField,
                        OrderBy = reportDefinition.OrderBy,
                        QueryTemplate = reportDefinition.QueryTemplate,
                        IncludeCustomProperties = reportDefinition.IncludeCustomProperties,
                        IncludeUserProperties = reportDefinition.IncludeUserProperties,
                        ShowTeamsitePicker = reportDefinition.ShowTeamsitePicker,
                        FilterCategoryOrder = reportDefinition.FilterCategoryOrder,
                        RequiredFeatureKeys = reportDefinition.RequiredFeatureKeys,
                        LastModified = draftReportEntity.ModifiedOnUtc,
                        DataAreaKey = reportDefinition.DataAreaKey
                    },
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to parse draft reportId:{ReportId}, reportName:{ReportName}. Please validate yaml", draftReportEntity.ReportId, draftReportEntity.ReportName);
                return null;
            }
        }
        private ReportDefinitionQuery BuildReportDefinitionQuery(DataAccess.Entities.DraftReport draftReportEntity, ReportDefinitionMetadata report)
        {
            try
            {
                return new ReportDefinitionQuery(report);
            }
            catch(Exception ex)
            {
                _logger.Error(ex, "Failed to parse draft reportId:{ReportId}, reportName:{ReportName}. Please validate yaml", draftReportEntity.ReportId, draftReportEntity.ReportName);
                throw;
            }
        }
    }
}
