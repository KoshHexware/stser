﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.FeatureProfiles;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.UserManagement.Model;
using Serilog;
using System.Collections;
using System.Collections.Generic;
using ModelPropertyType = Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.PropertyType;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class SystemReportService(ISystemReportsRepository _systemReportsRepository, 
        ISeismicContextProvider _contextProvider, IDraftReportService _draftReportService,
        ICustomPropertyService _customPropertyService, IUserService _userService, IFeatureService _featureService,
        IDataAccessor _dataAccessor, ILogger _logger, ITenantService _tenantService, IPermissionService _permissionService) : ISystemReportsService
    {
        private Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;
        private string UserId => _contextProvider.GetContext().UserId;

        private readonly ILogger _logger = _logger.ForContext<SystemReportService>();

        public async Task<IEnumerable<ReportDefinitionMetadata>> GetAllReports(bool includeDrafts = true)
        {
            var systemReports = GetAllSystemReportDefinitions();
            var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
            var featureProfiles = _systemReportsRepository.GetAllFeatureProfiles();
            var tenantEnabledFeatures = await GetTenantEnabledFeatures(featureProfiles);
            
            if (draftReportsEnabled && includeDrafts)
            {
                var systemReportIds = systemReports.Select(r => r.ReportId);
                var drafts = await _draftReportService.GetAllDraftReports(TenantId);

                //remove drafts which are already present in system reports
                drafts.RemoveAll(d => systemReportIds.Contains(d.ReportId));

                systemReports = systemReports.Concat(drafts.Select(d => d.Metadata));
            }

            systemReports = systemReports.Where(systemReport => AreRequiredFeaturesEnabled(tenantEnabledFeatures, systemReport.RequiredFeatureKeys ?? [], featureProfiles));
            
            
            return systemReports;
        }

        public async Task<IEnumerable<ReportDefinitionMetadata>> GetUserAccessibleSystemReports(bool includeDrafts = true)
        {
            var dataAreas = await _dataAccessor.GetAllDataAreasAccessAsync(TenantId);
            var defaultDataAreas = _systemReportsRepository.GetAllSystemDataAreas() ?? [];
            var user = await _userService.GetUserById(TenantId, UserId);

            var systemReports = await GetAllReports(includeDrafts);
            systemReports = systemReports.Where(systemReport => HasAccessToDataArea(user, defaultDataAreas, dataAreas, systemReport.DataAreaKey));
            return systemReports;
        }

        public async Task<IEnumerable<Guid>> GetUserAccessibleSystemReportIds( List<string> reportNames,bool includeDrafts = true)
        {
            List<Guid> rid = new List<Guid>();
            var dataAreas = await _dataAccessor.GetAllDataAreasAccessAsync(TenantId);
            var defaultDataAreas = _systemReportsRepository.GetAllSystemDataAreas() ?? [];
            var user = await _userService.GetUserById(TenantId, UserId);

            var systemReports = await GetAllReports(includeDrafts);
            systemReports = systemReports.Where(systemReport => HasAccessToDataArea(user, defaultDataAreas, dataAreas, systemReport.DataAreaKey));
            foreach (ReportDefinitionMetadata rdm in systemReports)
            {
                foreach (string rName in reportNames)
                {
                    if (rdm.ReportName == rName)
                        rid.Add(rdm.ReportId);
                }
            }
            return rid;
        }

        public IEnumerable<ReportDefinitionMetadata> GetAllSystemReportDefinitions()
        {
            return _systemReportsRepository.GetAllReportDefinitions();
        }

        public async Task<ReportDefinitionQuery> GetQueryDefinition(Guid reportId)
        {
            var result = _systemReportsRepository.GetQueryDefinition(reportId);
            if (result != null)
                return result;

            var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
            if (!draftReportsEnabled)
            {
                throw new NotFoundException($"Report with Id {reportId} not found.");
            }

            var draft = await _draftReportService.GetDraftReportYamlById(reportId, TenantId);
            if (draft != null)
            {
                return draft.Query;
            }

            throw new NotFoundException($"Report with Id {reportId} not found.");
        }

        public IEnumerable<ReportFragmentDefinitionQuery> GetReportFragmentQueryDefinition(List<Guid> reportId)
        {
            return  _systemReportsRepository.GetFragmentQueryDefinition(reportId);
        }

        public List<DeletedItem>? GetArchivedFilters(Guid reportId)
        {
            return _systemReportsRepository.GetArchivedFilters(reportId);
        }

        public async Task<ReportDefinitionMetadata?> GetReportDefinition(Guid reportId, bool includeAccessibleFieldAndFilter = true)
        {
            var systemReport = _systemReportsRepository.GetReportDefinition(reportId);
            
            if (includeAccessibleFieldAndFilter)
            {
                includeAccessibleFieldAndFilter = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDomainAccessControl);
            }
            var dataAreasAccesses = await _dataAccessor.GetAllDataAreasAccessAsync(TenantId);
            var defaultDataAreas = _systemReportsRepository.GetAllSystemDataAreas() ?? [];
            var user = await _userService.GetUserById(TenantId, UserId);
            
            ReportDefinitionMetadata? reportDefinition = null;

            if (systemReport != null)
            {
                if (includeAccessibleFieldAndFilter && !HasAccessToDataArea(user, defaultDataAreas, dataAreasAccesses, systemReport.DataAreaKey))
                {
                    _logger.Error("User:{userId} does not have access to required data area.", UserId);
                    throw new ForbiddenException($"User {UserId} does not have access to required data area.");
                }
                reportDefinition = await ProcessReportDefinition(systemReport, includeAccessibleFieldAndFilter, user, defaultDataAreas, dataAreasAccesses);
            }
            else
            {
                var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
                if (draftReportsEnabled)
                {
                    var draft = await _draftReportService.GetDraftReportYamlById(reportId, TenantId);
                    if (draft != null)
                    {
                        if (!HasAccessToDataArea(user, defaultDataAreas, dataAreasAccesses, draft.Metadata.DataAreaKey))
                        {
                            _logger.Error("User:{userId} does not have access to required data area.", UserId);
                            throw new ForbiddenException($"User {UserId} does not have access to required data area.");
                        }
                        reportDefinition = await ProcessReportDefinition(draft.Metadata, includeAccessibleFieldAndFilter, user, defaultDataAreas, dataAreasAccesses);
                    }
                }
            }

            return reportDefinition;
        }

        /// <summary>
        /// Process the report definition to add custom properties and filter out the fields and filters based on the required features
        /// </summary>
        /// <param name="report"></param>
        /// <param name="isCustomReport"></param>
        /// <param name="customReportSelectedTeamsiteIds"></param>
        /// <returns></returns>
        private async Task<ReportDefinitionMetadata?> ProcessReportDefinition(ReportDefinitionMetadata report, bool includeAccessibleFieldAndFilter, UserResource user, IEnumerable<DataArea> defaultDataAreas, IEnumerable<DataAccess.Entities.DataAreaAccess> dataAreasAccesses)
        {
            var featureProfiles = _systemReportsRepository.GetAllFeatureProfiles();
            var tenantEnabledFeatures = await GetTenantEnabledFeatures(featureProfiles);
            var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
            var draftReports = new List<DraftReport>();
            var isDrillInEnabled = await _tenantService.IsLDFlagEnabled(LDConstants.EnableDrillInFeatureLDKey);
            if (draftReportsEnabled)
            {
                draftReports = await _draftReportService.GetAllDraftReports(TenantId);
            }
            var allSystemReports = GetAllSystemReportDefinitions();
            var access = await _permissionService.GetContextUserAccess(false);

            if (AreRequiredFeaturesEnabled(tenantEnabledFeatures, report.RequiredFeatureKeys ?? [], featureProfiles))
            {
                var reportDefinition = await AddCustomPropertiesMetadata(report);
                FilterFieldsAndFiltersByFeaturesAndUserAccess(tenantEnabledFeatures, reportDefinition, featureProfiles, includeAccessibleFieldAndFilter, user, defaultDataAreas, dataAreasAccesses, draftReports, allSystemReports, access, isDrillInEnabled);
                return reportDefinition;
            }

            return null;
        }

        private async Task<IList<string>> GetTenantEnabledFeatures(IEnumerable<FeatureProfile> featureProfiles)
        {
            var requiredLdKeyNames = featureProfiles
                .Where(f => f.Type == FeatureTypeConstants.LaunchDarkly)
                .Select(f => f.Name)
                .ToList();

            return await _featureService.GetFeaturesEnabledInTenantAsync(requiredLdKeyNames);
        }

        private void FilterFieldsAndFiltersByFeaturesAndUserAccess(IList<string> tenantEnabledFeatures, ReportDefinitionMetadata reportDefinition, 
            IEnumerable<FeatureProfile> featureProfiles, bool includeAccessibleFieldAndFilter, UserResource user, IEnumerable<DataArea> defaultDataAreas,
            IEnumerable<DataAccess.Entities.DataAreaAccess> dataAreasAccesses, List<DraftReport> draftReports, IEnumerable<ReportDefinitionMetadata> allSystemReports,
            AccessLevel access, bool isDrillInEnabled)
        {
            var reportFields = reportDefinition.FieldGroups.SelectMany(fg => fg.Fields).ToList();
            List<string> fieldsToRemove = [];
            List<string> filtersToRemove = [];

            if (!isDrillInEnabled)
            {
                foreach (var fieldsGroup in reportDefinition.FieldGroups)
                {
                    foreach (var field in fieldsGroup.Fields)
                    {
                        field.DrillIn = null;
                    }
                }
            }
            
            foreach (var field in reportFields)
            {
                if (!AreRequiredFeaturesEnabled(tenantEnabledFeatures, field.RequiredFeatureKeys ?? [], featureProfiles))
                {
                    fieldsToRemove.Add(field.Name);
                    if (field.FilterName != null)
                    {
                        filtersToRemove.Add(field.FilterName);
                    }
                }

                //Remove Drill In Information from field metadata if user do not have access to target report 
                if (!fieldsToRemove.Contains(field.Name) && field.DrillIn != null)
                {
                    var targetReport = allSystemReports.FirstOrDefault(x => x.ReportId == field.DrillIn.TargetReport);
                    var draftReport = draftReports.FirstOrDefault(d => d.ReportId == field.DrillIn.TargetReport);
                    var removeFields = (targetReport == null && draftReport == null) || access == AccessLevel.Viewer;
                    var dataAreaKey = targetReport != null ? targetReport.DataAreaKey : draftReport != null ? draftReport.Metadata.DataAreaKey : null;
                    if (removeFields || !HasAccessToDataArea(user, defaultDataAreas, dataAreasAccesses, dataAreaKey))
                    {
                        foreach (var fieldsGroup in reportDefinition.FieldGroups)
                        {
                            var reportField = fieldsGroup.Fields.FirstOrDefault(f => f.Name == field.Name);
                            if (reportField != null)
                            {
                                reportField.DrillIn = null;
                                break;
                            }
                        }
                    }
                }

                if (includeAccessibleFieldAndFilter && !string.IsNullOrWhiteSpace(field.DataAreaKey) && !HasAccessToDataArea(user, defaultDataAreas, dataAreasAccesses, field.DataAreaKey))
                {
                    fieldsToRemove.Add(field.Name);
                    if (field.FilterName != null)
                    {
                        filtersToRemove.Add(field.FilterName);
                    }
                }
            }

            reportDefinition.FieldGroups.ForEach(fg => fg.Fields.RemoveAll(f => fieldsToRemove.Contains(f.Name)));
            reportDefinition.Filters?.RemoveAll(f => filtersToRemove.Contains(f.FilterName));
        }

        private static bool AreRequiredFeaturesEnabled(IList<string> enabledFeatures, string[] requiredFeatureKeys, IEnumerable<FeatureProfile> featureProfiles)
        {
            if (requiredFeatureKeys == null || requiredFeatureKeys.Length == 0)
            {
                return true;
            }

            var requiredFeatureNames = GetRequiredFeatureNames(requiredFeatureKeys, featureProfiles);
            if (requiredFeatureNames.Count != requiredFeatureKeys.Length)
            {
                return false;
            }

            return requiredFeatureNames.All(rf => enabledFeatures.Contains(rf, StringComparer.OrdinalIgnoreCase));
        }

        private static List<string> GetRequiredFeatureNames(string[] requiredFeatureKeys, IEnumerable<FeatureProfile> featureProfiles)
        {
            return [.. featureProfiles
                .Where(f => requiredFeatureKeys.Contains(f.Key))
                .Select(f => f.Name)];
        }

        private async Task<ReportDefinitionMetadata> AddCustomPropertiesMetadata(ReportDefinitionMetadata reportDefinition)
        {
            if (reportDefinition.IncludeUserProperties == false && reportDefinition.IncludeCustomProperties == false)
            {
                return reportDefinition;
            }

            //UserProperties
            var userCustomProps = await _customPropertyService.GetUserCustomProperties(TenantId);
            //ContentCustomProperties
            var context = _contextProvider.GetContext();
            var userSettings = await _userService.GetUserSettingsAsync(TenantId, context.UserId);
            var contentCustomProps = reportDefinition.ShowTeamsitePicker
                ? await _customPropertyService.GetFilteredContentPropertiesByUserTeamsites(TenantId, userSettings.Teamsites)
                : await _customPropertyService.GetContentCustomProperties(TenantId);

            if ((userCustomProps == null || userCustomProps.Count == 0) && (contentCustomProps == null || contentCustomProps.Count == 0))
                return reportDefinition;

            reportDefinition.Filters ??= [];

            reportDefinition.Filters.RemoveAll(x => x.Category == CustomPropertyConstant.CUSTOM_PROPERTIES);
            reportDefinition.FieldGroups.RemoveAll(x => x.UxLabel == CustomPropertyConstant.CUSTOM_PROPERTIES);

            var userPropertyFields = reportDefinition.IncludeUserProperties ?
                userCustomProps?.Select(p => GetReportFieldForCustomProperty(p, ModelPropertyType.UserProperty)).ToList() ?? [] : [];

            var contentPropertyFields = reportDefinition.IncludeCustomProperties ?
                contentCustomProps?.Select(p => GetReportFieldForCustomProperty(p, ModelPropertyType.ContentCustomProperty)).ToList() ?? [] : [];

            return AddFieldsAndFilters(reportDefinition, userCustomProps, contentCustomProps, userPropertyFields, contentPropertyFields);
        }

        private static ReportDefinitionMetadata AddFieldsAndFilters(ReportDefinitionMetadata reportDefinition, IList<UserProperty>? userCustomProps, IList<ContentCustomProperty>? contentCustomProps, List<Models.Template.ReportField> userPropertyFields, List<Models.Template.ReportField> contentPropertyFields)
        {
            reportDefinition.FieldGroups.Add(
                            new FieldGroup
                            {
                                UxLabel = CustomPropertyConstant.CUSTOM_PROPERTIES,
                                Fields = [.. userPropertyFields, .. contentPropertyFields]
                            });

            if (reportDefinition.IncludeUserProperties)
            {
                reportDefinition.Filters ??= [];
                reportDefinition.Filters.AddRange((userCustomProps ?? []).Select(p => new Models.Template.ReportFilter
                {
                    FilterName = p.Name + p.Id,
                    IsDefault = false,
                    Category = CustomPropertyConstant.CUSTOM_PROPERTIES
                }));
            }

            if (reportDefinition.IncludeCustomProperties)
            {
                reportDefinition.Filters ??= [];
                reportDefinition.Filters.AddRange((contentCustomProps ?? []).Select(p => new Models.Template.ReportFilter
                {
                    FilterName = p.Name + p.Id,
                    IsDefault = false,
                    Category = CustomPropertyConstant.CUSTOM_PROPERTIES
                }));
            }

            return reportDefinition;
        }

        private static ReportField GetReportFieldForCustomProperty(SeismicBaseProperty property, PropertyType propertyType)
        {
            return new ReportField
            {
                Name = (property.Name + property.Id).Replace("-", ""),
                DataType = DataTypeHelper.GetDataType(property.Type),
                IsDefault = false,
                UxLabel = property.Name,
                UxDescription = property.Description ??  (propertyType == ModelPropertyType.UserProperty ? 
                $"A custom user property for your organization." : $"A custom property for your organization."),
                IsProperty = true,
                PropertyType = propertyType,
                PropertyId = property.Id.ToString(),
                TeamsiteIds = property.TeamsiteIds,
                Definition = property.Definition
            };
        }

        public bool HasAccessToDataArea(UserResource user, IEnumerable<DataArea> defaultDataAreas, IEnumerable<DataAccess.Entities.DataAreaAccess> dataAccesses, string? dataAreaKey)
        {
            if (string.IsNullOrWhiteSpace(dataAreaKey))
            {
                return true;
            }
            var dataArea = defaultDataAreas.FirstOrDefault(x=> x.Key == dataAreaKey);
            if (dataArea == null)
                return false;

            var dataAreaAccess = dataAccesses.FirstOrDefault(x => x.DataAreaId == dataArea.Id);
            if (dataAreaAccess == null || dataAreaAccess.AccessType == DataAccess.Enum.AccessType.NoAccess)
                return false;

            if(dataAreaAccess.AccessType == DataAccess.Enum.AccessType.All)
            {
                return true;
            }


            if(dataAreaAccess.AccessType == DataAccess.Enum.AccessType.Included)
            {
                if(dataAreaAccess.UserIds.Contains(user.LegacyId) || dataAreaAccess.UserGroupIds.Intersect(user.DirectGroupLegacyIds).Any())
                {
                    return true;
                }
                return false;
            }

            if (dataAreaAccess.AccessType == DataAccess.Enum.AccessType.Excluded)
            {
                if (dataAreaAccess.UserIds.Contains(user.LegacyId) || dataAreaAccess.UserGroupIds.Intersect(user.DirectGroupLegacyIds).Any())
                {
                    return false;
                }
                return true;
            }
            return false;
        }
    }
}
