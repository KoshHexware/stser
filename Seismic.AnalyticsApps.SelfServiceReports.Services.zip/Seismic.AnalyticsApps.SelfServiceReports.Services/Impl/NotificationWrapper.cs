﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Platform.Notification.Client;
using Serilog;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class NotificationWrapper(ILogger logger, INotificationClient _notificationClient) : INotificationWrapper
    {
        private readonly ILogger _logger = logger.ForContext<NotificationWrapper>();
        private static readonly JsonSerializerOptions serializerOptions = new() { WriteIndented = true };

        private static readonly Dictionary<string, string[]> _supportedScenarioSettings = new()
        {
            { NotifcationConstants.SSRSSupportedScenarioSettings, new [] { NotifcationConstants.SSRSNotificationsBizCategory, NotifcationConstants.SSRSReportSharedBizScenario } }
        };

        public async Task<IEnumerable<NotificationRequestResponseResource>> SendNotificationRequestAsync(ReportSharedNotificationPayload reportSharedPayload, string[] userIds, Guid tenantId)
        {
            var notificationCreateRequest = CreateNotificationRequest(reportSharedPayload, userIds);

            _logger.Information("Sending PNS notification request for tenantId:{tenantId}. Request:{request}. Category and Scenarios:{scenarios}", 
                tenantId, JsonSerializer.Serialize(reportSharedPayload), JsonSerializer.Serialize(notificationCreateRequest.Scenarios));

            var response = await _notificationClient.CreateNotificationRequest(tenantId.ToString(), notificationCreateRequest);
            if (response == null)
            {
                _logger.Error("Failed to send notification request. ReportName: {reportName}, UserId: {userId}, TenantId: {tenantId}", reportSharedPayload.ReportName, reportSharedPayload.UserId, tenantId);
                return [];
            }
            return response;
        }

        private static NotificationRequestCreateResource CreateNotificationRequest<T>(T payloadModel, string[] userIds) where T : class
        {
            var scenarioSettings = _supportedScenarioSettings[typeof(T).Name];
            var bizCategory = scenarioSettings[0];
            var bizScenario = scenarioSettings[1];

            var request = new NotificationRequestCreateResource
            {
                Payload = ToPayload<T>(payloadModel),
                Scenarios =
                [
                        new ScenarioRequest
                        {
                            UserIds = userIds,
                            BizCategory = bizCategory,
                            BizScenario = bizScenario
                        }
                    ]
            };
            return request;
        }

        private static Dictionary<string, Newtonsoft.Json.Linq.JToken> ToPayload<T>(T obj) where T : class
        {
            var jsonObject = JsonSerializer.SerializeToDocument(obj, serializerOptions).RootElement;

            var payload = new Dictionary<string, Newtonsoft.Json.Linq.JToken>();

            foreach (var property in jsonObject.EnumerateObject())
            {
                payload[property.Name] = Newtonsoft.Json.Linq.JToken.Parse(property.Value.GetRawText());
            }

            return payload;
        }
    }
}
