﻿using Fluid;
using Seismic.Analytics.DataAccess.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Extension;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.QueryBuilder;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.Common.ServiceFoundation;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class QueryService(ISystemReportsService _systemReportsService, ISeismicContextProvider _contextProvider, ILogger logger) : IQueryService
    {
        protected Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        private readonly ILogger _logger = logger.ForContext<QueryService>();

        public async Task<Query> CreateQuery(ReportDefinitionMetadata reportMetadata,  List<CreateQueryFilterModel> selectedFilters,
            IList<UserProperty> userProperties, IList<ContentCustomProperty> contentCustomProperties,
            int skip, int take, string? orderField = null, string? orderBy = null, List<ReportExecutionField>? requestedFieldsList = null, string[]? selectedTeamsites = null, bool includePrimaryKeyField = false)
        {
            var query = await _systemReportsService.GetQueryDefinition(reportMetadata.ReportId);

            IEnumerable<ReportFragmentDefinitionQuery> reportFragments = [];

            if (reportMetadata.IncludeUserProperties || reportMetadata.IncludeCustomProperties)
            {
                reportFragments = _systemReportsService.GetReportFragmentQueryDefinition(
                    [ 
                        Guid.Parse(ReportFragmentConstant.USER_PROPERTY_SELECT_JOIN_ON_USER_TABLE), 
                        Guid.Parse(ReportFragmentConstant.USER_PROPERTY_FIELD_SELECT), 
                        Guid.Parse(ReportFragmentConstant.USER_PROPERTY_FINAL_SELECT_JOIN),
                        Guid.Parse(ReportFragmentConstant.CONTENT_PROPERTY_SELECT_JOIN_ON_LIBRARY_CONTENT_TABLE),
                        Guid.Parse(ReportFragmentConstant.CONTENT_PROPERTY_FIELD_SELECT),
                        Guid.Parse(ReportFragmentConstant.CONTENT_PROPERTY_FINAL_SELECT_JOIN)
                    ]);
            }

            return CreateQuery(reportMetadata, selectedFilters, skip, take, orderField, orderBy, query, userProperties, contentCustomProperties, reportFragments, requestedFieldsList, selectedTeamsites, includePrimaryKeyField);
        }

        private Query CreateQuery(ReportDefinitionMetadata reportMetadata, List<CreateQueryFilterModel> selectedFilters, int skip, int take, string? orderField, string? orderBy, 
            ReportDefinitionQuery query, IEnumerable<UserProperty> userProperties, IEnumerable<ContentCustomProperty> customContentProperties, 
            IEnumerable<ReportFragmentDefinitionQuery> reportFragmentQueries, List<ReportExecutionField>? requestedFieldsList = null, string[]? selectedTeamsites = null, bool includePrimaryKeyField = false)
        {
            var templateParams = new Dictionary<string, object>();
            var stringParams = new Dictionary<string, string>();
            var dateParams = new Dictionary<string, DateTime?>();
            var boolParams = new Dictionary<string, bool?>();
            var intParams = new Dictionary<string, int?>();
            var decimalParams = new Dictionary<string, decimal?>();
            var multiStringParams = new Dictionary<string, string[]>();

            var allowedFields = reportMetadata.FieldGroups.SelectMany(fg => fg.Fields);

            HashSet<string> requestedFields = [];
            if (requestedFieldsList != null)
            {
                requestedFields = requestedFieldsList.Select(x => x.Name).ToHashSet();
                var pr = reportMetadata.PrimaryKeyField;
                if (includePrimaryKeyField && !requestedFields.Contains(pr) && !string.IsNullOrWhiteSpace(reportMetadata.PrimaryKeyField))
                {
                    requestedFields.Add(pr);
                }
            }

            //Add generic filters in selected fields for generic filters support
            requestedFields = requestedFields.Concat(selectedFilters
                .Where(filter => filter.IsGeneric)
                .Where(filter => allowedFields.Any(field => field.Name.Equals(filter.FilterName, StringComparison.OrdinalIgnoreCase)))
                .Select(filter => filter.FilterName)
                ).Distinct().ToHashSet();

            AddFieldParams(templateParams, allowedFields, requestedFields);

            var userPropertyFilters = selectedFilters.Where(x => x.QueryParam.StartsWith(CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS)).ToList();
            var contentCustomPropertyFilters = selectedFilters.Where(x => x.QueryParam.StartsWith(CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS)).ToList();
            selectedFilters = selectedFilters.Except([..userPropertyFilters, ..contentCustomPropertyFilters]).ToList();

            //Global Teamsites filter
            // This filter is applies only if the selected teamsites are not null and the reportMetadata has IncludeCustomProperties set to true
            if (reportMetadata.ShowTeamsitePicker && selectedTeamsites != null && selectedTeamsites.Length > 0)
            {
                selectedFilters.Add(new CreateQueryFilterModel
                {
                    FilterName = "teamsiteId",
                    QueryParam = "teamsiteId",
                    Operation = Operation.IsOneOf,
                    DataType = DataType.Text,
                    Values = selectedTeamsites
                });
            }

            var filterBuilder = new FilterBuilder()
            {
                SelectedFilters = selectedFilters,
                BoolParams = boolParams,
                DateParams = dateParams,
                DecimalParams = decimalParams,
                IntParams = intParams,
                MultiStringParams = multiStringParams,
                StringParams = stringParams,
                TemplateParams = templateParams
            };

            filterBuilder.AddFilters();

            orderField = GetOrderByField(orderField, requestedFieldsList);

            if ((reportMetadata.IncludeUserProperties && userProperties?.Count() > 0)
                || (reportMetadata.IncludeCustomProperties && customContentProperties?.Count() > 0))
            {
                var fragmentTemplateParams = new Dictionary<string, object>();
                orderField = AddUserPropertiesFragmentParams(fragmentTemplateParams, allowedFields, requestedFields, userProperties, orderField, userPropertyFilters, stringParams, dateParams, boolParams, intParams, multiStringParams, decimalParams);
                orderField = AddContentCustomPropertiesFragmentParams(fragmentTemplateParams, allowedFields, requestedFields, customContentProperties, orderField, contentCustomPropertyFilters, stringParams, dateParams, boolParams, intParams, multiStringParams, decimalParams);
                foreach (var fragmentQuery in reportFragmentQueries)
                {
                    var fragmentContext = new TemplateContext(fragmentTemplateParams, true);
                    fragmentContext.Options.MemberAccessStrategy = new UnsafeMemberAccessStrategy();
                    var fragmentCompiledQuery = fragmentQuery.CompiledQuery.Render(fragmentContext);
                    templateParams.Add(fragmentQuery.FragmentName, fragmentCompiledQuery);
                }
            }

            AddOrderByFields(orderField, orderBy, templateParams);

            AddOffsetParams(skip, take, intParams);

            var context = new TemplateContext(templateParams, true);
            context.Options.MemberAccessStrategy = new UnsafeMemberAccessStrategy();
            var compiledQuery = query.CompiledQuery.Render(context);

            if (multiStringParams != null && multiStringParams.Count > 0)
            {
                compiledQuery = compiledQuery.ExpandMultiValueParameters(multiStringParams.Select(x => (x.Key, x.Value)));
            }

            // Remove filters that are not used in the query
            RemoveFiltersNotInQuery(selectedFilters, stringParams, dateParams, boolParams, intParams, decimalParams, compiledQuery);

            return new Query()
            {
                Name = query.ReportName,
                BoolParams = boolParams,
                DateParams = dateParams,
                IntParams = intParams,
                DecimalParams = decimalParams,
                MultiStringParams = multiStringParams,
                StringParams = stringParams,
                Sql = compiledQuery
            };
        }

        private static void RemoveFiltersNotInQuery(List<CreateQueryFilterModel> selectedFilters, Dictionary<string, string> stringParams, Dictionary<string, DateTime?> dateParams, 
            Dictionary<string, bool?> boolParams, Dictionary<string, int?> intParams, Dictionary<string, decimal?> decimalParams, string compiledQuery)
        {
            foreach (var filter in selectedFilters)
            {
                if (!compiledQuery.Contains($"@{filter.QueryParam}"))
                {
                    dateParams.Remove(filter.QueryParam);
                    stringParams.Remove(filter.QueryParam);
                    boolParams.Remove(filter.QueryParam);
                    intParams.Remove(filter.QueryParam);
                    decimalParams.Remove(filter.QueryParam);
                }

                if (filter.Operation == Operation.Between && !compiledQuery.Contains($"@{filter.QueryParam}_start"))
                {
                    var endParam = $"{filter.QueryParam}_end";
                    var startParam = $"{filter.QueryParam}_start";
                    dateParams.Remove(endParam);
                    dateParams.Remove(startParam);
                    intParams.Remove(endParam);
                    intParams.Remove(startParam);
                    decimalParams.Remove(endParam);
                    decimalParams.Remove(startParam);
                }
            }
        }

        private  string? AddUserPropertiesFragmentParams(Dictionary<string, object> templateParams, IEnumerable<ReportField> allowedFields,
             HashSet<string> requestedFields, IEnumerable<UserProperty>? userProperties, string? orderField, List<CreateQueryFilterModel> userPropertyFilters,
             Dictionary<string, string> stringParams, Dictionary<string, DateTime?> dateParams,
            Dictionary<string, bool?> boolParams, Dictionary<string, int?> intParams, Dictionary<string, string[]> multiStringParams, Dictionary<string, decimal?> decimalParams)
         {

            var selectedUserPropertyFields = allowedFields.Where(f => f.IsProperty == true && f.PropertyType == Models.Template.PropertyType.UserProperty);

            if (userProperties?.Count() > 0)
            {
                List<CustomPropertyReportFragmentQueryModel> userPropertyQueryModels = [];
                if (requestedFields != null)
                {
                    foreach (var f in selectedUserPropertyFields)
                    {
                        var userProperty =  userProperties.SingleOrDefault(x => (x.Name + x.Id).Replace("-", "").Equals(f.Name, StringComparison.InvariantCultureIgnoreCase));
                        if (userProperty == null)
                        {
                            continue;
                        }

                        var queryAlias = (CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS + userProperty.Id).Replace("-", "");
                        var isUserPropertyFilterSelected = userPropertyFilters.Any(x=> x.QueryParam == queryAlias);
                        if ((requestedFields.Contains(f.Name, StringComparer.OrdinalIgnoreCase) || isUserPropertyFilterSelected) && userProperty is not null)
                        {
                            var userPropertyQueryModel = CreateCustomPropertyQueryModel(requestedFields, ref orderField, userPropertyFilters, 
                                stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams, f, userProperty, queryAlias);
                            userPropertyQueryModels.Add(userPropertyQueryModel);
                        }
                    }
                }
                templateParams.Add("userPropertiesArray", userPropertyQueryModels);
                templateParams.Add("isUserPropertyFilterSelected", userPropertyQueryModels.Any(x => x.IsFilterApplied));
                templateParams.Add("isUserPropertySelected", userPropertyQueryModels.Any(x => x.IsSelected));
            }
            return orderField;
         }

        private CustomPropertyReportFragmentQueryModel CreateCustomPropertyQueryModel(HashSet<string> requestedFields, ref string? orderField, 
            List<CreateQueryFilterModel> userPropertyFilters, Dictionary<string, string> stringParams, Dictionary<string, DateTime?> dateParams, 
            Dictionary<string, bool?> boolParams, Dictionary<string, int?> intParams, Dictionary<string, decimal?> decimalParams, Dictionary<string, string[]> multiStringParams, ReportField f, UserProperty userProperty, string queryAlias)
        {
            var userPropertyFilterModel = userPropertyFilters.SingleOrDefault(x => x.QueryParam == queryAlias);
            var userPropertyQueryModel = new CustomPropertyReportFragmentQueryModel
            {
                Name = userProperty.Name,
                Id = userProperty.Id,
                IsSelected = requestedFields.Contains(f.Name, StringComparer.OrdinalIgnoreCase),
                QueryAlias = queryAlias,
            };

            if ((userProperty.Name + userProperty.Id).Replace("-", "").Equals(orderField?.ToLowerInvariant(), StringComparison.InvariantCultureIgnoreCase))
            {
                orderField = queryAlias;
            }

            if (userPropertyFilterModel != null)
            {
                if (userPropertyFilterModel.DataType == DataType.Text)
                {
                    AdjustTextFilterOperation(userPropertyFilterModel);
                }
                userPropertyQueryModel.IsFilterApplied = true;
                userPropertyQueryModel.FilterName = queryAlias;
                userPropertyQueryModel.FilterOperator = OperatorHelper.GetSqlOperator(userPropertyFilterModel.Operation);
                if (userPropertyFilterModel.Operation != Operation.IsNull && userPropertyFilterModel.Operation != Operation.IsNotNull)
                {
                    AddCustomPropertyFilterValues(userPropertyFilterModel, userPropertyQueryModel, stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams);
                }
            }
            return userPropertyQueryModel;
        }

        

        private string? AddContentCustomPropertiesFragmentParams(Dictionary<string, object> templateParams, IEnumerable<ReportField> allowedFields,
             HashSet<string> requestedFields, IEnumerable<ContentCustomProperty> contentCustomProperties, string? orderField, List<CreateQueryFilterModel> contentCustomPropertyFilters,
             Dictionary<string, string> stringParams, Dictionary<string, DateTime?> dateParams,
            Dictionary<string, bool?> boolParams, Dictionary<string, int?> intParams, Dictionary<string, string[]> multiStringParams, Dictionary<string, decimal?> decimalParams)
        {
            var selectedContentCustomPropertyFields = allowedFields.Where(f => f.IsProperty == true && f.PropertyType == Models.Template.PropertyType.ContentCustomProperty);

            if (contentCustomProperties == null || !contentCustomProperties.Any())
                return orderField;

            List<CustomPropertyReportFragmentQueryModel> contentCustomPropertyQueryModels = [];

            if (requestedFields != null)
            {
                foreach (var f in selectedContentCustomPropertyFields)
                {
                    var contentCustomProperty = contentCustomProperties.SingleOrDefault(x => (x.Name + x.Id).Replace("-", "").Equals(f.Name, StringComparison.InvariantCultureIgnoreCase));
                    if (contentCustomProperty == null)
                    {
                        continue;
                    }
                    var queryAlias = (CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS + contentCustomProperty.Id).Replace("-", "");
                    var isContentCustomPropertyFilterSelected = contentCustomPropertyFilters.Any(x => x.QueryParam == queryAlias);
                    if ((requestedFields.Contains(f.Name, StringComparer.OrdinalIgnoreCase) || isContentCustomPropertyFilterSelected) && contentCustomProperty is not null)
                    {
                        var contentCustomPropertyFilterModel = contentCustomPropertyFilters.SingleOrDefault(x => x.QueryParam == queryAlias);
                        var contentCustomPropertyQueryModel = new CustomPropertyReportFragmentQueryModel
                        {
                            Name = contentCustomProperty.Name,
                            Id = contentCustomProperty.Id,
                            IsSelected = requestedFields.Contains(f.Name, StringComparer.OrdinalIgnoreCase),
                            QueryAlias = queryAlias,
                            AllowMultipleValues = contentCustomProperty.AllowMultipleValues,

                        };

                        if ((contentCustomProperty.Name + contentCustomProperty.Id).Replace("-", "").Equals(orderField?.ToLower(), StringComparison.CurrentCultureIgnoreCase))
                        {
                            orderField = queryAlias;
                        }
                        if (contentCustomPropertyFilterModel != null)
                        {
                            if (contentCustomPropertyFilterModel.DataType == DataType.Text)
                            {
                                AdjustTextFilterOperation(contentCustomPropertyFilterModel);
                            }
                            if (contentCustomPropertyFilterModel.DataType == DataType.Boolean)
                            {
                                contentCustomPropertyQueryModel.IsBoolean = true;
                            }
                            contentCustomPropertyQueryModel.IsFilterApplied = true;
                            contentCustomPropertyQueryModel.FilterName = queryAlias;
                            contentCustomPropertyQueryModel.FilterOperator = OperatorHelper.GetSqlOperator(contentCustomPropertyFilterModel.Operation);
                            if (contentCustomPropertyFilterModel.Operation != Operation.IsNull && contentCustomPropertyFilterModel.Operation != Operation.IsNotNull)
                            {
                                AddCustomPropertyFilterValues(contentCustomPropertyFilterModel, contentCustomPropertyQueryModel, stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams);
                            }
                        }
                        contentCustomPropertyQueryModels.Add(contentCustomPropertyQueryModel);
                    }
                }
            }

            templateParams.Add("contentCustomPropertiesArray", contentCustomPropertyQueryModels);
            templateParams.Add("isContentCustomPropertyFilterSelected", contentCustomPropertyQueryModels.Any(x => x.IsFilterApplied));
            templateParams.Add("isContentCustomPropertySelected", contentCustomPropertyQueryModels.Any(x => x.IsSelected));
            return orderField;
        }

        private static string? GetOrderByField(string? orderField, List<ReportExecutionField>? requestedFieldsList = null)
        {
            if (requestedFieldsList == null || requestedFieldsList.Count == 0)
                return null;

            var result = requestedFieldsList.Where(x => string.Equals(x.Name, orderField, StringComparison.OrdinalIgnoreCase)).FirstOrDefault()?.Name;
            if (result != null)
                return result;

            if (!requestedFieldsList.Any(x => string.Equals(x.Name, orderField, StringComparison.OrdinalIgnoreCase)))
            {
                return requestedFieldsList.First()?.Name;
            }

            return null;
        }

        private static void AddOrderByFields(string? orderField, string? orderBy, Dictionary<string, object> templateParams)
        {
            if (!string.IsNullOrWhiteSpace(orderField))
            {
                templateParams.Add("orderField", orderField);
                var orderByName = "ASC";
                if (!string.IsNullOrWhiteSpace(orderBy))
                {
                    orderByName = EnumExtension.GetDisplayName(Enum.Parse<OrderType>(orderBy, true));
                }
                templateParams.Add("orderBy", orderByName.ToUpper());
            }
        }

        private static void AddOffsetParams(int skip, int take, Dictionary<string, int?> intParams)
        {
            intParams.Add("records_skip", skip);
            intParams.Add("records_take", take);
        }

        private void AddCustomPropertyFilterValues(CreateQueryFilterModel filter,  CustomPropertyReportFragmentQueryModel customPropertyQueryModel, 
            Dictionary<string, string> stringParams, Dictionary<string, DateTime?> dateParams, Dictionary<string, bool?> boolParams, 
            Dictionary<string, int?> intParams, Dictionary<string, decimal?> decimalParams, Dictionary<string, string[]> multiStringParams)
        {
            if(filter.Values == null || filter.Values.Length == 0)
            {
                _logger.Warning("No filter values found. queryParam:{queryParam} for filter:{filter}", filter.QueryParam, filter.FilterName);
                return;
            }

            if(string.IsNullOrWhiteSpace(filter?.DataType.ToString()))
            {
                throw new BadRequestException($"Filter data type {filter?.DataType} is not supported.");
            }

            var queryParam = filter.QueryParam;
            var paramValues = filter.Values;

            switch (filter.DataType.ToString().ToLower())
            {
                case "boolean":
                    boolParams.Add(queryParam, bool.Parse(paramValues[0]));
                    customPropertyQueryModel.FilterValue = [$"@{queryParam}"];
                    break;
                case "datetime":
                case "date":
                    AddDateCustomPropertyFilterValue(filter, customPropertyQueryModel, dateParams, queryParam, paramValues);
                    break;
                case "integer":
                    AddIntegerCustomPropertyFilterValue(filter, customPropertyQueryModel, intParams, queryParam, paramValues);
                    break;
                case "decimal" or "float" or "double":
                    AddDecimalCustomPropertyFilterValue(filter, customPropertyQueryModel, decimalParams, queryParam, paramValues);
                    break;
                case "text":
                case "csv":
                    if (filter.Operation == Operation.IsOneOf || filter.Operation == Operation.IsNotOneOf || filter.Operation == Operation.IsAllOf)
                    {

                        multiStringParams.Add(queryParam, paramValues);
                        customPropertyQueryModel.FilterValue = [$"({{{multiStringParams.Count - 1}}})"];
                        customPropertyQueryModel.FilterValueCount = paramValues.Length;
                        break;
                    }

                    stringParams.Add(queryParam, AdjustParamValueForLikeOperation(filter.Operation, paramValues[0]));

                    customPropertyQueryModel.FilterValue = [$"@{queryParam}"];
                    break;
                //TODO: Add support for CSV datatype
                default: throw new BadRequestException($"Filter data type {filter.DataType} is not supported.");
            }
        }

        private static string[] AddIntegerCustomPropertyFilterValue(CreateQueryFilterModel filter, CustomPropertyReportFragmentQueryModel customPropertyQueryModel, Dictionary<string, int?> intParams, string queryParam, string[] paramValues)
        {
            if (filter.Operation == Operation.Between && paramValues.Length == 2)
            {
                paramValues = [.. paramValues.OrderBy(x => int.Parse(x))];
                intParams.Add($"{queryParam}_start", int.Parse(paramValues[0]));
                intParams.Add($"{queryParam}_end", int.Parse(paramValues[1]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}_start", $"@{queryParam}_end"];
            }
            else
            {
                intParams.Add(queryParam, int.Parse(paramValues[0]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}"];
            }

            return paramValues;
        }

        private static string[] AddDecimalCustomPropertyFilterValue(CreateQueryFilterModel filter, CustomPropertyReportFragmentQueryModel customPropertyQueryModel, Dictionary<string, decimal?> decimalParams, string queryParam, string[] paramValues)
        {
            if (filter.Operation == Operation.Between && paramValues.Length == 2)
            {
                paramValues = [.. paramValues.OrderBy(x => decimal.Parse(x))];
                decimalParams.Add($"{queryParam}_start", decimal.Parse(paramValues[0]));
                decimalParams.Add($"{queryParam}_end", decimal.Parse(paramValues[1]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}_start", $"@{queryParam}_end"];
            }
            else
            {
                decimalParams.Add(queryParam, decimal.Parse(paramValues[0]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}"];
            }

            return paramValues;
        }

        private static string[] AddDateCustomPropertyFilterValue(CreateQueryFilterModel filter, CustomPropertyReportFragmentQueryModel customPropertyQueryModel, Dictionary<string, DateTime?> dateParams, string queryParam, string[] paramValues)
        {
            customPropertyQueryModel.IsDate = true;
            if (filter.Operation == Operation.Between && paramValues.Length == 2)
            {
                paramValues = [.. paramValues.OrderBy(x => DateTime.Parse(x))];
                dateParams.Add($"{queryParam}_start", DateTime.Parse(paramValues[0]));
                dateParams.Add($"{queryParam}_end", DateTime.Parse(paramValues[1]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}_start", $"@{queryParam}_end"];
            }
            else
            {
                dateParams.Add(queryParam, DateTime.Parse(paramValues[0]));
                customPropertyQueryModel.FilterValue = [$"@{queryParam}"];
            }

            return paramValues;
        }

        private static string AdjustParamValueForLikeOperation(Operation operation, string paramValue)
        {
            return operation switch
            {
                Operation.Contains => $"%{paramValue}%",
                Operation.DoesNotContain => $"%{paramValue}%",
                Operation.StartsWith => $"{paramValue}%",
                Operation.EndsWith => $"%{paramValue}",
                _ => paramValue
            };
        }

        private static void AddFieldParams(Dictionary<string, object> templateParams, IEnumerable<ReportField> allFields, HashSet<string> requestedFields)
        {

            var allowedFields = allFields.Where(f => f.IsProperty != true && string.IsNullOrWhiteSpace(f.PropertyType.ToString()));

            if (requestedFields != null && requestedFields.Count > 0)
            {
                foreach (var f in allowedFields)
                {
                    if (requestedFields.Contains(f.Name, StringComparer.OrdinalIgnoreCase))
                    {
                        templateParams.Add($"fields_{f.Name}", true);
                    }
                }
            }
            else
            {
                foreach (var f in allowedFields)
                {
                    if (f.IsDefault)
                    {
                        templateParams.Add($"fields_{f.Name}", true);
                    }
                }
            }
        }

        private static void AdjustTextFilterOperation(CreateQueryFilterModel queryFilterModel)
        {
            queryFilterModel.Operation = queryFilterModel.Operation switch
            {
                Operation.Equals => Operation.TextEquals,
                Operation.NotEquals => Operation.TextNotEquals,
                _ => queryFilterModel.Operation
            };
        }
    }
}
