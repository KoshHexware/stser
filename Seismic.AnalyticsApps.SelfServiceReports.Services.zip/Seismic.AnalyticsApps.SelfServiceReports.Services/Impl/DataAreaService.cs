﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.DataArea;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Platform.UserManagement.Model;
using Serilog;
using System.Text.Json;
namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class DataAreaService(IDataAccessor _dataAccessor, IUserInfoProvider _userInfoProvider, IUserService _userService,
        ISystemDataAreaService _systemDataAreaService, ILogger logger) : IDataAreasService
    {
        private readonly ILogger _logger = logger.ForContext<ReportService>();

        public async Task<List<DataAreaAccessModel>> GetAllDataAreasAccess(Guid tenantId, string? searchText = null,
            string? dataAreaIds = null, string? domainNames = null, string? userOruserGroupIds = null)
        {
            var dataAreaIdsForFilter = ParseJsonList(dataAreaIds);
            var domainsForFilter = ParseJsonList(domainNames);
            var userOruserGroupdIdsForFilter = ParseJsonList(userOruserGroupIds);

            var userIds = ExtractPrefixedIds(userOruserGroupdIdsForFilter, "user_");
            var userGroupIds = ExtractPrefixedIds(userOruserGroupdIdsForFilter, "group_");

            var dataAreaEntityList = await _dataAccessor.GetAllDataAreasAccessAsync(tenantId);
            List<DataAreaAccessModel> dataAreas = [];
            var defaultDataAreas = _systemDataAreaService.GetAllSystemDataAreas();
            if (!dataAreaEntityList.Any())
            {
                dataAreas = [.. defaultDataAreas.Select(da => new DataAreaAccessModel
                {
                    Id = da.Id,
                    Name = da.UxLabel,
                    Domain = da.Domain,
                    AccessType = AccessType.NoAccess
                })];
                dataAreas = FilterDataAreasBySearchText(searchText, dataAreas);
                dataAreas = FilterDataAreasByIdsAndDomains(dataAreaIdsForFilter, domainsForFilter, dataAreas);
                dataAreas = await FilterDataAreasByUserAndGroup(tenantId, userIds, userGroupIds, dataAreas);
                return dataAreas;
            }

            (List<UserInfoModel> userInfos, IEnumerable<GroupResource> groupRes) = await GetUserInfosAndGroups(tenantId, dataAreaEntityList);

            PopulateDataAreaAccessModels(dataAreaEntityList, dataAreas, defaultDataAreas, userInfos, groupRes);

            dataAreas = FilterDataAreasBySearchText(searchText, dataAreas);
            dataAreas = FilterDataAreasByIdsAndDomains(dataAreaIdsForFilter, domainsForFilter, dataAreas);
            dataAreas = await FilterDataAreasByUserAndGroup(tenantId, userIds, userGroupIds, dataAreas);
            return dataAreas;
        }

        public async Task<List<DataAreaAccessModel>> UpdateAccessForAllDataAreas(AccessType dataAccessType, string userId, Guid tenantId)
        {
            try
            {
                var dataAreas = await GetAllDataAreasAccess(tenantId);
                foreach (var daa in dataAreas)
                {
                    daa.AccessType = dataAccessType;
                }

                return await UpdateDataAreas(dataAreas, userId, tenantId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in UpdateAccessForAllDataAreas for tenantId: {TenantId}, userId: {UserId}", tenantId, userId);
                throw;
            }
        }

        public async Task<List<DataAreaAccessModel>> UpdateDataAreas(List<DataAreaAccessModel> dataAreas, string userId, Guid tenantId)
        {
            try
            {
                if (dataAreas == null || !dataAreas.Any())
                    throw new ArgumentException("dataAreaAccess cannot be null or empty");

                var existingAccessDict = (await _dataAccessor.GetAllDataAreasAccessByIdsAsync(tenantId, dataAreas.Select(d => d.Id).ToArray())).ToDictionary(x => x.DataAreaId);
                var dataAreasToUpdate = new List<DataAreaAccess>();
                var dataAreasToAdd = new List<DataAreaAccess>();

                foreach (var daa in dataAreas)
                {
                    if (existingAccessDict.TryGetValue(daa.Id, out var daAccess))
                    {
                        daAccess.AccessType = (DataAccess.Enum.AccessType)daa.AccessType;
                        daAccess.UserIds = daa != null && daa.Users.Any() ? daa.Users.Select(u => u.LegacyId).Distinct().ToArray() : Array.Empty<string>();
                        daAccess.UserGroupIds = daa != null && daa.UserGroups.Any() ? daa.UserGroups.Select(g => g.Id).Distinct().ToArray() : Array.Empty<string>();

                        if (string.IsNullOrWhiteSpace(daAccess.CreatedBy))
                        {
                            daAccess.CreatedBy = userId;
                            daAccess.CreatedOnUtc = DateTime.UtcNow;
                        }
                        daAccess.ModifiedBy = userId;
                        daAccess.ModifiedOnUtc = DateTime.UtcNow;

                        dataAreasToUpdate.Add(daAccess);
                    }
                    else
                    {
                        dataAreasToAdd.Add(new DataAreaAccess
                        {
                            DataAreaId = daa.Id,
                            AccessType = (DataAccess.Enum.AccessType)daa.AccessType,
                            TenantId = tenantId,
                            UserIds = daa != null && daa.Users.Any() ? daa.Users.Select(u => u.LegacyId).Distinct().ToArray() : Array.Empty<string>(),
                            UserGroupIds = daa != null && daa.UserGroups.Any() ? daa.UserGroups.Select(g => g.Id).Distinct().ToArray() : Array.Empty<string>(),
                            CreatedBy = userId,
                            CreatedOnUtc = DateTime.UtcNow,
                            ModifiedBy = userId,
                            ModifiedOnUtc = DateTime.UtcNow
                        });



                    }
                }

                if (dataAreasToUpdate.Any())
                {
                    await _dataAccessor.UpdateDataAreaAccessRange(dataAreasToUpdate);
                }

                if (dataAreasToAdd.Any())
                {
                    await _dataAccessor.AddDataAreaAccessRangeAsync(dataAreasToAdd);
                }

                return await GetAllDataAreasAccess(tenantId);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in UpdateDataAreas for tenantId: {TenantId}, userId: {UserId}", tenantId, userId);
                throw;
            }
        }

        public async Task<bool> ResetAllAccess(string userId, Guid tenantId)
        {
            var lstDataAreaAccess = await _dataAccessor.GetAllDataAreasAccessAsync(tenantId);

            foreach (DataAreaAccess daa in lstDataAreaAccess)
            {
                daa.IsDeleted = true;
                daa.DeletedBy = userId;
                daa.DeletedOnUtc = DateTime.UtcNow;
            }

            await _dataAccessor.UpdateDataAreaAccessRange(lstDataAreaAccess);

            return true;
        }

        public bool HasAccessToDataArea(UserResource user, IEnumerable<DataArea> defaultDataAreas, IEnumerable<DataAccess.Entities.DataAreaAccess> dataAccesses, string? dataAreaKey)
        {
            if (string.IsNullOrWhiteSpace(dataAreaKey))
            {
                return false;
            }

            var dataArea = defaultDataAreas.FirstOrDefault(x => x.Key == dataAreaKey);
            if (dataArea == null)
                return false;

            var dataAreaAccess = dataAccesses.FirstOrDefault(x => x.DataAreaId == dataArea.Id);
            if (dataAreaAccess == null || dataAreaAccess.AccessType == DataAccess.Enum.AccessType.NoAccess)
                return false;

            if (dataAreaAccess.AccessType == DataAccess.Enum.AccessType.All)
            {
                return true;
            }


            if (dataAreaAccess.AccessType == DataAccess.Enum.AccessType.Included)
            {
                if (dataAreaAccess.UserIds.Contains(user.LegacyId) || dataAreaAccess.UserGroupIds.Intersect(user.DirectGroupLegacyIds).Any())
                {
                    return true;
                }
                return false;
            }

            if (dataAreaAccess.AccessType == DataAccess.Enum.AccessType.Excluded)
            {
                if (dataAreaAccess.UserIds.Contains(user.LegacyId) || dataAreaAccess.UserGroupIds.Intersect(user.DirectGroupLegacyIds).Any())
                {
                    return false;
                }
                return true;
            }
            return false;
        }

        private List<UserGroupModel> MapUserGroups(string[] userGroupIds, IEnumerable<GroupResource> groupRes)
        {
            var userGroups = new List<UserGroupModel>();
            if (!userGroupIds.Any())
                return userGroups;
            return groupRes.Where(gr => userGroupIds.Contains(gr.LegacyId)).Select(g => new UserGroupModel
            {
                Name = g.Name,
                Id = g.LegacyId
            }).ToList();

        }

        private async Task<(List<UserInfoModel> userInfos, IEnumerable<GroupResource> groupRes)> GetUserInfosAndGroups(Guid tenantId, IEnumerable<DataAreaAccess> dataAreaEntityList)
        {
            var distinctUserIds = dataAreaEntityList.SelectMany(x => x.UserIds).Distinct().ToList();
            var distinctGroupIds = dataAreaEntityList.SelectMany(x => x.UserGroupIds).Distinct();

            var userInfosTask = distinctUserIds.Any() ? _userInfoProvider.GetUsersDetails(tenantId, distinctUserIds) : Task.FromResult(new List<UserInfoModel>());
            var groupResTask = distinctGroupIds.Any() ? _userService.GetGroupsByGroupIdsAsync(tenantId, distinctGroupIds.ToArray()) : Task.FromResult(Enumerable.Empty<GroupResource>());

            await Task.WhenAll(userInfosTask, groupResTask);
            var userInfos = userInfosTask.Result;
            var groupRes = groupResTask.Result;
            return (userInfos, groupRes);
        }

        private void PopulateDataAreaAccessModels(IEnumerable<DataAreaAccess> dataAreaEntityList, List<DataAreaAccessModel> dataAreas, IEnumerable<DataArea> defaultDataAreas, List<UserInfoModel> userInfos, IEnumerable<GroupResource> groupRes)
        {
            foreach (var da in defaultDataAreas)
            {
                var dataArea = dataAreaEntityList.FirstOrDefault(a => da.Id == a.DataAreaId);

                dataAreas.Add(new DataAreaAccessModel
                {
                    Id = da.Id,
                    Name = da.UxLabel,
                    Domain = da.Domain,
                    AccessType = dataArea != null ? (AccessType)dataArea.AccessType : AccessType.NoAccess,
                    Users = dataArea != null && dataArea.UserIds.Any() ? userInfos.Where(u => dataArea.UserIds.Contains(u.LegacyId)).ToList() : [],
                    UserGroups = dataArea != null ? MapUserGroups(dataArea.UserGroupIds, groupRes) : []
                });
            }
        }

        private static List<DataAreaAccessModel> FilterDataAreasBySearchText(string? searchText, List<DataAreaAccessModel> dataAreas)
        {
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                var search = searchText.Trim();
                return dataAreas.Where(da =>
                        da.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                        da.Domain.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            return dataAreas;
        }

        private static List<DataAreaAccessModel> FilterDataAreasByIdsAndDomains(List<string> dataAreasForFilter, List<string> domainsForFilter, List<DataAreaAccessModel> dataAreas)
        {
            if (dataAreasForFilter.Count > 0)
            {
                var parsedDataAreaIds = new List<Guid>();
                foreach (var dataAreaId in dataAreasForFilter)
                {
                    if (Guid.TryParse(dataAreaId, out var parsedId))
                    {
                        parsedDataAreaIds.Add(parsedId);
                    }
                }

                if (parsedDataAreaIds.Count > 0)
                {
                    dataAreas = dataAreas.Where(da => parsedDataAreaIds.Contains(da.Id)).ToList();
                }
            }

            if (domainsForFilter.Count > 0)
            {
                dataAreas = dataAreas.Where(da => domainsForFilter.Contains(da.Domain, StringComparer.CurrentCultureIgnoreCase)).ToList();
            }

            return dataAreas;
        }

        private async Task<List<DataAreaAccessModel>> FilterDataAreasByUserAndGroup(Guid tenantId, string[]? userIds, string[] userGroupIds, List<DataAreaAccessModel> dataAreas)
        {
            if (userIds != null && userIds.Length > 0)
            {
                var userIdsSet = userIds.ToHashSet();
                var userIdsGroups = await _userInfoProvider.GetUsersDetails(tenantId, [.. userIds]);
                var userGroupLegacyIds = userIdsGroups.SelectMany(g => g.DirectGroupIds).ToArray();
                var groups = userGroupLegacyIds.Any() ? await _userService.GetGroupsByGroupIdsAsync(tenantId, userGroupLegacyIds) : [];
                var userGroupsSet = groups.Select(g => g.LegacyId).ToHashSet();

                dataAreas = dataAreas.Where(da => IsDataAreaAccessibleToUser(da, userIdsSet, userGroupsSet)).ToList();
            }

            if (userGroupIds != null && userGroupIds.Length > 0)
            {
                // Batch all async calls instead of sequential foreach
                var userIdTasks = userGroupIds.Select(ugId => _userService.GetUserIdsByGroupIdAsync(tenantId.ToString(), ugId));
                var userIdResults = await Task.WhenAll(userIdTasks);

                var allUsersIds = userIdResults
                    .SelectMany(result => result.Resource)
                    .Distinct()
                    .ToList();

                var users = await _userInfoProvider.GetUsersDetails(tenantId, allUsersIds);
                var userIdsOfUserGroups = users
                    .Where(x => x.LegacyId != null)
                    .Select(x => x.LegacyId!)
                    .ToHashSet();

                var userGroupIdsSet = userGroupIds.ToHashSet();
                var combinedUserIds = (userIds ?? []).Concat(userIdsOfUserGroups).ToHashSet();

                dataAreas = dataAreas.Where(da => IsDataAreaAccessibleToUser(da, combinedUserIds, userGroupIdsSet)).ToList();
            }

            return dataAreas;
        }

        private static bool IsDataAreaAccessibleToUser(DataAreaAccessModel da, HashSet<string> userIds, HashSet<string> userGroupIds)
        {
            return da.AccessType switch
            {
                AccessType.All => true,
                AccessType.NoAccess => false,
                AccessType.Included => HasUserOrGroupAccess(da, userIds, userGroupIds),
                AccessType.Excluded => !HasUserOrGroupAccess(da, userIds, userGroupIds),
                _ => false
            };
        }

        private static bool HasUserOrGroupAccess(DataAreaAccessModel da, HashSet<string> userIds, HashSet<string> userGroupIds)
        {
            var userExistsInDataArea = da.Users?.Any(u => userIds.Contains(u.LegacyId)) == true;
            var userInDataAreaGroups = da.UserGroups?.Any(u => userGroupIds.Contains(u.Id)) == true;
            return userExistsInDataArea || userInDataAreaGroups;
        }

        private List<string> ParseJsonList(string? json)
        {
            if (string.IsNullOrWhiteSpace(json)) return new List<string>();

            try
            {
                return JsonSerializer.Deserialize<List<string>>(json, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase) ?? new List<string>();
            }
            catch (Exception ex)
            {
                var sanitizedJson = json?.Replace("\r", string.Empty).Replace("\n", string.Empty);
                _logger.Error("Failed to parse JSON list: {json}. Error: {error}", sanitizedJson, ex.Message);
                return new List<string>();
            }
        }

        private static string[] ExtractPrefixedIds(List<string> ids, string prefix)
        {
            return ids.Where(id => id.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                      .Select(id => id.Substring(prefix.Length))
                      .ToArray();
        }
    }
}
