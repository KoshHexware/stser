﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.Common.ServiceFoundation;
using EntityPropertyType = Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities.PropertyType;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class SystemFiltersService(ISystemReportsRepository _systemReportsRepository, 
        IDraftReportFiltersService _draftReportFiltersService, ICustomPropertyService _customPropertyService,
        ISeismicContextProvider _contextProvider, IFiltersMacroResolver _fitersDynamicDomainOfValuesBuilder, IUserService _userService) : ISystemFiltersService
    {
        private Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        public async Task<IEnumerable<FilterTemplateModel>> GetAllFiltersAsync(List<FieldGroup> fieldGroups, List<string> reportDefinitionFilters, bool showTeamsitePicker, bool isCustomReport, string[]? customReportSelectedTeamsiteIds)
        {
            var systemFilters = _systemReportsRepository.GetAllFilters();
            systemFilters = [.. systemFilters.Where(f => reportDefinitionFilters.Contains(f.FilterName, StringComparer.OrdinalIgnoreCase))];
            var systemFilterNames = systemFilters.Select(f => f.FilterName);

            if (fieldGroups != null)
            {
                var genericFilters = CreateGenericFilters(fieldGroups);
                systemFilters = systemFilters.Concat(genericFilters.Where(d => !systemFilterNames.Contains(d.FilterName, StringComparer.OrdinalIgnoreCase)));
            }


            //user custom properties filters
            var userCustomPropsFilters = new List<FilterTemplateModel>();
            var userCustomProps = await _customPropertyService.GetUserCustomProperties(TenantId);
            if (userCustomProps.Any())
            {
                userCustomPropsFilters.AddRange(
                userCustomProps.Select(p => new FilterTemplateModel
                {
                    FilterName = p.Name + p.Id,
                    Category = CustomPropertyConstant.CUSTOM_PROPERTIES,
                    DataType = (DataAccess.Entities.DataType)DataTypeHelper.GetDataType(p.Type),
                    DomainValues = p.Values?.Length > 0 ? p.Values.ToList() : null,
                    FilterType = p.Values?.Length > 0 ? FilterType.domainOfValues : FilterType.freetext,
                    QueryParam = (CustomPropertyConstant.USER_PROPERTIES_QUERY_ALIAS + p.Id).Replace("-", ""),
                    UxDescription = p.Description ?? $"A custom user property for your organization.",
                    UxLabel = p.Name,
                    AllowedOperators = OperatorHelper.GetAllowedOperatorsByDataType(DataTypeHelper.GetDataType(p.Type), p.Values?.Length > 0, true, false, false),
                    FilterPicklistQuery = null,
                    IsProperty = true,
                    PropertyId = p.Id.ToString(),
                    PropertyType = EntityPropertyType.UserProperty,
                    IsNullable = true
                }).ToList());
            }

            //content custom properties filters
            var context = _contextProvider.GetContext();
            var userSettings = await _userService.GetUserSettingsAsync(TenantId, context.UserId);
            var contentCustomProps = showTeamsitePicker
                ? await _customPropertyService.GetFilteredContentPropertiesByUserTeamsites(TenantId, userSettings.Teamsites)
                : await _customPropertyService.GetContentCustomProperties(TenantId);
            var contentCustomPropsFilters = new List<FilterTemplateModel>();
            if (contentCustomProps.Any())
            {
                contentCustomPropsFilters.AddRange(
                contentCustomProps.Select(p => new FilterTemplateModel
                {
                    FilterName = p.Name + p.Id,
                    Category = CustomPropertyConstant.CUSTOM_PROPERTIES,
                    DataType = (DataAccess.Entities.DataType)DataTypeHelper.GetDataType(p.Type),
                    DomainValues = p.Values?.Length > 0 ? [.. p.Values] : null,
                    FilterType = p.Values?.Length > 0 ? FilterType.domainOfValues : FilterType.freetext,
                    QueryParam = (CustomPropertyConstant.CONTENT_CUSTOM_PROPERTIES_QUERY_ALIAS + p.Id).Replace("-", ""),
                    UxDescription = p.Description ?? string.Empty,
                    UxLabel = p.Name,
                    AllowedOperators = OperatorHelper.GetAllowedOperatorsByDataType(DataTypeHelper.GetDataType(p.Type), p.Values?.Length > 0, true, p.AllowMultipleValues?? false, false),
                    FilterPicklistQuery = null,
                    IsNullable = true,
                    IsProperty = true,
                    PropertyId = p.Id.ToString(),
                    PropertyType = EntityPropertyType.ContentCustomProperty,
                    TeamsiteIds = p.TeamsiteIds,
                }).ToList());
            }

            //Merge all filters
            systemFilters = systemFilters.Concat(userCustomPropsFilters).Concat(contentCustomPropsFilters);

            //Merge draft filters if enabled and not already present in system filters
            var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
            if (draftReportsEnabled)
            {
                var drafts = await _draftReportFiltersService.GetDraftFiltersAsync();

                var allSystemAndGenericFilterNames = systemFilters.Select(f => f.FilterName);
                systemFilters = systemFilters.Concat(drafts.Filters.Where(d => !allSystemAndGenericFilterNames.Contains(d.FilterName, StringComparer.OrdinalIgnoreCase)) ?? []);
            }
           
            await ExtractDomainOfValuesFromMacro(systemFilters);
            return systemFilters;
        }

        private async Task ExtractDomainOfValuesFromMacro(IEnumerable<FilterTemplateModel> systemFilters)
        {
            var context = _contextProvider.GetContext();
            var dynamicDomainOfValuesFilters = systemFilters
            .Where(f => f.FilterType == FilterType.domainOfValues && f.DomainValues != null && f.DomainValues.Any(dv => DomainOfValuesMacro.ValidMacros.Contains(dv, StringComparer.OrdinalIgnoreCase)));

            foreach (var filter in dynamicDomainOfValuesFilters)
            {
                var domainValues = new List<string>();

                foreach (var domainValue in filter.DomainValues)
                {
                    if (DomainOfValuesMacro.ValidMacros.Contains(domainValue, StringComparer.OrdinalIgnoreCase))
                    {
                        var fetchedDomainValues = await _fitersDynamicDomainOfValuesBuilder.GetMacroValues(domainValue, context.TenantIdentifier.TenantUniqueId, context.UserId);
                        domainValues.AddRange(fetchedDomainValues);
                    }
                    else
                    {
                        domainValues.Add(domainValue);
                    }
                }

                filter.DomainValues = domainValues.Distinct().ToList();
            }
        }

        public async Task<FilterTemplateModel?> GetFilterByNameAsync(string filterName, List<FieldGroup>? fieldGroups = null)
        {
            if (fieldGroups != null)
            {
                var genericFilters = CreateGenericFilters(fieldGroups);
                var genericFilter = genericFilters.FirstOrDefault(f => string.Equals(f.FilterName, filterName, StringComparison.OrdinalIgnoreCase));
                if (genericFilter != null)
                    return genericFilter;
            }

            var result = _systemReportsRepository.GetFilterByName(filterName);
            if (result != null)
                return result;

            

            var draftReportsEnabled = await _contextProvider.DraftReportsEnabled();
            if (!draftReportsEnabled)
            {
                throw new NotFoundException($"Filter with name '{filterName}' not found.");
            }

            var draftFilter = await _draftReportFiltersService.GetDraftFilterByNameAsync(filterName);
            return draftFilter.Filters.SingleOrDefault() ?? throw new NotFoundException($"Filter with name '{filterName}' not found.");
        }

        private static List<FilterTemplateModel> CreateGenericFilters(List<FieldGroup>? fieldGroups)
        {
            var genericFilterTemplates = new List<FilterTemplateModel>();

            if (fieldGroups == null || fieldGroups.Count == 0)
            {
                return genericFilterTemplates;
            }

            foreach (var fieldGroup in fieldGroups)
            {
                foreach (var field in fieldGroup.Fields)
                {
                    if ((field.HasGenericFilter ?? true) && field.FilterName == null && (field.IsProperty ?? false) == false)
                    {
                        var haveDomainValuesOrPicklistQuery = field.FilterDomainValues != null && field.FilterDomainValues.Count > 0 || !string.IsNullOrWhiteSpace(field.FilterPicklistQuery);
                        var filterType = field.FilterDomainValues != null && field.FilterDomainValues.Count > 0 ? FilterType.domainOfValues : !string.IsNullOrWhiteSpace(field.FilterPicklistQuery) ? FilterType.picklist : FilterType.freetext;
                        var doesSupportRelativeTeamFilters = !string.IsNullOrWhiteSpace(field.EnableRelativeUserFilterField);
                        genericFilterTemplates.Add(new FilterTemplateModel
                        {
                            FilterName = field.Name,
                            QueryParam = field.Name,
                            UxLabel = field.UxLabel,
                            UxDescription = field.UxDescription,
                            Category = fieldGroup.UxLabel,
                            DataType = (DataAccess.Entities.DataType)field.DataType,
                            AllowedOperators = OperatorHelper.GetAllowedOperatorsByDataType(field.DataType, haveDomainValuesOrPicklistQuery, field.Nullable, false, doesSupportRelativeTeamFilters),
                            FilterType = filterType,
                            IsNullable = field.Nullable,
                            IsGenericFilter = true,
                            FilterPicklistQuery = field.FilterPicklistQuery,
                            DomainValues = field.FilterDomainValues ?? [],
                            IsDefault = field.FilterIsDefault,
                            FilterDefaultOperator = field.FilterDefaultOperator,
                            FilterDefaultValues = field.FilterDefaultValues,
                            FilterIsDefault = field.FilterIsDefault,
                            QueryAlias = field.QueryAlias,
                            FilterValuesByTeamsite = field.FilterValuesByTeamsite,
                            EnableRelativeUserFilterField = field.EnableRelativeUserFilterField,
                            DataAreaKey = field.DataAreaKey,
                        });
                    }
                }
            }
            return genericFilterTemplates;
        }

    }
}
