﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement.PermissionMigration;
using Seismic.Platform.UserManagement.Client;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class EntitlementsMigrationService(ILogger _logger, IEntitlementServiceClientWrapper _entitlementServiceClientWrapper, IUserService _userService) : IEntitlementsMigrationService
    {
        private static readonly List<string> preDefinedRoleIds = new List<string>
        {
            "1f87fda4-6813-1f78-05aa-bd350da13062", // "Premium"
            "947ce411-f2d8-9a65-1b5e-063dc48871bd", // "Business"
            "006f920a-ec39-e24d-d1ce-a8b060c38392", // "Partner"
            "af1b49bc-4c3d-4570-b38f-a12ff3ecf149", // "Admin"
            "38521c7b-e763-4c99-a380-321cba6e681c", // "Creator"
            "23ba7837-bf54-415e-ab13-6de35a3b29a2", // "Manager"
            "5aa9a264-2052-413e-8582-922a1ee23f40" // "Learner"
         };

        public async Task<List<MigrationInfo>> GetMigrationInfoForTenant(Guid tenantId, string platformToken)
        {
            var toReturn = new List<MigrationInfo>();

            var ssrViewerUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsViewer);
            var ssrEditorUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsEditor);
            var ssrCreatorsUgMemberTask = _userService.GetGroupMembers(tenantId, UserGroupConstants.SelfServiceReportsCreator);

            await Task.WhenAll(ssrViewerUgMemberTask, ssrEditorUgMemberTask, ssrCreatorsUgMemberTask);

            var ssrViewerUgMembers = ssrViewerUgMemberTask?.Result ?? [];
            var ssrEditorUgMembers = ssrEditorUgMemberTask?.Result ?? [];
            var ssrCreatorsUgMembers = ssrCreatorsUgMemberTask?.Result ?? [];

            var viewerUserList = new HashSet<string>();
            var editorUserList = new HashSet<string>();
            var creatorUserList = new HashSet<string>();


            // Process Editor group members
            var ssrEditorUsers = ssrEditorUgMembers.Select(x => x.LegacyId).ToList();
            var ssrEditorUsersCount = ssrEditorUsers.Count;


            await ProcessEditorGroupMembers(tenantId, toReturn, ssrEditorUgMembers, viewerUserList, editorUserList, creatorUserList, ssrEditorUsers, ssrEditorUsersCount, platformToken);
            await ProcessCreatorGroupMembers(tenantId, toReturn, ssrCreatorsUgMembers, viewerUserList, editorUserList, creatorUserList, platformToken);
            ProcessViewerGroupMembers(tenantId, toReturn, ssrViewerUgMembers, ssrEditorUgMembers, ssrCreatorsUgMembers, viewerUserList);
            return toReturn;
        }

        private async Task ProcessEditorGroupMembers(Guid tenantId, List<MigrationInfo> toReturn, List<Platform.UserManagement.Model.UsersBasicInfoResource> ssrEditorUgMembers, HashSet<string> viewerUserList, HashSet<string> editorUserList, HashSet<string> creatorUserList, List<string> ssrEditorUsers, int ssrEditorUsersCount, string platformToken)
        {
            if (ssrEditorUsersCount > 0)
            {
                var userRoleRelations = await _entitlementServiceClientWrapper.GetUserRolesByUserIdsAsync(tenantId, ssrEditorUsers, platformToken);
                var filteredUserIdsOfEditorUg = GetFilterOutUserIdsInEditorGroup(userRoleRelations, UserGroupConstants.SelfServiceReportsEditor);
                var filteredUserIdsOfEditorUgSet = new HashSet<string>(filteredUserIdsOfEditorUg);
                var remainingEditorMembers = ssrEditorUgMembers.Where(x => filteredUserIdsOfEditorUgSet.Contains(x.LegacyId)).ToList();

                if (remainingEditorMembers.Count > 0)
                {
                    var users = remainingEditorMembers.Select(x => x.LegacyId).Distinct().ToList();
                    foreach (var id in remainingEditorMembers.Select(x => x.LegacyId))
                        editorUserList.Add(id);
                    toReturn.Add(new MigrationInfo
                    {
                        Users = users,
                        Operation = Operation.Enable,
                        Permissions = [PermissionConstants.SelfServiceReportsCreatorPermissionKey, PermissionConstants.SelfServiceReportsManageReportsPermissionKey, PermissionConstants.SelfServiceReportsViewerPermissionKey],
                        MigrationType = MigrationType.PerUsersAndGroups,
                        UserGroups = [],
                    });
                }

                if (ssrEditorUsersCount > remainingEditorMembers.Count)
                {
                    var filteredUserIdsHashSet = new HashSet<string>(filteredUserIdsOfEditorUg);
                    var nonFilteredUsersOfEditorUg = userRoleRelations?.Where(x => !filteredUserIdsHashSet.Contains(x.UserId)).ToList();
                    var filteredUserIdsForCreatorUg = GetFilterOutUserIdsInEditorGroup(nonFilteredUsersOfEditorUg, UserGroupConstants.SelfServiceReportsCreator);
                    var filteredUserIdsSetForCreatorUg = new HashSet<string>(filteredUserIdsForCreatorUg);
                    var remainingCreatorMembers = ssrEditorUgMembers.Where(x => filteredUserIdsSetForCreatorUg.Contains(x.LegacyId)).ToList();

                    var remainingCreatorMembersCount = remainingCreatorMembers.Count;

                    if (remainingCreatorMembersCount > 0)
                    {
                        foreach (var id in remainingCreatorMembers.Select(x => x.LegacyId))
                            creatorUserList.Add(id);
                    }

                    var nonFilteredUsersCount = nonFilteredUsersOfEditorUg?.Count ?? 0;
                    if (nonFilteredUsersCount > remainingCreatorMembersCount)
                    {
                        var filteredUserIdsForCreatorUgHashSet = new HashSet<string>(filteredUserIdsForCreatorUg);
                        var nonFilteredUsers = nonFilteredUsersOfEditorUg ?? new List<UserRolesView>();
                        var nonFilteredUserIdsForViewer = new HashSet<string>(
                            nonFilteredUsers.Where(x => !filteredUserIdsForCreatorUgHashSet.Contains(x.UserId))
                                               .Select(x => x.UserId)
                        );

                        var remainingViewerUser = ssrEditorUgMembers.Where(x => nonFilteredUserIdsForViewer.Contains(x.LegacyId) && !editorUserList.Contains(x.LegacyId) && !creatorUserList.Contains(x.LegacyId)).ToList();
                        if (remainingViewerUser.Count > 0)
                        {
                            foreach (var id in remainingViewerUser.Select(x => x.LegacyId))
                                viewerUserList.Add(id);
                        }
                    }
                }
            }
            else
            {
                _logger.Information("EntitlementsMigrationController.GetMigrationInfo, No member found in self service editor group for tenant {0}", tenantId);
            }
        }
        
        private async Task ProcessCreatorGroupMembers(Guid tenantId, List<MigrationInfo> toReturn, List<Platform.UserManagement.Model.UsersBasicInfoResource> ssrCreatorsUgMembers, HashSet<string> viewerUserList, HashSet<string> editorUserList, HashSet<string> creatorUserList, string platformToken)
        {
            // Process Creator group members
            var ssrCreatorUsers = ssrCreatorsUgMembers.Select(x => x.LegacyId).ToList();
            var ssrCreatorUsersCount = ssrCreatorUsers.Count;

            if (ssrCreatorUsersCount > 0)
            {
                var creatorUserRoleRelations = await _entitlementServiceClientWrapper.GetUserRolesByUserIdsAsync(tenantId, ssrCreatorUsers, platformToken);
                var filteredCreatorUserIds = GetFilterOutUserIdsInEditorGroup(creatorUserRoleRelations, UserGroupConstants.SelfServiceReportsCreator);
                var filteredCreatorUserIdsSet = new HashSet<string>(filteredCreatorUserIds);
                var remainingCreatorMembersFromCreatorGroup = ssrCreatorsUgMembers.Where(x => filteredCreatorUserIdsSet.Contains(x.LegacyId)).ToList();

                if (remainingCreatorMembersFromCreatorGroup.Count > 0)
                {
                    foreach (var id in remainingCreatorMembersFromCreatorGroup.Select(x => x.LegacyId))
                        creatorUserList.Add(id);
                    var users = creatorUserList.Distinct().Where(x => !editorUserList.Contains(x)).ToList();

                    toReturn.Add(new MigrationInfo
                    {
                        Users = users,
                        Operation = Operation.Enable,
                        Permissions = [PermissionConstants.SelfServiceReportsCreatorPermissionKey, PermissionConstants.SelfServiceReportsViewerPermissionKey],
                        MigrationType = MigrationType.PerUsersAndGroups,
                        UserGroups = [],
                    });
                }

                if (ssrCreatorUsersCount > remainingCreatorMembersFromCreatorGroup.Count)
                {
                    var filteredCreatorUserIdsHashSet = new HashSet<string>(filteredCreatorUserIds);
                    var nonFilteredCreatorUsers = creatorUserRoleRelations?.Where(x => !filteredCreatorUserIdsHashSet.Contains(x.UserId)).ToList();
                    var nonFilteredUserIdsForViewer = new HashSet<string>(
                        nonFilteredCreatorUsers!.Where(x => !filteredCreatorUserIdsHashSet.Contains(x.UserId))
                                       .Select(x => x.UserId)
                    );

                    var remainingViewerMembersFromCreatorGroup = ssrCreatorsUgMembers.Where(x => nonFilteredUserIdsForViewer.Contains(x.LegacyId) && !editorUserList.Contains(x.LegacyId) && !creatorUserList.Contains(x.LegacyId)).ToList();

                    if (remainingViewerMembersFromCreatorGroup.Count > 0)
                    {
                        foreach (var id in remainingViewerMembersFromCreatorGroup.Select(x => x.LegacyId))
                            viewerUserList.Add(id);
                    }
                }
            }
            else
            {
                _logger.Information("EntitlementsMigrationController.GetMigrationInfo, No member found in self service creator group for tenant {0}", tenantId);
            }

            if(ssrCreatorUsersCount==0 && creatorUserList.Count > 0)
            {
                var users = creatorUserList.Distinct().Where(x => !editorUserList.Contains(x)).ToList();
                toReturn.Add(new MigrationInfo
                {
                    Users = users,
                    Operation = Operation.Enable,
                    Permissions = [PermissionConstants.SelfServiceReportsCreatorPermissionKey, PermissionConstants.SelfServiceReportsViewerPermissionKey],
                    MigrationType = MigrationType.PerUsersAndGroups,
                    UserGroups = [],
                });
            }
        }
        
        private void ProcessViewerGroupMembers(Guid tenantId, List<MigrationInfo> toReturn, List<Platform.UserManagement.Model.UsersBasicInfoResource> ssrViewerUgMembers, List<Platform.UserManagement.Model.UsersBasicInfoResource> ssrEditorUgMembers, List<Platform.UserManagement.Model.UsersBasicInfoResource> ssrCreatorsUgMembers, HashSet<string> viewerUserList)
        {
            // Process Viewer group members
            var editorIds = new HashSet<string>(ssrEditorUgMembers.Select(e => e.LegacyId));
            var creatorIds = new HashSet<string>(ssrCreatorsUgMembers.Select(c => c.LegacyId));

            var ssrViewerUsers = ssrViewerUgMembers
                .Where(x => !editorIds.Contains(x.LegacyId) && !creatorIds.Contains(x.LegacyId))
                .Select(z => z.LegacyId)
                .ToList();

            var finalViewerUsers = new HashSet<string>(ssrViewerUsers);
            foreach (var id in viewerUserList) finalViewerUsers.Add(id);

            var distinctViewerUsers = finalViewerUsers.Distinct().ToList();
            if (distinctViewerUsers.Count > 0)
            {
                toReturn.Add(new MigrationInfo
                {
                    Users = distinctViewerUsers.Select(x => ShortGuidExtension.ToLegacyId(x)).ToList(),
                    Operation = Operation.Enable,
                    Permissions = [PermissionConstants.SelfServiceReportsViewerPermissionKey],
                    MigrationType = MigrationType.PerUsersAndGroups,
                    UserGroups = []
                });
            }
            else
            {
                _logger.Information("EntitlementsMigrationController.GetMigrationInfo, No member found in self service viewer group for tenant {0}", tenantId);
            }
        }

        private static List<string> GetFilterOutUserIdsInEditorGroup(List<UserRolesView>? userRoleRelations, string selfServiceReportsUserGroup)
        {
            var needBeFilteredOutRoleIds = new List<string>();
            if (selfServiceReportsUserGroup == UserGroupConstants.SelfServiceReportsEditor)
            {
                needBeFilteredOutRoleIds =
                [
                    "947ce411-f2d8-9a65-1b5e-063dc48871bd", //Business
                    "006f920a-ec39-e24d-d1ce-a8b060c38392", //Partner
                    "5aa9a264-2052-413e-8582-922a1ee23f40" //Learner
                ];
            }
            else if (selfServiceReportsUserGroup == UserGroupConstants.SelfServiceReportsCreator)
            {
                needBeFilteredOutRoleIds =
                [
                    "006f920a-ec39-e24d-d1ce-a8b060c38392", //Partner
                ];
            }
            else if (selfServiceReportsUserGroup == UserGroupConstants.SelfServiceReportsViewer)
            {
                needBeFilteredOutRoleIds = [];
            }

            List<string> filteredUserIds = [];
            foreach (var user in userRoleRelations!)
            {
                var userRoles = user.Roles;
                if (userRoles is null || userRoles.Count == 0) throw new Exception($"User id:{user.UserId} has no roles assigned.");

                if (userRoles is not null && userRoles.Count > 2) throw new Exception($"User id:{user.UserId} has more than 2 roles assigned.");

                // try to get the related pre-defined roles for a user,
                // if the user's role is a pre-defined one, which is identified by originalRoleId is null/empty, use it directly;
                // if the user's role is a custom one, get the related pre-defined role by originalRoleId.
                var userRelatedPreDefinedRoleIds = userRoles!.Select(r =>
                {
                    var originalRoleId = r.OriginalRoleId;
                    if (string.IsNullOrEmpty(originalRoleId))
                    {
                        originalRoleId = r.Id;
                    }
                    return originalRoleId.ToLower();
                }).ToList();

                userRelatedPreDefinedRoleIds = preDefinedRoleIds.Where(r => userRelatedPreDefinedRoleIds.Contains(r)).ToList();

                if (userRelatedPreDefinedRoleIds.Count != userRoles!.Count)
                {
                    throw new Exception($"User {user.UserId} does not find the related pre-defined roles for all roles: {string.Join(" ", userRoles.Select(r => r.Name))}.");
                }

                // filter out userId via needBeFilteredOutRoleIds
                var needBeFilteredOut = false;

                needBeFilteredOutRoleIds = needBeFilteredOutRoleIds.Select(e => e.ToLower()).ToList();

                // only if a user's all related pre-defined roles are in the black list, then this user will be filtered out
                if (needBeFilteredOutRoleIds.Intersect(userRelatedPreDefinedRoleIds).Count() == userRelatedPreDefinedRoleIds.Count)
                {
                    needBeFilteredOut = true;
                }

                if (needBeFilteredOut)
                {
                    Console.WriteLine($"user id:{user.UserId} be filtered out userRoles:{string.Join(" ", userRoles.Select(e => e.Id))} userOriginalRole:{string.Join(" ", userRelatedPreDefinedRoleIds)}");
                }
                else
                {
                    filteredUserIds.Add(user.UserId);
                }
            }
            return filteredUserIds;
        }
    }
}
