﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.Platform.UserManagement.Client;
using Seismic.Platform.UserManagement.Model;
using Serilog;
using System.Net;
using System.Text.Json;


namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class UserService(IUserManagementClient _umsClient, ILogger logger, IDataAccessor _dataAccessor, ICMService _cmService) : IUserService
    {
        public static Version DefaultRequestVersion => HttpVersion.Version20;

        private readonly ILogger _logger = logger.ForContext<UserService>();

        public async Task<List<UserResource>> GetMultipleUsersInTenant(Guid tenantId, string[] userIds)
        {
            if (userIds == null || userIds.Length == 0)
                return [];
            return await GetMultipleUsersInTenant(tenantId, new HashSet<string>(userIds));
        }

        public async Task<GroupResource> GetUserGroupByName(Guid tenantId, string groupName)
        {
            var response = await _umsClient.GetGroupByNameAsync(tenantId.ToString(), groupName);
            if (!response.IsSuccessStatusCode)
            {
                var error = JsonSerializer.Serialize(response.Error);
                _logger.Error("Error in getting User group:{groupName} for tenant:{tenantId}, Error:{error}", groupName, tenantId, error);
                throw new Exception($"Error in getting User:{groupName} for tenant:{tenantId}, Error:{error}");
            }
            return response.Resource;
        }

        public async Task<IEnumerable<CustomPropertyResource>> GetCustomUserProperties(Guid tenantId)
        {
            var response = await _umsClient.GetCustomPropertiesAsync(tenantId.ToString());
            if (!response.IsSuccessStatusCode)
            {
                var error = JsonSerializer.Serialize(response.Error);
                _logger.Error("Error in getting user properties for tenant:{tenantId}, Error:{error}", tenantId, error);
                throw new Exception($"Error in getting user properties for tenant:{tenantId}, Error:{error}");
            }
            return response.Resource.Items;
        }

        public async Task<UserResource> GetUserById(Guid tenantId, string userId)
        {
            // should we cache response of this api call?
            var response = await _umsClient.GetUserByIdAsync(tenantId.ToString(), userId);
            if (!response.IsSuccessStatusCode)
            {
                var error = JsonSerializer.Serialize(response.Error);
                var sanitizedUserId = userId.Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
                _logger.Error("Error in getting User:{userId} for tenant:{tenantId}, Error:{error}", sanitizedUserId, tenantId, error);
                throw new Exception($"Error in getting User:{sanitizedUserId} for tenant:{tenantId}, Error:{error}");
            }
            return response.Resource;
        }

        public async Task<List<UsersBasicInfoResource>> GetGroupMembers(Guid tenantId, string groupName)
        {
            var group = await GetUserGroupByName(tenantId, groupName);

            if (group == null)
            {
                _logger.Warning("User group with name:{groupName} for tenant:{tenantId} does not exist or deleted, Response: {result}", groupName, tenantId);
                return new List<UsersBasicInfoResource>();
            }
            var response = await _umsClient.GetUsersBasicInfoByGroupId(tenantId.ToString(), group.LegacyId, new ExtensionParameter());

            if (response.IsSuccessStatusCode)
            {
                return response.Resource.Items.ToList();
            }

            var error = JsonSerializer.Serialize(response.Error);
            _logger.Error("Error in GetGroupMembers for User group:{groupName} for tenant:{tenantId}, Error:{error}", groupName, tenantId, error);
            throw new Exception($"Error in GetGroupMembers for User group:{groupName} for tenant:{tenantId}, Error:{error}");
        }

       public async Task<IEnumerable<GroupResource>> GetGroupsByGroupIdsAsync(Guid tenantId, string[] groupIds)
        {
            var response = await _umsClient.GetGroupsByGroupIdsAsync(tenantId.ToString(), groupIds);
            if (!response.IsSuccessStatusCode)
            {
                var error = JsonSerializer.Serialize(response.Error);
                var groupIdsString = string.Join(',', groupIds);
                _logger.Error("Error in getting user group:{groupIds} for tenant:{tenantId}, Error:{error}", groupIdsString, tenantId, error);
                throw new Exception($"Error in getting user groups for tenant:{tenantId}, Error:{error}");
            }
           
            return response.Resource?.Items ?? new List<GroupResource>();
        }

        private async Task<List<UserResource>> GetMultipleUsersInTenant(Guid tenantId, HashSet<string> userIds)
        {
            var target = userIds.ToArray();
            var result = new List<UserResource>();

            var batchSize = 200;
            int skip = 0;
            int remaining;

            do
            {
                var pagedResult = await _umsClient.GetUsersByIdsAsync(tenantId.ToString(), target.Skip(skip).Take(batchSize).ToArray());
                result.AddRange(pagedResult.Resource.Items);

                skip += batchSize;
                remaining = target.Length - skip;
            }
            while (remaining > 0);

            return result;
        }

        public async Task<Models.UserSettings> GetUserSettingsAsync(Guid tenantId, string userId)
        {
            var userAccessibleTeamsitesTask = _cmService.GetUserAccessibleTeamsitesAsync(tenantId, userId);
            var userSettingsTask = _dataAccessor.GetUserSettingsAsync(tenantId, userId);

            await Task.WhenAll(userAccessibleTeamsitesTask, userSettingsTask);

            var userAccessibleTeamsites = await userAccessibleTeamsitesTask;
            var userSettings = await userSettingsTask;

            var reportsFilterOption = userSettings?.ReportsFilterOption?.ToLower() ?? ReportsFilterOption.All.ToString().ToLower();

            if (userAccessibleTeamsites == null || userAccessibleTeamsites.Count == 0)
            {
                return new Models.UserSettings()
                {
                    Teamsites = [],
                    ReportsFilterOption = reportsFilterOption
                };
            }

            var userTeamsitesList = new List<Teamsites>();
            if (userSettings == null || userSettings.Teamsites == null ||  userSettings.Teamsites?.Length == 0)
            {
                userTeamsitesList = [.. userAccessibleTeamsites.Select(t => new Teamsites
                {
                    Id = t.Id,
                    Name = t.Name,
                    Description = t.Description,
                    // if preferred teamsites is null or empty , all user accessible teamsites are selected
                    IsSelected = true
                })];
            }
            else
            {
                userTeamsitesList = [.. userAccessibleTeamsites.Select(t => new Teamsites
                {
                    Id = t.Id,
                    Name = t.Name,
                    Description = t.Description,
                    IsSelected = userSettings.Teamsites != null && userSettings.Teamsites.Contains(t.Id)
                })];
            }

            return new Models.UserSettings()
            {
                Teamsites = userTeamsitesList,
                ReportsFilterOption = reportsFilterOption,
                OrderBy = userSettings?.OrderBy,
                OrderField = userSettings?.OrderField
            };
        }

        public async Task<List<Teamsites>> UpdateUserPreferredTeamsitesAsync(Guid tenantId, string userId, string[] teamsiteIds)
        {
            var userAccessibleTeamsitesTask = _cmService.GetUserAccessibleTeamsitesAsync(tenantId, userId);
            var userTeamsitesTask = _dataAccessor.GetUserSettingsAsync(tenantId, userId);

            await Task.WhenAll(userAccessibleTeamsitesTask, userTeamsitesTask);

            var userAccessibleTeamsites = userAccessibleTeamsitesTask.Result;
            var userTeamsites = userTeamsitesTask.Result;
            var teamsitesEntity = userTeamsites ?? new DataAccess.Entities.UserSettings
            {
                TenantId = tenantId,
                UserId = userId,
                CreatedOnUtc = DateTime.UtcNow
            };

            teamsitesEntity.Teamsites = teamsiteIds ?? [];
            teamsitesEntity.ModifiedOnUtc = DateTime.UtcNow;
            if (userTeamsites != null)
            {
                await _dataAccessor.UpdateUserSettingsAsync(teamsitesEntity);
            }
            else
            {
                await _dataAccessor.AddUserSettingsAsync(teamsitesEntity);
            }

            if (teamsiteIds == null || teamsiteIds.Length == 0)
            {
                return userAccessibleTeamsites ?? [];
            }

            return userAccessibleTeamsites.Select(t => new Teamsites
            {
                Id = t.Id,
                Name = t.Name,
                Description = t.Description,
                IsSelected = teamsiteIds.Contains(t.Id)
            }).ToList();
        }

        public async Task CreateOrUpdateReportsFilterOption(Guid tenantId, string userId, string filterOption)
        {
            var existingReportsFilterOption = await _dataAccessor.GetUserSettingsAsync(tenantId, userId);

            var reportsFilterOption = Enum.GetName(typeof(ReportsFilterOption), Enum.Parse<ReportsFilterOption>(filterOption, true)) ?? ReportsFilterOption.All.ToString();

            if (existingReportsFilterOption != null)
            {
                existingReportsFilterOption.ReportsFilterOption = reportsFilterOption;
                existingReportsFilterOption.ModifiedOnUtc = DateTime.UtcNow;
                await _dataAccessor.UpdateUserSettingsAsync(existingReportsFilterOption);
            }
            else
            {
                var newReportsFilterOption = new DataAccess.Entities.UserSettings
                {
                    TenantId = tenantId,
                    UserId = userId,
                    ReportsFilterOption = reportsFilterOption,
                    CreatedOnUtc = DateTime.UtcNow,
                    ModifiedOnUtc = DateTime.UtcNow
                };
                await _dataAccessor.AddUserSettingsAsync(newReportsFilterOption);
            }
        }

        public async Task<ResourceResponse<IEnumerable<string>>> GetUserIdsByGroupIdAsync(string tenantId, string userGroupId)
        {
            return await _umsClient.GetUserIdsByGroupIdAsync(tenantId, userGroupId);
        }
    }
}
