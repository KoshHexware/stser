﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.CustomProperty.Model;
using Seismic.CustomProperty.Client;
using Seismic.Foreshock.Value;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class CustomPropertyClientWrapper(CustomPropertyClient customPropertyClient) : ICustomPropertyClientWrapper
    {
        private readonly CustomPropertyClient _customPropertyClient = customPropertyClient;

        public async Task<ResourceResponse<ResourceList<CustomPropertyResource>>> GetAllCustomPropertiesAsync(string tenantId, FilterExpression options)
        {
            return await _customPropertyClient.GetAllCustomPropertiesAsync(tenantId, options);
        }

    }
}
