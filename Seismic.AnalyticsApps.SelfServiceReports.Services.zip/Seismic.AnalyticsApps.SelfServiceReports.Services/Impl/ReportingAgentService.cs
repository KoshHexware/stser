﻿using Amazon.S3.Model;
using Amazon.S3.Model.Internal.MarshallTransformations;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
//using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;


//using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportingAgent;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.Platform.Matrix.Client;
using System.Collections.Generic;
using static Seismic.Platform.Authentication.Filter.AuthFilterConstants;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class ReportingAgentService(IReportService _reportService, IMatrixClient _matrixClient, IPicklistQueryService _picklistQueryService, ISystemReportsService _systemReportsService, IReportRunner _reportRunner, ILogger logger, IDataAccessor _dataAccessor) : IReportingAgentService
    {
        private readonly Serilog.ILogger _logger = logger.ForContext<ReportingAgentService>();

        public Task<List<Dictionary<string, object>>> GetFilterDomainValuesAsync(Guid tenantId, string userId,Guid reportId, string reportName, List<string> filterNames, string? searchTerm = null, List<string>? teamsiteIds = null)
        {
            throw new NotImplementedException();
        }


        public async Task<ApiResponse<List<StandardReport>>> GetAllStandardReportsAsync(Guid tenantId, string? userId = null)
        {
            List<ApiError> lstApiError = new();
            ApiResponse<List<StandardReport>> apiResponse = new() { Success = false, Data = new List<StandardReport>(), Errors = lstApiError };           
            PagedList<ReportSummary> ssrsResults = await _reportService.GetAllReports(tenantId, userId, "system", null, 1000, 0, null, null, true);

            var reports = ssrsResults.Data
                .Select(r => new Dictionary<string, object>
                {
                    { "id", r.Id },
                    { "ReportName", r.ReportName },
                    { "SystemReportId", r.SystemReportId },
                    { "SystemReportName", r.SystemReportName },
                    { "Description", r.Description },
                    { "OwnerUserName", r.OwnerUserName ?? string.Empty },
                    { "OwnerThumbnailUrl", r.OwnerThumbnailUrl ?? string.Empty },
                    { "OwnerUserId", r.OwnerUserId ?? string.Empty },
                    { "LastViewed", r.LastViewed ?? DateTime.MinValue },
                    { "LastUpdated", r.LastUpdated ?? DateTime.MinValue },
                    { "ReportType", r.ReportType },
                    { "ShowTeamsitePicker", r.ShowTeamsitePicker },
                    { "SharedOn", r.SharedOn ?? DateTime.MinValue }
                })
                .ToList();

            if (reports.Count == 0)
            { 
                ApiError error = new ApiError
                {
                    ErrorMessage = "No reports available.",
                    Suggestion = "There are no standard reports available for this tenant."
                };
                lstApiError.Add(error);
                apiResponse.Success = false;
                apiResponse.Errors = lstApiError;
                apiResponse.Data = null;
                return apiResponse;
            }
            else
            {
                List<StandardReport> lststdReport = new List<StandardReport>();
                foreach (var report in reports)
                {
                    var idObj = report.GetValueOrDefault("id");
                    if (idObj == null)
                    {
                        apiResponse.Success = false;
                        lstApiError.Add(new ApiError { ErrorMessage = "Report id is null.", WithValue = "", Suggestion = "" });
                        apiResponse.Errors = lstApiError;
                        apiResponse.Data = null;
                        return apiResponse;
                    }

                    Guid id;
                    if (idObj is Guid guid)
                    {
                        id = guid;
                    }
                    else if (idObj is string idStr && Guid.TryParse(idStr, out var parsedGuid))
                    {
                        id = parsedGuid;
                    }
                    else
                    {
                        apiResponse.Success = false;
                        lstApiError.Add(new ApiError { ErrorMessage = "Invalid report id.", WithValue = "", Suggestion = "" });
                        apiResponse.Errors = lstApiError;
                        apiResponse.Data = null;
                        return apiResponse;
                    }
                    StandardReport stdReport = new StandardReport();
                    try
                    {
                        var metaData = await _reportService.GetReportById(id, tenantId, userId, false);
                        if (metaData != null)
                        {
                            stdReport.ReportId = metaData.Id;
                            stdReport.ReportName = metaData.ReportName;
                            stdReport.ReportDescription = metaData.Description!;
                            stdReport.DefaultFields = new List<ReportField>();                            
                            stdReport.Metrics = new List<ReportField>();
                            if (metaData.StandardReportMetadata != null && metaData.StandardReportMetadata.FieldGroups != null)
                            {
                                var fieldGroups = metaData.StandardReportMetadata.FieldGroups as IEnumerable<object> ?? Enumerable.Empty<object>();

                                foreach (FieldGroup group in fieldGroups)
                                {
                                    var uxLabel = group.UxLabel;
                                    if (string.Equals(uxLabel, "KPI and metrics", StringComparison.Ordinal))
                                    {
                                        foreach (ReportField fld in group.Fields)
                                        {
                                            stdReport.Metrics.Add(fld);
                                        }
                                    }
                                }
                            }

                            if (metaData.RequestedFields != null)
                            {
                                List<ReportField> lstfield = metaData.RequestedFields.ToList();
                                foreach (ReportField fld in lstfield)
                                {                                    
                                    if (!stdReport.Metrics.Contains(fld) && fld.IsDefault == true)
                                    {
                                        stdReport.DefaultFields.Add(fld);
                                    }
                                }
                            }
                            lststdReport.Add(stdReport);
                        }
                        else
                        {
                            lstApiError.Add(new ApiError { ErrorMessage = "Report metadata not found for reportId " + id, WithValue = "", Suggestion = "" });
                        }
                    }
                    catch (BadRequestException ex)
                    {
                        lstApiError.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = " Please raise a request to get access to view reportId" + id });
                    }
                }
                if (lststdReport.Count > 0)
                {
                    apiResponse.Success = true;
                    apiResponse.Data = lststdReport;
                    apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
                }
                else 
                {
                    apiResponse.Success = false;
                    apiResponse.Data = null;
                    apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
                }
                return apiResponse;
            }
        }

        public async Task<ApiResponse<List<ReportDetail>>> FetchMetadataByReportNameAsync(Guid tenantId,  List<string> reportNames, string userId, bool listCustomProperties)
        {
            List<ApiError> lstApiError = new();
            ApiResponse<List<ReportDetail>> apiResponse = new() { Success = false, Data = new List<ReportDetail>(), Errors = lstApiError };
            if (reportNames == null)
            {
                ApiError error = new ApiError
                {
                    ErrorMessage = "Report names are not provided.",
                    Suggestion = "Please provide reportIds to get detail."
                };
                lstApiError.Add(error);
                apiResponse.Success = false;
                apiResponse.Errors = lstApiError;
                apiResponse.Data = null;
                return apiResponse;
            }

            List<ReportDetail> lstdtlReport = new List<ReportDetail>();
            var metadataList = new List<Dictionary<string, object>>();

            var rids = await _systemReportsService.GetUserAccessibleSystemReportIds(reportNames, false);
            foreach (var rid in rids)
            {
                Guid id = Guid.Empty;
                try
                {
                    ReportDetail dtlReport = new ReportDetail();
                    // GetDraftReportByName(string reportName, Guid tenantId)
                   
                  //  var rid = await _dataAccessor.GetDraftReportIdByName(reportName, tenantId);
                   ////reportName,tenantId,userId)


                    if (rid == Guid.Empty)                        
                    {
                        lstApiError.Add(new ApiError
                        {
                            ErrorMessage = $"Report entity not found for reportId {rid}.",
                            WithValue = "",
                            Suggestion = ""
                        }); 
                        continue;
                    }

                    //var reportId = rid;
                    //id = reportId;

                    var metaData = await _reportService.GetReportById(rid, tenantId, userId, false);
                    if (metaData != null)
                    {
                        dtlReport.ReportId = metaData.Id;
                        dtlReport.ReportName = metaData.ReportName;
                        dtlReport.ReportDescription = metaData.Description!;
                        dtlReport.Fields = new List<ReportField>();
                        dtlReport.Metrics = new List<ReportField>();
                        dtlReport.Filters = new List<AgentReportFilter>();

                        if (metaData.StandardReportMetadata != null && metaData.StandardReportMetadata.FieldGroups != null)
                        {
                            var fieldGroups = metaData.StandardReportMetadata.FieldGroups as IEnumerable<object> ?? Enumerable.Empty<object>();

                            foreach (FieldGroup group in fieldGroups)
                            {
                                var uxLabel = group.UxLabel;
                                if (string.Equals(uxLabel, "KPI and metrics", StringComparison.Ordinal))
                                {
                                    foreach (ReportField fld in group.Fields)
                                    {
                                        dtlReport.Metrics.Add(fld);
                                    }
                                }
                            }
                        }
                        if (listCustomProperties)
                        {
                            dtlReport.CustomPropertyFields = new List<ReportField>();
                            List<ReportField> lstfield = metaData.RequestedFields.ToList();
                            foreach (ReportField fld in lstfield)
                            {
                                if (fld.Name.Contains("custom") && !fld.IsDefault)
                                {
                                    dtlReport.CustomPropertyFields.Add(fld);
                                }
                            }
                        }

                        if (metaData.RequestedFields != null)
                        {
                            List<ReportField> lstfield = metaData.RequestedFields.ToList();
                            foreach (ReportField fld in lstfield)
                            {
                                if (!dtlReport.Metrics.Contains(fld) && fld.IsDefault == true)
                                {
                                    dtlReport.Fields.Add(fld);
                                }
                            }
                        }
                        if (metaData.AppliedFilters != null)
                        {
                            List<ReportExecutionFilter> lstREFilters = metaData.AppliedFilters.ToList();
                            List<string> allowedOps = new List<string>();
                            foreach (ReportExecutionFilter rExefilter in lstREFilters)
                            {
                                AgentReportFilter arf = new AgentReportFilter();
                                arf.Name = rExefilter.FilterName;
                                arf.Description = rExefilter.FilterName;
                                arf.AllowedOperators = rExefilter.Values.ToList();
                                arf.DataType = rExefilter.PropertyType.ToString();

                                dtlReport.Filters.Add(arf);
                            }
                        }
                        lstdtlReport.Add(dtlReport);
                    }
                    else
                    {
                        lstApiError.Add(new ApiError { ErrorMessage = "Report metadata not found for reportId " + id, WithValue = "", Suggestion = "" });
                    }
                }
                catch (BadRequestException ex)
                {
                    lstApiError.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = " Please raise a request to get access to view reportId" + id });
                }
                catch (Exception ex)
                {
                    lstApiError.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = " Please raise a request to get access to view reportId" + id });
                }
            }
            if (lstdtlReport.Count > 0)
            {
                apiResponse.Success = true;
                apiResponse.Data = lstdtlReport;
                apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
            }
            else
            {
                apiResponse.Success = false;
                apiResponse.Data = lstdtlReport;
                apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
            }
            return apiResponse;

        }

        public async Task<ExecuteApiResponse<List<RowData>>> ExecuteReportAsync(Guid tenantId, Guid reportId, string reportName, string userId, List<string>? fields, List<AdditionalFilter>? afilters, string? orderField, string? orderBy, string? teamsiteIds, int skip, int take, bool isSavedReport)
        {
            List<ApiError> lstApiError = new();

            ExecuteApiResponse<List<RowData>> apiResponse = new() { Success = false, Errors = lstApiError, Fields = new List<ColumnField>(), Data = new List<RowData>(), Pagination = new Pagination() { Skip = skip, Take = take, TotalRecords = 0 } };
            try
            {
                List<string> filters = new List<string>();
                foreach (var addFilter in afilters ?? new List<AdditionalFilter>())
                {

                    filters.Add(addFilter.FilterName);
                }
                var report = await _reportService.GetReportById(reportId, tenantId, userId, false);
                var generated = await _reportRunner.RunReport(reportId, tenantId, skip, take, userId, filters[0], fields[0], orderField, orderBy, teamsiteIds, report.ShowTeamsitePicker);
                Report rpt = generated.Report;

                // var rawParams = generated["raw"] as Dictionary<string, object> ?? new();
                var rawParams = generated.Report != null
                ? new Dictionary<string, object>
                {
                    { "Id", generated.Report.Id },
                    { "ReportName", generated.Report.ReportName },
                    { "SystemReportId", generated.Report.SystemReportId },
                    { "SystemReportName", generated.Report.SystemReportName },
                    { "Description", generated.Report.Description },
                    { "Domain", generated.Report.Domain },
                    { "OwnerUserName", generated.Report.OwnerUserName },
                    { "OwnerThumbnailUrl", generated.Report.OwnerThumbnailUrl },
                    { "OwnerUserId", generated.Report.OwnerUserId },
                    { "LastViewed", generated.Report.LastViewed },
                    { "LastUpdated", generated.Report.LastUpdated },
                    { "ReportType", generated.Report.ReportType },
                    { "OrderField", generated.Report.OrderField },
                    { "OrderBy", generated.Report.OrderBy },
                    { "RequestedFields", generated.Report.RequestedFields },
                    { "AppliedFilters", generated.Report.AppliedFilters },
                    { "StandardReportMetadata", generated.Report.StandardReportMetadata },
                    { "Teamsites", generated.Report.Teamsites },
                    { "ShowTeamsitePicker", generated.Report.ShowTeamsitePicker }
                }
                : new Dictionary<string, object>();
                List<ColumnField> columns = new List<ColumnField>();

                //return await Task.Run(() =>
                //{
                //    try
                //    {

                //        //new
                //        var result = new Dictionary<string, object>
                //        {
                //            ["data"] = generated.Data,
                //            ["totalRecords"] = generated.Pagination?.TotalRecords ?? 0,
                //            ["reportMetadata"] = rawParams
                //        };
                //        return result;
                //    }
                //    catch (Exception e)
                //    {
                //        lstApiError.Add(new ApiError { ErrorMessage = "Report metadata not found for", WithValue = "", Suggestion = "" });
                //        Console.Error.WriteLine($"Error processing report {reportId}: {e}");
                //        return new Dictionary<string, object>
                //        {
                //            ["error"] = true,
                //            ["message"] = "Error processing report data. Please try again later.",
                //            ["exception"] = e.Message
                //        };
                //    }
                    

                //});

               
            }
            catch (Exception e)
            {
                lstApiError.Add(new ApiError { ErrorMessage = "Report metadata not found for reportId " + reportId, WithValue = "", Suggestion = "" });
                Console.Error.WriteLine($"Error executing report {reportId}: {e}");

            }
          
            apiResponse.Success = true;
           
            apiResponse.Errors = lstApiError;
            return apiResponse;
        }

        public async Task<ApiResponse<List<FilterDetail>>> GetFilterDomainValuesAsync(Guid tenantId, string userId, Guid reportId,string reportName, string filterName, string? searchTerm = null)
        {

            _logger.Information($"Fetching filter domain values (multi), report_id={reportId}, filter_names=[{string.Join(", ", filterName)}]");
            List<ApiError> lstApiError = new();
            ApiResponse<List<FilterDetail>> apiResponse = new() { Success = false, Data = new List<FilterDetail>(), Errors = lstApiError };
            List <FilterDetail>  dtlFilter= new List<FilterDetail>();
            try
            {
                // Fetch report metadata
                var report = await _reportService.GetReportById(reportId, tenantId, userId, false);

                if (report == null)
                {
                    lstApiError.Add(new ApiError { ErrorMessage = "Report metadata not found for reportId " + reportId, WithValue = "", Suggestion = "" });
                   
                }

                if (filterName == null )
                {
                    ApiError error = new ApiError
                    {
                        ErrorMessage = "Filter names are not provided.",
                        Suggestion = "Please provide filter names to get detail."
                    };
                    lstApiError.Add(error);
                    apiResponse.Success = false;
                    apiResponse.Errors = lstApiError;
                    apiResponse.Data = null;
                    return apiResponse;
                   
                }

                async Task<Dictionary<string, object>> FetchFilterDomainValues(string name)
                {
                    try
                    {
                        // Create a dictionary manually
                        var reportDict = new Dictionary<string, object>
                        {
                            ["Id"] = report.Id,
                            ["ReportName"] = report.ReportName,
                            ["SystemReportId"] = report.SystemReportId,
                            ["SystemReportName"] = report.SystemReportName,
                            ["Description"] = report.Description,
                            ["Domain"] = report.Domain,
                            ["OwnerUserName"] = report.OwnerUserName,
                            ["OwnerThumbnailUrl"] = report.OwnerThumbnailUrl,
                            ["OwnerUserId"] = report.OwnerUserId,
                            ["LastViewed"] = report.LastViewed,
                            ["LastUpdated"] = report.LastUpdated,
                            ["ReportType"] = report.ReportType,
                            ["OrderField"] = report.OrderField,
                            ["OrderBy"] = report.OrderBy,
                            ["RequestedFields"] = report.RequestedFields,
                            ["AppliedFilters"] = report.AppliedFilters,
                            ["StandardReportMetadata"] = report.StandardReportMetadata,
                            ["Teamsites"] = report.Teamsites,
                            ["ShowTeamsitePicker"] = report.ShowTeamsitePicker
                        };

                        var extractResult = await ReportMetadataHelper.ExtractSsrsFilterValuesAsync(
                            reportDict,
                            name,
                            async filterName =>
                            {
                                // Call SSRS filter values API
                                var teamsiteIdsString = "teamsites" != null ? string.Join(",", "teamsiteIds") : null; // corrected line
                                var domain = await _picklistQueryService.GetFilterValues(filterName, reportId, searchTerm, teamsiteIdsString, tenantId);
                                // Prefer "data" if present; otherwise flatten values to a list // uncommented line
                                if (domain is IDictionary<string, object> dict && dict.TryGetValue("data", out object? dataObj) && dataObj is IEnumerable<object> list)
                                    return list.ToList().AsReadOnly();
                                return new List<object>(domain is IDictionary<string, object> d ? d.Values : domain.Cast<object>()).AsReadOnly();
                            });

                        bool success = extractResult.Success;
                        object valuesOrMessage = extractResult.ValuesOrMessage;

                        if (success)
                        {
                            return new Dictionary<string, object>
                            {
                                ["filter_name"] = name,
                                ["values"] = valuesOrMessage
                            };
                        }

                        return new Dictionary<string, object>
                        {
                            ["filter_name"] = name,
                            ["error"] = valuesOrMessage?.ToString() ?? "Unknown error"
                        };
                    }
                    catch (Exception e)
                    {
                        lstApiError.Add(new ApiError { ErrorMessage = e.Message, WithValue = e.StackTrace, Suggestion = " " });
                        return new Dictionary<string, object>
                        {
                            ["filter_name"] = name,
                            ["error"] = $"Unexpected error: {e.Message}"
                        };
                    }
                   // return
                }

                // Launch all tasks in parallel
                //var tasks = filterName.Select(FetchFilterDomainValues);
                //var results = await Task.WhenAll(tasks);
                //return results.ToList();
                
            }
            catch (BadRequestException ex)
            {
                lstApiError.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = " " });
            }

            if (dtlFilter.Count > 0)
            {
                apiResponse.Success = true;
                apiResponse.Data = dtlFilter;
                apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
            }
            else
            {
                apiResponse.Success = false;
                apiResponse.Data = dtlFilter;
                apiResponse.Errors = lstApiError.Count == 0 ? null : lstApiError;
            }
            return apiResponse;
        }

        public Task<List<FilterDetail>> GetFilterDomainValuesAsync(Guid tenantId, string userId, Guid reportId, string reportName, List<string> filterNames, string? searchTerm = null)
        {
            throw new NotImplementedException();
        }
    }

}
