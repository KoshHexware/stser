﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class SSRConfigurationService(IPermissionService _permissionsService, IUserService _userService,
        IOrgHierarchyService _orgHierarchyService, IReportService _reportService, ILogger logger) : ISSRConfigurationService
    {
        private readonly ILogger _logger = logger.ForContext<SSRConfigurationService>();

        public async Task<SSRUserConfiguration> GetSSRConfigurationAsync(Guid tenantId, string userId)
        {
            var access = await _permissionsService.GetContextUserAccess();
            if (access == AccessLevel.None)
            {
                return new SSRUserConfiguration
                {
                    AccessLevel = access,
                };
            }

            var userSettings = await _userService.GetUserSettingsAsync(tenantId, userId);
            var reportType = userSettings?.ReportsFilterOption?.ToLower() ?? ReportsFilterOption.All.ToString().ToLower();
            var orderField = !string.IsNullOrWhiteSpace(userSettings.OrderField) ? userSettings.OrderField : GetOrderField(reportType);
            var orderBy = !string.IsNullOrWhiteSpace(userSettings.OrderBy) ? userSettings.OrderBy : "desc";
            var tenantSettings = await _orgHierarchyService.GetTenantOrgHierarchySettings(tenantId);
            userSettings.TenantSettings = tenantSettings;
            userSettings.OrderField = orderField;
            userSettings.OrderBy = orderBy;
            try
            {
                var (allReports, hasSystemReportAccess) = await GetReportsInfoAsync(tenantId, userId, reportType, orderField, orderBy);
                return new SSRUserConfiguration
                {
                    AccessLevel = access,
                    UserSettings = userSettings,
                    ReportsList = allReports,
                    HasSystemReportAccess = hasSystemReportAccess
                };
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to fetch reports for user {UserId} in tenant {TenantId}", userId, tenantId);
                throw;
            }
        }

        private async Task<(PagedList<ReportSummary>? allReports, bool hasSystemReportAccess)> GetReportsInfoAsync(Guid tenantId, string userId, string reportType, string orderField, string orderBy)
        {
            var allReports = await _reportService.GetAllReports(tenantId, userId, reportType, null, 1000, 0, orderField, orderBy);
            var hasSystemReportAccess = false;
            try
            {
                var systemReports = await _reportService.GetAllReports(tenantId, userId, "system", null, 1, 0);
                hasSystemReportAccess = systemReports?.Data.Count > 0;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Failed to fetch system reports as user {UserId} in tenant {TenantId} does not have access to view system reports", userId, tenantId);
            }

            return (allReports, hasSystemReportAccess);
        }

        private static string GetOrderField(string reportType)
        {
            return reportType switch
            {
                "shared" => "sharedOn",
                "all" or "owned" => "lastUpdated",
                "system" => "lastViewed",
                _ => "lastViewed",
            };
        }
    }
}
