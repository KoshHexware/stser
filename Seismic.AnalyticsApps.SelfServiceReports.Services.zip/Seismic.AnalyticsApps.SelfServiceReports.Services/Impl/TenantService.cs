﻿using Microsoft.EntityFrameworkCore;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Matrix.Client;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class TenantService(ISsrsContext _dbContext, IMatrixClient _matrixClient, ILogger logger, ISeismicContextProvider _contextProvider) : ITenantService
    {
        private readonly ILogger _logger = logger.ForContext<TenantService>();

        public async Task<int> AddTenant(Guid tenantId)
        {
            var existing = await _dbContext.Set<TenantCacheInfo>().Where(t => t.TenantId == tenantId).SingleOrDefaultAsync();
            var existingOrgInfo = await _dbContext.Set<TenantOrgCacheInfo>().Where(t => t.TenantId == tenantId).SingleOrDefaultAsync();
            
            if (existing != null && existingOrgInfo != null)
            {
                return 0;
            }

            if (existing == null )
            {
                _dbContext.Set<TenantCacheInfo>().Add(new TenantCacheInfo
                {
                    TenantId = tenantId,
                    CacheRefreshedAt = DateTime.MinValue,
                    CreatedOnUtc = DateTime.UtcNow,
                });
            }
            if (existingOrgInfo == null)
            {
                _dbContext.Set<TenantOrgCacheInfo>().Add(new TenantOrgCacheInfo
                {
                    TenantId = tenantId,
                    CacheRefreshedAt = DateTime.MinValue,
                    CreatedOnUtc = DateTime.UtcNow,
                });
            }
            
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> AddTenants(HashSet<Guid> tenantIds)
        {
            var existing = await _dbContext.Set<TenantCacheInfo>().Where(t => tenantIds.Contains(t.TenantId)).ToListAsync();
            var toAdd = tenantIds.Except(existing.Select(t => t.TenantId)).Select(t => new TenantCacheInfo
            {
                TenantId = t,
                CacheRefreshedAt = DateTime.MinValue,
                CreatedOnUtc = DateTime.UtcNow,
            });

            await _dbContext.Set<TenantCacheInfo>().AddRangeAsync(toAdd);
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> RemoveTenant(Guid tenantId)
        {
            var existing = await _dbContext.Set<TenantCacheInfo>().Where(t => t.TenantId == tenantId).SingleOrDefaultAsync();
            if (existing != null)
            {
                _dbContext.Set<TenantCacheInfo>().Remove(existing);
                return await _dbContext.SaveChangesAsync();
            }

            _logger.Information("Tenant does not exist in db: {tenantId}", tenantId);
            return 0;
        }

        public async Task<TenantCacheInfo?> GetTenantForCacheRefresh()
        {
            var tenantInfo = await _dbContext.Set<TenantCacheInfo>()
                .Where(p => p.CacheRefreshedAt < DateTime.UtcNow.AddSeconds(-CacheConstants.BACKGROUND_CACHE_REFRESH_INTERVAL_SECONDS))
                .OrderBy(p => p.CacheRefreshedAt).FirstOrDefaultAsync();

            if (tenantInfo == null)
                return null;

            try
            {
                var matrixTenant = await _matrixClient.GetTenantAsync(tenantInfo.TenantId);
                if (matrixTenant != null && matrixTenant.IsActive)
                    return tenantInfo;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error checking tenant existence for tenant {tenantId}. Deleting it.", tenantInfo.TenantId);
            }

            await RemoveTenant(tenantInfo.TenantId);

            return null;
        }

        public async Task<TenantCacheInfo?> UpdateTenant(TenantCacheInfo tenant)
        {
            _dbContext.Set<TenantCacheInfo>().Update(tenant);
            await _dbContext.SaveChangesAsync();
            return tenant;
        }

        public async Task<TenantOrgCacheInfo?> UpdateTenantOrgCacheInfo(TenantOrgCacheInfo tenant)
        {
            _dbContext.Set<TenantOrgCacheInfo>().Update(tenant);
            await _dbContext.SaveChangesAsync();
            return tenant;
        }

        public async Task<bool> CheckHasAccess()
        {
            var context = _contextProvider.GetContext();

            if (context == null)
            {
                _logger.Warning("Context not found");
                return false;
            }

            var featureEnabled = await CheckFMSAndLDFLagsEnabled();
            if (!featureEnabled)
            {
                return false;
            }
            return true;
        }

        public async Task<bool> CheckFMSAndLDFLagsEnabled()
        {
            var context = _contextProvider.GetContext();

            if (context == null)
            {
                _logger.Warning("Context not found");
                return false;
            }

            var fmsFeature = await _matrixClient.GetFeatureSettingByTenantAsync(context.TenantIdentifier.TenantUniqueId, FMSConstants.SelfServiceReportsKey);
            var fmsFeatureEnabled = fmsFeature?.Toggle == null ? false : fmsFeature.Toggle.Value;
            if (!fmsFeatureEnabled)
            {
                _logger.Warning("FMS Toggle {key} not enabled for tenant:{tenantId}", FMSConstants.SelfServiceReportsKey, context.TenantIdentifier.TenantUniqueId);
                return false;
            }
            
            return true;
        }
    
        public async Task<bool> IsLDFlagEnabled(string flagKey)
        {
            var context = _contextProvider.GetContext();
            if (context == null)
            {
                _logger.Warning("Context not found. Unable to check LD flag : {flagKey}.", flagKey);
                return false;
            }
            var ldFeatureEnabled = await context.IsToggleEnabled(flagKey, false);
            if (!ldFeatureEnabled)
            {
                _logger.Warning("LD Toggle {key} not enabled for tenant:{tenantId}", flagKey, context.TenantIdentifier.TenantUniqueId);
                return false;
            }
            return true;
        }

        public async Task<bool> CheckSsrWinterFy26ReleaseLDFlagEnabled()
        {
            var context = _contextProvider.GetContext();
            if (context == null)
            {
                _logger.Warning("Context not found. Unable to check LD flag : {flagKey}.", LDConstants.SsrWinterFy26Release);
                return false;
            }
            var ldFeatureEnabled = await context.IsToggleEnabled(LDConstants.SsrWinterFy26Release, false);
            if (!ldFeatureEnabled)
            {
                _logger.Warning("LD Toggle {key} not enabled for tenant:{tenantId}", LDConstants.SsrWinterFy26Release, context.TenantIdentifier.TenantUniqueId);
                return false;
            }
            return true;
        }

    }
}
