﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Serilog;
using System.Diagnostics;


namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class DiscClient : IDiscClient
    {
        protected readonly ILogger _logger;
        protected readonly ISnowflakeClient _snowflakeClient;
        protected readonly ISeismicContextProvider _contextProvider;

        protected Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        public DiscClient(ISnowflakeClient snowflakeClient, ILogger logger, ISeismicContextProvider contextProvider)
        {
            _logger = logger.ForContext(this.GetType());
            _snowflakeClient = snowflakeClient;
            _contextProvider = contextProvider;
        }

        public virtual async Task<IList<T>> ExecuteQuery<T>(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
             Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null) where T : class
        {
            _logger.Information("Query started: query:{query}, TenantId: {tenantId}.", queryName, TenantId);

            var sw = Stopwatch.StartNew();

            try
            {
                var result = await _snowflakeClient.QueryAsync<T>
                        (
                            conn =>
                            SnowflakeUtils.BuildQuery(conn, query, stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams)
                        );

                sw.Stop();
                return result;
            }
            catch(Exception ex)
            {
                _logger.Error(ex, "Error executing query: query:{query}, TenantId: {tenantId}.", queryName, TenantId);
                throw;
            }
            finally
            {
                _logger.Information("Query complete: query:{query}, TenantId: {tenantId}, elapsed: {elapsed}ms.", queryName, TenantId, sw.ElapsedMilliseconds);
            }
        }

        public virtual async Task<QueryResult> ExecuteGenericQuery(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
             Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null)
        {
            _logger.Information("Query started: query:{query}, TenantId: {tenantId}.", queryName, TenantId);

            var sw = Stopwatch.StartNew();

            try
            {
                var result = await _snowflakeClient.ExecuteSnowflakeQuery
                        (
                            conn =>
                            SnowflakeUtils.BuildQuery(conn, query, stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams)
                        );

                sw.Stop();
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error executing query: query:{query}, TenantId: {tenantId}.", queryName, TenantId);
                throw;
            }
            finally
            {
                _logger.Information("Query complete: query:{query}, TenantId: {tenantId}, elapsed: {elapsed}ms.", queryName, TenantId, sw.ElapsedMilliseconds);
            }
        }


        public virtual async Task<string> ExecuteQueryToCsv(string query, string queryName,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
            Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null)
        {
            _logger.Information("Query started: query:{query}, TenantId: {tenantId}.", queryName, TenantId);

            var sw = Stopwatch.StartNew();

            try
            {
                var result = await _snowflakeClient.ExportToCsvAsync
                        (
                            conn =>
                            SnowflakeUtils.BuildQuery(conn, query, stringParams, dateParams, boolParams, intParams, decimalParams, multiStringParams)
                        );

                sw.Stop();
                return result;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error executing query: query:{query}, TenantId: {tenantId}.", queryName, TenantId);
                throw;
            }
            finally
            {
                _logger.Information("Query complete: query:{query}, TenantId: {tenantId}, elapsed: {elapsed}ms.", queryName, TenantId, sw.ElapsedMilliseconds);
            }
        }
    }
}