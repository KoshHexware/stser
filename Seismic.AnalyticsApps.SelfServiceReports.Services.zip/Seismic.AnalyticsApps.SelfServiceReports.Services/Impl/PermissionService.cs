﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Entitlement.Client.Model;
using Seismic.Platform.Matrix.Client;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class PermissionService(IUserService _userService, ISeismicContextProvider _contextProvider,
        ISeismicRedisCache _cache, IEntitlementServiceClientWrapper _entitlementService,
        ITenantService _tenantService, IMatrixClient _matrixClient, ILogger logger) : IPermissionService
    {
        private readonly ILogger _logger = logger.ForContext<PermissionService>();

        private Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        public async Task<bool> CheckContextUserAccess(bool forceRefresh = false)
        {
            var access = await GetContextUserAccess(forceRefresh);
            return access != AccessLevel.None;
        }

        public async Task<bool> HasAdminAccess(bool forceRefresh = false)
        {
            var context = _contextProvider.GetContext();
            if (context == null)
            {
                _logger.Warning("Context not found");
                return false;
            }

            var cacheKey = new UserAdminAccessCacheKey(context.UserId, TenantId);
            if (!forceRefresh)
            {
                var cachedResult = await _cache.GetAsync<string>(cacheKey);
                if (!string.IsNullOrWhiteSpace(cachedResult) && bool.TryParse(cachedResult, out bool result))
                {
                    return result;
                }
            }

            var userId = context.UserId;
            
            var userTask = _userService.GetUserById(TenantId, userId);
            var tenantInfoTask = _matrixClient.GetTenantAsync(TenantId);
            var granularPermissionsTask = context.IsToggleEnabled(LDConstants.SeismicEnableGranularPermissionsLDKey, false);
            var insightsAdoptTask = context.IsToggleEnabled(LDConstants.InsightsAdoptEntitlementLDKey, false);
            var insightsAdoptLearningTask = context.IsToggleEnabled(LDConstants.InsightsAdoptEntitlementLearningLDKey, false);
            var useEntitlementsTask = context.IsToggleEnabled(LDConstants.SsrUseEntitlementsLDKey, false);


            await Task.WhenAll(userTask, tenantInfoTask, granularPermissionsTask, insightsAdoptTask, insightsAdoptLearningTask, useEntitlementsTask);

            var user =  userTask.Result;
            if (user.IsFullControl)
            {
                await _cache.SetAsync<string>(cacheKey, true.ToString());
                return true;
            }

            if (useEntitlementsTask.Result)
            {
                var hasManageReportPermission = await _entitlementService.CheckUserPermissionAsync(userId, PermissionConstants.SelfServiceReportsManageReportsPermissionKey, TenantId);
                var access = hasManageReportPermission.Resource?.Allowed ?? false;
                await _cache.SetAsync<string>(cacheKey, access.ToString());
                return hasManageReportPermission.Resource?.Allowed == true;
            }

            var tenantInfo = tenantInfoTask.Result;
            var isLessonlyOnlyUser = tenantInfo.Systems.Count() == 1 && tenantInfo.Systems.Any(x => x.Type == SystemType.Lessonly);
            var isGranularPermissionsEnabled =  granularPermissionsTask.Result;
            var isInsightsAdoptEnabled =  insightsAdoptTask.Result;
            var isInsightsAdoptLearningEnabled = insightsAdoptLearningTask.Result;

           
            if (!isGranularPermissionsEnabled && !isInsightsAdoptEnabled && !isInsightsAdoptLearningEnabled)
            {
                await _cache.SetAsync<string>(cacheKey, false.ToString());
                return false;
            }
            
            var permissionTasks = new List<Task<ResourceResponse<CheckPermissionResultResource>>>();
            
            if (isGranularPermissionsEnabled && !isLessonlyOnlyUser)
            {
                permissionTasks.Add(_entitlementService.CheckUserPermissionAsync(userId, 
                    PermissionConstants.SeismicSecuritySettingManagePermissionKey, TenantId));
            }
            
            if (isInsightsAdoptEnabled || isInsightsAdoptLearningEnabled)
            {
                permissionTasks.Add(_entitlementService.CheckUserPermissionAsync(userId, 
                    PermissionConstants.LiveInsightsManagePermissionKey, TenantId));
                permissionTasks.Add(_entitlementService.CheckUserPermissionAsync(userId, 
                    PermissionConstants.SnowflakeManagePermissionKey, TenantId));
            }
            
            if (permissionTasks.Count == 0)
            {
                await _cache.SetAsync<string>(cacheKey, false.ToString());
                return false;
            }
            
            await Task.WhenAll(permissionTasks);
            
            bool isAdmin = permissionTasks.Any(task => task.Result.Resource?.Allowed == true);
            await _cache.SetAsync<string>(cacheKey, isAdmin.ToString());
            return isAdmin;
        }

        public async Task<AccessLevel> GetContextUserAccess(bool forceRefresh = false)
        {
            var context = _contextProvider.GetContext();

            if (context == null)
            {
                _logger.Warning("Context not found");
                return AccessLevel.None;
            }

            var featureEnabled = await _tenantService.CheckFMSAndLDFLagsEnabled();

            if (!featureEnabled)
            {
                return AccessLevel.None;
            }

            var cacheKey = new UserAccessCacheKey(context.UserId, TenantId);
            if (!forceRefresh)
            {
                var cached = await _cache.GetAsync(cacheKey);
                if (!string.IsNullOrWhiteSpace(cached) && Enum.TryParse(cached, true, out AccessLevel access))
                {
                    return access;
                }
                else
                    _logger.Information("GetContextUserAccess. Cache miss for key: {key}", cacheKey.Key);
            }

            _logger.Information("GetUserAccess - Refreshing cache. userId:{userId}, tenantId:{tenantId}", context.UserId, TenantId);

             var useEntitlements = await _contextProvider.GetContext().IsToggleEnabled(LDConstants.SsrUseEntitlementsLDKey);

            if (useEntitlements) 
            {
                var entitleResult = await CheckUserPermissionAsync(context);
                //await _cache.SetAsync<string>(cacheKey, entitleResult.ToString());
                return entitleResult;
            }
            else
            {
                var result = await GetUserAccess(context);
                await _cache.SetAsync<string>(cacheKey, result.ToString());
                return result;
            }
        }

        private async Task<AccessLevel> GetUserAccess(ISeismicContext? context)
        {
            if (context == null)
            {
                _logger.Warning("Context not found");
                return AccessLevel.None;
            }

            var user = await _userService.GetUserById(context.TenantIdentifier.TenantUniqueId, context.UserId);

            if (user == null)
            {
                logger.Error("User :{userId} not found in tenant:{TenantId}", context.UserId, TenantId);
                throw new Exception($"User :{context.UserId} not found in tenant:{TenantId}");
            }

            var ssrViewerUgTask = _userService.GetUserGroupByName(TenantId, UserGroupConstants.SelfServiceReportsViewer);
            var ssrEditorUgTask = _userService.GetUserGroupByName(TenantId, UserGroupConstants.SelfServiceReportsEditor);
            var ssrCreatorsUgTask = _userService.GetUserGroupByName(TenantId, UserGroupConstants.SelfServiceReportsCreator);
           
            await Task.WhenAll(ssrViewerUgTask, ssrEditorUgTask, ssrCreatorsUgTask);

            var ssrViewerUg = ssrViewerUgTask.Result;
            var ssrEditorUg = ssrEditorUgTask.Result;
            var ssrCreatorsUg = ssrCreatorsUgTask.Result;
         
            if (ssrViewerUg == null && ssrEditorUg == null && ssrCreatorsUg == null)
            {
                _logger.Warning("viewer, editor and create new report user groups not found. userId:{userId}, tenantId:{tenantId}", context.UserId, TenantId);
                return AccessLevel.None;
            }

            if (ssrEditorUg != null && !ssrEditorUg.IsDeactivated && user.DirectGroupLegacyIds.Contains(ssrEditorUg.LegacyId))
            {
                return AccessLevel.Editor;
            }
            else if (ssrCreatorsUg != null && !ssrCreatorsUg.IsDeactivated && user.DirectGroupLegacyIds.Contains(ssrCreatorsUg.LegacyId))
            {
                return AccessLevel.CustomReportEditor;
            }
            else if (ssrViewerUg != null && !ssrViewerUg.IsDeactivated && user.DirectGroupLegacyIds.Contains(ssrViewerUg.LegacyId))
            {
                return AccessLevel.Viewer;
            }
            else
            {
                return AccessLevel.None;
            }
        }

        private async Task<AccessLevel> CheckUserPermissionAsync(ISeismicContext? context)
        {
            if (context == null)
            {
                _logger.Warning("Context not found");
                return AccessLevel.None;
            }
            
            var hasCreatorPermissionTask = _entitlementService.CheckUserPermissionAsync(context.UserId, PermissionConstants.SelfServiceReportsCreatorPermissionKey, context.TenantIdentifier.TenantUniqueId);
            var hasViewerPermissionTask = _entitlementService.CheckUserPermissionAsync(context.UserId, PermissionConstants.SelfServiceReportsViewerPermissionKey, context.TenantIdentifier.TenantUniqueId);

            await Task.WhenAll(hasCreatorPermissionTask, hasViewerPermissionTask);

            var hasCreatorPermission = hasCreatorPermissionTask.Result;
            var hasViewerPermission = hasViewerPermissionTask.Result;

            
            if (hasCreatorPermission.Resource.Allowed)
            {
                return AccessLevel.Editor;
            }
            else if (hasViewerPermission.Resource.Allowed)
            {
                return AccessLevel.Viewer;
            }
            else
            {
                return AccessLevel.None;
            }
        }

        private async Task<AccessLevel> GetUserEntitlementPermissionAccess(ISeismicContext? context)
        {
            if (context == null)
            {
                _logger.Warning("Context not found");
                return AccessLevel.None;
            }
            var userPermissions = await _entitlementService.GetUserPermissionsAsync(context.UserId, context.TenantIdentifier.TenantUniqueId);

            if (userPermissions == null)
            {
                return AccessLevel.None;
            }
            else if (userPermissions.Any(p => p.Key == PermissionConstants.SelfServiceReportsManageReportsPermissionKey))
            {
                return AccessLevel.Editor;
            }
            else if (userPermissions.Any(p => p.Key == PermissionConstants.SelfServiceReportsCreatorPermissionKey))
            {
                return AccessLevel.CustomReportEditor;
            }
            else if (userPermissions.Any(p => p.Key == PermissionConstants.SelfServiceReportsViewerPermissionKey))
            {
                return AccessLevel.Viewer;
            }
            else
            {
                return AccessLevel.None;
            }
        }
         
    }
}