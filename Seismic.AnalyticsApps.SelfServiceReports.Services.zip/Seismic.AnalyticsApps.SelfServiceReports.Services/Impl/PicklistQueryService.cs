﻿using Fluid;
using Microsoft.AspNetCore.Mvc;
using Seismic.Analytics.DataAccess.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Serilog;
using System.Text.Json;


namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class PicklistQueryService(ISystemFiltersService _systemFiltersService, IDiscClient _discClient, ILogger logger, ISystemReportsService _systemReportsService,
        ISeismicContextProvider _contextProvider, ICMService _cmService, ISeismicRedisCache _cache) 
        : IPicklistQueryService
    {
        private readonly ILogger _logger = logger.ForContext<PicklistQueryService>();

        public async Task<List<string>> GetFilterValues(string filterName, Guid systemReportId, string? searchTerm, [FromQuery] string? teamsiteIds, Guid tenantId)
        {
            ReportDefinitionMetadata reportDefinitionMetadata = null;
            List<FieldGroup> fieldGroups = [];

            reportDefinitionMetadata = await _systemReportsService.GetReportDefinition(systemReportId);
            if (reportDefinitionMetadata == null)
            {
                throw new NotFoundException($"System report not found. report id:{systemReportId}");
            }
            else 
            { 
                fieldGroups = reportDefinitionMetadata.FieldGroups ?? []; 
            }

            var filter = await _systemFiltersService.GetFilterByNameAsync(filterName, fieldGroups);
            
            if (filter == null || string.IsNullOrWhiteSpace(filter.FilterPicklistQuery))
            {
                throw new BadRequestException($"Filter with name '{filterName}' not found.");
            }

            var cacheKey = new PicklistQueryCacheKey(tenantId, systemReportId, filterName, teamsiteIds, searchTerm);
            var cached = await _cache.GetAsync(cacheKey);

            if (cached != null)
            {
                _logger.Information("Filter values retrieved from cache for key: {CacheKey}", cacheKey.Key);
                return cached;
            }

            var templateParams = new Dictionary<string, object>();
            var stringParams = new Dictionary<string, string>();

            var multiStringParams = new Dictionary<string, string[]>();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                templateParams["filter_has_searchTerm"] = true;
                stringParams["filter_searchTerm"] = $"%{searchTerm}%";
            }

            var picklistQuery = filter.FilterPicklistQuery;
            if (reportDefinitionMetadata != null && reportDefinitionMetadata.ShowTeamsitePicker && filter.FilterValuesByTeamsite.HasValue && filter.FilterValuesByTeamsite.Value)
            {
                var selectedTeamsitesArray = DeserializeSelectedTeamsites(teamsiteIds);
                await EnsureTeamsitesAccessible(selectedTeamsitesArray);
                multiStringParams["filter_teamsiteId_filterValue"] = selectedTeamsitesArray;
                templateParams["filter_teamsiteId_filterValue"] = $"({{{multiStringParams.Count - 1}}})"; 
                picklistQuery = picklistQuery + "WHERE teamsiteId IN {{ filter_teamsiteId_filterValue }}";
            }


            var filterPicklistQuery = ParsePicklistQuery(picklistQuery, templateParams);
            if (multiStringParams != null && multiStringParams.Count > 0)
            {
                filterPicklistQuery = filterPicklistQuery.ExpandMultiValueParameters(multiStringParams.Select(x => (x.Key, x.Value)));
            }

            var filterValues = new List<string>();
            if (string.IsNullOrWhiteSpace(filterPicklistQuery))
            {
                return filterValues;
            }

            var query = new Query { Sql = filterPicklistQuery, Name = $"filter values query - {filterName}" };
            var result = await _discClient.ExecuteGenericQuery(query.Sql, "", stringParams, null, null, null, null, multiStringParams);

            if (result?.Rows == null)
            {
                return filterValues;
            }


            filterValues = [.. result.Rows
                .Select(row => row[0]?.ToString())
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .OrderBy(x => x)];

            await _cache.SetAsync<List<string>>(cacheKey, filterValues);
            return filterValues;
        }

        private static string ParsePicklistQuery(string picklistQuery, Dictionary<string, object> templateParams)
        {
            var parser = new FluidParser();
            var compiledQuery = parser.Parse(picklistQuery);
            var context = new TemplateContext(templateParams);
            return compiledQuery.Render(context);
        }

        private string[] DeserializeSelectedTeamsites(string? selectedTeamsites)
        {
            if (string.IsNullOrWhiteSpace(selectedTeamsites))
                return [];

            var sanitizedTeamsites = selectedTeamsites.Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
            try
            {
                return string.IsNullOrWhiteSpace(sanitizedTeamsites) ? []
                : JsonSerializer.Deserialize<List<string>>(sanitizedTeamsites, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase)?.ToArray() ?? [];
            }
            catch (JsonException ex)
            {
                _logger.Error(ex, "Error deserializing selected Teamsites:{selectedTeamsites}", sanitizedTeamsites);
                return [];

            }
        }

        private async Task EnsureTeamsitesAccessible(string[]? selectedTeamsites)
        {
            if (selectedTeamsites == null || selectedTeamsites.Length == 0)
            {
                return;
            }
            var context = _contextProvider.GetContext();
            var accessibleTeamsites = await _cmService.GetUserAccessibleTeamsitesAsync(context.TenantIdentifier.TenantUniqueId, context.UserId);
            var inaccessibleTeamsites = selectedTeamsites.Except(accessibleTeamsites.Select(t => t.Id));
            if (inaccessibleTeamsites?.Count() > 0)
            {
                _logger.Error("User:{userId} does not have access to teamsites:{teamsites}", context.UserId, string.Join(",", inaccessibleTeamsites));
                throw new ForbiddenException($"User {context.UserId} does not have access to requested teamsites.");
            }
        }

    }
}
