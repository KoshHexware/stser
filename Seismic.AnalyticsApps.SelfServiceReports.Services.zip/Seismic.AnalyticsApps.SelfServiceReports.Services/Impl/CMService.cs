﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Matrix.Client;
using Serilog;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public  class CMService(HttpClient _httpClient, IMatrixClient _matrixClient, ILogger logger, ISeismicRedisCache _seismicCache, ISeismicContextProvider _seismicContextProvider) : ICMService
    {
        private readonly ILogger _logger = logger.ForContext<CMService>();

        public async Task<List<Teamsites>> GetUserAccessibleTeamsitesAsync(Guid tenantId, string userId, bool refreshCache = false)
        {
            var cmServer = await _matrixClient.GetServiceEndpointByTenantAsync(ServiceAliasConstants.CONTENTMANAGER, tenantId, true);
            var sanitizedUserId = userId.Replace("\n", "").Replace("\r", "");
            var reativeUrl = $"/v1.0/tenants/{tenantId}/users/{sanitizedUserId}/teamSites?user={sanitizedUserId}";
            var uri = new Uri(new Uri(cmServer), reativeUrl);
            var url = uri.AbsoluteUri;

            var cacheKey = new UserAccessibleTeamsitesCacheKey(tenantId, userId);

            if (!refreshCache)
            {
                var cached = await _seismicCache.GetAsync(cacheKey);
                if (cached != null)
                {
                    return cached;
                }
            }
            else
            {
                _logger.Information("Refreshing cache for Cm call. Url:{url}", url);
            }

            var context = _seismicContextProvider.GetContext();
            var tenantToken = await context.GetTenantToken();
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {tenantToken}");

            _logger.Information("Begin Cm call. Url:{url}", url);

            var response = await _httpClient.GetAsync(url);

            if (response == null || response.Content == null || !response.IsSuccessStatusCode )
            {
                _logger.Error("Error in Cm call. Url:{url}, Status code:{statusCode}", url, response?.StatusCode);
                return [];
            }
            response.EnsureSuccessStatusCode();

            var content = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrWhiteSpace(content))
            {
                return [];
            }
            var teamSites = JsonSerializer.Deserialize<List<Teamsites>>(content, JsonSerializerCustomOptions.IgnorePropertyNameAndEnumCase);
            return await _seismicCache.SetAsync(cacheKey, teamSites ?? []);
        }

        public async Task<List<Teamsites>> RefreshUserAccessibleTeamsitesCacheAsync(Guid tenantId, string userId)
        {
            return await GetUserAccessibleTeamsitesAsync(tenantId, userId, true);
        }
    }
}
