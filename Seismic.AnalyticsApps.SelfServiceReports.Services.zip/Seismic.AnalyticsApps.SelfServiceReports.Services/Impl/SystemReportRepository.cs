using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.DataAreas;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template.FeatureProfiles;
using Serilog;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;

/// <summary>
/// this class is a singleton that holds all the standard report definitions and queries
/// </summary>
public class SystemReportRepository : ISystemReportsRepository
{
    private readonly Dictionary<Guid, ReportDefinitionMetadata> _reportMetadata = [];
    private readonly Dictionary<Guid, ReportDefinitionQuery> _queries = [];
    private readonly Dictionary<string, FilterTemplateModel> _filters = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, FeatureProfile> _features = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<Guid, DataArea> _dataAreas = [];
    private readonly Dictionary<Guid, List<DeletedItem>> _archivedFilters = [];
    private readonly Dictionary<string, DateTime> _reportLastUpdatedDates = new(StringComparer.OrdinalIgnoreCase);

    private readonly Dictionary<Guid, ReportFragmentDefinition> _reportFragmentMetadata = [];
    private readonly Dictionary<Guid, ReportFragmentDefinitionQuery> _reportFragmentQueries = [];
    private readonly ILogger _logger;

    public SystemReportRepository(IFileSystemHelper _fileSystemHelper, ILogger logger)
    {
        _logger = logger;
        _reportMetadata.Clear();
        _queries.Clear();
        _filters.Clear();
        _features.Clear();
        _archivedFilters.Clear();
        _reportLastUpdatedDates.Clear();
        _dataAreas.Clear();

        //Load system report modification details
        var reportLastUpdatedFiles = _fileSystemHelper.GetTextFiles();
        //find the file which name matches to git_yaml_reports_last_modified_date.txt
        string? filePath = reportLastUpdatedFiles.FirstOrDefault(f => f.EndsWith("git_yaml_reports_last_modified_date.txt", StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrEmpty(filePath))
        {
            string[] lines = File.ReadAllLines(filePath);

            foreach (var line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                var parts = line.Split(' ', 2);
                if (parts.Length < 2)
                {
                    continue; // Invalid line format
                }

                // Parse the date
                if (!long.TryParse(parts[0], out long unixTimeSeconds))
                {
                    continue; // Skip if date can't be parsed
                }
                DateTime modificationDate = DateTimeOffset.FromUnixTimeSeconds(unixTimeSeconds).UtcDateTime;

                // Extract just the filename from the path
                string fileName = Path.GetFileName(parts[1]);
                if (string.IsNullOrEmpty(fileName))
                {
                    continue; // Skip if filename is empty
                }

                _reportLastUpdatedDates.Add(fileName, modificationDate);
            }
        }

        // Load all the report definitions
        var templates = _fileSystemHelper.GetReportTemplateFiles();

        foreach (var file in templates)
        {
            var yamlTxt = _fileSystemHelper.ReadTextFile(file);
            var report = YamlHelper.Deserialize<ReportDefinitionMetadata>(yamlTxt);

            // Add Reports last modified Time
            if (_reportLastUpdatedDates.TryGetValue(Path.GetFileName(file), out DateTime lastModified))
            {
                report.LastModified = lastModified;
            }
            else
            {
                report.LastModified = null;
            }

            _reportMetadata.Add(report.ReportId, report);
            _queries.Add(report.ReportId, new ReportDefinitionQuery(report));
        }

        // Load all the report fragments
        var reportFragmentFiles = _fileSystemHelper.GetReportFragmentTemplateFiles();
        foreach (var file in reportFragmentFiles)
        {
            var yamlTxt = _fileSystemHelper.ReadTextFile(file);
            var report = YamlHelper.Deserialize<ReportFragmentDefinition>(yamlTxt);

            _reportFragmentMetadata.Add(report.FragmentId, report);
            _reportFragmentQueries.Add(report.FragmentId, new ReportFragmentDefinitionQuery(report));
        }

        // Load all the filters
        var filtersFiles = _fileSystemHelper.GetFilterTemplateFiles();
        foreach (var filtersFile in filtersFiles)
        {
            var filtersYamlTxt = _fileSystemHelper.ReadTextFile(filtersFile);
            var filtersList = YamlHelper.Deserialize<DraftFilterModel>(filtersYamlTxt);

            if (filtersList == null)
            {
                continue;
            }

            foreach (var filter in filtersList.Filters)
            {
                _filters.Add(filter.FilterName, filter);
            }
        }

        var dataAreas = _fileSystemHelper.GetDataAreas();
        foreach (var file in dataAreas)
        {
            var yamlTxt = _fileSystemHelper.ReadTextFile(file);
            var dataArea = YamlHelper.Deserialize<DataAreas>(yamlTxt);

            if (dataArea == null)
            {
                continue;
            }

            foreach (var area in dataArea.DataArea)
            {
                _dataAreas.Add(area.Id, area);
            }
        }

        // Load all the feature profiles
        var featureProfiles = _fileSystemHelper.GetFeatureProfiles();
        foreach (var file in featureProfiles)
        {
            var yamlTxt = _fileSystemHelper.ReadTextFile(file);
            var featureProfile = YamlHelper.Deserialize<FeatureProfiles>(yamlTxt);

            if (featureProfile == null)
            {
                continue;
            }

            foreach (var feature in featureProfile.Features)
            {
                _features.Add(feature.Key, feature);
            }
        }

        // Load all the archive filters
        var archivedFilterFiles = _fileSystemHelper.GetArchivedFilters();
        foreach (var file in archivedFilterFiles)
        {
            var jsonText = _fileSystemHelper.ReadTextFile(file);

            List<ArchivedFilters>? archiveFilters = JsonSerializer.Deserialize<List<ArchivedFilters>>(jsonText, JsonSerializerCustomOptions.Default);

            if (archiveFilters == null || !archivedFilterFiles.Any())
            {
                continue;
            }

            foreach (var af in archiveFilters)
            {
                _archivedFilters.Add(af.ReportId, af.DeletedItems);
            }
        }
    }

    public List<DeletedItem>? GetArchivedFilters(Guid reportId)
    {
        return _archivedFilters.TryGetValue(reportId, out List<DeletedItem>? value) ? value : null;
    }

    public IEnumerable<ReportDefinitionMetadata> GetAllReportDefinitions()
    {
        var reports = _reportMetadata.Values;
        var mappedReports = new List<ReportDefinitionMetadata>();
        if (reports != null)
        {
            foreach (var report in reports)
            {
                mappedReports.Add(MapReport(report));
            }
        }
        return mappedReports;
    }

    public ReportDefinitionMetadata? GetReportDefinition(Guid reportId)
    {
        var report = _reportMetadata.TryGetValue(reportId, out ReportDefinitionMetadata? value) ? value : null;

        if (report != null)
        {
            return MapReport(report);
        }
        return report;
    }

    public ReportFragmentDefinition? GetReportFragmentDefinition(Guid fragmentId)
    {
        return _reportFragmentMetadata.TryGetValue(fragmentId, out ReportFragmentDefinition? value) ? value : null;
    }

    public ReportFragmentDefinitionQuery? GetFragmentQueryDefinition(Guid fragmentId)
    {
        return _reportFragmentQueries.TryGetValue(fragmentId, out ReportFragmentDefinitionQuery? value) ? value : null;
    }

    public IEnumerable<ReportFragmentDefinitionQuery> GetFragmentQueryDefinition(List<Guid> fragmentIds)
    {
        List<ReportFragmentDefinitionQuery> values = [];
        foreach (var key in fragmentIds)
        {
            if (_reportFragmentQueries.TryGetValue(key, out var value))
            {
                values.Add(value);
            }
        }
        return values;
    }

    public ReportDefinitionQuery? GetQueryDefinition(Guid reportId)
    {
        return _queries.TryGetValue(reportId, out ReportDefinitionQuery? value) ? value : null;
    }

    public bool IsSystemReport(Guid reportId)
    {
        return _reportMetadata.ContainsKey(reportId);
    }

    public IEnumerable<FilterTemplateModel> GetAllFilters()
    {
        var filters = _filters.Values;
        var mappedFilters = new List<FilterTemplateModel>();
        if (filters != null)
        {
            foreach (var filter in filters)
            {
                mappedFilters.Add(MapFilter(filter));
            }
        }
        return mappedFilters;
    }

    public FilterTemplateModel? GetFilterByName(string filterName)
    {
        var filter = _filters.TryGetValue(filterName, out FilterTemplateModel? value) ? value : null;

        if (filter != null)
        {
            return MapFilter(filter);
        }
        return filter;
    }

    public IEnumerable<DataArea> GetAllSystemDataAreas()
    {
        return _dataAreas.Values;
    }

    public DataArea GetDataArea(Guid key)
    {
        return _dataAreas.TryGetValue(key, out DataArea? value) ? value : null;
    }

    public IEnumerable<FeatureProfile> GetAllFeatureProfiles()
    {
        return _features.Values;
    }

    public IEnumerable<FeatureProfile> GetFeatureProfiles(List<string> featureKeys)
    {
        featureKeys = [.. featureKeys.Distinct()];
        List<FeatureProfile> values = [];
        foreach (var key in featureKeys)
        {
            if (_features.TryGetValue(key, out var value))
            {
                values.Add(value);
            }
        }
        return values;
    }

    public FeatureProfile? GetFeatureProfile(string featureKey)
    {
        return _features.TryGetValue(featureKey, out FeatureProfile? value) ? value : null;
    }

    private static FilterTemplateModel MapFilter(FilterTemplateModel filter)
    {
        return new FilterTemplateModel()
        {
            FilterName = filter.FilterName,
            QueryParam = filter.QueryParam,
            UxLabel = filter.UxLabel,
            UxDescription = filter.UxDescription,
            Category = filter.Category,
            DataType = filter.DataType,
            AllowedOperators = MapAllowedOperators(filter, filter.AllowedOperators, filter.EnableRelativeUserFilterField),
            FilterType = filter.FilterType,
            FilterPicklistQuery = filter.FilterPicklistQuery,
            IsRequired = filter.IsRequired,
            DomainValues = filter.DomainValues,
            IsProperty = filter.IsProperty,
            PropertyType = filter.PropertyType,
            PropertyId = filter.PropertyId,
            IsGenericFilter = filter.IsGenericFilter,
            IsNullable = filter.IsNullable,
            IsDefault = filter.IsDefault,
            FilterValuesByTeamsite = filter.FilterValuesByTeamsite,
            EnableRelativeUserFilterField = filter.EnableRelativeUserFilterField
        };
    }

    private static List<DataAccess.Entities.FilterOperation> MapAllowedOperators(FilterTemplateModel filter, List<DataAccess.Entities.FilterOperation> allowedOperators, string? enableRelativeUserFilterField)
    {
        if (allowedOperators == null || allowedOperators.Count == 0)
        {
            var filterJson = JsonSerializer.Serialize(filter);
            return allowedOperators;
        }

        if (string.IsNullOrWhiteSpace(enableRelativeUserFilterField) )
        {
            return allowedOperators;
        }

        var localOperators = new List<DataAccess.Entities.FilterOperation>(allowedOperators);
        if (localOperators.Count(x => x != null && (x.Name == OperatorConstants.IS_CURRENT_USER || x.Name == OperatorConstants.IS_MY_TEAM)) == 0)
        {
            if (localOperators.Count >= 2)
            {
                // Insert the IS_CURRENT_USER at the 3rd position (index 2)
                localOperators.Insert(2, new DataAccess.Entities.FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                // Insert the IS_MY_TEAM at the 4th position (index 3)
                localOperators.Insert(3, new DataAccess.Entities.FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
            }
            else
            {
                // If there are less than 2 items, just add them to the end
                localOperators.Add(new DataAccess.Entities.FilterOperation { Name = OperatorConstants.IS_CURRENT_USER, UxLabel = OperatorConstants.IS_CURRENT_USER_LABEL });
                localOperators.Add(new DataAccess.Entities.FilterOperation { Name = OperatorConstants.IS_MY_TEAM, UxLabel = OperatorConstants.IS_MY_TEAM_LABEL });
            }
        }
       
        return localOperators;
    }

    private static ReportDefinitionMetadata MapReport(ReportDefinitionMetadata report)
    {
        return new ReportDefinitionMetadata()
        {
            ReportName = report.ReportName,
            ReportId = report.ReportId,
            Description = report.Description,
            OrderField = report.OrderField,
            OrderBy = report.OrderBy,
            FilterCategoryOrder = report.FilterCategoryOrder,
            Filters = MapReportFilters(report.Filters),
            Fields = MapReportFields(report.Fields),
            FieldGroups = MapFieldGroups(report.FieldGroups),
            RequiredFeatureKeys = report.RequiredFeatureKeys,
            IncludeUserProperties = report.IncludeUserProperties,
            IncludeCustomProperties = report.IncludeCustomProperties,
            ShowTeamsitePicker = report.ShowTeamsitePicker,
            QueryTemplate = report.QueryTemplate,
            LastModified = report.LastModified,
            DataAreaKey = report.DataAreaKey,
            PrimaryKeyField = report.PrimaryKeyField
        };
    }

    private static List<ReportFilter> MapReportFilters(List<ReportFilter> sourceFilters)
    {
        if (sourceFilters == null)
        {
            return [];
        }

        var mappedFilters = new List<ReportFilter>();

        foreach (var filter in sourceFilters)
        {
            var mappedFilter = new ReportFilter
            {
                FilterName = filter.FilterName,
                Category = filter.Category,
                DefaultOperator = filter.DefaultOperator,
                DefaultValues = filter.DefaultValues,
                IsDefault = filter.IsDefault
                // Map other properties as needed...
            };

            mappedFilters.Add(mappedFilter);
        }

        return mappedFilters;
    }

    private static List<ReportField> MapReportFields(List<ReportField> sourceFields)
    {
        if (sourceFields == null)
        {
            return [];
        }

        var mappedFields = new List<ReportField>();

        foreach (var field in sourceFields)
        {
            var mappedField = new ReportField
            {
                Name = field.Name,
                UxDescription = field.UxDescription,
                UxLabel = field.UxLabel,
                DataType = field.DataType,
                IsDefault = field.IsDefault,
                Formatter = MapFormatter(field.DataType, field.Formatter ?? string.Empty),
                HasGenericFilter = field.HasGenericFilter,
                IsProperty = field.IsProperty,
                Nullable = field.Nullable,
                PropertyId = field.PropertyId,
                PropertyType = field.PropertyType,
                RequiredFeatureKeys = field.RequiredFeatureKeys,
                FilterName = field.FilterName,
                FilterPicklistQuery = field.FilterPicklistQuery,
                FilterDomainValues = field.FilterDomainValues,
                FilterIsDefault = field.FilterIsDefault,
                FilterDefaultOperator = field.FilterDefaultOperator,
                FilterDefaultValues = field.FilterDefaultValues,
                QueryAlias = field.QueryAlias,
                FilterValuesByTeamsite = field.FilterValuesByTeamsite ?? false,
                Definition = field.Definition,
                EnableRelativeUserFilterField = field.EnableRelativeUserFilterField,
                DataAreaKey = field.DataAreaKey,
                DrillIn = MapDrillIn(field.DrillIn),
            };

            mappedFields.Add(mappedField);
        }

        return mappedFields;
    }
    
    private static string MapFormatter(DataType dataType, string formatter)
    {
        if(dataType == DataType.Integer || dataType == DataType.Decimal)
            return Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities.FormatterType.NUMBER_FORMATTER.ToDisplayName();
        else
            return formatter;
    }

    private static DrillIn MapDrillIn(DrillIn? drillIn)
    {
        if (drillIn != null)
        {
            return new DrillIn { 
                TargetReport = drillIn.TargetReport, 
                SourceValue = drillIn.SourceValue, 
                TargetFilter = drillIn.TargetFilter,
                optionalFilters = MapOptionalFilters(drillIn.optionalFilters)
            };
        }
        return null;
    }

    private static List<OptionalFilters> MapOptionalFilters(List<OptionalFilters>? sourceOptionalFilters)
    {
        if (sourceOptionalFilters == null)
        {
            return [];
        }

        var mappedOptionalFilters = new List<OptionalFilters>();

        foreach (var optionalFilter in sourceOptionalFilters)
        {
            var mappedOptionalFilter = new OptionalFilters
            {
                TargetFilter = optionalFilter.TargetFilter,
                SourceValue = optionalFilter.SourceValue
            };

            mappedOptionalFilters.Add(mappedOptionalFilter);
        }

        return mappedOptionalFilters;
    }

    private static List<FieldGroup> MapFieldGroups(List<FieldGroup> sourceFieldGroups)
    {
        if (sourceFieldGroups == null)
        {
            return [];
        }

        var mappedFieldGroups = new List<FieldGroup>();

        foreach (var fieldGroup in sourceFieldGroups)
        {
            var mappedFieldGroup = new FieldGroup
            {
                UxLabel = fieldGroup.UxLabel,
                Fields = MapReportFields(fieldGroup.Fields)

            };

            mappedFieldGroups.Add(mappedFieldGroup);
        }

        return mappedFieldGroups;
    }
}