﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Common.ServiceFoundation;
using Serilog;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.Platform.UserManagement.Model;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using System.Text.Json;
using System.Diagnostics;
using Seismic.Platform.Matrix.Client;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class OrgHierarchyService(ISeismicContextProvider _contextProvider, ILogger logger, ISeismicRedisCache _cache,
        IUserService _userService, IMatrixClient _matrixClient, HttpClient _umsHttpClient) : IOrgHierarchyService
    {
        private readonly ILogger _logger = logger.ForContext<OrgHierarchyService>();

        private Guid TenantId => _contextProvider.GetContext().TenantIdentifier.TenantUniqueId;

        public async Task<UserResource> GetUserById(Guid tenantId, string userId, bool forceRefresh = false)
        {
            var cacheKey = new TenantUsersDetailCacheKey(TenantId, userId);
            if (!forceRefresh)
            {
                var cached = await _cache.GetAsync(cacheKey);
                if (cached != null)
                    return cached;
            }
            return await _userService.GetUserById(tenantId, userId);
        }

        public async Task<HierarchyLevel> GetCurrentUserHierarchyLevel(Guid tenantId, string managerUserId)
        {
            _logger.Information("GetAllDirectReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}.", managerUserId.ToSanitizedString(), tenantId);
           
            var cacheKey = new UserHierarchyLevelCacheKey(TenantId, managerUserId);
            var cached = await _cache.GetAsync(cacheKey);
            
            if (!string.IsNullOrWhiteSpace(cached) && Enum.TryParse(cached, true, out HierarchyLevel hierarchyLevel))
            {
                return hierarchyLevel;
            }

            try
            {
                var endpoint = $"/api/ums/v1/tenants/{tenantId}/managers/{managerUserId}/directReports?pageIndex={0}&pageSize={10}";
                var pagedResult = await GetUmsData<UmsContinuationTokenResourceList<HierarchyUserResource>>(tenantId, endpoint);

                if (pagedResult == null || pagedResult.Items == null || !pagedResult.Items.Any())
                {
                    _logger.Warning("GetCurrentUserHierarchyLevel - Received no data from UMS for managerUserId:{managerUserId} for tenantId:{tenantId} from url:{url}", managerUserId.ToSanitizedString(), tenantId, endpoint.ToSanitizedString());
                }

                _logger.Information("GetCurrentUserHierarchyLevel - Count of all reports for tenantId:{tenantId} and managerId:{managerUserId} is:{count} from url:{url}", tenantId, managerUserId.ToSanitizedString(), pagedResult.Items.Count(), endpoint.ToSanitizedString());

                var userHierarchyLevel = pagedResult.Items.Count() > 0 ? HierarchyLevel.Manager : HierarchyLevel.IC;

                _logger.Information("GetCurrentUserHierarchyLevel for managerUserId:{managerUserId} and tenantId:{tenantId}. items:{items}", managerUserId.ToSanitizedString(), tenantId, pagedResult.Items.Count());
                 await _cache.SetAsync<string>(cacheKey, userHierarchyLevel.ToString());
                return userHierarchyLevel;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in GetCurrentUserHierarchyLevel for managerUserId:{managerUserId} and tenantId:{tenantId}", managerUserId.ToSanitizedString(), tenantId);
                //throw;
            }
            return HierarchyLevel.IC;
        }



        public async Task<List<HierarchyUserResource>> GetDirectReportsForManager(Guid tenantId, string managerUserId, bool forceRefresh = false)
        {
            _logger.Information("GetAllDirectReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}.", managerUserId.ToSanitizedString(), tenantId);

            var cacheKey = new UserDirectReportsCacheKey(TenantId, managerUserId);

            if (!forceRefresh)
            {
                var cached = await _cache.GetAsync(cacheKey);
                if (cached != null)
                  return cached;
            }

            var result = new List<HierarchyUserResource>();
            var pageIndex = 0;
            var pageSize = 200;

            try
            {
                while (true)
                {
                    var endpoint = $"/api/ums/v1/tenants/{tenantId}/managers/{managerUserId}/directReports?pageIndex={pageIndex}&pageSize={pageSize}";

                    var pagedResult = await GetUmsData<UmsContinuationTokenResourceList<HierarchyUserResource>>(tenantId, endpoint);

                    if (pagedResult == null || pagedResult.Items == null || !pagedResult.Items.Any())
                    {
                        if (result.Count == 0)
                        {
                            _logger.Warning("GetAllReportsForManager - Received no data from UMS for managerUserId:{managerUserId} for tenantId:{tenantId} from url:{url}", managerUserId.ToSanitizedString(), tenantId, endpoint.ToSanitizedString());
                        }
                        break;
                    }

                    _logger.Information("GetAllReportsForManager - Count of all reports for tenantId:{tenantId} and managerId:{managerUserId} is:{count} from url:{url}", tenantId, managerUserId.ToSanitizedString(), pagedResult.Items.Count(), endpoint.ToSanitizedString());

                    var fetchedItems = pagedResult.Items.Count();

                    result.AddRange(pagedResult.Items);
                    pageIndex++;
                    if (fetchedItems < pageSize)
                    {
                        break;
                    }
                }

                _logger.Warning("GetAllReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}. items:{items}", managerUserId.ToSanitizedString(), tenantId, result.Count);
                return await _cache.SetAsync(cacheKey, result);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in GetAllReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}", managerUserId.ToSanitizedString(), tenantId);
                //throw;
            }
            return result;
        }

        public async Task<List<HierarchyUserResource>> GetAllReportsForManager(Guid tenantId, string managerUserId, bool forceRefresh)
        {
            _logger.Information("GetAllReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}.", managerUserId.ToSanitizedString(), tenantId);

            var cacheKey = new UserDirectIndirectReportsCacheKey(TenantId, managerUserId);

            if (!forceRefresh)
            {
                var cached = await _cache.GetAsync(cacheKey);
                if (cached != null)
                    return cached;
            }

            var result = new List<HierarchyUserResource>();
            var pageIndex = 0;
            var pageSize = 200;

            try
            {
                while (true)
                {
                    var endpoint = $"/api/ums/v1/tenants/{tenantId}/managers/{managerUserId}/allReports?pageIndex={pageIndex}&pageSize={pageSize}";

                    var pagedResult = await GetUmsData<UmsContinuationTokenResourceList<HierarchyUserResource>>(tenantId, endpoint);

                    if (pagedResult == null || pagedResult.Items == null || !pagedResult.Items.Any())
                    {
                        if (result.Count == 0)
                        {
                            _logger.Warning("GetAllReportsForManager - Received no data from UMS for managerUserId:{managerUserId} for tenantId:{tenantId} from url:{url}", managerUserId.ToSanitizedString(), tenantId, endpoint.ToSanitizedString());
                        }
                        break;
                    }

                    _logger.Information("GetAllReportsForManager - Count of all reports for tenantId:{tenantId} and managerId:{managerUserId} is:{count} from url:{url}", tenantId, managerUserId.ToSanitizedString(), pagedResult.Items.Count(), endpoint.ToSanitizedString());

                    var fetchedItems = pagedResult.Items.Count();

                    result.AddRange(pagedResult.Items);
                    pageIndex++;
                    if (fetchedItems < pageSize)
                    {
                        break;
                    }
                }

                _logger.Information("GetAllReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}. items:{items}", managerUserId.ToSanitizedString(), tenantId, result.Count);

                return await _cache.SetAsync(cacheKey, result);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in GetAllReportsForManager for managerUserId:{managerUserId} and tenantId:{tenantId}", managerUserId.ToSanitizedString(), tenantId);
              //  throw;
            }
            return result;
        }

        public async Task<TenantSettings> GetTenantOrgHierarchySettings(Guid tenantId)
        {
            var settings = new TenantSettings();
            var isHierarchyEnabled = await GetManagerState();

            settings.IsOrgHierarchyEnabled = isHierarchyEnabled.StateIsReady;
            settings.HasOrgHierarchy = isHierarchyEnabled.StateIsReady;

            return settings;
        }

        private async Task<HierarchyState> GetManagerState()
        {
            _logger.Information("Start GetManagerState for tenantId:{TenantId}", TenantId);
            var relativeUrl = $"/api/ums/v1/tenants/{TenantId}/managers/state";
            var umsServer = await _matrixClient.GetServiceEndpointByTenantAsync("ums", TenantId);
            var token = await _contextProvider.GetContext().GetPlatformToken();
            _umsHttpClient.DefaultRequestHeaders.Clear();
            _umsHttpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");
            var url = GetSafeUrl(relativeUrl, umsServer);
            var response = await _umsHttpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode)
            {
                _logger.Error("Failed to get manager state from url:{Url}. status:{Status}", url.ToSanitizedString(), response.StatusCode);
                return new HierarchyState();
            }
            var body = await response.Content.ReadAsStringAsync();
            _logger.Information("End GetManagerState for tenantId:{TenantId}, Url:{Url}, status:{Status}", TenantId, url.ToSanitizedString(), response.StatusCode);
            return JsonSerializer.Deserialize<HierarchyState>(body, JsonSerializerCustomOptions.Default) ?? new HierarchyState();
        }

        private async Task<T?> GetUmsData<T>(Guid tenantId, string relativeUrl) where T : class
        {
            _logger.Information("Start GetUmsData. Url:{url}, tenantId:{tenantId}", relativeUrl.ToSanitizedString(), tenantId);
            var umsServer = await _matrixClient.GetServiceEndpointByTenantAsync("ums", tenantId);

            var token = await _contextProvider.GetContext().GetPlatformToken();

            _umsHttpClient.DefaultRequestHeaders.Clear();
            _umsHttpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

            var url = GetSafeUrl(relativeUrl, umsServer);

            var sw = Stopwatch.StartNew();

            _logger.Information("Begin Ums call. Url:{url}", url.ToSanitizedString());

            var response = await _umsHttpClient.GetAsync(url);

            var body = await response?.Content?.ReadAsStringAsync();

            _logger.Information("End GetUmsData. tenantId:{tenantId}, Url:{url}, status:{status}, duration:{duration}ms", tenantId, url.ToSanitizedString(), response.StatusCode, sw.Elapsed);

            sw.Stop();

            if (!response.IsSuccessStatusCode)
            {
                var responseHeaders = response.Headers.Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
                var requestHeaders = response.RequestMessage?.Headers?.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
                var httpHeaders = _umsHttpClient.DefaultRequestHeaders.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");

                _logger.Error("Failed to get data from url:{url}. status:{status}, response:{response}, " +
                    "httpHeaders:{httpHeaders}, requestHeaders:{requestHeaders}, responseHeaders:{responseHeaders}",
                        url.ToSanitizedString(), response.StatusCode, body.ToSanitizedString(), httpHeaders, requestHeaders, responseHeaders);
            }

            response.EnsureSuccessStatusCode();

            if (string.IsNullOrWhiteSpace(body))
            {
                return default;
            }

            var result = JsonSerializer.Deserialize<T>(body, JsonSerializerCustomOptions.Default);
            return result;
        }

        private static string GetSafeUrl(string relativeUrl, string umsServer)
        {
            if (string.IsNullOrWhiteSpace(relativeUrl))
            {
                throw new ArgumentNullException(nameof(relativeUrl));
            }

            if (string.IsNullOrWhiteSpace(umsServer) || (!umsServer.EndsWith("seismic.com") && !umsServer.EndsWith("seismic-dev.com")))
            {
                throw new Exception($"Invalid UMS server:{umsServer}");
            }

            var result = new Uri(new Uri(umsServer), relativeUrl);

            var host = result.DnsSafeHost;

            if (host.EndsWith("seismic.com") || host.EndsWith("seismic-dev.com"))
            {
                return result.AbsoluteUri;
            }

            throw new Exception($"Invalid UMS server:{umsServer}");
        }

        

    }
}
