﻿using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Entitlement;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.Platform.Entitlement.Client;
using Seismic.Platform.Entitlement.Client.Model;
using Seismic.Platform.Matrix.Client;
using Serilog;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl;

public class EntitlementServiceClientWrapper(EntitlementServiceClient _entitlementServiceClient, ILogger logger, HttpClient _httpClient,
    IMatrixClient _matrixClient, ISeismicContextProvider _contextProvider) : IEntitlementServiceClientWrapper
{
    private readonly ILogger _logger = logger.ForContext<EntitlementServiceClientWrapper>();
    private const string ASSIGNEE_TYPE_USER = "User";

    public async Task<List<PermissionResource>> GetUserPermissionsAsync(string userId, Guid tenantId)
    {
        _logger.Information("GetUserPermissionsAsync for user :{userId} and tenantId:{tenantId}.", userId, tenantId);
        var result = new List<PermissionResource>();
        var pageIndex = 1;
        var pageSize = 200;

        try
        {
            while (true)
            {
                var response = await _entitlementServiceClient.GetUserAllPermisisonsAsync(tenantId.ToString(), userId, pageIndex, pageSize);
                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    _logger.Error("Failed to get custom properties for tenant: {TenantId}, status: {StatusCode}, Error.StatusCode:{ErrorStatusCode} kind:{ResponseErrorKind}", tenantId, response.StatusCode, response.Error?.StatusCode, response.Error?.Kind);
                }

                if (response.Resource == null || response.Resource.Items == null || response.Resource.Items.Count == 0)
                {
                    _logger.Error("GetUserPermissionsAsync - Received no data from entitlement for userId:{UserId} for tenantId:{TenantId}", userId, tenantId);
                    break;
                }

                result.AddRange(response.Resource.Items);
                pageIndex++;
                if (response.Resource.Items.Count < pageSize)
                {
                    break;
                }
            }

            _logger.Information("GetUserPermissionsAsync for userId:{userId} and tenantId:{tenantId}. items:{items}", userId, tenantId, result.Count);

            return result;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Error in GetUserPermissionsAsync for userId:{userId} and tenantId:{tenantId}", userId, tenantId);
            throw;
        }
    }

    public async Task<List<PermissionAssignee>> GetUsersWithSsrAccess(string permissionKey, Guid tenantId)
    {
        _logger.Information("GetPermissionsAllAssignees for permissionKey :{permissionKey} and tenantId:{tenantId}.", permissionKey, tenantId);

        var result = new List<PermissionAssignee>();
        var pageIndex = 1;
        var pageSize = 200;
        try
        {
            var entitlementServer = await _matrixClient.GetServiceEndpointByTenantAsync(ServiceAliasConstants.ENTITLEMENT, tenantId);
            var context = _contextProvider.GetContext();
            var platformToken = await context.GetPlatformToken();

            int requestCounter = 1;
            var sw = Stopwatch.StartNew();
            while (true)
            {
                var endpoint = $"/api/entitlement/v1/tenants/{tenantId}/permissions/{permissionKey}/allAssignees?pageIndex={pageIndex}&pageSize={pageSize}";
                var url = new Uri(new Uri(entitlementServer), endpoint);

                var pagedResult = await GetAllAssigneesByPermissionKey<PagedResponse<PermissionAssignee>>(tenantId, url.AbsoluteUri, platformToken);

                if (pagedResult == null || pagedResult.Items == null || pagedResult.Items.Count == 0)
                {
                    if (result.Count == 0)
                    {
                        _logger.Error("GetPermissionsAllAssignees for permissionKey:{permissionKey} and tenantId:{tenantId}. items:{items}", permissionKey, tenantId, endpoint);
                    }
                    break;
                }

                result.AddRange(pagedResult.Items.Where(x => x.AssigneeType == ASSIGNEE_TYPE_USER));
                pageIndex++;
                requestCounter++;
                if (!pagedResult.HasNextPage)
                {
                    break;
                }
            }
            sw.Stop();
            _logger.Information("GetPermissionsAllAssignees for permissionKey:{permissionKey} and tenantId:{tenantId}. items:{items}, Total request count: {RequestCounter}, elapsed: {elapsed}ms.", permissionKey, tenantId, result.Count, requestCounter, sw.ElapsedMilliseconds);
            return result;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Error in GetPermissionsAllAssignees for permissionKey:{permissionKey} and tenantId:{tenantId}", permissionKey, tenantId);
            throw;
        }
    }

    public async Task<ResourceResponse<CheckPermissionResultResource>> CheckUserPermissionAsync(string userId, string permissionKey, Guid tenantId)
    {
        _logger.Information("CheckUserPermissionAsync for user :{userId}, permissionKey:{permissionKey} and tenantId:{tenantId}.", userId, permissionKey, tenantId);
        try
        {
            var response = await _entitlementServiceClient.CheckUserPermissionAsync(tenantId.ToString(), userId, permissionKey);
            if (response.StatusCode != System.Net.HttpStatusCode.OK)
            {
                _logger.Error("Failed to check permission for user: {UserId}, permissionKey:{PermissionKey}, tenant: {TenantId}, status: {StatusCode}, Error.StatusCode:{ErrorStatusCode} kind:{ResponseErrorKind}", userId, permissionKey, tenantId, response.StatusCode, response.Error?.StatusCode, response.Error?.Kind);
            }
            return response;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Error in CheckUserPermissionAsync for userId:{userId}, permissionKey:{permissionKey} and tenantId:{tenantId}", userId, permissionKey, tenantId);
            throw;
        }
    }

    public async Task<List<UserRolesView>?> GetUserRolesByUserIdsAsync(Guid tenantId, List<string> userIds, string platformToken)
    {
        _logger.Information("GetUserRolesByUserIdsAsync for tenantId:{tenantId}.", tenantId);
        var allUserRoles = new List<UserRolesView>();
        var pageIndex = 1;
        var pageSize = 200;
        try
        {
            var entitlementServer = await _matrixClient.GetServiceEndpointByTenantAsync(ServiceAliasConstants.ENTITLEMENT, tenantId);

            for (int i = 0; i < userIds.Count; i += pageSize)
            {
                var endpoint = $"/api/entitlement/v1/tenants/{tenantId}/users/roles";
                var url = new Uri(new Uri(entitlementServer), endpoint);

                var batch = userIds.Skip(i).Take(pageSize).ToList();

                var requestBody = JsonSerializer.Serialize(batch);
                var content = new StringContent(requestBody, System.Text.Encoding.UTF8, "application/json");

                using var request = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = content
                };
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", platformToken);

                var sw = Stopwatch.StartNew();

                var response = await _httpClient.SendAsync(request);

                if (response == null || response.Content == null)
                {
                    _logger.Error("Error in Api call. Url:{url}, response content is null", url);
                    return default;
                }

                var body = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode || string.IsNullOrWhiteSpace(body))
                {
                    _logger.Error("Error in Api call. Url:{url}, Status code:{statusCode}", url, response.StatusCode);
                    var responseHeaders = response.Headers.Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
                    var requestHeaders = response.RequestMessage?.Headers?.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
                    var httpHeaders = _httpClient.DefaultRequestHeaders.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");

                    _logger.Error("Failed to get data from url:{url}. status:{status}, response:{response}, " +
                        "httpHeaders:{httpHeaders}, requestHeaders:{requestHeaders}, responseHeaders:{responseHeaders}",
                            url, response.StatusCode, body, httpHeaders, requestHeaders, responseHeaders);
                    return default;
                }

                var pagedResult = JsonSerializer.Deserialize<PagedResponse<UserRolesView>>(body, JsonSerializerCustomOptions.Default);

                if (pagedResult?.Items != null && pagedResult.Items.Count > 0)
                {
                    allUserRoles.AddRange(pagedResult.Items);
                }
            }

            return allUserRoles;
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Error in GetUserRolesByUserIdsAsync for tenantId:{tenantId}", tenantId);
            throw;
        }
    }

    private async Task<T?> GetAllAssigneesByPermissionKey<T>(Guid tenantId, string url, string platformToken) where T : class
    {
        _logger.Information("Start GetAllAssigneesByPermissionKey. Url:{url}, tenantId:{tenantId}", url, tenantId);

        var sw = Stopwatch.StartNew();

        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", platformToken);

        var response = await _httpClient.SendAsync(request);

        if (response == null || response.Content == null)
        {
            _logger.Error("Error in Api call. Url:{url}, response content is null", url);
            return default;
        }

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode || string.IsNullOrWhiteSpace(body))
        {
            _logger.Error("Error in Api call. Url:{url}, Status code:{statusCode}", url, response.StatusCode);
            var responseHeaders = response.Headers.Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
            var requestHeaders = response.RequestMessage?.Headers?.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");
            var httpHeaders = _httpClient.DefaultRequestHeaders.Where(h => h.Key != "Authorization").Select(x => $"key:{x.Key}, value:{string.Join(",", x.Value)}");

            _logger.Error("Failed to get data from url:{url}. status:{status}, response:{response}, " +
                "httpHeaders:{httpHeaders}, requestHeaders:{requestHeaders}, responseHeaders:{responseHeaders}",
                    url, response.StatusCode, body, httpHeaders, requestHeaders, responseHeaders);
            return default;
        }

        _logger.Information("End GetAllAssigneesByPermissionKey. tenantId:{tenantId}, Url:{url}, status:{status}, duration:{duration}ms", tenantId, url, response.StatusCode, sw.Elapsed);

        var result = JsonSerializer.Deserialize<T>(body, JsonSerializerCustomOptions.Default);
        return result;
    }

}
