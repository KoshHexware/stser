﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.Common.ServiceFoundation.Abstraction;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.Common.ServiceFoundation;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class FiltersMacroResolver : IFiltersMacroResolver
    {
        private readonly ICMService _cmService;
        private readonly ISeismicRedisCache _seismicCache;
        private readonly ISeismicContextProvider _seismicContextProvider;

        public FiltersMacroResolver(ICMService cmService, ISeismicRedisCache seismicCache, ISeismicContextProvider seismicContextProvider)
        {
            _cmService = cmService;
            _seismicCache = seismicCache;
            _seismicContextProvider = seismicContextProvider;
            DefaultDomainValueMacros = new Dictionary<string, Func<string, Guid, string, Task<string[]>>>(StringComparer.OrdinalIgnoreCase)
            {
                { DomainOfValuesMacro.ACCESSIBLE_TEAMSITES_MACRO, (macroName, tenantId, userId) => GetUserAccessibleTeamsites(macroName, tenantId, userId) }
            };
        }

        private readonly Dictionary<string, Func<string, Guid, string, Task<string[]>>> DefaultDomainValueMacros;

        public async Task<string[]> GetMacroValues(string macroName, Guid tenantId, string userId)
        {
            if (DefaultDomainValueMacros.TryGetValue(macroName, out var func))
            {
                return await func(macroName, tenantId, userId);
            }
            throw new ArgumentException("Invalid macro", nameof(macroName));
        }

        /// <summary>
        /// ACCESSIBLE_TEAMSITES()
        /// Results will be cached for 1 hour
        /// </summary>
        /// <param name="macroName"></param>
        /// <param name="tenantId"></param>
        /// <param name="userId"></param>
        /// <returns>All the tamsites which current user have access</returns>
        private async Task<string[]> GetUserAccessibleTeamsites(string macroName, Guid tenantId, string userId)
        {
            var cacheKey = new MacroCacheKey(macroName, tenantId, userId);

            var cached = await _seismicCache.GetAsync(cacheKey);
            if (cached != null)
            {
                return cached;
            }

            string userToken = GetAUserToken();

            var teamsites = await _cmService.GetUserAccessibleTeamsitesAsync(tenantId, userId); // Simulate async work
            var result = teamsites.Select(t => t.Name).ToArray();
            return await _seismicCache.SetAsync(cacheKey, result);
        }

        private string GetAUserToken()
        {
            var context = _seismicContextProvider.GetContext();
            var userToken = context.Token.TokenString;
            return userToken;
        }
    }
}