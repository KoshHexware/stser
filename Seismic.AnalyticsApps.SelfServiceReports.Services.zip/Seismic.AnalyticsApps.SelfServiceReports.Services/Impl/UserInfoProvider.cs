﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.CacheKeys;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Utils;
using Seismic.Common.ServiceFoundation.Abstraction;
using Serilog;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Impl
{
    public class UserInfoProvider(IUserService _userService, ISeismicRedisCache _cache, 
        IBssHelper _bssHelper, ILogger logger) : IUserInfoProvider
    {
        private readonly ILogger _logger = logger.ForContext<UserInfoProvider>();

        public async Task<List<UserInfoModel>> GetUsersDetails(Guid tenantId, IEnumerable<string?> userIds)
        {
            return await GetUsersDetails(tenantId, userIds, false);
        }

        public async Task<List<UserInfoModel>> RefreshUsersDetails(Guid tenantId, IEnumerable<string?> userIds)
        {
            return await GetUsersDetails(tenantId, userIds, true);
        }

        private async Task<List<UserInfoModel>> GetUsersDetails(Guid tenantId, IEnumerable<string?> userIds, bool refreshCache)
        {
            if (userIds == null || !userIds.Any())
                return [];

            var cacheKey = new TenantUsersCacheKey(tenantId);

            var result = new List<UserInfoModel>();

            var uniqueUserIds = userIds.Where(u => !string.IsNullOrWhiteSpace(u)).Distinct();

            if(!refreshCache)
            {
                var cached = await _cache.GetAsync(cacheKey);

                if (cached != null)
                {
                    result.AddRange(cached.Where(c => c != null && uniqueUserIds.Contains(c.LegacyId)));
                }
            }

            var resultIds = result.Select(r => r.LegacyId);
            var userIdsToFetch = uniqueUserIds.Where(u => !resultIds.Contains(u) && !string.IsNullOrWhiteSpace(u)).ToArray();

            if (userIdsToFetch.Length > 0)
            {
                var users = await _userService.GetMultipleUsersInTenant(tenantId, userIdsToFetch);
                var umsData = users.Select(p => UserInfoModelBuilder.Build(p)).ToList();

                var imageRequestItems = umsData.Where(p => !string.IsNullOrWhiteSpace(p.ThumbnailId))
                    .Select(p => (p.Id, PhotoThumbnailId: p.ThumbnailId)).ToList();

                var urlItems = await _bssHelper.GetImageURLsAsync(tenantId, imageRequestItems);

                foreach (var (UserId, Url) in urlItems)
                {
                    var userInfo = umsData.FirstOrDefault(p => p.Id == UserId);
                    if (userInfo != null)
                    {
                        userInfo.ThumbnailUrl = Url;
                    }
                }
                result.AddRange(umsData);
            }

            await _cache.SetAsync(cacheKey, result);

            return result;
        }

    }
}
