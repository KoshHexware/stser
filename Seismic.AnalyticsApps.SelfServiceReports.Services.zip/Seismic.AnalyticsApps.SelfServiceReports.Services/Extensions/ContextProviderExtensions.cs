﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.Common.ServiceFoundation;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions
{
    public static class ContextProviderExtensions
    {
        public static async Task<bool> DraftReportsEnabled(this ISeismicContextProvider contextProvider)
        {
            var context = contextProvider.GetContext();
            if (context == null)
                return false;

            return await context.IsToggleEnabled(LDConstants.SelfServiceDraftReportsKey);
        }
    }
}
