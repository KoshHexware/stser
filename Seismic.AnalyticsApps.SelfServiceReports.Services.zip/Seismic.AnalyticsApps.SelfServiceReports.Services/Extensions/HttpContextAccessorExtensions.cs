﻿using Microsoft.AspNetCore.Http;
using Seismic.AnalyticsApps.SelfServiceReports.Common;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions
{
    public static class HttpContextAccessorExtensions
    {
        public static string? GetCorrelationId(this IHttpContextAccessor httpContextAccessor)
        {
            return httpContextAccessor?.HttpContext?.Items?.TryGetValue(CorrelationConstants.CORRELATION_ID, out var correlationIdObj) == true
                ? correlationIdObj?.ToString() : null;
        }
    }
}
