﻿using Microsoft.Extensions.Caching.Distributed;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using System.Reflection;
using System.Text;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.Services.Extensions;

public static class CacheExtensions
{
    private static readonly Dictionary<string, Func<Guid, string, string>> MacroCacheKeys = InitializeMacroCacheKeys();

    private static Dictionary<string, Func<Guid, string, string>> InitializeMacroCacheKeys()
    {
        var macroCacheKeys = new Dictionary<string, Func<Guid, string, string>>(StringComparer.OrdinalIgnoreCase);
        var fields = typeof(DomainOfValuesMacro).GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy);

        foreach (var field in fields)
        {
            if (field.IsLiteral && !field.IsInitOnly)
            {
                var macroName = field.GetValue(null)?.ToString();
                if (macroName != null)
                {
                    macroCacheKeys[macroName] = (tenantId, userId) => $"{macroName}-{tenantId}-{userId}";
                }
            }
        }

        return macroCacheKeys;
    }

    public static async Task<T?> GetAsync<T>(this IDistributedCache cache, ICacheKey<T> cacheKey,
        CancellationToken token = default) where T : class
    {
        return FromBytes<T>(await cache.GetAsync(cacheKey.Key, token));
    }

    public static async Task<T> SetAsync<T>(this IDistributedCache cache, ICacheKey<T> cacheKey, T value,
        CancellationToken token = default) where T : class
    {
        await cache.SetAsync(cacheKey.Key, ToBytes(value), cacheKey.CacheOptions, token);
        return value;
    }

    public static async Task RemoveAsync<T>(this IDistributedCache cache, ICacheKey<T> cacheKey, CancellationToken token = default) where T : class
    {
        await cache.RemoveAsync(cacheKey.Key, token);
    }

    public static string GetTenantCacheKeyName(Guid tenantId, string name)
    {
        return $"{tenantId}-{name}";
    }

    /// <summary>
    /// Use this method to get the cache key for a macro
    /// </summary>
    /// <param name="macroName"></param>
    /// <param name="tenantId"></param>
    /// <param name="userId"></param>
    /// <returns>Returns the cache key name</returns>
    public static string GetMacroCacheKeyName(string macroName, Guid tenantId, string userId)
    {
        if(MacroCacheKeys.TryGetValue(macroName, out var func))
        {
            return func(tenantId, userId);
        }
        else
        {
           return null;
        }
    }


    public static string GetTenantCustomReportCacheKeyName(Guid tenantId, string name, Guid reportId)
    {
        return $"{tenantId}-{name}-{reportId}";
    }

    public static string GetUserAccessibleTeamsitesCacheKeyName(Guid tenantId, string userId)
    {
        return $"{tenantId}-{userId}-UserAccessibleTeamsites";
    }

    public static string GetTenantUserCacheKeyName(Guid tenantId, string userId, string name)
    {
        return $"{tenantId}-{userId}-{name}";
    }

    public static string GetPicklistQueryCacheKeyName(Guid tenantId, Guid systemReportId, string filterName, string name, string? teamsiteIds, string? searchTerm)
    {
        return $"{tenantId}-{systemReportId}-{filterName}-{name}-{teamsiteIds}-{searchTerm}";
    }

    private static byte[] ToBytes<T>(T item) where T : class
    {
        var json = JsonSerializer.Serialize(item, JsonSerializerCustomOptions.Default);
        return Encoding.UTF8.GetBytes(json);
    }

    private static T? FromBytes<T>(byte[]? data) where T : class
    {
        if (data == null || data.Length == 0)
        {
            return null;
        }

        var json = Encoding.UTF8.GetString(data);
        return JsonSerializer.Deserialize<T>(json, JsonSerializerCustomOptions.Default);
    }
}