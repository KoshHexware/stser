# =============================================================
# Lookup plugin with local cache to fasten config file creation
# Created by Guillaume Le Fourner
# V1.1 2024.07.23
# 
# Should work without having to install any python package if
# AWS CLI is already setup and configured
# =============================================================

import json
import os
import time

import boto3
from ansible.plugins.lookup import LookupBase
from requests import session


class ConsoleColor:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


CACHE_TTL_MINUTES = 5


def print_with_color(color: str, val: str):
    print(color + val + ConsoleColor.ENDC)


class LookupModule(LookupBase):
    def __init__(self, *args, **kwargs):
        super().__init__(**kwargs)
        self.secret_name = None
        self.profile_name = None
        self.is_nested = False
        self.cache_file_path = os.path.dirname(os.path.abspath(__file__)) + '/aws_secret_cache.json'

    def run(self, terms, variables=None, **kwargs) -> list:
        self.secret_name = terms[0]
        self.profile_name = kwargs['aws_profile']
        self.is_nested = kwargs.get('nested', False)

        if self.profile_name is None:
            raise Exception("AWS profile name is required. Please provide the profile name in the 'aws_profile' parameter.")
        #
        # if self.profile_name == "uat" or self.profile_name == "prod":
        #     print_with_color(ConsoleColor.WARNING, f"Profile name '{self.profile_name}' is not allowed. Skipping secret")
        #     return [""]

        secret_value = self.cache_data_to_file(self.cache_file_path, self.retrieve_aws_secret)
        return [secret_value]

    def retrieve_aws_secret(self):
        secret = self.get_aws_secret(self.secret_name.split('.')[0], self.profile_name)

        if self.is_nested:
            path = '.'.join(self.secret_name.split('.')[1:])
            secret = self.get_sub_field(json.loads(secret), path)

        return secret

    def get_aws_secret(self, secret_name, profile_name, region_name="us-east-1"):
        aws_session = boto3.session.Session(profile_name=profile_name)

        if self.profile_name == "uat" or self.profile_name == "prod":
            access_key = os.environ.get('AWS_ACCESS_KEY_UAT' if self.profile_name == "uat" else 'AWS_ACCESS_KEY_PROD')
            secret_token = os.environ.get('AWS_SECRET_KEY_UAT' if self.profile_name == "uat" else 'AWS_SECRET_KEY_PROD')

            if access_key is None or secret_token is None:
                print_with_color(ConsoleColor.WARNING, f"Profile name '{self.profile_name}' is not allowed. Skipping secret")
                return "{}"

            aws_session = boto3.session.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_token)

        client = aws_session.client('secretsmanager', region_name)
        try:
            response = client.get_secret_value(SecretId=secret_name)
            return response['SecretString']
        except Exception as e:
            raise e

    @staticmethod
    def get_sub_field(json_data, path):
        try:
            parts = path.split('.')

            for part in parts:
                json_data = json_data[part]

            return json_data
        except (KeyError, TypeError):
            # Return None if the path is invalid
            return None

    def cache_data_to_file(self, cache_file_path, data_generator_func):
        """
        Cache data to a file. If the cache exists, use it; otherwise, generate and cache the data.

        :param cache_file_path: Path to the cache file.
        :param data_generator_func: Function to generate the data if cache is not available.
        :return: The data, either from cache or generated.
        """
        cache_data = {}
        if os.path.exists(cache_file_path):
            # Opening cache file
            with open(cache_file_path, 'r+') as cache_file:
                try:
                    cache_data = json.load(cache_file)
                except json.JSONDecodeError:
                    # If the cache is empty or corrupted, reset it
                    cache_data = {}

            # Checking is secret_name is in cache
            if self.secret_name in cache_data:
                # Checking if cache is expired
                if cache_data[self.secret_name]['timestamp'] + (CACHE_TTL_MINUTES * 60) < time.time():
                    print_with_color(ConsoleColor.WARNING, f"[CACHE] Cache for {self.secret_name} secret is expired")
                    cache_data.pop(self.secret_name)
                else:
                    print_with_color(ConsoleColor.OKBLUE, f"[CACHE] Getting {self.secret_name} value")
                    return cache_data[self.secret_name]["data"]

        # Generating data
        print_with_color(ConsoleColor.OKCYAN, f"[AWS]   Getting {self.secret_name} value")
        data = data_generator_func()

        with open(cache_file_path, 'a+') as cache_file:
            if cache_file.read() is None:
                cache_data = {}

            cache_data[self.secret_name] = {
                'timestamp': time.time(),
                'data': data
            }
            cache_file.seek(0)
            cache_file.truncate()
            json.dump(cache_data, cache_file)

        return data


if __name__ == '__main__':
    lookup = LookupModule()
    print(lookup.run(['/workload/dev/search-index-queues/client_secret'], nested=False, aws_profile='dev')[0])