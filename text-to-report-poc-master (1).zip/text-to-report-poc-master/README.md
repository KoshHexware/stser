# text-to-report-poc
POC code for the text-to-report AI use case
