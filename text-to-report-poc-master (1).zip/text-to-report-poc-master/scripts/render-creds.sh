echo $1 > creds.txt
echo -n "$1/Seismic123!" | md5sum >> creds.txt