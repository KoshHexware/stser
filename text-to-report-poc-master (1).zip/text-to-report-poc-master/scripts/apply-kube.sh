kubectl apply -f config/00-local-deployment.yaml --overwrite
