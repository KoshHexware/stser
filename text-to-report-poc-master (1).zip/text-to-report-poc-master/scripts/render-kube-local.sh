#!/bin/bash
dockertag=${1?param missing - dockertag}
mkdir -p config
export ANSIBLE_HASH_BEHAVIOUR=merge
ansible-playbook -vv\
        --connection=local \
        --inventory 127.0.0.1, \
        -e phase=local-native \
        -e @ansible/vars/main.yml \
        --extra-vars="docker_tag=$dockertag phase=local-kube" \
        ansible/playbooks/render-kube-local.yml
