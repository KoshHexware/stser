#!/bin/bash
set -e
dockertag=${1?param missing - dockertag}
docker build . -t seismic/reporting-agent-service:$dockertag

