#!/bin/bash
mkdir -p demo-app/config
export ANSIBLE_HASH_BEHAVIOUR=merge
ansible-playbook -vv\
        --vault-id dev@~/.ansible_vault_password_dev \
        --connection=local \
        --inventory 127.0.0.1, \
        -e phase=local-native \
        -e @ansible/vars/main.yml \
        --extra-vars="phase=local" \
        ansible/playbooks/render-local.yml
