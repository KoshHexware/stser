#!/bin/bash
dockertag=${1?param missing - dockertag}
docker run -p 5000:5000 -d seismic/reporting-agent-service:$dockertag