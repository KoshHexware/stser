from fastapi import (
    APIRouter,
    Form,
)
from fastapi.responses import JSONResponse
import seismic_auth as auth
from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_foundation.foundation.ServiceProvider import ServiceProvider
from seismic_foundation.foundation.MatrixClient import MatrixClient

from models.prompt_chain import PromptChainModel
from models.agentic_react_model import AgenticReactModel
from services.ssrs_client import SSRSClient
from services.abstract_llm_client import AbstractLLMClient
from util.auth_util import populate_credentials_from_token

router = APIRouter()


@router.post("/recommend-reports")
@auth.validate_token(
    allow_platform=True, require_user=False, required_scopes=["reporting"]
)
@populate_credentials_from_token
async def recommend_reports(
    question: str = Form(...),
    tenant: str = Form(...),
    model: str = Form("prompt-chain"),
):
    try:
        result = None

        if model == "agentic-react":
            matrix = ServiceProvider.get_service(MatrixClient)
            model_kwargs = {
                "llmg_endpoint": matrix.get_tenant_service(tenant, "llmg"),
            }
            model = AgenticReactModel(
                config=ServiceProvider.get_service(ConfigProvider),
                ssrs_client=ServiceProvider.get_service(SSRSClient),
                tenant=tenant,
                model_kwargs=model_kwargs,
            )
            result = await model.recommend_reports(question)
        else:
            model = PromptChainModel(
                config=ServiceProvider.get_service(ConfigProvider),
                ssrs_client=ServiceProvider.get_service(SSRSClient),
                llm_client=ServiceProvider.get_service(AbstractLLMClient),
                tenant=tenant,
            )
            result = await model.recommend_reports(question)

        return result
    except Exception as e:
        return JSONResponse(
            content={"error": "Error recommending reports."}, status_code=500
        )


@router.post("/recommend-fields-and-filters")
@auth.validate_token(
    allow_platform=True, require_user=False, required_scopes=["reporting"]
)
@populate_credentials_from_token
async def recommend_fields_and_filters(
    question: str = Form(...),
    tenant: str = Form(...),
    report_ids: str = Form(...),
    model: str = Form("prompt-chain"),
):
    report_ids_list = report_ids.split(",")
    try:
        result = None

        if model == "agentic-react":
            matrix = ServiceProvider.get_service(MatrixClient)
            model_kwargs = {
                "llmg_endpoint": matrix.get_tenant_service(tenant, "llmg"),
            }
            model = AgenticReactModel(
                config=ServiceProvider.get_service(ConfigProvider),
                ssrs_client=ServiceProvider.get_service(SSRSClient),
                tenant=tenant,
                model_kwargs=model_kwargs,
            )
            result = await model.recommend_fields_and_filters(question, report_ids_list)
            return result.get("answer").model_dump()
        else:
            model = PromptChainModel(
                config=ServiceProvider.get_service(ConfigProvider),
                ssrs_client=ServiceProvider.get_service(SSRSClient),
                llm_client=ServiceProvider.get_service(AbstractLLMClient),
                tenant=tenant,
            )
            result = await model.recommend_fields_and_filters(question, report_ids_list)
            return result.get("answer").model_dump()
    except Exception as e:
        return JSONResponse(
            content={"error": "Error recommending fields and filters."}, status_code=500
        )
