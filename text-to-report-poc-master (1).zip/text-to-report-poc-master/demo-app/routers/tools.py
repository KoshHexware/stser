from functools import wraps
from fastapi import (
    APIRouter,
    Body,
    Form,
    Request,
)
from fastapi.responses import JSONResponse
from typing import List, Optional
import seismic_auth as auth
from seismic_foundation.foundation.ServiceProvider import ServiceProvider

from services.ssrs_client import SSRSClient
from tools.reporting_tools import (
    describe_available_reports,
    fetch_metadata_by_report_id,
    execute_report,
    get_filter_domain_values,
    generate_ssr_url,
    format_fields_and_filters_names,
)
from structures.ssrs_structures import ReportFieldsFiltersRecommendation
from util.auth_util import populate_credentials_from_token


router = APIRouter()


@router.post("/execute-report")
@auth.validate_token(required_scopes=["reporting"], require_user=True)
@populate_credentials_from_token
async def tool_execute_report(
    request: Request,
    fields_and_filters: ReportFieldsFiltersRecommendation = Body(...),
    tenant: Optional[str] = Body(None),  # Make optional since it can come from token
    user: Optional[str] = Body(None),  # Make optional since it can come from token
):
    """
    Tool endpoint to execute a report with given fields and filters.
    """
    try:
        ssrs_client = ServiceProvider.get_service(SSRSClient)
        result = await execute_report(ssrs_client, tenant, fields_and_filters, user)
        if result.get("error"):
            return JSONResponse(
                content={
                    "success": False,
                    "error": result["message"],
                    "tenant": tenant,
                },
                status_code=500,
            )
        return {
            "success": True,
            "data": result,
            "tenant": tenant,
            "report_config": fields_and_filters,
        }
    except PermissionError as pe:
        return JSONResponse(
            content={
                "success": False,
                "error": "Encountered permission error while executing report.",
                "tenant": tenant,
            },
            status_code=403,
        )
    except Exception as e:
        return JSONResponse(
            content={
                "success": False,
                "error": "Error executing report.",
                "tenant": tenant,
            },
            status_code=500,
        )


@router.get("/describe-available-reports")
@auth.validate_token(required_scopes=["reporting"], require_user=True)
@populate_credentials_from_token
async def tool_describe_available_reports(
    request: Request,
    tenant: Optional[str] = Body(None),  # Make optional since it can come from token
    user: Optional[str] = Body(None),  # Make optional since it can come from token
):
    """
    Tool endpoint to describe all available reports for a tenant.
    """
    try:
        ssrs_client = ServiceProvider.get_service(SSRSClient)
        result = await describe_available_reports(ssrs_client, tenant, user)
        return {"success": True, "data": result, "tenant": tenant}
    except PermissionError as pe:
        return JSONResponse(
            content={
                "success": False,
                "error": "Encountered permission error while describing available reports.",
                "tenant": tenant,
            },
            status_code=403,
        )
    except Exception as e:
        return JSONResponse(
            content={
                "success": False,
                "error": "Error describing available reports.",
                "tenant": tenant,
            },
            status_code=500,
        )


@router.post("/fetch-metadata-by-report-id")
@auth.validate_token(required_scopes=["reporting"], require_user=True)
@populate_credentials_from_token
async def tool_fetch_metadata_by_report_id(
    request: Request,
    report_ids: List[str] = Body(...),
    tenant: Optional[str] = Body(None),  # Make optional since it can come from token
    user: Optional[str] = Body(None),  # Make optional since it can come from token
):
    """
    Tool endpoint to fetch metadata for specific report IDs.
    """
    try:
        ssrs_client = ServiceProvider.get_service(SSRSClient)
        result = await fetch_metadata_by_report_id(
            ssrs_client, tenant, report_ids, user
        )
        return {
            "success": True,
            "data": result,
            "tenant": tenant,
            "report_ids": report_ids,
        }
    except PermissionError as pe:
        return JSONResponse(
            content={
                "success": False,
                "error": "Encountered permission error while fetching metadata.",
                "tenant": tenant,
                "report_ids": report_ids,
            },
            status_code=403,
        )
    except Exception as e:
        return JSONResponse(
            content={
                "success": False,
                "error": "Error fetching metadata.",
                "tenant": tenant,
                "report_ids": report_ids,
            },
            status_code=500,
        )


@router.post("/fetch-filter-domain-values")
@auth.validate_token(required_scopes=["reporting"], require_user=True)
@populate_credentials_from_token
async def tool_get_filter_domain_values(
    request: Request,
    report_id: str = Body(...),
    filter_names: list[str] = Body(...),
    tenant: Optional[str] = Body(None),  # May come from token
    user: Optional[str] = Body(None),  # May come from token
):
    """
    Tool endpoint to retrieve the domain of possible values for multiple filters in a report.
    """
    try:
        ssrs_client = ServiceProvider.get_service(SSRSClient)
        result = await get_filter_domain_values(
            ssrs_client=ssrs_client,
            tenant=tenant,
            report_id=report_id,
            filter_names=filter_names,
            user=user,
        )

        return {
            "success": True,
            "data": result,
            "tenant": tenant,
            "report_id": report_id,
            "filter_names": filter_names,
        }
    except PermissionError as pe:
        return JSONResponse(
            content={
                "success": False,
                "error": "Encountered permission error while getting filter domain values.",
                "tenant": tenant,
                "report_id": report_id,
                "filter_names": filter_names,
            },
            status_code=403,
        )
    except Exception as e:
        return JSONResponse(
            content={
                "success": False,
                "error": f"Error getting filter domain values",
                "tenant": tenant,
                "report_id": report_id,
                "filter_names": filter_names,
            },
            status_code=400 if isinstance(e, ValueError) else 500,
        )


@router.post("/format-ssr-reports-response")
@auth.validate_token(required_scopes=["reporting"], require_user=True)
@populate_credentials_from_token
async def tool_format_ssr_reports_response(
    request: Request,
    fields_and_filters: ReportFieldsFiltersRecommendation = Body(...),
    explainer: Optional[str] = Body(None),
    tenant: Optional[str] = Body(None),  # May come from token; included for parity
    user: Optional[str] = Body(None),
):
    """
    Tool endpoint to format an SSR report response payload from a ReportFieldsFiltersRecommendation.
    """
    try:
        ssrs_client = ServiceProvider.get_service(SSRSClient)

        result = await generate_ssr_url(
            ssrs_client=ssrs_client,
            fields_and_filters=fields_and_filters,
            tenant=tenant,
            user=user,
        )
        # Return the formatted payload directly to match the specified shape
        if (
            result.get("ssr_preview_url") is None
            or result.get("ssr_report_url") is None
        ):
            return JSONResponse(
                content={
                    "success": False,
                    "error": "Failed to generate SSR URLs",
                    "tenant": tenant,
                    "fields_and_filters": fields_and_filters,
                },
                status_code=400,
            )
        # Build fields_and_filters mapping with ux_name -> name
        formatted_fields_and_filters = await format_fields_and_filters_names(
            ssrs_client=ssrs_client,
            tenant=tenant,
            fields_and_filters=fields_and_filters,
            user=user,
        )

        return {
            "success": True,
            "ssr_preview_url": result.get("ssr_preview_url"),
            "ssr_report_url": result.get("ssr_report_url"),
            "report_id": result.get("reportId"),
            "report_name": result.get("reportName"),
            "fields_and_filters": formatted_fields_and_filters,
            "Explainer": explainer,
        }
    except PermissionError as pe:
        return JSONResponse(
            content={
                "success": False,
                "error": "Encountered permission error while formatting SSR response.",
                "tenant": tenant,
            },
            status_code=403,
        )
    except Exception as e:
        return JSONResponse(
            content={
                "success": False,
                "error": "Error formatting SSR response.",
                "tenant": tenant,
            },
            status_code=500,
        )
