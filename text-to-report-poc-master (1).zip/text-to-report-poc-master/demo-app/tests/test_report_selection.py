import asyncio
from typing import Callable
import pytest
from models.abstract_reporting_model import AbstractReportingModel
from models.prompt_chain import (
    PromptChainModel,
)
from models.agentic_react_model import AgenticReactModel
from structures.ssrs_structures import ReportRecommendation, ReportResponse
from tests.test_data_setup import create_expected_reports
from .test_structs import LLMTestCase


@pytest.mark.parametrize(
    "mock_reporting_model,test_case",
    [
        pytest.param(
            AgenticReactModel,  # <- Put the model you want to test
            test_case,
            id=test_case.input,
        )
        for test_case in create_expected_reports()
    ],
    indirect=["mock_reporting_model"],
)
@pytest.mark.asyncio
async def test_report_recommendations(
    test_case: LLMTestCase, mock_reporting_model: Callable[[str], AbstractReportingModel]
):
    assert mock_reporting_model is not None, "Mock reporting model should not be None"
    response = await mock_reporting_model(test_case.tenant).recommend_reports(question=test_case.input)

    expected_output: ReportResponse = test_case.expected_output
    actual_output: list[ReportRecommendation] = response.reports
    expected_report_names = [
        report.report_name.lower() for report in expected_output.reports
    ]
    actual_report_names = [
        report.report_name.lower() for report in actual_output
    ]

    print(f"Expected Output: {expected_report_names}")
    print(f"Actual Output: {actual_report_names}")

    assert not response.error, "Error should be False"
    assert response.exception is None, "Exception should be None"
    assert response.conversations is not None and len(response.conversations) > 0, "Prompts should be returned"

    if len(expected_report_names) == 0:
        assert (
            len(actual_report_names) == 0
        ), f"Expected no reports, but the actual output was {actual_report_names}"

    for report_name in expected_report_names:
        assert (
            report_name in actual_report_names
        ), f"Expected report {report_name} not found in actual output {actual_report_names}"
