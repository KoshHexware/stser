from numpy import average
import pytest
from tests.test_data_setup import create_expected_fields_and_filters
from models.abstract_reporting_model import AbstractReportingModel
from tests.test_fields_and_filters_selection import (
    GradeableResult,
    expected_reports_included_errors,
    expected_fields_included_errors,
    expected_filters_included_errors,
    expected_filter_operators_errors,
    expected_filter_values_errors,
    correct_sort_by_field_errors,
    correct_sort_by_order_errors,
    are_fields_expected_any,
    are_filters_expected_any,
    is_sort_by_expected_any
)

test_case_inputs = [
    test_case.input for test_case in create_expected_fields_and_filters()
]

# This credit is applied differently. If there are no filters, this value will remain the same,
# but the other configuration-related credits will be scaled up.
report_credit = 50

field_credit = 20

filter_credit = 20
filter_credit_field = 80
filter_credit_operator = 10
filter_credit_value = 10

sorting_credit = 10
sorting_credit_field = 80
sorting_credit_order = 20

passing_credit = 85

def test_partial_credit_constants_sane():
    total = report_credit + field_credit + filter_credit + sorting_credit
    filter_total = filter_credit_field + filter_credit_operator + filter_credit_value
    sorting_total = sorting_credit_field + sorting_credit_order
    assert total == 100, f"Total credit does not sum to 100 (got {total})"
    assert filter_total == 100, f"Filter credit does not sum to 100 (got {filter_total})"
    assert sorting_total == 100, f"Sorting credit does not sum to 100 (got {sorting_total})"
    assert passing_credit < 100, f"Passing credit should be less than 100 (got {passing_credit})"
    assert passing_credit >= 0, f"Passing credit should be non-negative (got {passing_credit})"

class GradeResult:
    def __init__(self, partial_credit: int, max_credit: int, grade: int, errors: list[str]):
        self.partial_credit = partial_credit
        self.max_credit = max_credit
        self.grade = grade
        self.errors = errors
    
    def __add__(self, other):
        return GradeResult(
            self.partial_credit + other.partial_credit,
            self.max_credit + other.max_credit,
            None,
            self.errors + other.errors
        )

def _grade_section(passed: bool, expected: bool, credit: int, errors: list[GradeableResult], error_fmt:str, report_grade:int) -> GradeResult:
    """
    Helper to grade a section (fields, filters, sorting).
    """
    if passed:
        return GradeResult(credit, credit, 100, [])
    elif not expected:
        return GradeResult(0, 0, None, [])
    else:
        # multiply by the report grade because the tests don't return errors if there is no matching report
        fail_ratio = average([(len(e.difference) * report_grade) / (len(e.expected_items) * 100) for e in errors]) if errors else 0
        grade = int(100 * (1 - fail_ratio))
        partial_credit = int(credit * (1 - fail_ratio))
        error_messages = [error_fmt.format(e.difference, e.actual_items) for e in errors]
        return GradeResult(partial_credit, credit, grade, error_messages)

def grading(csv_gradebook, reportResult, fieldsResults, filtersResults, sortingResults, test_input):
    cumulative_grade = GradeResult(0, 0, None, [])

    # Report grading
    report_fmt = "Expected reports {} not included in actual output: {}"
    report_grade_result = _grade_section(
        reportResult.difference is None or len(reportResult.difference) == 0,
        True,  # Always expect reports to be included
        report_credit,
        [reportResult],
        report_fmt,
        100 # This is the full credit for the report section
    )
    report_grade = report_grade_result.grade
    cumulative_grade.errors += report_grade_result.errors

    if report_grade_result.grade == 0:
        print(f"Test case {test_input} failed: {report_grade_result.errors}")
        csv_gradebook.writerow([test_input, 0, None, None, None, 0, ' | '.join(report_grade_result.errors)])
        return 0

    # Field grading
    fieldsPassed, areFieldsExpected, fieldsErrors = fieldsResults
    field_fmt = "Expected fields {} not found in actual output fields: {}"
    fields_grade_result = _grade_section(fieldsPassed, areFieldsExpected, field_credit, fieldsErrors, field_fmt, report_grade)
    fields_grade = fields_grade_result.grade
    cumulative_grade += fields_grade_result

    # Filter grading
    filtersPassed, areFiltersExpected, filtersFieldErrors, filtersOperatorErrors, filtersValueErrors = filtersResults
    filter_field_fmt = "Expected filters {} not found in actual output filters: {}"
    filters_grade_result_field = _grade_section(filtersPassed, areFiltersExpected, (filter_credit * filter_credit_field)/100, filtersFieldErrors, filter_field_fmt, report_grade)
    filters_grade_field = filters_grade_result_field.grade
    cumulative_grade += filters_grade_result_field

    filter_operator_fmt = "Expected filter operators {} not found in actual output filters: {}"
    filters_grade_result_operator = _grade_section(filtersPassed, areFiltersExpected, (filter_credit * filter_credit_operator)/100, filtersOperatorErrors, filter_operator_fmt, report_grade)
    filters_grade_operator = filters_grade_result_operator.grade
    cumulative_grade += filters_grade_result_operator

    filter_value_fmt = "Expected filter values {} not found in actual output filters: {}"
    filters_grade_result_values = _grade_section(filtersPassed, areFiltersExpected, (filter_credit * filter_credit_value)/100, filtersValueErrors, filter_value_fmt, report_grade)
    filters_grade_value = filters_grade_result_values.grade
    cumulative_grade += filters_grade_result_values

    filters_grade = None
    if filters_grade_field is not None and filters_grade_operator is not None and filters_grade_value is not None:
        filters_grade = int((filters_grade_field * filter_credit_field + filters_grade_operator * filter_credit_operator + filters_grade_value * filter_credit_value) / 100)

    # Sorting grading
    sortingPassed, isSortingExpected, sortingFieldErrors, sortingOrderErrors = sortingResults
    sort_field_fmt = "Expected sort by field '{}' but got '{}'"
    sorting_grade_result_field = _grade_section(sortingPassed, isSortingExpected, (sorting_credit * sorting_credit_field)/100, sortingFieldErrors, sort_field_fmt, report_grade)
    sorting_grade_field = sorting_grade_result_field.grade
    cumulative_grade += sorting_grade_result_field

    sort_order_fmt = "Expected sort by order '{}' but got '{}'"
    sorting_grade_result_order = _grade_section(sortingPassed, isSortingExpected, (sorting_credit * sorting_credit_order)/100, sortingOrderErrors, sort_order_fmt, report_grade)
    sorting_grade_order = sorting_grade_result_order.grade
    cumulative_grade += sorting_grade_result_order

    sorting_grade = None
    if sorting_grade_field is not None and sorting_grade_order is not None:
        sorting_grade = int((sorting_grade_field * sorting_credit_field + sorting_grade_order * sorting_credit_order) / 100)

    if areFieldsExpected or areFiltersExpected or isSortingExpected:
        grade = int(cumulative_grade.partial_credit * (100-report_credit) / cumulative_grade.max_credit) + int(report_grade_result.partial_credit * report_credit / report_grade_result.max_credit) if cumulative_grade.max_credit > 0 else 0
    else:
        # An incomplete test case that fails to get the right report would still fail if it were completed
        # If the correct report was selected, we still can't give full credit without the rest of the test case
        grade = report_grade if report_grade == 0 else None

    csv_gradebook.writerow([test_input, report_grade, fields_grade, filters_grade, sorting_grade, grade, ' | '.join(cumulative_grade.errors)])
    return grade

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_run_all_checks_for_input(test_input, populated_test_cases_internal, csv_gradebook):
    test_case = populated_test_cases_internal[test_input]
    if test_case.skip:
        pytest.skip(f"Skipping test case: {test_case.error}")
    elif test_case.error:
        csv_gradebook.writerow([test_input, None, None, None, None, 0, f"Test case setup failed: {test_case.error}"])
        assert False, f"Test case setup failed: {test_case.error}"

    reportResult = expected_reports_included_errors(test_case)

    areFieldsExpected = are_fields_expected_any(test_case.expected_output.reports)
    fieldsErrors = expected_fields_included_errors(test_case)
    fieldsPassed = areFieldsExpected and len(fieldsErrors) == 0

    areFiltersExpected = are_filters_expected_any(test_case.expected_output.reports)
    filtersFieldErrors = expected_filters_included_errors(test_case)
    filtersOperatorErrors = expected_filter_operators_errors(test_case)
    filtersValueErrors = expected_filter_values_errors(test_case)
    filtersPassed = areFiltersExpected and len(filtersFieldErrors) == 0 and len(filtersOperatorErrors) == 0 and len(filtersValueErrors) == 0

    isSortingExpected = is_sort_by_expected_any(test_case.expected_output.reports)
    sortingFieldErrors = correct_sort_by_field_errors(test_case)
    sortingOrderErrors = correct_sort_by_order_errors(test_case)
    sortingPassed = isSortingExpected and len(sortingFieldErrors) == 0 and len(sortingOrderErrors) == 0

    print(f"Test case: {test_input}")
    print(f"Fields Passed: {fieldsPassed if areFieldsExpected else 'N/A'}, Filters Passed: {filtersPassed if areFiltersExpected else 'N/A'}, Sorting Passed: {sortingPassed if isSortingExpected else 'N/A'}")

    partial_credit = grading(
        csv_gradebook,
        reportResult,
        (fieldsPassed, areFieldsExpected, fieldsErrors),
        (filtersPassed, areFiltersExpected, filtersFieldErrors, filtersOperatorErrors, filtersValueErrors),
        (sortingPassed, isSortingExpected, sortingFieldErrors, sortingOrderErrors),
        test_input
    )

    assert partial_credit is None or partial_credit > 0, f"Failed all checks for test case: {test_input}"

    if len(reportResult.difference) == 0 and (not areFieldsExpected or fieldsPassed) and (not areFiltersExpected or filtersPassed) and (not isSortingExpected or sortingPassed):
        print(f"All checks passed for test case: {test_input}")
        assert True
    else:
        assert partial_credit < 100, f"Partial credit should be less than 100 (got {partial_credit})"
        print(f"Partial credit for test case {test_input}: {partial_credit}")
        assert partial_credit >= passing_credit, f"Partial credit {partial_credit} is less than passing credit {passing_credit} for test case: {test_input}"