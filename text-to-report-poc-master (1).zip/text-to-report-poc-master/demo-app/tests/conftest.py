import asyncio
from more_itertools import flatten
import pytest
import requests
from concurrent.futures import ThreadPoolExecutor

from models.abstract_reporting_model import AbstractReportingModel
from structures.ssrs_structures import ReportFieldsFiltersResponse
from models.prompts import create_react_system_template
from tests.test_data_setup import create_expected_fields_and_filters
import csv
import os
from datetime import datetime
from unittest.mock import MagicMock, AsyncMock
from models.prompt_chain import PromptChainModel
from models.agentic_react_model import AgenticReactModel
from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_foundation.foundation.AuthTokenClient import AuthTokenClient
from seismic_foundation.foundation.MatrixClient import MatrixClient
from services.openai_llm_client import OpenAI_LLM_Client
from services.ssrs_client import SSRSClient
from tests.test_constants import REPORT_DESCRIPTIONS, REPORT_METADATA, TESTING_DATE
from typing import Callable
from tests.test_structs import LLMTestCase

@pytest.fixture(scope="session")
def mock_setup() -> tuple[ConfigProvider, SSRSClient]:
    config = MagicMock(spec=ConfigProvider)
    config.openai_api_key = os.getenv("OPENAI_API_KEY", "placeholder-api-key")
    config.azure_openai_api_version = "2025-04-01-preview"
    config.azure_openai_endpoint = "https://seismic-nonprod-eastus2.openai.azure.com/"
    config.client_id = "b7f33896-b598-11ea-9eae-4b2ac0c30688"
    config.client_secret = os.getenv("POC_CLIENT_SECRET", "placeholder-client-secret")
    config.azure_openai_deployment = "eastus2"
    config.seismic_env = "qa"
    config.auth_server = "https://auth-qa.seismic-dev.com"
    config.poc_users = [
        {
            "tenant": "qadisc",
            "user_id": "0252de2a-30a9-d12f-e021-67ebb5a62e12"
        },
        {
            "tenant": "apiqa2",
            "user_id": "70101569-ab3e-ee7b-030d-54d864d2138a"
        },
        {
            "tenant": "readinesscoachingqa",
            "user_id": "121830df-6bc2-482a-8b5b-f0b34b6243b4"
        }
    ]

    def get_auth_token_side_effect(scope, tenant) -> str:
        body = {
            "client_id": config.client_id,
            "client_secret": config.client_secret,
            "grant_type": "client_credentials",
            "scope": scope,
        }

        resp = requests.post(f"{config.auth_server}/tenants/{tenant}/connect/token", data=body)

        if resp.status_code != 200:
            raise Exception(
                f"Failed to get JWT, status_code: {resp.status_code}, resp: {resp.text}"
            )

        return resp.json()["access_token"]

    mock_auth_client = MagicMock(spec=AuthTokenClient)
    mock_auth_client.get_auth_token = MagicMock(side_effect=get_auth_token_side_effect)
    mock_matrix_client = MagicMock(spec=MatrixClient)
    mock_matrix_client.get_tenant_service = MagicMock(
        return_value="https://ssrs-edge-qa-az-westus-wombat.seismic-dev.com"
    )
    real_ssrs_client = SSRSClient(mock_matrix_client, mock_auth_client, config)

    # Create mock that wraps the real client
    mock_ssrs_client = MagicMock(spec=SSRSClient, wraps=real_ssrs_client)

    # Set up mock to return report metadata when queried
    async def get_metadata_side_effect(tenant, report_id, user=None):
        for report in REPORT_METADATA["reports"]:
            if report.get("id") == report_id:
                return report
        raise ValueError(f"Report ID {report_id} not found in metadata.")
    
    # ToDo: Replace this with an actual call to the SSRS client
    # This will require either mapping report IDs to the tenant's reports
    # or acquiring a test tenant with all standard reports.
    async def execute_report_side_effect(*args):
        tenant = args[0] if len(args) > 0 else None
        report_id = args[1] if len(args) > 1 else None
        return {
            "message": "Report executed successfully",
            "report_id": report_id,
            "tenant": tenant,
            "data": "Data is available!",
            "params": args[2] if len(args) > 2 else {},
        }
    
    def get_expected_reports(reports):
        result = []
        for report in reports:
            if hasattr(report, 'any'):
                result.extend(get_expected_reports(report.any))
            else:
                result.append(report)
        return result

    async def get_filter_values_only_mock_side_effect(tenant, report_id, filter_name):
        test_cases = create_expected_fields_and_filters()
        filter_values = []
        for test_case in test_cases:
            for report in get_expected_reports(test_case.expected_output.reports):
                if report.id == report_id:
                    for filter in report.additional_filters:
                        if filter.filter_name.lower() == filter_name.lower():
                            filter_values += filter.filter_values
        return filter_values

    # Gets both the real values as well as the ones in the test cases
    # In case the real tenant does not have the filter values in the test cases
    async def get_filter_values_side_effect(tenant, report_id, filter_name):
        real_values = await real_ssrs_client.get_filter_values(tenant, report_id, filter_name)
        if real_values is None or not isinstance(real_values, list):
            # Error when appropriate
            return real_values
        elif len(real_values) > 0:
            # If real values are found, return them along with the mock values
            return await get_filter_values_only_mock_side_effect(tenant, report_id, filter_name) + await real_ssrs_client.get_filter_values(tenant, report_id, filter_name)
        else:
            # If it should return values but didn't (no data), return the mock values
            return await get_filter_values_only_mock_side_effect(tenant, report_id, filter_name)

    # Uncomment to mock these SSRS client methods. Comment to use the real client.
    mock_ssrs_client.get_report_metadata = AsyncMock(side_effect=get_metadata_side_effect)
    #mock_ssrs_client.execute_report = AsyncMock(side_effect=execute_report_side_effect)
    #mock_ssrs_client.get_all_reports = AsyncMock(return_value={"data": REPORT_DESCRIPTIONS["reports"]})
    mock_ssrs_client.get_filter_values = AsyncMock(side_effect=get_filter_values_side_effect)
    return config, mock_ssrs_client

@pytest.fixture(scope="session")
def mock_reporting_model(
    mock_setup: tuple[ConfigProvider, SSRSClient],
    T: type[AbstractReportingModel] = AgenticReactModel,
) -> Callable[[str], AbstractReportingModel]:
    """Creates a AbstractReportingModel with mocked dependencies for testing"""
    # Mock config provider
    config, mock_ssrs_client = mock_setup

    # Create model instance with mocked dependencies
    return lambda tenant: T(
        config=config,
        ssrs_client=mock_ssrs_client,
        llm_client=OpenAI_LLM_Client(config),
        tenant=tenant,
        model_kwargs={"current_date": TESTING_DATE},
    )


def extract_report_ids(report):
    """Helper function to extract IDs from report objects"""
    if hasattr(report, 'any'):  # This is a ReportFieldsFiltersAnyOf
        return [r.id for r in report.any]
    else:  # This is a ReportFieldsFiltersRecommendationTestCase
        return [report.id]
    
def report_has_config(report):
    """Helper function to check if a report has configuration."""
    if (hasattr(report, "any") and report.any):
        return report_has_config(report.any[0])
    return (hasattr(report, "fields") and report.fields) or \
           (hasattr(report, "additional_filters") and report.additional_filters) or \
           (hasattr(report, "sort_by") and report.sort_by)

@pytest.fixture(scope="function")
def populated_test_case(populated_test_cases_internal: dict[str, LLMTestCase], request):
    """Fixture to get a populated test case by input string"""
    test_input = request.param
    if test_input in populated_test_cases_internal:
        test_case = populated_test_cases_internal[test_input]
        if (test_case.skip):
            pytest.skip(f"Skipping test case: {test_case.error}")
        assert test_case.error is None, f"Test case setup failed: {test_case.error}"
        return test_case
    else:
        raise ValueError(f"Test case with input '{test_input}' not found in populated test cases.")

@pytest.fixture(scope="session")
def populated_test_cases_internal(mock_reporting_model: Callable[[str], AbstractReportingModel], request):
    populated_test_cases = {}

    def process_case_sync(test_case):
        # Sync wrapper for the async operation
        async def _process():
            try:
                full_test = request.config.getoption("--full-test")
                if full_test:
                    result = await mock_reporting_model(test_case.tenant).answer_question(question=test_case.input)
                    test_case.actual_output = ReportFieldsFiltersResponse(
                            reports=result.get("fields_and_filters") if "fields_and_filters" in result and result.get("fields_and_filters") else []
                        )
                elif hasattr(test_case.expected_output, "reports") and len(test_case.expected_output.reports) > 0 and report_has_config(test_case.expected_output.reports[0]):
                    report_ids = list(flatten([extract_report_ids(report) for report in test_case.expected_output.reports]))
                    response = await mock_reporting_model(test_case.tenant).recommend_fields_and_filters(
                        question=test_case.input,
                        report_ids=report_ids,
                    )
                    if "error" in response and response.get("error"):
                        raise Exception(f"Agent failed: {response.get('answer', 'No answer in response')}")
                    test_case.actual_output = response.get("answer")
                else:
                    test_case.skip = True
                    test_case.error = "This test case has no reports or no report configuration"
                return test_case.input, test_case
            except Exception as e:
                print(f"Error processing test case '{test_case.input}': {type(e).__name__}: {str(e)}")
                test_case.actual_output = ReportFieldsFiltersResponse(reports=[])
                test_case.error = f"{type(e).__name__}: {str(e)}"
                return test_case.input, test_case
        
        return asyncio.run(_process())

    test_cases = create_expected_fields_and_filters()

    async def process_all_cases():
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=10) as executor:
            tasks = [
                loop.run_in_executor(executor, process_case_sync, test_case)
                for test_case in test_cases
            ]
            results = await asyncio.gather(*tasks)
            return results

    results = asyncio.run(process_all_cases())
    for input_str, test_case in results:
        populated_test_cases[input_str] = test_case

    return populated_test_cases


# --- CSV setup ---
CSV_FILENAME = None
CSV_FILE = None
CSV_WRITER = None


@pytest.fixture(scope="session")
def csv_gradebook():
    """Pytest hook to create a new CSV file at the start of the session."""
    global CSV_FILENAME, CSV_FILE, CSV_WRITER
    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    CSV_FILENAME = f"tests/grades/test-grades-{timestamp}.csv"
    CSV_FILE = open(CSV_FILENAME, mode="w", newline="", encoding="utf-8")
    CSV_WRITER = csv.writer(CSV_FILE)
    CSV_WRITER.writerow(
        ["input", "reports_grade", "fields_grade", "filters_grade", "sort_grade", "grade", "errors"]
    )
    return CSV_WRITER


def pytest_sessionfinish(session, exitstatus):
    """Pytest hook to close the CSV file at the end of the session."""
    global CSV_FILE
    if CSV_FILE:
        CSV_FILE.close()


def pytest_addoption(parser):
    """Add custom command line options for pytest."""
    parser.addoption(
        "--full-test",
        action="store_true",
        default=False,
        help="Run tests without providing report IDs (call answer_question instead)",
    )
