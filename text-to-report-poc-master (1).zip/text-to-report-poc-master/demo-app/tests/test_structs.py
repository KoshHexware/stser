from __future__ import annotations
from pydantic import BaseModel, Field, ConfigDict
from typing import Union, Optional, Annotated
from structures.ssrs_structures import (
    FilterRecommendation,
    SortRecommendation,
    ReportRecommendation,
    ReportResponse,
)

class FieldAnyOf(BaseModel):
    any: list[str]

# Union type for field that can be either a string or an "any" object
FieldRecommendationOption = Union[str, FieldAnyOf]

class FilterAnyOf(BaseModel):
    any: list[FilterRecommendationOption]

FilterRecommendationOption = Union[FilterRecommendation, FilterAnyOf]

class SortRecommendationAnyOf(BaseModel):
    any: list[SortRecommendationOption]

SortRecommendationOption = Union[SortRecommendation, SortRecommendationAnyOf]

class ReportsAnyOf(BaseModel):
    any: list[ReportRecommendationOption]

class ReportFieldsFiltersRecommendationTestCase(ReportRecommendation):
    fields: list[FieldRecommendationOption]
    additional_filters: Optional[
        Annotated[
            list[FilterRecommendationOption], Field(serialization_alias="additionalFilters")
        ]
    ] = None
    sort_by: Optional[
        Annotated[SortRecommendationOption, Field(serialization_alias="sortBy")]
    ] = None

ReportRecommendationOption = Union[ReportFieldsFiltersRecommendationTestCase, ReportsAnyOf, ReportRecommendation]

class ReportFieldsFiltersResponseTestCase(BaseModel):
    reports: list[ReportRecommendationOption]

# Rebuild models to resolve forward references
ReportFieldsFiltersRecommendationTestCase.model_rebuild()

expected_output_types = Union[ReportResponse, ReportFieldsFiltersResponseTestCase]

class LLMTestCase(BaseModel):
    input: str
    actual_output: dict
    tenant: Optional[str] = None
    expected_output: expected_output_types
    error: Optional[str] = None
    skip: bool = False