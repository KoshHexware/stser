from glob import glob
import os
import yaml


def load_yaml_data(file_path):
    with open(file_path, "r") as file:
        return yaml.safe_load(file)


def load_all_report_metadata(reports_dir):
    metadata = {"reports": []}
    for file_path in glob(os.path.join(reports_dir, "*.yml")):
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)
            if isinstance(data, list):
                metadata["reports"].extend(data)
            elif data:
                metadata["reports"].append(data)
    return metadata


""" UPDATE THIS FILE WITH YOUR TEST CASES """
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_DESCRIPTIONS = load_yaml_data(
    os.path.join(TEST_DIR, "../test_data/report_descriptions.yml")
)
# Combine all YAML files in the reports directory for REPORT_METADATA
REPORT_METADATA = load_all_report_metadata(
    os.path.join(TEST_DIR, "../test_data/reports")
)
FIELD_AND_FILTERS_TEST_CASES = load_yaml_data(
    os.path.join(TEST_DIR, "../test_data/test_cases.yml")
)
TESTING_DATE = "2025-06-01"
DEFAULT_TENANT = "qadisc"  # Default tenant for testing
