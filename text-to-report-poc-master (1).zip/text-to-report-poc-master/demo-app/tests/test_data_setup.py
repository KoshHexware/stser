import os
from structures.ssrs_structures import (
    ReportRecommendation,
    ReportResponse,
)
from tests.test_structs import (
    LLMTestCase,
    ReportFieldsFiltersRecommendationTestCase,
    ReportsAnyOf,
    ReportFieldsFiltersResponseTestCase,
)
from tests.test_constants import (
    FIELD_AND_FILTERS_TEST_CASES,
    DEFAULT_TENANT,
)


def create_report_from_dict(report_dict: dict):
    """Create the appropriate report type based on the dictionary structure"""
    if "any" in report_dict:
        # This is an "any" type with multiple options
        return ReportsAnyOf(
            any=[create_report_from_dict(r) for r in report_dict["any"]]
        )
    elif "fields" in report_dict or "additional_filters" in report_dict or "sort_by" in report_dict:
        # This is a regular report
        return ReportFieldsFiltersRecommendationTestCase(**report_dict)
    else:
        return ReportRecommendation(**report_dict)

def flatten_report_anys(reports):
    """Flattens the 'any' field in a report into a list of ReportFieldsFiltersRecommendationTestCase"""
    flattened = []
    for report in reports:
        if "any" in report:
            flattened.extend(flatten_report_anys(report["any"]))
        else:
            flattened.append(report)
    return flattened


def create_expected_fields_and_filters() -> list[LLMTestCase]:
    """Creates expected recommendations for testing"""
    return [
            LLMTestCase(
                input=test_case["q"],
                actual_output={},  # To be filled with actual output from the model
                tenant=test_case.get('tenant', DEFAULT_TENANT),
                expected_output=ReportFieldsFiltersResponseTestCase(
                    reports=[
                        create_report_from_dict(report)
                        for report in test_case["reports"]
                    ]
                ),
            )
            for test_case in FIELD_AND_FILTERS_TEST_CASES["test_cases"]
        ]


def create_expected_reports() -> list[LLMTestCase]:
    """Creates expected recommendations for testing"""
    
    test_cases=[
            LLMTestCase(
                input=test_case["q"],
                actual_output={},  # To be filled with actual output from the model
                tenant=test_case.get('tenant', DEFAULT_TENANT),
                expected_output=ReportResponse(
                    reports=[
                        ReportRecommendation(
                            id=report.get("id", "00000000-0000-0000-0000-000000000000"),
                            report_name=report.get("report_name", "Unknown Report"),
                        )
                        for report in flatten_report_anys(test_case["reports"])
                    ]
                ),
            )
            for test_case in FIELD_AND_FILTERS_TEST_CASES["test_cases"]
        ]

    return test_cases
