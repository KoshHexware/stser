from more_itertools import flatten
import pytest
from structures.ssrs_structures import TextOperations, SortRecommendation
from tests.test_data_setup import create_expected_fields_and_filters
from tests.test_constants import REPORT_METADATA
import re
from datetime import datetime
from .test_structs import LLMTestCase

test_case_inputs = [
    test_case.input for test_case in create_expected_fields_and_filters()
]

"""
Standard structure to hold results for grading in test_fields_and_filters_per_test.py
"""
class GradeableResult:
    def __init__(self, report_name: str, difference: list[str], expected_items: list[str], actual_items: list[str]):
        self.report_name = report_name
        self.difference = difference
        self.expected_items = expected_items
        self.actual_items = actual_items
    
    def __iter__(self):
        return iter((self.report_name, self.difference, self.expected_items, self.actual_items))
    
def expected_config_any_helper(expected_config, base_op):
    """Helper function to handle 'any' configurations in expected reports."""
    if hasattr(expected_config, 'any'):
        results = []
        for sub_config in expected_config.any:
            results += expected_config_any_helper(sub_config, base_op)
        if len(results) == len(expected_config.any):
            return [f"Any({', '.join(results)})"]
        return []
    else:
        return base_op(expected_config)
    
def reports_expected_any_helper(reports, base_op):
    """Check if any of the sub-reports of an 'any' have expected elements."""
    if not reports or len(reports) == 0:
        return False
    return any([reports_expected_any_helper(report.any, base_op) if hasattr(report, 'any') else base_op(report) for report in reports])

def expected_reports_included_errors(test_case: LLMTestCase) -> GradeableResult:
    """Helper function to check if expected reports are included in the actual output."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output

    assert hasattr(actual_output, "reports"), f"Actual output reports not found in `{actual_output}`"
    actual_report_names = [
        report.report_name.lower() for report in actual_output.reports
    ]
    difference = list(flatten([expected_config_any_helper(expected_report,
            lambda x: [x.report_name.lower()] if x.report_name.lower() not in actual_report_names else []
            ) for expected_report in expected_output.reports]))
    expected_reports = list(flatten([expected_config_any_helper(expected_report,
            lambda x: [x.report_name.lower()]
            ) for expected_report in expected_output.reports]))
    return GradeableResult(
        report_name=None,
        difference=difference,
        expected_items=expected_reports,
        actual_items=actual_report_names
    )

# Parametrize the test function with just the input strings
@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_expected_reports_included(populated_test_case):
    """Test that the output contains at least one of the expected reports."""
    test_case = populated_test_case
    _, errors, _, actual_reports = expected_reports_included_errors(test_case)

    if len(errors) > 0:
        assert False, f"Some expected reports {errors} were not found in the actual output: {actual_reports}"

def get_expected_report(expected_reports, report_name):
    """Helper function to get the expected report by name."""
    for report in expected_reports:
        if hasattr(report, 'any'):
            result = get_expected_report(report.any, report_name)
            if result:
                return result
        elif report.report_name.lower() == report_name.lower():
            return report
    return None

### FIELD CHECKS ###

def are_fields_expected(report):
    return report and hasattr(report, 'fields') and report.fields and len(report.fields) > 0

def are_fields_expected_any(reports):
    return reports_expected_any_helper(reports, are_fields_expected)

def expected_fields_included_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if expected fields are included in the actual output."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)

        if are_fields_expected(expected_report):
            actual_fields = [field for field in report.fields] if report.fields else []

            # check if the actual sort field is included in the actual fields
            expected_fields_config = expected_report.fields
            if report.sort_by and expected_report.sort_by:
                # check if the sort by is a correct answer (no credit otherwise)
                sort_results = correct_sort_by_field_errors(test_case)
                if len(sort_results) == 0:
                    expected_fields_config.append(f"{report.sort_by.field_name} *chosen sort field*")

            difference = list(flatten([expected_config_any_helper(field,
                lambda expected_field: ([expected_field] if expected_field.lower().replace(" *chosen sort field*", "") not in [f.lower() for f in actual_fields] else []
            )) for field in expected_fields_config]))
            expected_fields = list(flatten(expected_config_any_helper(field,
                lambda expected_field: [expected_field]
            ) for field in expected_fields_config))
            if len(difference) > 0:
                results.append(GradeableResult(report.report_name, difference, expected_fields, actual_fields))
    return results

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_expected_fields_included(populated_test_case):
    """Test that all expected fields are included in the output."""
    test_case = populated_test_case
    results = expected_fields_included_errors(test_case)

    # If no results, all expected fields are included
    if len(results) == 0:
        assert True
    for result in results:
        report_name, difference, _, actual_fields = result
        assert False, f"[{report_name}] Expected fields {difference} not found in actual output fields: {actual_fields}"

### FILTER CHECKS ###

def are_filters_expected(report):
    return report and hasattr(report, 'additional_filters') and report.additional_filters and len(report.additional_filters) > 0

def are_filters_expected_any(reports):
    return reports_expected_any_helper(reports, are_filters_expected)

def expected_filters_included_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if expected filters are included in the actual output."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)

        if are_filters_expected(expected_report):
            actual_filters = [
                filter.filter_name for filter in report.additional_filters
            ] if report.additional_filters else []
            difference = list(flatten(expected_config_any_helper(filter,
                    base_op=lambda expected: [expected.filter_name] if str(expected.filter_name.lower()) not in [f.lower() for f in actual_filters] else []
                ) for filter in expected_report.additional_filters))
            expected_filters = list(flatten(expected_config_any_helper(filter,
                    base_op=lambda expected: [expected.filter_name]
                ) for filter in expected_report.additional_filters))
            if len(difference) > 0:
                results.append(GradeableResult(report.report_name, difference, expected_filters, actual_filters))
    return results

def expected_filter_operators_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if expected filter operators are used."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)

        actual_filters = report.additional_filters if report.additional_filters else []
        if are_filters_expected(expected_report):
            difference = list(flatten(expected_config_any_helper(expected_filter,
                base_op=lambda expected_filter: 
                    [f"{expected_filter.filter_name}: {expected_filter.operation}"] 
                    if (expected_filter.filter_name.lower(), expected_filter.operation) not in [(f.filter_name.lower(), f.operation) for f in actual_filters] 
                    else []
            ) for expected_filter in expected_report.additional_filters))
            expected_filters = list(flatten(expected_config_any_helper(expected_filter,
                base_op=lambda expected_filter: 
                    [f"{expected_filter.filter_name}: {expected_filter.operation}"]
            ) for expected_filter in expected_report.additional_filters))
            if len(difference) > 0:
                results.append(
                    GradeableResult(
                        report.report_name,
                        difference,
                        expected_filters,
                        [f"{f.filter_name}: {f.operation}" for f in actual_filters],
                    )
                )
    return results

def expected_filter_values_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if expected filter values are used."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)
        
        def trunc_time_if_datetime_string(value, operation):
            """Check if value is a datetime string and convert to date-only ISO format."""
            if not isinstance(value, str):
                return value
            
            if re.match(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', value): # ISO datetime
                try:
                    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                    return dt.date().isoformat()
                except ValueError:
                    pass
            return lower_if_not_sensitive(value, operation)
        
        def lower_if_not_sensitive(value, operation):
            """Lowercase the value if it is not a sensitive field."""
            if isinstance(value, str) and operation.lower() not in [TextOperations.is_one_of, TextOperations.is_not_one_of]:
                return value.lower()
            return value
        

        actual_filters = report.additional_filters if report.additional_filters else []
        if are_filters_expected(expected_report):
            difference = list(flatten(expected_config_any_helper(expected_filter,
                base_op=lambda expected_filter:
                    [f"{expected_filter.filter_name}.{expected_filter.operation}: {set(expected_filter.filter_values)}"] 
                    if (expected_filter.filter_name.lower(), expected_filter.operation, set([lower_if_not_sensitive(f, expected_filter.operation) for f in expected_filter.filter_values])) not in 
                        [(f.filter_name.lower(), f.operation, set([trunc_time_if_datetime_string(v, f.operation) for v in f.filter_values])) for f in actual_filters] 
                    else []
                ) for expected_filter in expected_report.additional_filters))
            expected_filters = list(flatten(expected_config_any_helper(expected_filter,
                base_op=lambda expected_filter: 
                    [f"{expected_filter.filter_name}.{expected_filter.operation}: {set(expected_filter.filter_values)}"]
            ) for expected_filter in expected_report.additional_filters))
            if len(difference) > 0:
                results.append(
                    GradeableResult(
                        report.report_name,
                        difference,
                        expected_filters,
                        [f"{f.filter_name}.{f.operation}: {set([trunc_time_if_datetime_string(v, f.operation) for v in f.filter_values])}" for f in actual_filters],
                    )
                )

    return results

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_filter_operators_allowed(populated_test_case):
    """Test that all filter operators are allowed."""
    test_case = populated_test_case
    actual_output = test_case.actual_output
    errors = []

    for actual_report in actual_output.reports:
        if not are_filters_expected(actual_report):
            continue

        filters_metadata = []
        for report_def in REPORT_METADATA["reports"]:
            if report_def.get("id") == actual_report.id:
                filters_metadata = report_def.get("filtersMetadata", [])
                break
        actual_filters = actual_report.additional_filters if actual_report.additional_filters else []
        for actual_filter in actual_filters:
            for filter_metadata in filters_metadata:
                if actual_filter.filter_name.lower() == filter_metadata.get("uxLabel", "").lower():
                    allowed_operators = [op.get("name") for op in filter_metadata.get("allowedOperators", [])]
                    if actual_filter.get_operation() not in allowed_operators:
                        errors.append(
                            (
                                actual_report.report_name,
                                actual_filter.filter_name,
                                actual_filter.get_operation(),
                                allowed_operators,
                            )
                        )
    assert len(errors) == 0, (
        "Some filters used disallowed operations:\n" +
        "\n".join(
            f"[{report_name}] Filter '{filter_name}' used operation '{op}' (allowed: {allowed})"
            for report_name, filter_name, op, allowed in errors
        )
    )

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_expected_filters_included(test_input, populated_test_cases):
    """Test that all expected filters are included in the output."""
    test_case = populated_test_cases[test_input]
    assert test_case.error is None, f"Test case setup failed: {test_case.error}"

    results = expected_filters_included_errors(test_case)

    # If no results, all expected filters are included
    if len(results) == 0:
        assert True
    for result in results:
        report_name, difference, _, actual_filters = result
        assert False, f"[{report_name}] Expected filters {difference} not found in actual output filters: {actual_filters}"

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_expected_filter_operators(populated_test_case):
    """Test that all expected filter operators are used in the output."""
    test_case = populated_test_case
    results = expected_filter_operators_errors(test_case)

    # If no results, all expected filter operators are used
    if len(results) == 0:
        assert True
    for report_name, _, expected_ops, actual_ops in results:
        assert False, f"[{report_name}] Expected filter operator {expected_ops[0]} but got {actual_ops[0]}"

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_expected_filter_values(populated_test_case):
    """Test that all expected filter values are used in the output."""
    test_case = populated_test_case
    results = expected_filter_values_errors(test_case)

    # If no results, all expected filter values are used
    if len(results) == 0:
        assert True
    for report_name, _, expected_values, actual_values in results:
        assert False, f"[{report_name}] Expected filter values {expected_values} do not match actual output values: {actual_values}"

### SORTING CHECKS ###

def is_sort_by_expected(report):
    return report and hasattr(report, 'sort_by') and report.sort_by

def is_sort_by_expected_any(reports):
    return reports_expected_any_helper(reports, is_sort_by_expected)

def correct_sort_by_field_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if the correct sort_by field is used."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)

        if is_sort_by_expected(expected_report):
            actual_sort = report.sort_by if report.sort_by else SortRecommendation("<no sort field>", None)
            actual_field = actual_sort.field_name
            difference = expected_config_any_helper(expected_report.sort_by,
                base_op=lambda expected_sort: [expected_sort.field_name] if expected_sort.field_name.lower() != actual_field.lower() else []
            )

            if len(difference) > 0:
                results.append(GradeableResult(report.report_name, difference, difference, [actual_field]))
    return results

def correct_sort_by_order_errors(test_case: LLMTestCase) -> list[GradeableResult]:
    """Helper function to check if the sort_by order is correct."""
    expected_output = test_case.expected_output
    actual_output = test_case.actual_output
    results = []
    for report in actual_output.reports:
        expected_report = get_expected_report(expected_output.reports, report.report_name)

        if is_sort_by_expected(expected_report):
            actual_sort = report.sort_by if report.sort_by else SortRecommendation("<no sort field>", None)
            difference = expected_config_any_helper(expected_report.sort_by,
                base_op=lambda expected_sort: [f"{expected_sort.field_name}<{expected_sort.sort_order}>"]
                if expected_sort.field_name.lower() != actual_sort.field_name.lower() or expected_sort.sort_order != actual_sort.sort_order 
                else []
            )

            if len(difference) > 0:
                results.append(
                    GradeableResult(report.report_name, 
                        difference, 
                        difference, 
                        [f"{actual_sort.field_name}<{actual_sort.sort_order}>"]
                    ))
    return results

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_correct_sort_by_field(populated_test_case):
    """Test that the correct sort_by field is used."""
    test_case = populated_test_case
    results = correct_sort_by_field_errors(test_case)

    # If no results, all sort_by fields are correct
    if len(results) == 0:
        assert True
    for report_name, _, expected_fields, actual_fields in results:
        assert False, f"[{report_name}] Expected sort by field '{expected_fields[0]}' but got '{actual_fields[0]}'"

@pytest.mark.parametrize("test_input", test_case_inputs, ids=lambda x: x)
def test_correct_sort_by_order(populated_test_case):
    """Test that the sort_by order is correct."""
    test_case = populated_test_case
    errors = correct_sort_by_order_errors(test_case)
    assert len(errors) == 0, (
        "Some reports have incorrect sort_by order:\n" +
        "\n".join(
            f"[{report_name}] expected sort_by order '{expected_orders[0]}' but got '{actual_orders[0]}'"
            for report_name, _, expected_orders, actual_orders in errors
        )
    )
