from uuid import uuid4
import aiofiles
from fastapi import (
    FastAPI,
    Request,
    Response,
    Form,
    Cookie,
    Depends,
    HTTPException,
    status,
)
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from yaml import safe_load
import time
from kink import di
from contextvars import ContextVar
from typing import Any
from types import SimpleNamespace
from routers import tools, models
import structlog

from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_foundation.foundation.ServiceProvider import ServiceProvider
import seismic_auth as auth

from seismic_foundation.foundation.MatrixClient import MatrixClient

from models.prompt_chain import PromptChainModel
from models.agentic_react_model import AgenticReactModel
from models.agent_module_registry import AgentModuleRegistry
from services.ssrs_client import SSRSClient
from services.poc_auth_service import POCAuthService
from services.abstract_llm_client import AbstractLLMClient
from services.openai_llm_client import OpenAI_LLM_Client
from models.prompts import create_react_system_template
from util.logging import init_logging, _request_trace_id, _request_tenant_id, _request_user_id

# Admin users who can clear cache
ADMIN_EMAILS = [
    "mkeller@seismic.com",
    "awhitehead@seismic.com",
    "tprekaski@seismic.com",
    "jryan@seismic.com"
]

# init
app = FastAPI(root_path="/ras")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Initialize ServiceProvider
ServiceProvider.initialize(None)

app.include_router(tools.router, prefix="/tools", tags=["Tools"])
app.include_router(models.router, prefix="/models", tags=["Models"])

try:
    config = ServiceProvider.get_service(ConfigProvider)
    # hack while we wait for python-foundation to be fixed
    config.matrix_server = config.matrix_server_hack  # TODO: Fix config
    config.matrix_certificate_password = config.matrix_certificate_password_hack  
    config.certificate_path = config.certificate_path_hack

    init_logging(log_level=config.log_level, running_local=config.seismic_env == "local")
    logger = structlog.get_logger()

    # Dependency injection
    di[AbstractLLMClient] = ServiceProvider.get_service(OpenAI_LLM_Client)
except Exception as e:
    logger.error(f"Service initialization failed: {e}", exc_info=e)
    config = None


@app.middleware("http")
async def add_request_context(request: Request, call_next):
    # Set the current request in a context variable.
    request_token = _request_ctx.set(request)
    # Initialize a "g-like" object that allows attribute assignment.
    g_token = _g_ctx.set(SimpleNamespace())
    _request_trace_id.set(uuid4())

    try:
        response = await call_next(request)
        return response
    finally:
        _request_ctx.reset(request_token)
        _g_ctx.reset(g_token)

_request_ctx: ContextVar[Request] = ContextVar("request_ctx")
_g_ctx: ContextVar[Any] = ContextVar("g_ctx")


def get_request():
    return _request_ctx.get()


def get_context():
    return _g_ctx.get()


def custom_make_response(*args, **kwargs):
    if "status" in kwargs:
        kwargs["status_code"] = kwargs.pop("status")
    return Response(*args, **kwargs)


origins = [
    r"https:\/\/.*\.seismic\.com",
    r"https:\/\/.*\.seismic-dev\.com",
    r"https:\/\/.*\.seismic-cn\.com"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

auth.init(get_request, get_context, custom_make_response, tier="all")


def check_login(logged_in: Optional[str] = Cookie(None, alias="logged-in")):
    if logged_in is None or logged_in != "true":
        raise HTTPException(
            status_code=status.HTTP_302_FOUND,
            detail="Not authenticated",
            headers={"Location": "/login"}
        )
    return True


# TODO cache or remove!
async def stock_questions():
    async with aiofiles.open("questions.yml", "r") as file:
        content = await file.read()
        return safe_load(content)


async def stock_self_service_reports(tenant):
    # Fetch reports from SSRS
    client = ServiceProvider.get_service(SSRSClient)
    reports_response = await client.get_all_reports(tenant)

    # Check if the response contains an error
    if "error" in reports_response:
        return templates.TemplateResponse(
            "response.html.j2",
            {"answer": f"Error fetching reports: {reports_response['error']}"},
        )

    # Extract reports data
    return reports_response.get("data", [])


@app.post("/process-login")
def process_login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...)
):
    try:
        auth = ServiceProvider.get_service(POCAuthService)

        if auth.authorize_login(email, password):
            response = templates.TemplateResponse("login-ok.html", {"request": request})
            response.set_cookie("logged-in", "true", secure=False)
            response.set_cookie("user-email", email, secure=False)
            return response

        return templates.TemplateResponse(
            "login-fail.html.j2",
            {"request": request, "message": "Unknown user or password"}
        )
    except Exception as e:
        return templates.TemplateResponse(
            "login-fail.html.j2",
            {"request": request, "message": f"Error: {str(e)}."}
        )


@app.get("/login")
def login(request: Request):
    return templates.TemplateResponse("login.html.j2", {"request": request})


@app.get("/logout")
def logout():
    response = RedirectResponse(url="/login", status_code=302)
    response.set_cookie("logged-in", "false", secure=False)
    response.set_cookie("user-email", "", secure=False, max_age=0)
    return response


@app.get("/about")
def about(request: Request, authenticated: bool = Depends(check_login)):
    return templates.TemplateResponse("about.html", {"request": request})


@app.get("/")
async def demo(request: Request, authenticated: bool = Depends(check_login)):
    try:
        tenants = []
        if config and hasattr(config, 'poc_users') and config.poc_users:
            tenants = [user["tenant"] for user in config.poc_users]

        # Get user email from cookie to determine if they're an admin
        user_email = request.cookies.get("user-email", "")
        is_admin = user_email in ADMIN_EMAILS

        return templates.TemplateResponse(
            "demo.html.j2",
            {
                "request": request,
                "questions": await stock_questions(),
                "prompt_options": AgentModuleRegistry.report_recommendation_agent_options,
                "default_prompt_options": AgentModuleRegistry.default_report_recommendation_agent_options,
                "default_react_system_prompt": create_react_system_template(),
                "tenants": tenants,
                "user_email": user_email,
                "is_admin": is_admin,
            }
        )
    except Exception as e:
        return templates.TemplateResponse(
            "response.html.j2",
            {"request": request, "answer": f"Error: {str(e)}."}
        )


@app.post("/go")
async def go(
    request: Request,
    question: str = Form(...),
    tenant: str = Form(...),
    promptOptions: Optional[str] = Form(None),
    reactSystemPrompt: Optional[str] = Form(None),
    model: str = Form("prompt-chain"),  # default if not set
):
    logger.info(f"Received question: \"{question}\"", question=question, tenant=tenant, model=model)
    prompt_options = promptOptions.split(",") if promptOptions else []
    react_system_prompt = reactSystemPrompt
    model_choice = model

    _request_tenant_id.set(f"RAS UX - {tenant}")
    _request_user_id.set(f"RAS UX - {request.cookies.get('user-email', '')}")

    try:
        start_time = time.time()  # Start timing

        # Select the model based on user input
        result = None
        if model_choice == "agentic-react":
            try:
                # Create a new instance of AgenticReactModel with tenant and model_kwargs
                # TODO does this take awhile? Time it!
                matrix = ServiceProvider.get_service(MatrixClient)

                model_kwargs = {
                    "system_prompt": react_system_prompt,
                    "llmg_endpoint": matrix.get_tenant_service(tenant, "llmg"),
                    "chosen_prompt_options": prompt_options,
                }
                model = AgenticReactModel(
                    config=ServiceProvider.get_service(ConfigProvider),
                    ssrs_client=ServiceProvider.get_service(SSRSClient),
                    tenant=tenant,
                    model_kwargs=model_kwargs,
                )
                # Get the answer from the model
                result = await model.answer_question(question=question)
            except Exception as e:
                return templates.TemplateResponse(
                    "response.html.j2",
                    {"request": request, "answer": f"Error: {str(e)}."}
                )
        else:
            # Create a new instance of PromptChainModel with tenant and model_kwargs
            model_kwargs = {
                "chosen_prompt_options": prompt_options,
            }
            model = PromptChainModel(
                config=ServiceProvider.get_service(ConfigProvider),
                ssrs_client=ServiceProvider.get_service(SSRSClient),
                llm_client=ServiceProvider.get_service(AbstractLLMClient),
                tenant=tenant,
                model_kwargs=model_kwargs,
            )
            # Get the answer from the model
            result = await model.answer_question(question=question)

        elapsed_time = time.time() - start_time  # Calculate elapsed time
        logger.info(f"Execution time: {elapsed_time:.2f} seconds", elapsed_time=f"{elapsed_time:.2f}", question=question)  # Log the time
        logger.info(f"Tokens spent: {result.get('token_usage', 0)}", token_usage=f"{result.get('token_usage', 0)}", question=question)  # Log tokens spent

        if result.get("error"):
            return templates.TemplateResponse(
                "response.html.j2",
                {"request": request, "answer": result["final_answer"]}
            )

        # Render the template with the results
        return templates.TemplateResponse(
            "response.html.j2",
            {
                "request": request,
                "answer": result["final_answer"],
                "fields_and_filters": result["fields_and_filters"],
                "convos": result["conversations"],
                "responseData": result["response_data"],
                "elapsed_time": elapsed_time,
                "token_usage": result.get("token_usage", 0)
            }
        )

    except Exception as e:
        return templates.TemplateResponse(
            "response.html.j2",
            {"request": request, "answer": f"Error: {str(e)}"}
        )


@app.post("/clear")
def clear(request: Request):
    return templates.TemplateResponse("clear.html", {"request": request})


@app.post("/clear-cache")
async def clear_cache(request: Request, authenticated: bool = Depends(check_login)):
    # Get the user's email from the cookie
    user_email = request.cookies.get("user-email", "")
    # Check if user is an admin
    if user_email not in ADMIN_EMAILS:
        return templates.TemplateResponse(
            "response.html.j2",
            {"request": request, "answer": "Access denied. Admin privileges required."}
        )

    try:
        # Clear all caches for all tenants
        client = ServiceProvider.get_service(SSRSClient)
        client.clear_cache()

        return templates.TemplateResponse(
            "response.html.j2",
            {"request": request, "answer": "Cache cleared successfully!"}
        )
    except Exception as e:
        return templates.TemplateResponse(
            "response.html.j2",
            {"request": request, "answer": f"Error clearing cache: {str(e)}"}
        )
