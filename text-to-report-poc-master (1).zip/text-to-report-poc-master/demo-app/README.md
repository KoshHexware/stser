# What is this app?

It's a simple FastAPI web app that we can use to demonstrate our progress toward the text-to-report use case.
Our team and stakeholders can use the app at anytime to try out our most-current solution.

The basic user flow will be:
- Login
- Enter a analytics question (eg. Who sent the most livesends in April?)
- Optionally, enter some additional context:
  - Which reports are available to this imagined tenant and user?
  - Where is the user in the Seismic application? On a SSR page or somewhere else?
- See the answer to the question!
  - A explanation from the LLM about why the chosen report is a good answer (describing the fields and filters)
  - The first 3 rows of data from the report to help motivate how good an answer it has constructed
- Also see the conversations the system had with the LLM
  - This will help us all understand what's happening and offer suggestions

# Why python?
Python has the richest ecosystem when it comes to generative AI work. Our final implementation will likely be done 
in/with the [aiml-agent-service](https://github.com/seismic/aiml-agent-service/), which is python based. 
If we want code reuse, we should just start in python from day one.

# Deployment
[Wombat K8s deployment](https://reporting-agent-qa-disc.seismic-dev.com/)

# Local Setup

1. `sh ./scripts/render-local.sh` (create the demo-app/config/instance-config.json file, needs AWS secret mgr)
1. `cd demo-app`
1. `python -m venv venv`
1. `source venv/bin/activate`
1. `export CONFIG_PATH=config/`
1. `pip install -r ../requirements.txt` (needs pip set up with JFrog, follow the "Set me up" instructions for pypi)
1. `uvicorn app:app --reload --host 127.0.0.1 --port 5000` (run FastAPI app with hot reload)

Hints: 
- Use python 3.12 which works with the seismic_foundation library. The 3.13 version can't install it.
- After starting the app, you can access the automatic FastAPI documentation at `http://localhost:5000/docs`
- The app has been migrated from Flask to FastAPI for better performance and modern Python features

# Simple Auth System
We have not set up with Seismic auth for users. If you are an authorized user, we have given you a password you can use. If you are not an authorized user, and you think you should be, you can ask for creds in #proj-agent-service.

### Generating a password

Generating passwords locally can be simply done in your command line using the `email` and `signature_key` of the targeted environment:
```
echo -n "email@email.com/signature_key" | md5sum
```
You can also use the `scripts/render-creds.sh` script.

# Developing

## Agent Models Overview

We have implemented two different approaches for handling text-to-report queries:

### 1. Prompt Chain Model (`PromptChainModel`)
The traditional approach that uses a series of individual prompts in sequence:

1. **Report Selection**: Find report(s) that can answer the question
2. **Report Configuration**: Configure the report(s) (select fields, filters, sort)
3. **Report Execution**: Call SSRS to get the first few results
4. **Final Answer**: Display & explain the results

### 2. Agentic ReAct Model (`AgenticReactModel`) 
A more advanced approach using the ReAct (Reasoning + Acting) pattern with LangGraph:

- **Autonomous Decision Making**: The agent decides which tools to use and when
- **Tool-Based Architecture**: Uses specialized tools for different operations
- **Iterative Problem Solving**: Can make multiple tool calls to solve complex queries
- **Structured Output**: Returns consistent, structured responses

## Prompts and Agent Modules (Prompt Chain Model)

The prompt chain model uses modular agent components. Each solution, or "agent module", takes a list of reports along with metadata and filters down to reports that can potentially answer a given question. 

The agent modules are listed in `models/agent_module_registry.py` and are defined in `models/report_recommendation_agent_modules.py`. All of the prompts are defined in `models/prompts.py`. New modules can be created by implementing the `AbstractReportRecommendationAgentModule` abstract class defined in `models/abstract_agent_modules.py`.

As of this writing, there has not been any need to create abstration for the report configuration step. A stub class, `AbstractReportConfigurationAgentModule`, does exist in `models/abstract_agent_modules.py` and could be expanded if the need arises.
The single prompt for report configuration is located in `models/prompts.py` and it is currently called in `models/prompt_chain.py`.

There is one additional prompt in `models/prompts.py`, the "final answer" prompt. This takes a report configuration input and produces a concise, natural language representation of the result.

## Agentic ReAct Model Architecture

The `AgenticReactModel` uses a fundamentally different approach based on the ReAct pattern:

### Tools Available to the Agent
The agent has access to three main tools (defined in `tools/reporting_tools.py`):

1. **`describe_available_reports`**: Gets all available reports with basic metadata
2. **`fetch_metadata_by_report_id`**: Fetches detailed metadata for specific reports
3. **`execute_report`**: Executes reports with given field and filter configurations

### How the Agent Works
1. **Question Analysis**: The agent analyzes the user's question
2. **Tool Selection**: Decides which tools to call and in what order
3. **Information Gathering**: May call multiple tools to gather necessary information
4. **Decision Making**: Uses the ReAct pattern to reason about the information
5. **Response Generation**: Provides a structured response with the final answer

### Customizing the ReAct System Prompt

The system prompt for the agentic model is crucial for its behavior. You can customize it in several ways:

#### 1. Using the Web Interface
- Select "Agentic ReAct" model in the dropdown
- Modify the "React System Prompt" text area
- The default prompt is loaded from `create_react_system_template()` in `models/prompts.py`

#### 2. Modifying the Default Template
Edit the `create_react_system_template()` function in `models/prompts.py`:

```python
def create_react_system_template():
    return """
    # Your custom system prompt here
    You are an expert data analyst...
    
    Available tools:
    - describe_available_reports: Get list of all reports
    - fetch_metadata_by_report_id: Get detailed report metadata  
    - execute_report: Execute reports with specific configurations
    
    Current date: {current_date}
    
    Begin!
    
    Question: {input}
    """
```

#### Key Prompt Elements
- **Role Definition**: Define the agent's expertise and personality
- **Tool Usage Guidelines**: How and when to use each tool
- **Output Format**: Specify the expected response structure
- **Date Handling**: Use `{current_date}` placeholder for dynamic date injection
- **Reasoning Instructions**: Guide the agent's decision-making process

### Debugging and Development

#### Testing Prompts
Use the web interface to quickly test prompt modifications:
1. Go to the demo page
2. Select "Agentic ReAct" model
3. Modify the system prompt
4. Test with various questions
5. Check the conversation log to see agent reasoning

This allows you to test tool functionality independently of the agent.

# API Endpoints
The app exposes several API endpoints to support testing and interaction with the AIML Agent Service.

**Note:** All endpoints require authentication with a Seisimic bearer token with `reporting` scope.

For detailed request/response schemas and interactive testing, visit the FastAPI docs at `https://reporting-agent-qa-disc.seismic-dev.com/docs`.

## Model Endpoints

The functionality of interacting with our model is also exposed via endpoints. For each endpoint, the user can specify either the `prompt-chain` or `agentic-react` model for use.

- `POST /models/recommend-reports`: Provides a list of viable reports containing information with suitable fields and filters for answering a question.
- `POST /models/recommend-fields-and-filters`: Given a list of report ID's, select fields, filters, and a sort by field to answer a question.

## Tool Endpoints

Each tool used by the agent is also available as a standalone API endpoint for integration with the AIML Agent Service. These responses contain a block of `data` that is designed to be easily consumed by the LLM.

- `GET /tools/describe-available-reports`: Returns a list of all available reports and their basic metadata.
- `GET /tools/fetch-metadata-by-report-id`: Given a report ID, returns a detailed metadata for that report (fields, filters, etc.).
- `POST /tools/execute-report`: Executes a report with specified fields and filters, returning the first few rows of data.

# Testing

## Testing With Pytest

All of the test cases are runnable with pytest.
`demo-app/test_data/test_cases.yml` contains several test cases that contain the structured output of expected responses to appropriately answer several example questions for Self-Service Reports. Our LLM generates response in the same structure, and we use metrics to quantify the quality of each response on several evaluatio criteria.

To run the tests locally:
1. Install the required dependencies. (needs pip set up with JFrog, follow the "Set me up" instructions for pypi. Make sure the JFrog URL is listed as an `extra-index-url`)
    ```
    pip install -r requirements.txt
    ```
1. Set the environment variable `OPENAI_API_KEY` to one of the values found in 1Password (`DISC SSR Agent (RAS) OpenAI Development KEY`)
1. `cd demo-app`
1. `pytest tests/test_report_selection.py`

You can specify additional arguments to pytest, such as `-k` to select particular tests by keyword, `-n` to run the tests with a number of parallel processes, `--count` to run the tests a number of times, or `-vv` to see the 
full, unredacted output. [Learn more here](https://docs.pytest.org/en/6.2.x/usage.html) or with `pytest -h`.

### The pytest tests

1. `test_report_selection` takes the test cases in `test_data/report_selection_test_cases.yml` and makes sure that for each test case, the agent returns the correct report(s)
    * By default, the tests run using the default report recommendation prompt options defined in `models/agent_module_registry.py`. You can edit the call to recommend_reports in `test_report_selection.py` to test different options
1. `test_fields_and_filters_selection` uses the test cases in `test_data/test_cases.yml` and checks that they are configured correctly. There are several test methods, each focused on a different aspect of the configuration
1. `test_fields_and_filters_per_test` runs the same checks as `test_fields_and_filters_selection`, but then weighs the results of each test case to find an overall "grade" for each test case. The weights are configured in 
`test_fields_and_filters_per_test`. These grades are stored as a CSV in `tests/grades`, where they can be used for analysis and comparison. Excel's "Format as Table" function can be helpful for viewing these results.
    * Note: it is not recommended to run this suite with the `-n` option

