import functools
import time
import asyncio
import inspect
import structlog


def timer(func):
    """Timer decorator that works with both sync and async functions."""
    logger = structlog.get_logger()
    if inspect.iscoroutinefunction(func):
        # Async version
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            method_name = func.__name__

            # Get class name if this is a method
            class_name = ""
            if args and hasattr(args[0], "__class__"):
                class_name = f"{args[0].__class__.__name__}."

            try:
                logger.info(f"TIMER START: {class_name}{method_name}", class_name=class_name, method=method_name)
                result = await func(*args, **kwargs)
                duration = (time.time() - start_time) * 1000
                logger.info(
                    f"TIMER END: {class_name}{method_name} completed in {duration:.1f}ms",
                    class_name=class_name,
                    method=method_name,
                    duration=duration
                )
                return result
            except Exception as e:
                duration = (time.time() - start_time) * 1000
                logger.error(
                    f"TIMER ERROR: {class_name}{method_name} FAILED in {duration:.1f}ms - {str(e)}",
                    class_name=class_name,
                    method=method_name,
                    duration=duration,
                    exc_info=e
                )
                raise

        return async_wrapper
    else:
        # Sync version
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            method_name = func.__name__

            # Get class name if this is a method
            class_name = ""
            if args and hasattr(args[0], "__class__"):
                class_name = f"{args[0].__class__.__name__}."

            try:
                logger.info(f"TIMER START: {class_name}{method_name}", class_name=class_name, method=method_name)
                result = func(*args, **kwargs)
                duration = (time.time() - start_time) * 1000
                logger.info(
                    f"TIMER END: {class_name}{method_name} completed in {duration:.1f}ms",
                    class_name=class_name,
                    method=method_name,
                    duration=duration
                )
                return result
            except Exception as e:
                duration = (time.time() - start_time) * 1000
                logger.error(
                    f"TIMER ERROR: {class_name}{method_name} FAILED in {duration:.1f}ms - {str(e)}",
                    class_name=class_name,
                    method=method_name,
                    duration=duration,
                    exc_info=e
                )
                raise

        return sync_wrapper
