from enum import Enum
import structlog

class FieldDetailLevel(Enum):
    none = 0
    names_only = 1
    names_and_descriptions = 2
    key_names_only = 3
    key_names_and_descriptions = 4
    names_and_descriptions_and_filters = 5


class MetricDetailLevel(Enum):
    none = 0
    names_only = 1
    names_and_descriptions = 2


class FilterDetailLevel(Enum):
    none = 0
    names_only = 1
    names_and_descriptions = 2
    names_descriptions_and_operations = 3

max_filter_values = 50

def _get_regular_fields(report):
    """Extract regular fields from report metadata."""
    return [
        field
        for fg in report.get("standardReportMetadata", {}).get("fieldGroups", [])
        for field in fg.get("fields", [])
        if not field.get("isProperty", False)
    ]


def _get_metrics(report):
    """Extract metrics from the 'KPI and metrics' field group."""
    for group in report.get("standardReportMetadata", {}).get("fieldGroups", []):
        if group.get("uxLabel") == "KPI and metrics":
            return group.get("fields", [])
    return []


def _get_filter_groups(report):
    """Extract filter groups from report metadata."""
    return report.get("standardReportMetadata", {}).get("filterGroup", [])


def _get_all_metadata_fields(report_metadata):
    """Extract all metadata fields for processing."""
    return [
        field
        for fg in report_metadata.get("standardReportMetadata", {}).get("fieldGroups", [])
        for field in fg.get("fields", [])
        if not field.get("isProperty", False)
    ]


def filters_that_are_not_fields(report):
    """Most filters are over fields that can appear in the report - but not all! Let's find 'em."""
    regular_fields = _get_regular_fields(report)
    filter_groups = _get_filter_groups(report)
    
    not_field_filters = []
    
    for g in filter_groups:
        for f in g.get("filters", []):
            if not f.get("isProperty", False):
                f_label = f.get("uxLabel", "")
                maybe_fields = [field for field in regular_fields if field.get("uxLabel", "?") == f_label]
                if len(maybe_fields) == 0:
                    not_field_filters.append(
                        (
                            f_label,
                            f.get("uxDescription"),
                            f.get("dataType", "Unknown"),
                            [op.get("name") for op in f.get("allowedOperators", [])],
                        )
                    )
    return not_field_filters


def field_descriptions(report, detail_level):
    if detail_level == FieldDetailLevel.none:
        return ""

    regular_fields = _get_regular_fields(report)
    metrics = _get_metrics(report)
    key_fields = [field for field in regular_fields if field.get("isDefault", False) and field not in metrics]

    if detail_level == FieldDetailLevel.key_names_only:
        return f"\nKey Fields: {', '.join([field.get('uxLabel') for field in key_fields])}"

    if detail_level == FieldDetailLevel.key_names_and_descriptions:
        summary = "\nKey Fields:"
        for field in key_fields:
            summary += f"\n  {field.get('uxLabel', 'Unknown Field')}: {field.get('uxDescription', 'No description available.')}"
        return summary

    if detail_level == FieldDetailLevel.names_and_descriptions:
        summary = "\nReport Fields:"
        for rf in regular_fields:
            field_label = rf.get('uxLabel', 'Unknown Field')
            field_desc = rf.get('uxDescription', 'No description available.')
            summary += f"\n  {field_label}: {field_desc}"
        return summary

    if detail_level == FieldDetailLevel.names_and_descriptions_and_filters:
        summary = "\nReport Fields:"
        for rf in regular_fields:
            field_label = rf.get("uxLabel", "Unknown Field")
            field_desc = rf.get("uxDescription", "No description available.")
            field_data_type = rf.get("dataType", "Unknown")
            has_generic_filters = rf.get("hasGenericFilters", True)
            summary += f"\n  {field_label} [{field_data_type}]: {field_desc}"
            if not has_generic_filters:
                summary += " (No generic filters available)"
        return summary

    return f"\nFields: {', '.join([field.get('uxLabel', 'Unknown Field') for field in regular_fields])}"


def metric_descriptions(report, detail_level):
    if detail_level == MetricDetailLevel.none:
        return ""

    metrics = _get_metrics(report)

    if detail_level == MetricDetailLevel.names_only:
        return "\nMetrics: " + ', '.join([metric.get("uxLabel", "Unknown Metric") for metric in metrics])

    if detail_level == MetricDetailLevel.names_and_descriptions:
        summary = "\nMetrics:"
        for metric in metrics:
            metric_name = metric.get("uxLabel", "Unknown Metric")
            metric_description = metric.get("uxDescription", "No description available.")
            summary += f"\n  {metric_name}: {metric_description}"
        return summary


def filter_descriptions(report, detail_level):
    if detail_level == FilterDetailLevel.none:
        return ""

    filters = filters_that_are_not_fields(report)

    if detail_level == FilterDetailLevel.names_only:
        return f"\nAdditional Filters: {', '.join([f[0] for f in filters])}"

    if detail_level == FilterDetailLevel.names_and_descriptions:
        summary = "\nAdditional Filters:"
        for filter in filters:
            summary += f"\n  {filter[0]}: {filter[1]}"
        return summary

    if detail_level == FilterDetailLevel.names_descriptions_and_operations:
        summary = "\nAdditional Filters:"
        for f in filters:
            summary += (
                f"\n  {f[0]} [{f[2]}]: {f[1]} (Allowed operations: {', '.join(f[3])})"
            )
        return summary


def report_summary(
    report,
    field_details=FieldDetailLevel.names_and_descriptions,
    metric_details=MetricDetailLevel.names_and_descriptions,
    filter_details=FilterDetailLevel.names_and_descriptions,
):
    summary = f"""Report Name: {report.get("reportName")}
Report Id: {report.get("id")}
Report Description: {report.get("description", "No description available.").strip()}"""
    summary += field_descriptions(report, field_details)
    summary += metric_descriptions(report, metric_details)
    summary += filter_descriptions(report, filter_details)
    summary += "\n"

    return summary


def fix_fields_for_execute(report_metadata, fields):
    field_names = []
    meta_fields = _get_all_metadata_fields(report_metadata)
    
    for given_field in fields:
        for meta_field in meta_fields:
            if given_field == meta_field.get("uxLabel"):
                field_names.append(meta_field.get("name"))
                break
    return field_names


def fix_filters_for_execute(report_metadata, filters):
    try:
        corrected_filters = []
        filter_groups = _get_filter_groups(report_metadata)

        for given_filter in filters:
            for meta_filter_group in filter_groups:
                for meta_filter in meta_filter_group.get("filters", []):
                    if given_filter.filter_name == meta_filter.get("uxLabel"):
                        operation = given_filter.get_operation()

                        values = []
                        for v in given_filter.filter_values:
                            if v == "true" or v == "false":
                                v = v.capitalize()
                            values.append(v)

                        new_filter = {
                            "filterName": meta_filter.get("filterName"),
                            "operation": operation,
                            "values": values
                        }
                        corrected_filters.append(new_filter)
                        break

        if len(corrected_filters) != len(filters):
            raise ValueError(
                f"Expected {len(filters)} filters, but got {len(corrected_filters)}"
            )
        return corrected_filters
    except Exception as e:
        structlog.get_logger().error(f"Error fixing filters for execution: {e}", exc_info=True)
        return []


async def extract_ssrs_filter_values(
    report, filter_ux_name, get_values_callback
) -> tuple[bool, str]:
    """Internal function to get filter domain values. Returns (success, values_or_message)."""
    report_id = report.get("id")
    filter_groups = _get_filter_groups(report)

    for group in filter_groups:
        for filter in group.get("filters", []):
            if filter.get("uxLabel") == filter_ux_name:
                filter_name = filter.get("filterName")
                if filter.get("filterType") == "domainOfValues":
                    # If the filter is a domain of values, return the values
                    domain_values = filter.get("domainValues", [])
                    return True, domain_values
                elif filter.get("filterPicklistQuery"):
                    values = await get_values_callback(filter_name)
                    if values and isinstance(values, list) and len(values) > 0:
                        if len(values) > max_filter_values:
                            return (
                                False,
                                f"Filter {filter_ux_name} in report {report_id} has more values than can be returned. Here are some example values: {values[:max_filter_values]}.",
                            )
                        return True, values
                    else:
                        return (
                            False,
                            f"Error: Filter {filter_ux_name} in report {report_id} did not return any values for its domain.",
                        )
                else:
                    return (
                        False,
                        f"Filter {filter_ux_name} in report {report_id} has no domain of values. Any value is acceptable.",
                    )

    return (
        False,
        f"Error: Filter `{filter_ux_name}` not found in report {report_id} metadata.",
    )


def fields_to_ux_name_pairs(report_metadata, fields: list[str]) -> list[dict]:
    """Return [{ux_name, name}] by mapping UX labels to internal field names.

    Assumptions:
      - fields is a list of UX labels (values of field['uxLabel']).
      - If a UX label is not found, echo it for both keys.
    """
    pairs: list[dict] = []
    if not fields:
        return pairs

    meta_fields = _get_all_metadata_fields(report_metadata) or []
    by_ux = {mf.get("uxLabel"): mf for mf in meta_fields if mf.get("uxLabel")}

    for key in fields:
        ux_label = str(key)
        meta = by_ux.get(ux_label)
        internal = meta.get("name") if meta else ux_label
        ux_description = meta.get("uxDescription") if meta else ""
        pairs.append(
            {"ux_name": ux_label, "name": internal, "ux_description": ux_description}
        )
    return pairs


def filters_to_ux_name_pairs(report_metadata, filters: list[str]) -> list[dict]:
    """Return [{ux_name, name}] by mapping UX labels to internal filter names.

    Assumptions:
      - filters is a list of UX labels (values of filter['uxLabel']).
      - If a UX label is not found, echo it for both keys.
    """
    pairs: list[dict] = []
    if not filters:
        return pairs

    filter_groups = _get_filter_groups(report_metadata) or []
    meta_filters = [f for g in filter_groups for f in g.get("filters", [])]
    by_ux = {mf.get("uxLabel"): mf for mf in meta_filters if mf.get("uxLabel")}

    for key in filters:
        ux_label = str(key)
        meta = by_ux.get(ux_label)
        internal = meta.get("filterName") if meta else ux_label
        pairs.append({"ux_name": ux_label, "name": internal})
    return pairs
