import asyncio
import yaml
import json
import os
from services.ssrs_client import SSRSClient
from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_foundation.foundation.ServiceProvider import ServiceProvider

"""
Fetch metadata for all reports and save to a YAML file for testing purposes,
extracting only the necessary fields: report name, id, filters, fields, and allowed operators.
"""
print("Fetching report metadata for testing...")

# Initialize the SSRS client
ServiceProvider.initialize()

config = ServiceProvider.get_service(ConfigProvider)
# hack while we wait for python-foundation to be fixed
config.matrix_server = "https://matrix-qa.seismic-dev.com"
config.matrix_certificate_password = config.matrix_certificate_password_hack
config.certificate_path = "config/qa-matrix-cert.pfx"
client = ServiceProvider.get_service(SSRSClient)

# Not every tenant might have the same reports, so you might need to use more than qadisc
tenant = "qadisc"
#tenant = "apiqa2"

"""
Fetch metadata for all reports and save to a YAML file for testing purposes,
extracting only the necessary fields: report name, id, filters, fields, and allowed operators.
"""
print("Fetching report metadata for testing...")

# Get all reports
reports_response = asyncio.run(client.get_all_reports(tenant))

reports = reports_response.get("data", [])
print(f"Found {len(reports)} reports")

# Create a dict to store simplified report metadata
simplified_metadata = []

# Fetch metadata for each report
for i, report in enumerate(reports):
    report_id = report["id"]
    report_name = report["reportName"]
    # skip if report name is not in the expected list. apiqa2 has a lot of "system" reports that are actually just AE testing
    if report_name not in [
        "User groups",
        "Library contents",
        "Content profiles",
        "CRM Accounts",
        "CRM Contacts",
        "CRM Opportunities",
        "Digital Sales Room templates",
        "Content views",
        "Learning gradebook",
        "Searches",
        "Digital Sales Rooms",
        "LiveSend links",
        "Lessons",
        "Recipients",
        "Email templates",
        "Emails",
        "Learning assignments",
        "Paths",
        "LiveDoc generations",
        "Users",
        "Learning journeys",
        "Publishing approvals",
        "Meeting contents",
        "Meeting participants",
        "Meetings",
        "Programs",
        "Program items",
        "Training event sessions",
        "Learning journey steps",
        "Page clicks",
        "Page contents",
        "Skills",
        "Skill reviews",
        "Skill coaching rooms",
        "WorkSpace content"
    ]:
        print(f"Skipping report '{report_name}' (ID: {report_id})")
        continue
    print(
        f"[{i+1}/{len(reports)}] Fetching metadata for '{report_name}' (ID: {report_id})"
    )

    metadata = asyncio.run(client.get_report_metadata(tenant, report_id))

    # Check if there was an error
    if "error" in metadata:
        print(f"  Error: {metadata['error']}")
        continue

    # Save to YAML file
    output_filename = f"test_data/reports/{report_name.lower().replace(' ', '_')}.yml"

    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(output_filename), exist_ok=True)

    with open(output_filename, "w") as file:
        yaml.dump(
            metadata,
            file,
            default_flow_style=False,
            sort_keys=False,
            indent=2,
        )

    print(f"Simplified metadata saved to {output_filename}")
