from functools import wraps
import seismic_auth as auth
from .logging import _request_user_id, _request_tenant_id


def populate_credentials_from_token(f):
    """
    Decorator that populates tenant from JWT token or form data.
    Priority: JWT token tenant > form/body tenant parameter
    """

    @wraps(f)
    async def decorated(*args, **kwargs):
        # Try to get tenant from JWT token using the same context as auth library
        tenant_from_token = None
        # Access the auth context directly to get the tenant
        context = (
            auth.auth_filter._get_context()
            if hasattr(auth.auth_filter, "_get_context")
            else None
        )
        if context and hasattr(context, "auth_data"):
            auth_data = context.auth_data
            # Check if it's a tenant token
            if auth_data.get("token_source") == "tenant":
                tenant_from_token = auth_data.get("tenant")
                tenant_id = auth_data.get("tenant_id")
                _request_tenant_id.set(tenant_id)
                user = auth_data.get("sub")
                _request_user_id.set(user)

        # If we have tenant from token, use it; otherwise keep the provided tenant
        if tenant_from_token and "tenant" in kwargs:
            kwargs["tenant"] = tenant_from_token
        if tenant_id and "tenant_id" in kwargs:
            kwargs["tenant_id"] = tenant_id
        if user and "user" in kwargs:
            kwargs["user"] = user

        return await f(*args, **kwargs)

    return decorated
