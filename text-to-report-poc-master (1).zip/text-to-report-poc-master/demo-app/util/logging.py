from contextvars import ContextVar
import json
import logging
import logging.config
from typing import Optional
from uuid import UUID
import structlog

_request_trace_id: ContextVar[Optional[UUID]] = ContextVar('request_trace_id', default=None)
_request_user_id: ContextVar[Optional[str]] = ContextVar('request_user_id', default=None)
_request_tenant_id: ContextVar[Optional[str]] = ContextVar('request_tenant_id', default=None)

def copy_event_to_message(logger, method_name, event_dict):
    if "event" in event_dict:
        event_value = event_dict["event"]
        
        # If event_dict["event"] is a JSON string, parse it
        if isinstance(event_value, str):
            try:
                event_value = json.loads(event_value)
            except Exception:
                pass  # Leave as string if not valid JSON
        
        if isinstance(event_value, dict) and "event" in event_value:
            event_dict["message"] = event_value["event"]
        else:
            event_dict["message"] = event_value
    return event_dict

def add_request_context(logger, method_name, event_dict):
    user_id = _request_user_id.get(None)
    tenant_id = _request_tenant_id.get(None)
    trace_id = _request_trace_id.get(None)
    if user_id is not None:
        event_dict["user"] = user_id
    if tenant_id is not None:
        event_dict["tenant"] = tenant_id
    if trace_id is not None:
        event_dict["request_trace_id"] = str(trace_id)
    return event_dict

def init_logging(log_level, running_local: bool = False):
    shared_processors = [
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.ExceptionRenderer(),
        add_request_context,
        copy_event_to_message,
    ]

    renderer = structlog.processors.JSONRenderer() if not running_local else structlog.dev.ConsoleRenderer()
    structlog_processors = [renderer]
    # Remove _record & _from_structlog.
    logging_processors = [structlog.stdlib.ProcessorFormatter.remove_processors_meta, renderer]

    LOGGING_CONFIG = {
        "version": 1,
        "handlers": {
            "default": {
                "class": "logging.StreamHandler",
                "formatter": "structlog",
                "stream": "ext://sys.stderr"
            }
        },
        "formatters": {
            "structlog": {
                '()': structlog.stdlib.ProcessorFormatter,
                'processors': logging_processors,
                'foreign_pre_chain': shared_processors,
            }
        },
        'root': {
            'handlers': ['default'],
            'level': log_level,
        },
        'loggers': {
            'httpx': {
                'handlers': ['default'],
                'level': 'WARNING',
            },
            'httpcore': {
                'handlers': ['default'],
                'level': 'WARNING',
            },
        }
    }

    logging.config.dictConfig(LOGGING_CONFIG)

    structlog.configure(
        processors=structlog_processors,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )