import hashlib
from kink import inject

from seismic_foundation.config.ConfigProvider import ConfigProvider

@inject
class POCAuthService:
    """A simple authentication class."""

    def __init__(self, config: ConfigProvider):
        self.authorized_emails = config.authorized_emails or []
        self.signature_key = config.signature_key

    def is_authorized(self, email: str) -> bool:
        """Check if the email is authorized."""
        return email in self.authorized_emails

    def authorize_login(self, email: str, password: str) -> bool:
        """Authorize login based on email and password."""
        # Check if the email is authorized
        if email not in self.authorized_emails:
            return False
        # Check if the password is correct
        # The password is a hash of the email and the secret value
        expected_password = hashlib.md5(
            (email + "/" + self.signature_key).encode("utf-8")
        ).hexdigest()

        return password == expected_password
