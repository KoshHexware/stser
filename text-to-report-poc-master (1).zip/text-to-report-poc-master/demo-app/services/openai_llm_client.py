from kink import inject
import openai
from seismic_foundation.config.ConfigProvider import ConfigProvider
from .abstract_llm_client import AbstractLLMClient, LLMResponse, TokenUsage

@inject
class OpenAI_LLM_Client(AbstractLLMClient):
    """
    OpenAI LLM Client for interacting with OpenAI's API.
    This class is responsible for sending requests to the OpenAI API
    and receiving responses.
    """
    def __init__(
        self,
        config: ConfigProvider,
        model="gpt-4.1-2025-04-14-global",
        temperature=0.0,
        top_p=1.0,
    ):
        """
        Initialize the OpenAI LLM client.

        Args:
            model (str): The model to use (default: "gpt-4o")
            temperature (float): The temperature for the model (default: 0.0)
            top_p (float): The top_p for the model (default: 1.0)
        """
        super().__init__(model, temperature, top_p)
        self.client = openai.AsyncAzureOpenAI(
            api_key=config.openai_api_key,
            api_version=config.azure_openai_api_version,
            azure_endpoint=config.azure_openai_endpoint,
            azure_deployment=config.azure_openai_deployment,
        )

    async def get_response(self, context, question=None):
        """Get response from LLM model."""
        response = await self.client.responses.create(
            model=self._model,
            instructions=context,
            input=question,
            temperature=self._temperature,
            top_p=self._top_p,
        )
        return LLMResponse(response=response.output_text.strip(),
            token_usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens
        ))

    async def get_response_structured(
        self, context, question=None, text_format=None
    ):
        """Get response from LLM model."""

        response = await self.client.responses.parse(
            model=self._model,
            input=[
                {"role": "system", "content": context},
                {"role": "user", "content": question},
            ],
            text_format=text_format,
            temperature=self._temperature,
            top_p=self._top_p,
        )
        return LLMResponse(response=response.output_parsed,
            token_usage=TokenUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens
        ))
