from abc import ABC, abstractmethod
from pydantic import BaseModel

class TokenUsage(BaseModel):
    input_tokens: int
    output_tokens: int

    def __add__(self, other):
        return TokenUsage(
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens
        )
    
    def empty():
        return TokenUsage(
            input_tokens=0,
            output_tokens=0
        )

class LLMResponse(BaseModel):
    response: object
    token_usage: TokenUsage

class AbstractLLMClient(ABC):
    """
    Abstract base class for AI models.
    """
    def __init__(self, model, temperature, top_p):
        """
        Initialize the LLM client.

        Args:
            model (str): The model to use (default: "gpt-4o")
            temperature (float): The temperature for the model (default: 0.0)
            top_p (float): The top_p for the model (default: 1.0)
        """
        self._model = model
        self._temperature = temperature
        self._top_p = top_p

    @abstractmethod
    async def get_response(self, context, question=None) -> LLMResponse:
        """Get response from LLM model."""
        pass

    @abstractmethod
    async def get_response_structured(
        self, context, question=None, text_format=None
    ) -> LLMResponse:
        """Get response from LLM model."""
        pass
