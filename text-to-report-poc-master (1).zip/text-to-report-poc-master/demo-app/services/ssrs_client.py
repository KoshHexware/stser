import structlog
import httpx
import json
from urllib.parse import urlencode
from kink import inject
from cachetools import TTLCache

from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_foundation.foundation.AuthTokenClient import AuthTokenClient
from seismic_foundation.foundation.MatrixClient import MatrixClient

from structures.ssrs_structures import SortOrder
from util.ssrs_parse_util import (
    fix_fields_for_execute,
    fix_filters_for_execute,
)

@inject
class SSRSClient:
    """A client for interacting with the Self-Service Reports Service (SSRS)."""

    def __init__(self, matrix: MatrixClient, auth: AuthTokenClient, config: ConfigProvider) -> None:
        """
        Initialize the SSRS client.
        :param base_url: The base URL of the SSRS service.
        :param token: The Bearer token for authorization.
        """
        self.matrix = matrix
        self.poc_users = config.poc_users
        self.auth = auth
        self.logger = structlog.get_logger()

        # Initialize caches
        self.reports_cache = TTLCache(maxsize=100, ttl=3600)
        self.metadata_cache = TTLCache(maxsize=1000, ttl=3600)

    def clear_cache(self, tenant=None):
        """Clear cache for a specific tenant or all caches."""
        if tenant:
            # Clear specific tenant caches
            keys_to_remove = [k for k in self.reports_cache.keys() if k.endswith(f":{tenant}")]
            for key in keys_to_remove:
                self.reports_cache.pop(key, None)

            keys_to_remove = [k for k in self.metadata_cache.keys() if k.startswith(f"metadata:{tenant}:")]
            for key in keys_to_remove:
                self.metadata_cache.pop(key, None)
        else:
            # Clear all caches
            self.reports_cache.clear()
            self.metadata_cache.clear()

    def base_url(self, tenant):
        return self.matrix.get_tenant_service(tenant, "ssrs")

    def get_user(self, tenant):
        return next(user["user_id"] for user in self.poc_users if user.get("tenant") == tenant)

    def get_jwt(self, tenant):
        return self.auth.get_auth_token("library", tenant)

    def get_tenant_domain(self, tenant):
        return self.matrix.get_tenant_info(tenant).get(
            "domain", f"{tenant}.seismic.com"
        )

    def generate_report_frontend_url(self, tenant: str, report_id: str) -> str:
        """
        Generate a front-end URL for linking to a report in the Seismic web app.
        Example: https://{tenant}.seismic.com/app#/selfservicereports/reports/{report_id}
        """
        return f"https://{self.get_tenant_domain(tenant)}/app#/selfservicereports/report/{report_id}"

    def generate_report_execution_url(self, tenant: str, report_id: str) -> str:
        """ """
        return f"{self.base_url(tenant)}/api/v1/report/execute/{report_id}"

    async def get_all_reports(self, tenant, user=None):
        """
        Retrieve all reports from the SSRS service.
        :param tenant: The tenant identifier
        :param user: Optional user ID to override the default user
        :return: A list of reports or an error message.
        """
        # Not each user has access to all reports, so we cache per user
        cache_key = f"reports:{tenant}:{user or 'default'}"
        if cache_key in self.reports_cache:
            return self.reports_cache[cache_key]

        url = f"{self.base_url(tenant)}/api/v1/reports/all?reportType=system&take=1000&skip=0&includeDrafts=true"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.get_jwt(tenant)}",
                        "Content-Type": "application/json",
                        "X-Seismic-UserId": user or self.get_user(tenant),
                    },
                    timeout=15
                )
                response.raise_for_status()
                result = response.json()
                # Cache successful responses only
                self.reports_cache[cache_key] = result
                return result
        except httpx.HTTPStatusError as e:
            if e.response is not None and e.response.status_code == 403:
                self.logger.warning(
                    f"User does not have access to self service reports: {e}",
                    tenant=tenant,
                    user=user,
                )
                raise PermissionError(
                    "User does not have access to self service reports"
                ) from e
            self.logger.warning(f"HTTP error fetching reports: {e}", tenant=tenant, user=user)
            return {"error": str(e)}
        except httpx.RequestError as e:
            self.logger.error(f"Request error fetching reports: {e}", exc_info=e)
            return {"error": str(e)}

    async def get_report_metadata(self, tenant, report_id, user=None):
        """
        Retrieve metadata for a specific report by ID.
        :param tenant: The tenant identifier
        :param report_id: The ID of the report to retrieve metadata for.
        :param user: Optional user ID to override the default user
        :return: The metadata of the report or an error message.
        """
        # Check cache first
        cache_key = f"metadata:{tenant}:{report_id}"
        if cache_key in self.metadata_cache:
            return self.metadata_cache[cache_key]

        url = f"{self.base_url(tenant)}/api/v1/report/{report_id}"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.get_jwt(tenant)}",
                        "Content-Type": "application/json",
                        "X-Seismic-UserId": user or self.get_user(tenant),
                    },
                    timeout=15
                )
                response.raise_for_status()
                result = response.json()
                # Cache successful responses only
                self.metadata_cache[cache_key] = result
                return result
        except httpx.HTTPStatusError as e:
            if e.response is not None and e.response.status_code == 403:
                self.logger.warning(
                    f"User does not have access to self service reports: {e}",
                    tenant=tenant,
                    user=user,
                )
                raise PermissionError(
                    "User does not have access to self service reports"
                ) from e
            self.logger.warning(f"HTTP error fetching report metadata: {e}", report_id=report_id)
            return {"error": str(e)}
        except httpx.RequestError as e:
            self.logger.error(f"Request error fetching report metadata: {e}", report_id=report_id, exc_info=e)
            return {"error": str(e)}

    async def get_filter_values(self, tenant, report_id, filter_name):
        """
        Retrieve the domain of possible values for a given filter in a report.
        """
        url = f"{self.base_url(tenant)}/api/v1/filter/{filter_name}/values?systemReportId={report_id}&filterName={filter_name}"
        user = self.get_user(tenant)
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.get_jwt(tenant)}",
                        "Content-Type": "application/json",
                        "X-Seismic-UserId": user,
                    },
                    timeout=15
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            if e.response is not None and e.response.status_code == 403:
                self.logger.warning(
                    f"User does not have access to self service reports: {e}",
                    tenant=tenant,
                    user=user,
                )
                raise PermissionError(
                    "User does not have access to self service reports"
                ) from e
            self.logger.warning(f"HTTP error fetching report metadata: {e}", report_id=report_id, filter_name=filter_name)
            return {"error": str(e)}
        except httpx.RequestError as e:
            self.logger.error(f"Request error fetching report metadata: {e}", report_id=report_id, filter_name=filter_name, exc_info=e)
            return {"error": str(e)}

    async def execute_report(
        self,
        tenant,
        report_id,
        fields=[],
        filters=None,
        order_field=None,
        order_by: SortOrder = None,
        teamsite_ids=None,
        skip=0,
        take=3,
        user=None,
    ):
        """
        Execute a report with the specified parameters.
        :param tenant: The tenant identifier
        :param report_id: The ID of the report to execute.
        :param fields: The fields to include in the report.
        :param filters: A JSON string representing the filters.
        :param order_field: The field to order by.
        :param order_by: The order direction (asc/desc).
        :param teamsite_ids: The selected teamsites.
        :param skip: The number of records to skip.
        :param take: The number of records to take.
        :param user: Optional user ID to override the default user
        :return: The execution result or an error message.
        """

        # Build query parameters using the shared helper (now returns raw and encoded params)
        generated_params = await self.generate_report_params(
            tenant=tenant,
            report_id=report_id,
            fields=fields,
            filters=filters,
            order_field=order_field,
            order_by=order_by,
            teamsite_ids=teamsite_ids,
            skip=skip,
            take=take,
            user=user,
        )
        url = self.generate_report_execution_url(tenant, report_id)
        params = generated_params["raw"]
        self.logger.debug(f"Executing report {report_id} with params", report_id=report_id, params=params)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.get_jwt(tenant)}",
                        "Content-Type": "application/json",
                        "X-Seismic-UserId": user or self.get_user(tenant),
                    },
                    params=params,
                    timeout=15,
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            if e.response is not None and e.response.status_code == 403:
                self.logger.warning(
                    f"User does not have access to execute self service reports: {e}",
                    tenant=tenant,
                    user=user,
                )
                raise PermissionError(
                    "User does not have access to self service reports"
                ) from e
            self.logger.warning(f"HTTP error executing report: {e}", report_id=report_id, params=params)
            return {"error": str(e)}
        except httpx.RequestError as e:
            self.logger.error(f"Request error executing report: {e}", report_id=report_id, params=params, exc_info=e)
            return {"error": str(e)}

    async def generate_report_params(
        self,
        tenant,
        report_id,
        fields: list[str] = [],
        filters=None,
        order_field: str | None = None,
        order_by: SortOrder | None = None,
        teamsite_ids=None,
        skip: int | None = 0,
        take: int | None = 3,
        user: str | None = None,
    ) -> dict:
        """
        Build query parameters for executing a report without performing the network request.

        Args:
            tenant: Tenant identifier.
            report_id: Report ID.
            fields: Field names to include.
            filters: Filters to apply.
            order_field: Field to order by.
            order_by: Sort order (asc/desc).
            skip: Number of records to skip.
            take: Number of records to take.
            user: Optional user ID for metadata lookups.

        Returns:
            dict: { "raw": dict, "encoded": str }
        """
        # Fetch metadata to normalize fields and filters like execute_report does
        report_metadata = await self.get_report_metadata(tenant, report_id, user)

        built_params = {
            "fields": json.dumps(
                [
                    {"name": f, "propertyType": "None"}
                    for f in fix_fields_for_execute(report_metadata, fields or [])
                ],
                separators=(",", ":"),
            ),  # fields is required, even if empty
            "filters": (
                json.dumps(
                    [f for f in fix_filters_for_execute(report_metadata, filters)],
                    separators=(",", ":"),
                )
                if filters
                else None
            ),
            "orderField": (
                fix_fields_for_execute(report_metadata, [order_field])[0]
                if order_field
                and fix_fields_for_execute(report_metadata, [order_field])
                else None
            ),
            "orderBy": order_by,
            "teamsiteIds": teamsite_ids,
            "skip": skip if skip else None,
            "take": take if take else None,
        }

        # Remove None entries to keep it tidy
        cleaned_params = {k: v for k, v in built_params.items() if v is not None}

        # Coerce enum values to their underlying string value for URL encoding
        to_encode = dict(cleaned_params)
        if "orderBy" in to_encode and isinstance(to_encode["orderBy"], SortOrder):
            to_encode["orderBy"] = to_encode["orderBy"].value

        encoded = urlencode(to_encode, doseq=True)
        return {"raw": cleaned_params, "encoded": encoded}
