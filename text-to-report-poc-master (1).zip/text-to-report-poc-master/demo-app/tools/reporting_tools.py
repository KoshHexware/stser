import asyncio
from typing import List

import structlog
from util.timer_util import timer
from services.ssrs_client import SSRSClient
from structures.ssrs_structures import ReportFieldsFiltersRecommendation
from langchain_core.tools import tool
from models.prompts import (
    FieldDetailLevel,
    FilterDetailLevel,
    MetricDetailLevel,
    report_summary,
)
from util.ssrs_parse_util import (
    extract_ssrs_filter_values,
    fields_to_ux_name_pairs,
    filters_to_ux_name_pairs,
)


@timer
async def describe_available_reports(
    ssrs_client: SSRSClient, tenant: str, user: str = None
) -> str:
    """Return a prompt for recommending reports based on the available reports and user question."""
    structlog.get_logger().info("Describing available reports")
    ssrs_results = await ssrs_client.get_all_reports(tenant, user)
    reports = ssrs_results.get("data", [])
    if ssrs_results.get("error"):
        raise ValueError(f"Failed to fetch reports: {ssrs_results['error']}")
    if not reports:
        return "No reports available."

    # Fetch all metadata in parallel
    async def fetch_metadata_for_report(report):
        metadata = await ssrs_client.get_report_metadata(
            tenant=tenant, report_id=report.get("id"), user=user
        )
        # Only add keys from report_metadata that are not already in report
        if not metadata.get("error"):  # Skip if metadata fetch failed
            for k, v in metadata.items():
                if k not in report:
                    report[k] = v
            return report
        return None

    # Execute all metadata fetches in parallel
    tasks = [fetch_metadata_for_report(report) for report in reports]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Filter out None results (failed metadata fetches)
    reports_with_metadata = [
        result
        for result in results
        if result is not None and not isinstance(result, Exception)
    ]
    report_summaries = "\n".join(
        [
            report_summary(
                r,
                field_details=FieldDetailLevel.key_names_only,
                metric_details=MetricDetailLevel.names_only,
                filter_details=FilterDetailLevel.none,
            )
            for r in reports_with_metadata
        ]
    )
    return report_summaries


@timer
async def fetch_metadata_by_report_id(
    ssrs_client: SSRSClient, tenant: str, report_ids: list[str], user: str = None
) -> str:
    """Return a prompt for filtering a list of reports based on their metadata."""
    structlog.get_logger().info("Fetching report metadata", report_ids=report_ids)
    metadata_list = []
    for report in report_ids:
        metadata = await ssrs_client.get_report_metadata(
            tenant=tenant, report_id=report, user=user
        )
        if metadata.get("error"):
            structlog.get_logger().error(f"Error fetching metadata for report {report}: {metadata['error']}", report_id=report, exc_info=True)
            raise ValueError(
                f"Failed to fetch metadata for report {report}: {metadata['error']}"
            )
        metadata_list.append(metadata)
    report_metadata = [
        report_summary(
            report,
            field_details=FieldDetailLevel.names_and_descriptions_and_filters,
            metric_details=MetricDetailLevel.names_and_descriptions,
            filter_details=FilterDetailLevel.names_descriptions_and_operations,
        )
        for report in metadata_list
    ]
    return report_metadata


@timer
async def execute_report(
    ssrs_client: SSRSClient,
    tenant: str,
    fields_and_filters: ReportFieldsFiltersRecommendation,
    user: str = None,
):
    structlog.get_logger().info("Executing report", report_id=fields_and_filters.id)
    try:
        ssrs_report_data = await ssrs_client.execute_report(
            tenant,
            fields_and_filters.id,
            fields_and_filters.fields,
            fields_and_filters.additional_filters,
            (
                fields_and_filters.sort_by.field_name
                if fields_and_filters.sort_by
                else None
            ),
            (
                fields_and_filters.sort_by.sort_order.value
                if fields_and_filters.sort_by
                else None
            ),
            user=user,
        )
        if ssrs_report_data.get("error"):
            structlog.get_logger().error(
                f"Error executing report {fields_and_filters.id}: {ssrs_report_data['error']}",
                tenant=tenant,
                user=user,
                report_id=fields_and_filters.id,
                params={
                    "fields": fields_and_filters.fields,
                    "filters": fields_and_filters.additional_filters,
                    "sort_by": fields_and_filters.sort_by,
                },
                exc_info=True,
            )
            raise ValueError(
                f"Failed to execute report {fields_and_filters.id}: {ssrs_report_data['error']}"
            )
        return {
            "report_id": fields_and_filters.id,
            "report_name": fields_and_filters.report_name,
            "data": ssrs_report_data.get("data", []),
        }
    except Exception as e:
        structlog.get_logger().error(f"Error executing report: {e}", report_id=fields_and_filters.id, exc_info=e)
        return {
            "error": True,
            "message": "Error executing report. Please try again later.",
            "exception": str(e),
        }


@timer
async def get_filter_domain_values(
    ssrs_client: SSRSClient,
    tenant: str,
    report_id: str,
    filter_names: list[str],
    user: str | None = None,
) -> list[dict]:
    """Return domain values for multiple filters in a report.

    Returns a list of objects shaped like:
      [{
         "filter_name": <uxLabel>,
         "values": [..]
       }, {
         "filter_name": <uxLabel>,
         "error": <message>
       }]
    """
    structlog.get_logger().info(
        "Fetching filter domain values (multi)",
        report_id=report_id,
        filter_names=filter_names,
    )
    report = await ssrs_client.get_report_metadata(
        tenant=tenant, report_id=report_id, user=user
    )
    if not report:
        return [
            {"filter_name": fn, "error": f"Error: Report {report_id} not found."}
            for fn in filter_names
        ]

    if not filter_names:
        return []

    async def fetch_filter_domain_values(name: str) -> dict:
        try:
            success, filter_result = await extract_ssrs_filter_values(
                report,
                name,
                lambda filter_name: ssrs_client.get_filter_values(
                    tenant=tenant, report_id=report_id, filter_name=filter_name
                ),
            )
            if success:
                structlog.get_logger().debug(
                    "Filter has values", report_id=report_id, filter_name=name
                )
                return {"filter_name": name, "values": filter_result}
            else:
                structlog.get_logger().warning(
                    "Filter domain retrieval issue",
                    report_id=report_id,
                    filter_name=name,
                    error=filter_result,
                )
                return {"filter_name": name, "error": filter_result}
        except Exception as e:
            structlog.get_logger().error(
                "Unexpected error fetching filter domain values",
                report_id=report_id,
                filter_name=name,
                error=str(e),
                exc_info=True,
            )
            return {"filter_name": name, "error": f"Unexpected error: {e}"}

    # Launch all tasks in parallel
    tasks = [fetch_filter_domain_values(fn) for fn in filter_names]
    results = await asyncio.gather(*tasks, return_exceptions=False)
    return results


@timer
async def generate_ssr_url(
    ssrs_client: SSRSClient,
    fields_and_filters: ReportFieldsFiltersRecommendation,
    tenant: str,
    user: str | None = None,
) -> dict:
    """Format a standardized SSR response payload using the given config.

    Returns a dict shaped like:
    {
        "ssr_data_url": "https://{tenantid}.seismic.com/...",
        "ssr_report_url": "https://ssr.seismic.com/report/<report_id>",
        "report_id": "<report_id>",
        "report_name": "<report_name>",
    }
    """
    structlog.get_logger().info("Generating SSR URLs", report_id=fields_and_filters.id)
    # Generate SSRS report parameters
    ssrs_preview_params = await ssrs_client.generate_report_params(
        tenant=tenant,
        report_id=fields_and_filters.id,
        fields=fields_and_filters.fields,
        filters=fields_and_filters.additional_filters,
        order_field=(
            fields_and_filters.sort_by.field_name
            if fields_and_filters.sort_by
            else None
        ),
        order_by=(
            fields_and_filters.sort_by.sort_order
            if fields_and_filters.sort_by
            else None
        ),
        user=user,
    )
    # Generate SSRS report parameters without skip & take
    ssrs_report_params = await ssrs_client.generate_report_params(
        tenant=tenant,
        report_id=fields_and_filters.id,
        fields=fields_and_filters.fields,
        filters=fields_and_filters.additional_filters,
        order_field=(
            fields_and_filters.sort_by.field_name
            if fields_and_filters.sort_by
            else None
        ),
        order_by=(
            fields_and_filters.sort_by.sort_order
            if fields_and_filters.sort_by
            else None
        ),
        user=user,
        skip=None,
        take=None,
    )

    # Retrieve URLs and Append Encoded Report
    ssrs_report_url = f"{ssrs_client.generate_report_frontend_url(tenant, fields_and_filters.id)}?{ssrs_report_params['encoded']}"
    ssrs_preview_url = f"{ssrs_client.generate_report_execution_url(tenant, fields_and_filters.id)}?{ssrs_preview_params['encoded']}"

    return {
        "ssr_report_url": ssrs_report_url,
        "ssr_preview_url": ssrs_preview_url,
        "reportName": fields_and_filters.report_name,
        "reportId": fields_and_filters.id,
    }


@timer
async def format_fields_and_filters_names(
    ssrs_client: SSRSClient,
    tenant: str,
    fields_and_filters: ReportFieldsFiltersRecommendation,
    user: str | None = None,
) -> dict:
    """Build fields_and_filters mapping with ux_name pairs for fields, filters, and sort_by.

    Returns structure:
    {
      "fields": [{ux_name, name}],
      "filters": [{ux_name, name}],
      "sort_by": { "field": {ux_name, name} | None, "order": "ASC"|"DESC"|None }
    }
    """
    structlog.get_logger().info("Formatting fields and filters names", report_id=fields_and_filters.id)
    report_metadata = await ssrs_client.get_report_metadata(
        tenant=tenant, report_id=fields_and_filters.id, user=user
    )

    # Direct mapping: inputs are internal names (field 'name' and filter 'filterName')
    mapped_fields = fields_to_ux_name_pairs(
        report_metadata, fields_and_filters.fields or []
    )

    filter_names: list[str] = [
        fltr.filter_name for fltr in (fields_and_filters.additional_filters or [])
    ]
    mapped_filters = filters_to_ux_name_pairs(report_metadata, filter_names)

    mapped_sort_by = (
        {
            "field": fields_to_ux_name_pairs(
                report_metadata, [fields_and_filters.sort_by.field_name]
            )[0],
            "order": fields_and_filters.sort_by.sort_order,
        }
        if fields_and_filters.sort_by
        else None
    )

    return {
        "fields": mapped_fields,
        "filters": mapped_filters,
        "sort_by": mapped_sort_by,
    }
