from enum import Enum
from typing import Annotated, Optional, Union
from pydantic import BaseModel, Field

# Accepted generic operations found here:
# https://github.com/seismic/self-service-reports-service/blob/develop/src/Seismic.AnalyticsApps.SelfServiceReports.Services/Helpers/OperatorHelper.cs

class TextOperations(str, Enum):
    is_one_of = "TEXT_IsOneOf"
    is_not_one_of = "TEXT_IsNotOneOf"
    is_null = "TEXT_IsNull"
    is_not_null = "TEXT_IsNotNull"
    contains = "TEXT_Contains"
    does_not_contain = "TEXT_DoesNotContain"
    # TODO check if op hasDomainValues 
    # starts_with = "TEXT_StartsWith"
    # ends_with = "TEXT_EndsWith"
    # equals = "TEXT_Equals"
    # not_equals = "TEXT_NotEquals"


class NumericOperations(str, Enum):  # For Integer or Decimal
    equals = "NUMERIC_Equals"
    not_equals = "NUMERIC_NotEquals"
    greater_than = "NUMERIC_GreaterThan"
    less_than = "NUMERIC_LessThan"
    greater_than_or_equal = "NUMERIC_GreaterThanOrEqual"
    less_than_or_equal = "NUMERIC_LessThanOrEqual"
    between = "NUMERIC_Between"
    # TODO check if op is nullable
    # is_null = "NUMERIC_IsNull"
    # is_not_null = "NUMERIC_IsNotNull"


class DateOperations(str, Enum):  # For Date or DateTime
    equals = "DATE_Equals"
    not_equals = "DATE_NotEquals"
    greater_than = "DATE_GreaterThan"
    less_than = "DATE_LessThan"
    between = "DATE_Between"
    is_null = "DATE_IsNull"
    is_not_null = "DATE_IsNotNull"
    in_the_last = "DATE_InTheLast"
    in_the_next = "DATE_InTheNext"
    named_range = "DATE_NamedRange"

class BooleanOperations(str, Enum):
    equals = "BOOL_Equals"
    not_equals = "BOOL_NotEquals"
    is_null = "BOOL_IsNull"
    is_not_null = "BOOL_IsNotNull"


class SortOrder(str, Enum):
    ascending = "ASC"
    descending = "DESC"


# Class defintions for strucutred responses from LLM
class ReportRecommendation(BaseModel):
    id: str
    report_name: str = Field(serialization_alias="reportName")


class ReportResponse(BaseModel):
    reports: list[ReportRecommendation]


class FilterRecommendation(BaseModel):
    filter_name: str = Field(serialization_alias="filterName")
    operation: Union[
        TextOperations,
        NumericOperations,
        DateOperations,
        BooleanOperations,
    ]
    filter_values: list[str] = Field(serialization_alias="values")

    def get_operation(self) -> str:
        """Returns the operation name without the prefix."""
        return self.operation.value.split("_")[-1]


class SortRecommendation(BaseModel):
    field_name: str = Field(serialization_alias="fieldName")
    sort_order: SortOrder = Field(serialization_alias="sortOrder")


class ReportFieldsFiltersRecommendation(ReportRecommendation):
    fields: list[str]
    additional_filters: Optional[
        Annotated[
            list[FilterRecommendation], Field(serialization_alias="additionalFilters")
        ]
    ] = None
    sort_by: Optional[
        Annotated[SortRecommendation, Field(serialization_alias="sortBy")]
    ] = None


class ReportFieldsFiltersResponse(BaseModel):
    reports: list[ReportFieldsFiltersRecommendation]
