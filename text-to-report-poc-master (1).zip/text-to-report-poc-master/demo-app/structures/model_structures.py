from typing import Annotated, Optional

from pydantic import Field
from .ssrs_structures import ReportFieldsFiltersResponse


class ReactFinalAnswer(ReportFieldsFiltersResponse):
    thoughts: Optional[
        Annotated[
            str,
            Field(description="Summary of the agent's reasoning and thought process."),
        ]
    ] = None
    # This is unused but will be required for the future functionality of asking further questions.
    # further_questions: Optional[
    #     Annotated[
    #         list[str],
    #         Field(
    #             description="Any final questions that the agent has after processing the request",
    #         ),
    #     ]
    # ] = None
