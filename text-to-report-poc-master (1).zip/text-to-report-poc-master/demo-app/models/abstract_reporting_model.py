from abc import ABC, abstractmethod
from models.abstract_agent_modules import ReportRecommendationAgentModuleResponse

class AbstractReportingModel(ABC):
    """
    Abstract base class for AI models that can answer questions about reports.

    This class defines the interface that all model implementations should follow,
    making them easily testable and comparable against each other.
    """

    @abstractmethod
    async def answer_question(self, question):
        """
        Answer a question using the model.

        Args:
            question (str): The question to answer

        Returns:
            dict: A dictionary containing the final_answer and any additional information
        """
        pass

    @abstractmethod
    async def recommend_reports(self, question) -> ReportRecommendationAgentModuleResponse:
        """
        Recommend reports based on the question.

        Args:
            question (str): The question to answer

        Returns:
            dict: A dictionary containing the recommended reports and any additional information
        """
        pass

    @abstractmethod
    async def recommend_fields_and_filters(self, question, report_ids) -> dict:
        """
        Recommend fields and filters based on the question and report IDs.

        Args:
            question (str): The question to answer
            report_ids (list): List of report IDs to consider

        Returns:
            dict: A dictionary containing the recommended fields and filters and any additional information
        """
        pass
