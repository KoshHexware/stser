from .report_recomendation_agent_modules import BroadAgentModule, BroadVerboseAgentModule, NarrowAgentModule, RelevancyAgentModule

class AgentModuleRegistry():
    report_recommendation_agent_options = {
        "broad": BroadAgentModule,  # Returns the best 3-5 reports. Cheap, fast, and mostly accurate.
        "broad-verbose": BroadVerboseAgentModule, # The same as broad, but with more context provided to the LLM.
        "relevancy": RelevancyAgentModule, # Returns any reports that may be relevant. Expensive, but most accurate.
        "narrow": NarrowAgentModule, # Returns the best 0-2 reports. Most context. Best used after another filter.
    }
    default_report_recommendation_agent_options = ["broad", "narrow"]

    # I'm just leaving this as a stub for now, as there's not currently a need for multiple implementations or turns for configuration.
    report_configuration_agent_options = {}
    default_report_configuration_agent_options = []
