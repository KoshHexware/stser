from kink import inject
from .abstract_reporting_model import (
    AbstractReportingModel,
    ReportRecommendationAgentModuleResponse,
)
from .abstract_agent_modules import Conversation
from util.timer_util import timer
from services.abstract_llm_client import AbstractLLMClient
from services.ssrs_client import SSRSClient
from seismic_foundation.config.ConfigProvider import ConfigProvider
from seismic_llm.langchain_adapters.chatLLMG import ChatLLMG
from langchain_core.tools import tool, StructuredTool
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage, RemoveMessage
from langgraph.errors import GraphRecursionError
from langgraph.graph.message import REMOVE_ALL_MESSAGES
from langgraph.prebuilt.chat_agent_executor import AgentState
from structures.ssrs_structures import (
    ReportFieldsFiltersRecommendation,
    ReportFieldsFiltersResponse,
    ReportRecommendation,
)
from tools.reporting_tools import (
    describe_available_reports,
    fetch_metadata_by_report_id,
    execute_report,
    get_filter_domain_values,
)
from structures.model_structures import ReactFinalAnswer
from langchain_core.messages.utils import trim_messages, count_tokens_approximately
import asyncio
from datetime import datetime
from .prompts import create_react_system_template
import structlog

@inject
class AgenticReactModel(AbstractReportingModel):
    def __init__(
        self,
        config: ConfigProvider,
        ssrs_client: SSRSClient,
        llm_client: AbstractLLMClient,
        tenant: str,
        model_kwargs={},
    ):
        self.config = config
        self.ssrs_client = ssrs_client
        self.tenant = tenant
        self.logger = structlog.get_logger()

        # Extract configuration from model_kwargs
        self.system_prompt = model_kwargs.get(
            "system_prompt", create_react_system_template()
        )
        self.llmg_endpoint = model_kwargs.get(
            "llmg_endpoint",
            "https://kubernetes-qa-az-westus-wombat.seismic-dev.com/llmg",
        )
        self.graph_recursion_limit = model_kwargs.get("graph_recursion_limit", 50)

        self.set_current_date(
            model_kwargs.get("current_date", datetime.now().strftime("%Y-%m-%d"))
        )

        # The agent cannot pass arguments like (self) to the tools, so we need to access the ssrs_client directly
        # For this reason, we cannot use the tools as methods of the class.
        def describe_available_reports_tool_sync() -> str:
            """Return a prompt for recommending reports based on the available reports and user question."""
            return asyncio.run(
                describe_available_reports(self.ssrs_client, self.tenant)
            )

        async def describe_available_reports_tool_async() -> str:
            """Return a prompt for recommending reports based on the available reports and user question."""
            return await describe_available_reports(self.ssrs_client, self.tenant)

        describe_available_reports_tool = StructuredTool.from_function(
            func=describe_available_reports_tool_sync,
            coroutine=describe_available_reports_tool_async,
            name="describe_available_reports",
            description="Return a prompt with the descriptions of all available reports with key fields and metrics.",
        )

        def fetch_metadata_by_report_id_tool_sync(report_ids: list[str]) -> str:
            """Return a prompt for filtering a list of reports based on their metadata."""
            return asyncio.run(
                fetch_metadata_by_report_id(self.ssrs_client, self.tenant, report_ids)
            )

        async def fetch_metadata_by_report_id_tool_async(report_ids: list[str]) -> str:
            """Return a prompt for filtering a list of reports based on their metadata."""
            return await fetch_metadata_by_report_id(
                self.ssrs_client, self.tenant, report_ids
            )

        fetch_metadata_by_report_id_tool = StructuredTool.from_function(
            func=fetch_metadata_by_report_id_tool_sync,
            coroutine=fetch_metadata_by_report_id_tool_async,
            name="fetch_report_metadata_by_report_id",
            description="Return the metadata for a list of report IDs. Metadata includes fields, filters, and metrics for each report.",
        )

        def sample_report_data_tool_sync(
            fields_and_filters: ReportFieldsFiltersRecommendation,
        ) -> dict:
            """
            Execute a report with the given fields and filters.
            Returns the report data.
            """
            return asyncio.run(
                execute_report(
                    ssrs_client=self.ssrs_client,
                    tenant=self.tenant,
                    fields_and_filters=fields_and_filters,
                )
            )

        async def sample_report_data_async(
            fields_and_filters: ReportFieldsFiltersRecommendation,
        ) -> dict:
            """
            Execute a report with the given fields and filters.
            Returns the report data.
            """
            return await execute_report(
                ssrs_client=self.ssrs_client,
                tenant=self.tenant,
                fields_and_filters=fields_and_filters,
            )

        sample_report_data_tool = StructuredTool.from_function(
            func=sample_report_data_tool_sync,
            coroutine=sample_report_data_async,
            name="sample_report_data",
            description="Execute a report with the given fields and filters. Returns the first three rows of report data as a sample.",
        )

        def get_filter_domain_values_tool_sync(
            report_id: str, filter_names: list[str]
        ) -> list[dict]:
            return asyncio.run(
                get_filter_domain_values(
                    ssrs_client=self.ssrs_client,
                    tenant=self.tenant,
                    report_id=report_id,
                    filter_names=filter_names,
                )
            )

        async def get_filter_domain_values_tool_async(
            report_id: str, filter_names: list[str]
        ) -> list[dict]:
            return await get_filter_domain_values(
                ssrs_client=self.ssrs_client,
                tenant=self.tenant,
                report_id=report_id,
                filter_names=filter_names,
            )

        get_filter_domain_values_tool = StructuredTool.from_function(
            func=get_filter_domain_values_tool_sync,
            coroutine=get_filter_domain_values_tool_async,
            name="get_filter_domain_values",
            description="Return the domain of possible values for each filter in a list of filters for a given report.",
        )

        # IMPORTANT: Every tool should return a string
        self.tools = [
            describe_available_reports_tool,
            fetch_metadata_by_report_id_tool,
            sample_report_data_tool,
            get_filter_domain_values_tool,
        ]

    def create_chain(self):

        llm = ChatLLMG(
            client_id=self.config.client_id,
            client_secret=self.config.client_secret,
            seismic_env=self.config.seismic_env,
            tenant_name=self.tenant,
            # ToDo: Follow up with the AIML team to see if we can have them retrieve API URL based on tenant
            api_url=self.llmg_endpoint,
            task="chat",
            model_kwargs={
                "model": "gpt-4.1-mini-2025-04-14",
                "temperature": 0,
                "FeatureId": "unregistered",  # We'll need to use one eventually, but for now we can use unregistered
                "maxTokens": 10000,
                "UserId": "123",
            },
        )

        return create_react_agent(
            model=llm,
            tools=self.tools,
            prompt=self.system_prompt,
            response_format=ReactFinalAnswer,
            pre_model_hook=self.pre_model_hook,
            post_model_hook=self.post_model_hook,
        )

    def pre_model_hook(self, state: AgentState):
        """
        Pre-model hook to process the state before passing it to the model.
        This hook is called before the model processes each message.
        This function can be used to trim messages, add additional context, or modify the state.
        Args:
            state (AgentState): The current state of the agent, which includes messages and other data.
        """
        trimmed_messages = trim_messages(
            state["messages"],
            strategy="last",
            token_counter=count_tokens_approximately,
            max_tokens=1000,
            start_on="human",
            end_on=("human", "tool"),
        )
        # You can return updated messages either under `llm_input_messages` or
        # `messages` key (see the note below)
        # return {"messages":  [RemoveMessage(REMOVE_ALL_MESSAGES)] + trimmed_messages}
        return {"llm_input_messages": trimmed_messages}

    def post_model_hook(self, state: AgentState):
        """
        Post-model hook to process the state after the model has processed the messages.
        This hook is called after the model processes each message.
        Args:
            state (AgentState): The current state of the agent, which includes messages and other data.
        """

        # Log the current state for debugging
        self.logger.debug("Agent State", state=state)
        # If the last message was not a tool call, the model has finished the ReAct cycle
        # Prepare the state to return the final answer by trimming the messages
        last_message = state["messages"][-1] if state["messages"] else None
        if not last_message.tool_calls:
            return {
                "messages": [RemoveMessage(REMOVE_ALL_MESSAGES)] + [last_message],
                "is_last_message": True,
            }

        return state

    # ToDo: See if the AIML team can improve the ChatLLMG to suport streaming updates
    # Currently, the lack of stream support means that we cannot capture metadata like token usage
    def get_agent_messages(self, stream, output_messages_key="llm_input_messages") -> list:
        """
        Log the stream of updates from the agent and return the messages.
        Args:
            stream: The stream of updates from the agent.
            output_messages_key: The key that the pre_model_hook uses to store messages.
            Returns:
                A list of messages from the agent.
        """
        messages = []
        for chunk in stream:
            for node, update in chunk.items():
                match node:
                    case "pre_model_hook":
                        messages_key = output_messages_key
                    case "generate_structured_response":
                        messages_key = "structured_response"
                    case _:
                        messages_key = "messages"
                if not update.get(messages_key):
                    self.logger.debug(f"No messages in update from node {node}", node=node)
                    continue
                for message in update[messages_key]:
                    self.logger.debug(f"Update from node: {node}", node=node, message=message)
                messages.append((node, update[messages_key]))
        return messages

    def set_current_date(self, current_date: str):
        """
        Set the current date for the agent's system prompt.

        If system prompt contains a placeholder for current_date, replace it
        If not in the prompt, it will be ignored

        Args:
            current_date (str): The current date in 'YYYY-MM-DD' format.
        """
        self.system_prompt = self.system_prompt.replace("{current_date}", current_date)

    @timer
    async def answer_question(
        self,
        question,
    ):
        """
        Answer a question using the agentic ReAct approach.

        Args:
            question (str): The question to answer

        Returns:
            dict: A dictionary containing the final_answer and intermediate responses
        """
        chain = self.create_chain()
        inputs = {"messages": [HumanMessage(content=question)]}
        try:
            response = self.get_agent_messages(
                chain.stream(
                    input=inputs,
                    config={"recursion_limit": self.graph_recursion_limit},
                    stream_mode="updates",
                ),
                output_messages_key="llm_input_messages",
            )
        except GraphRecursionError as e:
            self.logger.error(f"Graph recursion error: {e}", exc_info=e, question=question)
            return {
                "error": True,
                "answer": "Error processing the question. Agent recursions exceeded limit.",
                "exception": str(e),
            }
        try:
            # Retrieve the last message from the agent
            _, last_agent_message = next(
                (
                    (node, msg)
                    for node, messages in reversed(response)
                    for msg in messages
                    if node == "agent"
                ),
                (None, None),
            )
            # Retrieve the structured response from the agent
            _, structured_response = next(
                (
                    (node, data)
                    for node, data in reversed(response)
                    if node == "generate_structured_response"
                ),
                (None, None),
            )
            conversations = [
                Conversation(
                    title=node,
                    context=msg.__class__.__name__,
                    response=(msg.content),
                )
                for node, messages in response
                for msg in messages
                if hasattr(msg, "content")
                and msg.content
                and node
                not in [
                    "pre_model_hook",
                    "generate_structured_response",
                    "post_model_hook",
                ]
            ]

            response_data = (
                [
                    await execute_report(self.ssrs_client, self.tenant, report)
                    for report in structured_response.reports
                ]
                if structured_response
                else []
            )
            self.logger.info(f"Response data: {response_data}", question=question, response_data=response_data)
            return {
                "final_answer": (
                    structured_response.thoughts
                    if structured_response
                    else last_agent_message
                ),
                "conversations": conversations,
                "fields_and_filters": (
                    structured_response.reports if structured_response else None
                ),
                "response_data": response_data,
            }
        except ValueError as e:
            raise ValueError(f"Unexpected response format from the agent", e)

    @timer
    async def recommend_reports(self, question) -> ReportRecommendationAgentModuleResponse:
        """
        Recommend reports based on the provided question.

        Args:
            question (str): The question to answer

        Returns:
            ReportRecommendationAgentModuleResponse: The recommended reports
        """
        result = await self.answer_question(question=question)
        try:
            recommended_reports = (
                [
                    ReportRecommendation(report_name=r.report_name, id=r.id)
                    for r in result["fields_and_filters"]
                ]
                if result["fields_and_filters"]
                else []
            )
            return ReportRecommendationAgentModuleResponse(
                reports=recommended_reports, conversation=result["conversations"]
            )

        except Exception as e:
            self.logger.error(f"Error generating recommended report: {e}", exc_info=e, question=question)
            return ReportRecommendationAgentModuleResponse(
                reports=[],
                conversation=result["conversations"],
                error=True,
                error_message="Error generating recommended report. Please try again later.",
                exception=str(e),
            )

    @timer
    async def recommend_fields_and_filters(self, question, report_ids) -> dict:
        """
        Recommend fields and filters based on the provided question and report IDs.

        Args:
            question (str): The question to answer
            report_ids (list): List of report IDs to consider

        Returns:
            dict: A dictionary containing the recommended fields and filters and any additional information
        """
        # Compose a message that includes the question and the report IDs as context
        # so the agent can use its tools to fetch metadata and recommend fields/filters.
        # The agent's tools are responsible for fetching the metadata for these report_ids.
        try:
            # You may want to include the report_ids in the initial message for clarity,
            # but the agent should use its tools to fetch the metadata.
            initial_message = (
                f"{question}\n\nConsider only these report IDs: {', '.join(report_ids)}"
            )
            result = await self.answer_question(question=initial_message)
            return {
                "answer": ReportFieldsFiltersResponse(
                    reports=result["fields_and_filters"]
                ),
                "conversations": result["conversations"],
                "error": False,
            }
        except Exception as e:
            self.logger.error(f"Error in recommend_fields_and_filters: {e}", exc_info=e, question=question)
            return {
                "error": True,
                "answer": {
                    "message": "Error generating fields and filters. Please try again later.",
                    "exception": f"{type(e).__name__}: {str(e)}",
                }
            }
