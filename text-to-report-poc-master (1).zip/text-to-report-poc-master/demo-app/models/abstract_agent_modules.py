
from abc import ABC, abstractmethod
from pydantic import BaseModel
from services.abstract_llm_client import AbstractLLMClient, TokenUsage
from typing import Callable
from structures.ssrs_structures import ReportRecommendation

class Conversation(BaseModel):
    title: str
    context: str
    response: object

class ReportRecommendationAgentModuleResponse():
    reports: list[ReportRecommendation]
    conversations: list[Conversation]
    token_usage: TokenUsage
    error: bool = False
    error_message: str = None
    exception: str = None

    def __init__(self, reports=None, conversations=None, token_usage=None, 
                 error=False, error_message=None, exception=None):
        self.reports=reports or []
        self.conversations=conversations or []
        self.token_usage=token_usage or TokenUsage.empty()
        self.error = error
        self.error_message = error_message
        self.exception = exception

    def __init__(self, progress:"ReportRecommendationAgentModuleResponse"=None, reports=None, conversation=None, token_usage=None):
        self.reports = reports or []
        if progress:
            self.conversations = progress.conversations + [conversation] if conversation else progress.conversations
            self.token_usage = progress.token_usage + token_usage if token_usage else progress.token_usage
        else:
            self.conversations=conversation or []
            self.token_usage=token_usage or TokenUsage.empty()


class AbstractReportRecommendationAgentModule(ABC):
    
    @staticmethod
    @abstractmethod
    async def recommend_reports(
        question:str, 
        progress:ReportRecommendationAgentModuleResponse, 
        fetch_metadata:Callable[[list[str], bool], list[dict]],
        llm_client:AbstractLLMClient
    ) -> ReportRecommendationAgentModuleResponse:
        """
        Recommend reports based on the question.
        """
        pass

# I'm just leaving this as a stub for now, as there's not currently a need for multiple implementations or turns for configuration.
class AbstractReportConfigurationAgentModule(ABC):
    """
    Abstract base class for report configuration agent modules.
    """

    @staticmethod
    @abstractmethod
    async def recommend_fields_and_filters(
        question: str,
        progress: object,  # ReportConfigurationAgentModuleResponse
        fetch_metadata: Callable[[list[str], bool], list[dict]],
        llm_client: AbstractLLMClient
    ) -> dict:
        """
        Recommend fields and filters based on the question and selected reports.
        """
        pass