import structlog
from structures.ssrs_structures import ReportResponse, ReportRecommendation
from models.abstract_reporting_model import ReportRecommendationAgentModuleResponse
from .prompts import (
    create_filter_reports_prompt,
    create_recommended_report_prompt,
    check_report_relevancy_prompt,
)
from .abstract_agent_modules import ReportRecommendationAgentModuleResponse, AbstractReportRecommendationAgentModule, TokenUsage, Conversation
import asyncio

"""
Narrow down the report recommendations to the best 0-2 reports based on context.
All of the relevant context for all reports is provided to the LLM. This makes it accurate with fewer reports, but less accurate with more reports.
This is best used after another filter, such as broad or relevancy.
"""
class NarrowAgentModule(AbstractReportRecommendationAgentModule):
    @staticmethod
    async def recommend_reports(question, progress, fetch_metadata, llm_client) -> ReportRecommendationAgentModuleResponse:
        report_ids = [report.id for report in progress.reports]

        try:
            # Filter down to up to 2 reports based on metadata
            filter_reports_prompt = create_filter_reports_prompt(await fetch_metadata(report_ids))
            filtered_report_response = await llm_client.get_response_structured(
                context=filter_reports_prompt,
                question=question,
                text_format=ReportResponse,
            )
        except Exception as e:
            structlog.get_logger().error(f"Error narrowing report recommendations: {e}", question=question, exc_info=e)
            return {
                "error": True,
                "answer": "Error narrowing report recommendations. Please try again later.",
                "exception": str(e),
            }
        return ReportRecommendationAgentModuleResponse(
            progress = progress,
            reports = filtered_report_response.response.reports,
            conversation = Conversation(
                title = "Choosing the Report (Narrow)",
                context = filter_reports_prompt,
                response= filtered_report_response.response,
            ),
            token_usage = filtered_report_response.token_usage,
        )

"""
For each report, makes an LLM call (with all relevant report context) to determine if the report is relevant to the question.
This is the most accurate (besides narrow), but also the most expensive. It is only slightly slower than the broad agent module.
Generally, another module should follow this one to narrow down the results to the best few reports.
"""
class RelevancyAgentModule(AbstractReportRecommendationAgentModule):
    @staticmethod
    async def recommend_reports(question, progress, fetch_metadata, llm_client) -> ReportRecommendationAgentModuleResponse:
        try:
            relevant_reports = []
            relevancy_token_usage = TokenUsage.empty()
            metadata_list = await fetch_metadata([report.id for report in progress.reports])

            async def check_one(report, metadata_list):
                metadata = next((m for m in metadata_list if m.get("id") == report.id), None)
                if not metadata:
                        structlog.get_logger().debug(f"Metadata for report {report.report_name} not found, skipping.", report_name=report.report_name, question=question)
                        return None
                relevant_reports_prompt = check_report_relevancy_prompt(metadata)
                return await llm_client.get_response(
                    context=relevant_reports_prompt,
                    question=question)

            tasks = [check_one(report, metadata_list) for report in progress.reports]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for i, relevancy_response in enumerate(results):
                if not relevancy_response or isinstance(relevancy_response, Exception):
                    continue

                relevancy_token_usage += relevancy_response.token_usage
                if relevancy_response.response == "True": # apparently python is dumb about this
                    relevant_reports.append(progress.reports[i])
                    structlog.get_logger().debug(f"Report {progress.reports[i].report_name} may be relevant.", report_name=progress.reports[i].report_name, question=question)
            return ReportRecommendationAgentModuleResponse(
                reports=relevant_reports,
                progress=progress,
                conversation = Conversation(
                    title="Choosing the Report (Relevancy)",
                    context="Example, others omitted:\n" + check_report_relevancy_prompt(metadata_list[0]),
                    response=[ReportRecommendation(id=report.id, report_name=report.report_name) for report in relevant_reports]
                ),
                token_usage = relevancy_token_usage,
            )
        except Exception as e: # TODO: better error handling
            structlog.get_logger().error(f"Error filtering relevant reports: {e}", question=question, exc_info=e)
            return {
                "error": True,
                "answer": "Error filtering relevant reports. Please try again later.",
                "exception": str(e),
            }

"""
The same as BroadAgentModule, but with descriptions on the fields.
"""
class BroadVerboseAgentModule(AbstractReportRecommendationAgentModule):
    @staticmethod
    async def recommend_reports(question, progress, fetch_metadata, llm_client) -> ReportRecommendationAgentModuleResponse:
        return await BroadAgentModule.broad_filtering(question, progress, fetch_metadata, llm_client, verbose=True)

"""
Provides a broad overview of the reports, returning the best 3-5 reports based on the question.
This is the cheapest and fastest option, but may not be as accurate as the other options. It's the best bang for your buck.
Only provides the report names, descriptions, and a the names of a few key fields and metrics to the LLM.
"""
class BroadAgentModule(AbstractReportRecommendationAgentModule):
    @staticmethod
    async def recommend_reports(question, progress, fetch_metadata, llm_client) -> ReportRecommendationAgentModuleResponse:
        return await BroadAgentModule.broad_filtering(question, progress, fetch_metadata, llm_client, verbose=False)

    @staticmethod
    async def broad_filtering(question, progress, fetch_metadata, llm_client, verbose=False):
        try:
            metadata_list = await fetch_metadata([report.id for report in progress.reports])
            broad_reports_prompt = create_recommended_report_prompt(metadata_list, verbose)
            broad_report_response = await llm_client.get_response_structured(
                context=broad_reports_prompt,
                question=question,
                text_format=ReportResponse,
            )
            return ReportRecommendationAgentModuleResponse(
                reports=broad_report_response.response.reports,
                progress=progress,
                conversation=Conversation(
                    title="Choosing the Report (Broad)",
                    context=broad_reports_prompt,
                    response=broad_report_response.response,
                ),
                token_usage=broad_report_response.token_usage,
            )
        except Exception as e:
            structlog.get_logger().error(f"Error generating broad report recommendations: {e}", question=question, exc_info=e)
            return {
                "error": True,
                "answer": "Error generating broad report recommendations. Please try again later.",
                "exception": str(e),
            }
