import openai
import datetime
import asyncio
from kink import inject

from seismic_foundation.config.ConfigProvider import ConfigProvider
import structlog

from tests.test_constants import REPORT_DESCRIPTIONS
from services.ssrs_client import SSRSClient
from services.abstract_llm_client import AbstractLLMClient, TokenUsage
from structures.ssrs_structures import ReportFieldsFiltersResponse, ReportRecommendation

from .abstract_reporting_model import AbstractReportingModel
from .agent_module_registry import AgentModuleRegistry
from .abstract_agent_modules import (
    Conversation,
    TokenUsage,
    ReportRecommendationAgentModuleResponse,
)
from .prompts import (
    create_fields_and_filters_prompt,
    create_final_answer_prompt,
)
from tools.reporting_tools import execute_report
from util.timer_util import timer


@inject
class PromptChainModel(AbstractReportingModel):
    """
    Implementation of Model that uses a chain of prompts to generate an answer.

    This class encapsulates the prompt chaining logic from the go() method,
    separating it from the web application code for better testability.
    """

    def __init__(
        self,
        config: ConfigProvider,
        ssrs_client: SSRSClient,
        llm_client: AbstractLLMClient,
        tenant: str,
        model_kwargs=None,
    ) -> None:
        """
        Initialize the prompt chain model.

        Args:
            config (ConfigProvider): Configuration object containing API keys
            ssrs_client (SSRSClient): SSRS client for report operations
            llm_client (AbstractLLMClient): LLM client for language model operations
            tenant (str): The tenant for the model
            model_kwargs (dict, optional): Additional model configuration parameters
        """
        openai.api_key = config.openai_api_key
        self._ssrs_client = ssrs_client
        self._llm_client = llm_client
        self.tenant = tenant
        self.model_kwargs = model_kwargs or {}
        self.logger = structlog.get_logger()

        # Extract configuration from model_kwargs
        self.chosen_prompt_options = self.model_kwargs.get(
            "chosen_prompt_options",
            AgentModuleRegistry.default_report_recommendation_agent_options,
        )

    async def answer_question(self, question):
        """
        Answer a question using the prompt chain approach.

        Args:
            question (str): The question to answer

        Returns:
            dict: A dictionary containing the final_answer and intermediate responses
        """

        self.logger.info(f"Answering question: {question}", question=question)

        # Retrieve reports recommendations
        reports_response = await self.recommend_reports(question)

        # Retrieve fields and filters based on the recommended reports
        report_ids = [report.id for report in reports_response.reports]
        if not report_ids:
            return {
                "error": True,
                "final_answer": "No recommended reports found.",
            }

        fields_and_filters_response = await self.recommend_fields_and_filters(
            question, report_ids
        )

        # Generate final answer
        final_prompt = create_final_answer_prompt(fields_and_filters_response["answer"])
        final_response = await self._llm_client.get_response(final_prompt, question)

        response_data = [
            await execute_report(self._ssrs_client, self.tenant, report)
            for report in fields_and_filters_response.get("answer").reports
        ]
        self.logger.info(f"Response data: {response_data}", question=question, response_data=response_data)

        # Return the final answer along with intermediate results for debugging/testing
        return {
            "final_answer": final_response.response,
            "fields_and_filters": fields_and_filters_response["answer"].reports,
            "conversations": reports_response.conversations + [
                Conversation(
                    title="Configuring the Report",
                    context=fields_and_filters_response["prompt"],
                    response=fields_and_filters_response["answer"],
                ),
                Conversation(
                    title="Final Answer",
                    context=final_prompt,
                    response=final_response.response,
                ),
            ],
            "response_data": response_data,
            "error": False,
            "token_usage": (
                reports_response.token_usage
                + fields_and_filters_response.get("token_usage", TokenUsage.empty())
                + final_response.token_usage
            ),
        }

    @timer
    async def recommend_reports(self, question) -> ReportRecommendationAgentModuleResponse:
        """
        Recommend reports based on the provided question.
        """
        progress = ReportRecommendationAgentModuleResponse(
            reports=[ReportRecommendation(id=report.get("id"), report_name=report.get("reportName")) for report in await self._fetch_reports()]
        )
        for prompt_option in self.chosen_prompt_options:
            self.logger.debug(f"Processing prompt option: {prompt_option}", question=question)
            if prompt_option not in AgentModuleRegistry.report_recommendation_agent_options.keys():
                raise ValueError(f"Unrecognized prompt option: {prompt_option}")

            response = await AgentModuleRegistry.report_recommendation_agent_options[
                prompt_option
            ].recommend_reports(
                question,
                progress,
                self._fetch_metadata_callback,
                self._llm_client,
            )
            self.logger.info(f"Response for {prompt_option}: {response.conversations[-1].response}", question=question)
            if not response.reports or len(response.reports) == 0:
                self.logger.warning(f"No reports found for prompt option: {prompt_option}, stopping further processing.", question=question)
                return response
            progress = response
        return progress

    @timer
    async def recommend_fields_and_filters(self, question, report_ids) -> dict:
        """
        Recommend fields and filters based on the provided question and report IDs.

        Args:
            question (str): The question to answer
            report_ids (list): List of report IDs

        Returns:
            dict: A dictionary containing the recommended fields and filters
        """
        # Fetch metadata for the given report IDs
        try:
            metadata_list = await self._fetch_report_metadata(report_ids)
        except Exception as e:
            self.logger.warning(f"Error fetching report metadata: {e}", question=question, report_ids=report_ids)
            return {
                "error": True,
                "answer": {
                    "message": "Error fetching report metadata. Please try again later.",
                    "exception": str(e)
                },
            }

        # Get current_date from model_kwargs if provided
        current_date = self.model_kwargs.get("current_date")
        if current_date is None:
            current_date = datetime.datetime.now().strftime('%Y-%m-%d')

        # Generate metadata context
        prompt = None
        try:
            prompt = create_fields_and_filters_prompt(metadata_list, current_date)

            # Get recommended fields and filters
            field_response = await self._llm_client.get_response_structured(
                context=prompt,
                question=question,
                text_format=ReportFieldsFiltersResponse,
            )
            self.logger.info(f"Field response: {field_response.response}", question=question)
        except Exception as e:
            self.logger.error(f"Error generating fields and filters: {e}", question=question, exc_info=e)
            return {
                "error": True,
                "answer": {
                    "message": "Error generating fields and filters. Please try again later.",
                    "prompt": prompt,
                    "exception": str(e),
                },
            }

        return {
            "error": False,
            "answer": field_response.response,
            "prompt": prompt,
            "token_usage": field_response.token_usage,
        }

    async def _fetch_metadata_callback(
        self, report_ids, short=False
    ):  # "short" is now unused, but maybe it will be useful in the future?
        reports = [report for report in await self._fetch_reports() if report.get("id") in report_ids]
        if short:
            return reports
        metadata_list = await self._fetch_report_metadata(report_ids)
        # combine metadata with reports by id
        reports_with_metadata = []
        for report in reports:
            report_metadata = next((m for m in metadata_list if m.get("id") == report.get("id")), None)
            if report_metadata:
                # Only add keys from report_metadata that are not already in report
                for k, v in report_metadata.items():
                    if k not in report:
                        report[k] = v
                reports_with_metadata.append(report)
        return reports_with_metadata

    async def _fetch_reports(self):
        """Fetch reports using the provided reports_provider."""
        # reports_response = self._ssrs_client.get_all_reports()
        # While we're modifying report descriptions and testing, we can use the test data directly
        reports_response = {
            "data": REPORT_DESCRIPTIONS["reports"],
        }
        return reports_response.get("data", [])

    @timer
    async def _fetch_report_metadata(self, report_ids):
        """Fetch metadata for the identified reports."""
        async def fetch_one(report_id):
            try:
                return await self._ssrs_client.get_report_metadata(self.tenant, report_id)
            except Exception as e:
                self.logger.warning(f"Error fetching metadata for report ID {report_id}: {e}", report_id=report_id)
                return None

        tasks = [fetch_one(rid) for rid in report_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        metadata_list = []
        for result in results:
            if result is not None and not isinstance(result, Exception) and not result.get("error"):
                metadata_list.append(result)

        return metadata_list
