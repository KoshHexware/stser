// ReAct System Prompt Management
// This module handles the management of ReAct system prompts including:
// - Loading prompts from localStorage
// - Saving prompts to localStorage
// - Managing the default prompt from server
// - UI interactions for prompt selection, creation, and deletion

const REACT_PROMPTS_KEY = 'reactSystemPrompts';
const DEFAULT_PROMPT_NAME = 'Default Prompt';
let reactPrompts = {};

function loadReactPrompts() {
  const saved = localStorage.getItem(REACT_PROMPTS_KEY);
  if (saved) {
    try {
      reactPrompts = JSON.parse(saved);
    } catch (e) {
      console.error('Error parsing saved prompts:', e);
      reactPrompts = {};
    }
  }
  
  // Always ensure the default prompt from server is included
  const defaultPromptFromServer = document.getElementById('reactSystemPrompt').value;
  reactPrompts[DEFAULT_PROMPT_NAME] = defaultPromptFromServer;
  
  updatePromptSelect();
}

function saveReactPrompts() {
  localStorage.setItem(REACT_PROMPTS_KEY, JSON.stringify(reactPrompts));
}

function updatePromptSelect() {
  const select = document.getElementById('promptSelect');
  const deleteBtn = document.getElementById('deletePromptBtn');
  
  // Clear existing options except the first one
  select.innerHTML = '<option value="">Select a saved prompt...</option>';
  
  // Add Default Prompt first
  if (reactPrompts[DEFAULT_PROMPT_NAME]) {
    const defaultOption = document.createElement('option');
    defaultOption.value = DEFAULT_PROMPT_NAME;
    defaultOption.textContent = DEFAULT_PROMPT_NAME;
    select.appendChild(defaultOption);
  }
  
  // Add other saved prompts (excluding default)
  Object.keys(reactPrompts)
    .filter(name => name !== DEFAULT_PROMPT_NAME)
    .sort()
    .forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      select.appendChild(option);
    });
  
  // Enable/disable delete button - disable for default prompt or no selection
  deleteBtn.disabled = !select.value || select.value === DEFAULT_PROMPT_NAME;
}

function loadSelectedPrompt() {
  const select = document.getElementById('promptSelect');
  const textarea = document.getElementById('reactSystemPrompt');
  const deleteBtn = document.getElementById('deletePromptBtn');
  
  if (select.value && reactPrompts[select.value]) {
    textarea.value = reactPrompts[select.value];
  }
  
  // Enable/disable delete button - disable for default prompt or no selection
  deleteBtn.disabled = !select.value || select.value === DEFAULT_PROMPT_NAME;
}

function addNewPrompt() {
  const textarea = document.getElementById('reactSystemPrompt');
  const currentPrompt = textarea.value.trim();
  
  if (!currentPrompt) {
    alert('Please enter a prompt first');
    return;
  }
  
  // Check if prompt must contain required placeholders
  if (!currentPrompt.includes('{input}') || !currentPrompt.includes('{tools}')) {
    alert('Your prompt must include "{input}" and "{tools}" placeholders');
    return;
  }
  
  const name = prompt('Enter a name for this prompt:');
  if (!name) return;
  
  const trimmedName = name.trim();
  if (!trimmedName) {
    alert('Please enter a valid name');
    return;
  }
  
  // Prevent overwriting default prompt
  if (trimmedName === DEFAULT_PROMPT_NAME) {
    alert('You cannot overwrite the Default Prompt. Please choose a different name.');
    return;
  }
  
  // Check if name already exists
  if (reactPrompts[trimmedName]) {
    if (!confirm(`A prompt named "${trimmedName}" already exists. Do you want to replace it?`)) {
      return;
    }
  }
  
  reactPrompts[trimmedName] = currentPrompt;
  saveReactPrompts();
  updatePromptSelect();
  
  // Select the newly added prompt
  document.getElementById('promptSelect').value = trimmedName;
  document.getElementById('deletePromptBtn').disabled = false;
}

function deleteSelectedPrompt() {
  const select = document.getElementById('promptSelect');
  const selectedName = select.value;
  
  if (!selectedName) return;
  
  // Prevent deletion of default prompt
  if (selectedName === DEFAULT_PROMPT_NAME) {
    alert('The Default Prompt cannot be deleted. It is always loaded from the server.');
    return;
  }
  
  if (confirm(`Are you sure you want to delete the prompt "${selectedName}"?`)) {
    delete reactPrompts[selectedName];
    saveReactPrompts();
    updatePromptSelect();
    select.value = '';
    document.getElementById('deletePromptBtn').disabled = true;
  }
}

// Initialize prompt management on page load
document.addEventListener('DOMContentLoaded', function() {
  loadReactPrompts();
});