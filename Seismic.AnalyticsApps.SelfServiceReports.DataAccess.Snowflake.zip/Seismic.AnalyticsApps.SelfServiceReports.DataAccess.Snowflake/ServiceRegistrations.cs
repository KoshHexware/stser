﻿using Microsoft.Extensions.DependencyInjection;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake
{
    public static class ServiceRegistrations
    {
        public static void AddSnowflakeDataServices(this IServiceCollection services)
        {
            services.AddSingleton<ISnowflakeClient, SnowflakeClient>();
        }
    }
}
