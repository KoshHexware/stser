﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake
{
    public class Column
    {
        public required string Name { get; set; }

        public required string DataType { get; set; }
    }

    public class QueryResult
    {
        public required IList<Column> Columns { get; set; }

        public required IList<string[]> Rows { get; set; }

        public int TotalRowCount { get; set; }
    }
}
