﻿using Seismic.Analytics.DataAccess;
using System.Data.Common;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake
{
    public interface ISnowflakeClient
    {
        Task<IList<TResult>> QueryAsync<TResult>(Func<DbConnection, SnowflakeQueryBuilder> action, CancellationToken cancellationToken = default);

        Task<QueryResult> ExecuteSnowflakeQuery(Func<DbConnection, SnowflakeQueryBuilder> action, int? limit = null, CancellationToken cancellationToken = default);

        Task<string> ExportToCsvAsync(Func<DbConnection, SnowflakeQueryBuilder> action, CancellationToken cancellationToken = default);
    }
}
