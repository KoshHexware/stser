﻿using Seismic.Analytics.DataAccess;
using System.Data.Common;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake
{
    public static class SnowflakeUtils
    {
        public static SnowflakeQueryBuilder BuildQuery(DbConnection conn, string query,
            Dictionary<string, string>? stringParams = null,
            Dictionary<string, DateTime?>? dateParams = null,
            Dictionary<string, bool?>? boolParams = null,
            Dictionary<string, int?>? intParams = null,
            Dictionary<string, decimal?>? decimalParams = null,
            Dictionary<string, string[]>? multiStringParams = null)
        {
            var builder = new SnowflakeQueryBuilder(conn, query);

            stringParams?.ToList().ForEach(x => builder.AddStringParameter(x.Key, x.Value));

            dateParams?.ToList().ForEach(x => builder.AddDateTimeParameter(x.Key, x.Value));

            boolParams?.ToList().ForEach(x => builder.AddBooleanParameter(x.Key, x.Value));

            intParams?.ToList().ForEach(x => builder.AddIntParameter(x.Key, x.Value));

            decimalParams?.ToList().ForEach(x => builder.AddDecimalParameter(x.Key, x.Value));

            multiStringParams?.ToList().ForEach(x => builder.AddMultiValueStringParameter(x.Key, x.Value));
            return builder;
        }
    }
}
