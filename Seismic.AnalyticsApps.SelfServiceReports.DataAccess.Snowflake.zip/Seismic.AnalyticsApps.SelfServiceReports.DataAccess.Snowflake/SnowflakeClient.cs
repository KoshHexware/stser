﻿using Seismic.Analytics.DataAccess;
using Seismic.Common.ServiceFoundation;
using System.Data.Common;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake
{
    public class SnowflakeClient(ISeismicContextProvider _contextProvider) : ISnowflakeClient
    {
        // Default timeout for Snowflake queries (milliseconds). Adjust if needed.
        private const int DefaultQueryTimeoutMs = 60000; // 60 seconds - this also matches the nginx timeout. any changes here should match nginx timeout.

        public async Task<IList<TResult>> QueryAsync<TResult>(Func<DbConnection, SnowflakeQueryBuilder> action, CancellationToken cancellationToken = default)
        {
            using var linkedCts = GetCTSWithTimeout(cancellationToken);

            return await _contextProvider.GetContext().ExecuteSnowflakeQuery<TResult>
                    (
                        action,
                        _contextProvider.GetContext().TenantUniqueId,
                        linkedCts.Token
                    );
        }

        public async Task<string> ExportToCsvAsync(Func<DbConnection, SnowflakeQueryBuilder> action, CancellationToken cancellationToken = default)
        {
            using var linkedCts = GetCTSWithTimeout(cancellationToken);

            return await _contextProvider.GetContext().ExecuteSnowflakeQueryToCsv
                    (
                        action,
                        _contextProvider.GetContext().TenantUniqueId,
                        linkedCts.Token
                    );
        }

        public async Task<QueryResult> ExecuteSnowflakeQuery(Func<DbConnection, SnowflakeQueryBuilder> action, int? limit = null, CancellationToken cancellationToken = default)
        {
            using var linkedCts = GetCTSWithTimeout(cancellationToken);

            var dataFrame = await _contextProvider.GetContext().ExecuteSnowflakeQuery
                    (
                        action,
                        _contextProvider.GetContext().TenantUniqueId,
                        limit,
                        linkedCts.Token
                    );

            return new QueryResult
            {
                Columns = dataFrame.Columns.Select(c => new Column
                {
                    Name = c.Name,
                    DataType = c.SnowflakeDataType
                }).ToList(),
                Rows = dataFrame.Rows,
                TotalRowCount = dataFrame.TotalRowCount
            };
        }

        private CancellationTokenSource GetCTSWithTimeout(CancellationToken ct)
        {
            var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            // Apply default timeout on top of the provided token
            linkedCts.CancelAfter(DefaultQueryTimeoutMs);
            return linkedCts;
        }

    }
}
