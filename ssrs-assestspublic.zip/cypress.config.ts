const { defineConfig } = require("cypress");
const allureWriter = require('@shelex/cypress-allure-plugin/writer');

module.exports = defineConfig({
  reporter:'mochawesome',
  reporterOptions: {
    reportDir: 'cypress/results',
    overwrite: false,
    html: false,
    json: true,
  },
  component: {
    video: false,
    viewportWidth: 1000,
    viewportHeight: 600,
    env: {
      allure: true,
      allureResultsPath: "cypress/allure/result",
    },
    devServer: {
      framework: "react",
      bundler: "webpack",
      webpackConfig: require("./config/cypress.config"),
    },
    setupNodeEvents(on, config) {
      require('@cypress/code-coverage/task')(on, config)
      allureWriter(on, config);
      return config
    },
  },
});
