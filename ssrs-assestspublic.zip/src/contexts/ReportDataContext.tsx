
import React, { useReducer, ReactNode } from 'react';
import * as ReducerActions from './types';
import { ReportDataContext } from './index';
import { IReport } from '../interfaces/SSRTypes';
import { IReportDataState } from '../interfaces/ISSRContextTpes';
import { ContextAction } from '../interfaces/ISSRContextTpes';

interface ReportDataProviderProps {
    children: ReactNode;
    values?: Partial<IReportDataState>;
}

const reportDataInitialState: IReportDataState = {
    selectedReport: {} as IReport,
    reportMetadata: {},
    isReportShared: false,
    showReportSavedToast: false,
    isReportDrillIn: false,
    drillInReportExportPayload: {}
};

export const reportDataReducer = (
    state: IReportDataState,
    action: ContextAction
): IReportDataState => {
    switch (action.type) {
        case ReducerActions.SET_SELECTED_REPORT:
            return { ...state, selectedReport: action.payload };
        case ReducerActions.SET_SELECTED_REPORT_METADATA:
            return { ...state, reportMetadata: action.payload };
        case ReducerActions.SET_IS_REPORT_SHARED:
            return { ...state, isReportShared: action.payload };
         case ReducerActions.SET_SHOW_REPORT_SAVED_TOAST:
            return { ...state, showReportSavedToast: action.payload};
        case ReducerActions.SET_IS_REPORT_DRILL_IN:
            return { ...state, isReportDrillIn: action.payload};
        case ReducerActions.SET_DRILL_IN_REPORT_EXPORT_PAYLOAD:
            return { ...state, drillInReportExportPayload: action.payload};
        default:
            return state;
    }
};

const ReportDataProvider: React.FC<ReportDataProviderProps> = ({
    children,
    values = {},
}) => {
    const [state, dispatch] = useReducer(reportDataReducer, {
        ...reportDataInitialState,
        ...values,
    });

    const setSelectedReport = (data: IReport): void => {
        dispatch({
            type: ReducerActions.SET_SELECTED_REPORT,
            payload: data,
        });
    };

    const setShowReportSavedToast = (data: boolean) => {
        dispatch({
            type: ReducerActions.SET_SHOW_REPORT_SAVED_TOAST,
            payload: data,
        });
    };

    const setReportMetadata = (data: any): void => {
        dispatch({
            type: ReducerActions.SET_SELECTED_REPORT_METADATA,
            payload: data,
        });
    };

    const setIsReportShared = (data: boolean): void => {
        dispatch({
            type: ReducerActions.SET_IS_REPORT_SHARED,
            payload: data,
        });
    };

    const setIsReportDrillIn = (data: boolean): void => {
        dispatch({
            type: ReducerActions.SET_IS_REPORT_DRILL_IN,
            payload: data,
        });
    };

    const setDrillInReportExportPayload = (data: any): void => {
        dispatch({
            type: ReducerActions.SET_DRILL_IN_REPORT_EXPORT_PAYLOAD,
            payload: data,
        });
    };

    const contextValue = {
        ...state,
        setSelectedReport,
        setReportMetadata,
        setIsReportShared,
        setShowReportSavedToast,
        setIsReportDrillIn,
        setDrillInReportExportPayload
    };

    return (
        <ReportDataContext.Provider value={contextValue}>
            {children}
        </ReportDataContext.Provider>
    );
};

export default React.memo(ReportDataProvider);