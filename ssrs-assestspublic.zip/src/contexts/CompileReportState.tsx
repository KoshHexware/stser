import React, { useReducer } from 'react';
import * as ReducerActions from './types';
import { CompileReportContext } from './index';
import { IField, ICompileReportState, ReportsSummary } from '../interfaces/IReport';
import { IFilter } from '../interfaces/IFilterTypes';
import {
  areFiltersChanged,
  areTeamsitesChanged,
} from '../utils/reportFiltersUtils';
import { ITeamsites } from '../interfaces/IAppData';

export const compileReportInitialState: ICompileReportState = {
  isChanged: false,
  isSaved: false,
  shouldFetchOwnedReports: false,
  id: '',
  systemReportId: '',

  reportName: '',
  updatedReportName: '',

  description: '',
  updatedDescription: '',

  ownerUserId: '',

  fields: [],
  updatedFields: [],

  filters: [],
  updatedFilters: [],
  isFilterCardClicked: false,
  currentSelectedFilter: {} as IFilter,
  isNewFilterAdding: false,

  orderBy: '',
  updatedOrderBy: '',

  orderField: '',
  updatedOrderField: '',
  addColumnFields: [],

  filtersPickList: new Map<string, string[]>(),

  originalTeamsites: [] as Array<ITeamsites> | [],
  updatedTeamsites: [] as Array<ITeamsites> | [],
  isTeamsitesClicked: false,
  tempTeamsites: [] as Array<ITeamsites> | [],
  showTeamsitePicker: false,

  showLeaveWithoutSaveModal: false,
  gridHiddenColumns: [],
  allReportsSummary: [] as Array<ReportsSummary>,
  shouldTriggerWithDefaultsAPI: false,
};

export const CompileReportReducer = (
  state: ICompileReportState,
  action: any
) => {
  const newState = { ...state };
  switch (action.type) {
    case ReducerActions.SET_REPORT_ID:
      newState.id = action.payload;
      break;
    case ReducerActions.SET_SYSTEM_REPORT_ID:
      newState.systemReportId = action.payload;
      break;
    case ReducerActions.SET_IS_CHANGED:
      newState.isChanged = action.payload;
      break;
    case ReducerActions.SET_IS_SAVED:
      newState.isSaved = action.payload;
      break;
    case ReducerActions.SET_SHOULD_FETCH_OWNED_REPORTS:
      newState.shouldFetchOwnedReports = action.payload;
      break;
    case ReducerActions.SET_REPORT_NAME:
      newState.reportName = action.payload;
      break;
    case ReducerActions.SET_UPDATED_REPORT_NAME:
      newState.updatedReportName = action.payload;
      break;
    case ReducerActions.SET_REPORT_DESCRIPTION:
      newState.description = action.payload;
      break;
    case ReducerActions.SET_UPDATED_REPORT_DESCRIPTION:
      newState.updatedDescription = action.payload;
      break;
    case ReducerActions.SET_FEILDS:
      newState.fields = action.payload;
      break;
    case ReducerActions.SET_UPDATED_FEILDS:
      newState.updatedFields = action.payload;
      const fieldsNames = action.payload
        .filter((f) => f.isDefault)
        .map((f2) => f2.name);
      newState.addColumnFields = newState.addColumnFields?.map((f) => {
        return { ...f, isDefault: fieldsNames.includes(f.name) };
      });
      break;
    case ReducerActions.SET_FILTERS:
      newState.filters = action.payload;
      break;
    case ReducerActions.SET_UPDATED_FILTERS:
      newState.updatedFilters = action.payload;
      break;
    case ReducerActions.SET_ORDERBY:
      newState.orderBy = action.payload;
      break;
    case ReducerActions.SET_UPDATED_ORDERBY:
      newState.updatedOrderBy = action.payload;
      break;
    case ReducerActions.SET_ORDER_FEILD:
      newState.orderField = action.payload;
      break;
    case ReducerActions.SET_UPDATED_ORDER_FEILD:
      newState.updatedOrderField = action.payload;
      break;
    case ReducerActions.SET_UPDATED_TEAMSITES:
      newState.updatedTeamsites = action.payload;
      break;
    case ReducerActions.SET_ORIGINAL_TEAMSITES:
      newState.originalTeamsites = action.payload;
      break;
    case ReducerActions.SET_IS_TEAMSITES_OPEN:
      newState.isTeamsitesClicked = action.payload;
      break;
    case ReducerActions.SET_TEMP_TEAMSITES:
      newState.tempTeamsites = action.payload;
      break;
    case ReducerActions.RSET_COMPILE_REPORT_UPDATE_STATE:
      const fields = newState.fields
        .filter((f) => f.isDefault)
        .map((f2) => f2.name);
      newState.updatedReportName = newState.reportName;
      newState.updatedDescription = newState.description;
      newState.updatedFields = JSON.parse(JSON.stringify(newState.fields));
      newState.updatedFilters = JSON.parse(JSON.stringify(newState.filters));
      newState.updatedOrderBy = newState.orderBy;
      newState.updatedOrderField = newState.orderField;
      newState.addColumnFields = newState.addColumnFields.map((f) => {
        return { ...f, isDefault: fields.includes(f.name) };
      });
      newState.currentSelectedFilter = {} as IFilter;
      newState.filtersPickList = new Map<string, string[]>();
      break;
    case ReducerActions.RSET_COMPILE_REPORT_ORIGINAL_STATE:
      const {
        reportName,
        description,
        orderField,
        orderBy,
        fields: newFields,
        filters,
        addColumnFields,
        isSaved,
      } = action.payload;
      newState.isSaved = isSaved;
      newState.shouldFetchOwnedReports = true;
      newState.updatedReportName = newState.reportName = reportName;
      newState.updatedDescription = newState.description = description;
      newState.fields = newFields;
      newState.updatedFields = JSON.parse(JSON.stringify(newFields));
      newState.filters = filters;
      newState.updatedFilters = JSON.parse(JSON.stringify(filters));
      newState.updatedOrderBy = newState.orderBy = orderBy;
      newState.updatedOrderField = newState.orderField = orderField;
      newState.addColumnFields = addColumnFields;
      break;
    case ReducerActions.SET_IS_FILTER_CARD_CLICKED:
      newState.isFilterCardClicked = action.payload;
      break;
    case ReducerActions.SET_CURRENT_SELECTED_FILTER:
      newState.currentSelectedFilter = action.payload;
      break;
    case ReducerActions.SET_IS_NEW_FILTER_ADDING:
      newState.isNewFilterAdding = action.payload;
      break;
    case ReducerActions.ADD_TO_FILTERS_PICKLIST:
      const { key, values } = action.payload;
      newState.filtersPickList.set(key, values);
      break;
    case ReducerActions.SET_SHOW_LEAVE_WITHOUT_SAVE_MODAL:
      newState.showLeaveWithoutSaveModal = action.payload;
      break;
    case ReducerActions.SET_GRID_HIDDEN_COLUMNS:
      newState.gridHiddenColumns = action.payload;
      break;
    case ReducerActions.SET_ALL_REPORTS_SUMMARY:
      newState.allReportsSummary = action.payload;
      break;
    case ReducerActions.SET_SHOULD_TRIGGER_WITH_DEFAULTS_API:
      newState.shouldTriggerWithDefaultsAPI = action.payload;
      break;
    default:
      break;
  }
  const isOrederByChanged = newState.orderBy?.toLowerCase() !== newState.updatedOrderBy?.toLowerCase();
  const isOrderFeildChanged = newState.orderField?.toLowerCase() !== newState.updatedOrderField?.toLowerCase();
  const areFieldsChanged =
    JSON.stringify(newState.fields) !== JSON.stringify(newState.updatedFields);
  const filtersChanged = areFiltersChanged(
    newState.filters,
    newState.updatedFilters,
    false
  );
  const isTeamsitesChanged = areTeamsitesChanged(
    newState.originalTeamsites,
    newState.updatedTeamsites
  );
  newState.isChanged =
    isOrederByChanged ||
    isOrderFeildChanged ||
    areFieldsChanged ||
    filtersChanged ||
    isTeamsitesChanged;
  return newState;
};

const CompileReportState = ({ children, values }) => {
  const [state, dispatch] = useReducer(CompileReportReducer, values);

  const setIsChanged = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_CHANGED,
      payload: data,
    });
  };

  const setIsSaved = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_SAVED,
      payload: data,
    });
  };

  const setShouldFetchOwnedReports = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_SHOULD_FETCH_OWNED_REPORTS,
      payload: data,
    });
  };

  const setUpdatedReportName = (data: string) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_REPORT_NAME,
      payload: data,
    });
  };

  const setUpdatedDescription = (data: string) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_REPORT_DESCRIPTION,
      payload: data,
    });
  };

  const setUpdatedFields = (data: IField[]) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_FEILDS,
      payload: data,
    });
  };

  const setUpdatedFilters = (data: IFilter[]) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_FILTERS,
      payload: data,
    });
  };

  const setUpdatedOrderBy = (data: string) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_ORDERBY,
      payload: data,
    });
  };

  const setUpdatedOrderField = (data: string) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_ORDER_FEILD,
      payload: data,
    });
  };

  const setReportName = (data: string) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_REPORT_NAME,
      payload: data,
    });
  };

  const setDescription = (data: string) => {
    dispatch({
      type: ReducerActions.SET_REPORT_DESCRIPTION,
      payload: data,
    });
  };

  const setFields = (data: IField[]) => {
    dispatch({
      type: ReducerActions.SET_FEILDS,
      payload: data,
    });
  };

  const setFilters = (data: IFilter[]) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_FILTERS,
      payload: data,
    });
  };

  const setOrderBy = (data: string) => {
    dispatch({
      type: ReducerActions.SET_ORDERBY,
      payload: data,
    });
  };

  const setOrderField = (data: string) => {
    dispatch({
      type: ReducerActions.SET_ORDER_FEILD,
      payload: data,
    });
  };

  const resetCompileReportState = () => {
    dispatch({
      type: ReducerActions.RSET_COMPILE_REPORT_UPDATE_STATE,
    });
  };

  const resetCompileReportOriginalState = (data: any) => {
    dispatch({
      type: ReducerActions.RSET_COMPILE_REPORT_ORIGINAL_STATE,
      payload: data,
    });
  };

  const setIsFilterCardClicked = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_FILTER_CARD_CLICKED,
      payload: data,
    });
  };

  const setCurrentSelectedFilter = (data: IFilter) => {
    dispatch({
      type: ReducerActions.SET_CURRENT_SELECTED_FILTER,
      payload: data,
    });
  };

  const setIsNewFilterAdding = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_NEW_FILTER_ADDING,
      payload: data,
    });
  };

  const addToFiltersPicklist = ({ key, values }) => {
    dispatch({
      type: ReducerActions.ADD_TO_FILTERS_PICKLIST,
      payload: { key, values },
    });
  };

  const setUpdatedTeamsites = (data: any[]) => {
    dispatch({
      type: ReducerActions.SET_UPDATED_TEAMSITES,
      payload: data,
    });
  };

  const setOriginalTeamsites = (data: any[]) => {
    dispatch({
      type: ReducerActions.SET_ORIGINAL_TEAMSITES,
      payload: data,
    });
  };

  const setIsTeamsitesClicked = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_TEAMSITES_OPEN,
      payload: data,
    });
  };

  const setTempTeamsites = (data: any[]) => {
    dispatch({
      type: ReducerActions.SET_TEMP_TEAMSITES,
      payload: data,
    });
  };

  const setShowLeaveWithoutSaveModal = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_SHOW_LEAVE_WITHOUT_SAVE_MODAL,
      payload: data,
    });
  };

  const setGridHiddenColumns = (data: string[]) => {
    dispatch({
      type: ReducerActions.SET_GRID_HIDDEN_COLUMNS,
      payload: data,
    });
  };

  const setAllReportsSummary = (data: ReportsSummary[]) => {
    dispatch({
      type: ReducerActions.SET_ALL_REPORTS_SUMMARY,
      payload: data,
    });
  };

  const setShouldTriggerWithDefaultsAPI = (data: boolean) => {
    dispatch({
      type: ReducerActions.SET_SHOULD_TRIGGER_WITH_DEFAULTS_API,
      payload: data,
    });
  };

  return (
    <CompileReportContext.Provider
      value={{
        ...state,
        setIsChanged,
        setIsSaved,
        setShouldFetchOwnedReports,
        setUpdatedReportName,
        setUpdatedDescription,
        setUpdatedFields,
        setUpdatedFilters,
        setUpdatedOrderBy,
        setUpdatedOrderField,
        setReportName,
        setDescription,
        setFields,
        setFilters,
        setOrderBy,
        setOrderField,
        resetCompileReportState,
        resetCompileReportOriginalState,
        setIsFilterCardClicked,
        setCurrentSelectedFilter,
        setIsNewFilterAdding,
        addToFiltersPicklist,
        setUpdatedTeamsites,
        setOriginalTeamsites,
        setIsTeamsitesClicked,
        setTempTeamsites,
        setShowLeaveWithoutSaveModal,
        setGridHiddenColumns,
        setAllReportsSummary,
        setShouldTriggerWithDefaultsAPI
      }}
    >
      {children}
    </CompileReportContext.Provider>
  );
};

export default CompileReportState;
