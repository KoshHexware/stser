import React, { useReducer } from 'react';
import {
  INewUpdatedUserAccessList,
  IShareReportsState,
  IAccessUpdatedAPIStatus,
} from '../interfaces/IShareReportsTypes';
import * as ReducerActions from './types';
import { ShareReportsContext } from '.';

export const shareReportsInitialState: IShareReportsState = {
  showAccessMenuButton: false,
  sharedReportUsers: [],
  ssrsAccessUsersList: [],
  usersHasAccess: [],
  usersNoAccess: [],
  updatedUsersAccessList: {} as INewUpdatedUserAccessList,
  isAccessUpdated: false,
  searchUser: '',
  searchNoAccessUsersFound: false,
  accessUpdatedAPIStatus: '' as IAccessUpdatedAPIStatus,
};

export const ShareReportsReducer = (
  newState: IShareReportsState,
  action: any
) => {
  // Create a shallow copy of the state

  switch (action.type) {
    case ReducerActions.SET_SHOW_ACCESS_MENU_BUTTON:
      return {
        ...newState,
        showAccessMenuButton: action.payload,
      };

    case ReducerActions.SET_SHARED_REPORT_USERS:
      return {
        ...newState,
        sharedReportUsers: action.payload,
      };

    case ReducerActions.SET_SSRS_ACCESS_USERS_LIST:
      return {
        ...newState,
        ssrsAccessUsersList: action.payload,
      };

    case ReducerActions.SET_USERS_HAS_ACCESS:
      return {
        ...newState,
        usersHasAccess: action.payload,
      };

    case ReducerActions.SET_USERS_NO_ACCESS:
      return {
        ...newState,
        usersNoAccess: action.payload,
      };

    case ReducerActions.SET_NEW_UPDATED_USER_ACCESS_LIST:
      return {
        ...newState,
        updatedUsersAccessList: action.payload,
      };

    case ReducerActions.SET_IS_ACCESS_UPDATED:
      return {
        ...newState,
        isAccessUpdated: action.payload,
      };

    case ReducerActions.SET_SEARCH_USER:
      return {
        ...newState,
        searchUser: action.payload,
      };

    case ReducerActions.SET_SEARCH_NO_ACCESS_USERS_FOUND:
      return {
        ...newState,
        searchNoAccessUsersFound: action.payload,
      };

    case ReducerActions.SET_ACCESS_UPDATED_API_STATUS:
      return {
        ...newState,
        accessUpdatedAPIStatus: action.payload,
      };

    default:
      return newState;
  }
};

const ShareReportsState = ({ children, values }) => {
  const [state, dispatch] = useReducer(ShareReportsReducer, values);

  const setShowAccessMenuButton = (showAccessMenuButton: boolean) => {
    dispatch({
      type: ReducerActions.SET_SHOW_ACCESS_MENU_BUTTON,
      payload: showAccessMenuButton,
    });
  };

  const setSharedReportUsers = (sharedReportUsers: any) => {
    dispatch({
      type: ReducerActions.SET_SHARED_REPORT_USERS,
      payload: sharedReportUsers,
    });
  };

  const setSSRsAccessUsersList = (ssrsAccessUsersList: any) => {
    dispatch({
      type: ReducerActions.SET_SSRS_ACCESS_USERS_LIST,
      payload: ssrsAccessUsersList,
    });
  };

  const setUsersHasAccess = (usersHasAccess: any) => {
    dispatch({
      type: ReducerActions.SET_USERS_HAS_ACCESS,
      payload: usersHasAccess,
    });
  };

  const setUsersHasNoAccess = (usersNoAccess: any) => {
    dispatch({
      type: ReducerActions.SET_USERS_NO_ACCESS,
      payload: usersNoAccess,
    });
  };

  const setUpdatedUsersAccessList = (
    updatedUsersAccessList: INewUpdatedUserAccessList
  ) => {
    dispatch({
      type: ReducerActions.SET_NEW_UPDATED_USER_ACCESS_LIST,
      payload: updatedUsersAccessList,
    });
  };

  const setIsAccessUpdated = (isAccessUpdated: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_ACCESS_UPDATED,
      payload: isAccessUpdated,
    });
  };

  const setSearchUser = (searchUser: string) => {
    dispatch({
      type: ReducerActions.SET_SEARCH_USER,
      payload: searchUser,
    });
  };

  const setSearchNoAccessUsersFound = (searchNoAccessUsersFound: boolean) => {
    dispatch({
      type: ReducerActions.SET_SEARCH_NO_ACCESS_USERS_FOUND,
      payload: searchNoAccessUsersFound,
    });
  };

  const setAccessUpdatedAPIStatus = (accessUpdatedAPIStatus: IAccessUpdatedAPIStatus) => {
    dispatch({
      type: ReducerActions.SET_ACCESS_UPDATED_API_STATUS,
      payload: accessUpdatedAPIStatus,
    });
  };

  return (
    <ShareReportsContext.Provider
      value={{
        ...state,
        setShowAccessMenuButton,
        setSharedReportUsers,
        setSSRsAccessUsersList,
        setUsersHasAccess,
        setUsersHasNoAccess,
        setUpdatedUsersAccessList,
        setIsAccessUpdated,
        setSearchUser,
        setSearchNoAccessUsersFound,
        setAccessUpdatedAPIStatus
      }}
    >
      {children}
    </ShareReportsContext.Provider>
  );
};

export default ShareReportsState;
