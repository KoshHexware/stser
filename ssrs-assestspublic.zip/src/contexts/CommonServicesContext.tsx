import React, { createContext, useContext } from 'react';
import {
  IApplication,
  IFMSToggleSetting,
  ITranslations,
  IUserSettings,
} from '../interfaces/IAppData';
import { ILaunchDarklyToggle } from '../interfaces/ILaunchDarkly';
import { Translations } from '@seismic/mantle/dist/locale/translations';
import { LanguageCode } from 'seismic-common';

type IValue = {
  launchDarklyToggles: ILaunchDarklyToggle[];
  applicationInfo: IApplication;
  fmsToggleSettings: IFMSToggleSetting[];
  serviceAddresses: any;
  accessLevel: string;
  mantleTranslations: Translations;
  languageCode: LanguageCode;
  userSettings: IUserSettings;
  tenantUniqueId: string;
  ssrInitAppData?: any;
};
type Props = IValue & {
  children: React.ReactNode;
};

const CommonServicesContext = createContext<IValue>({} as IValue);

export const CommonServicesContextProvider: React.FC<Props> = (
  props: Props
) => {
  const value: IValue = {
    applicationInfo: props.applicationInfo,
    fmsToggleSettings: props.fmsToggleSettings,
    launchDarklyToggles: props.launchDarklyToggles,
    serviceAddresses: props.serviceAddresses,
    accessLevel: props.accessLevel,
    mantleTranslations: props.mantleTranslations,
    languageCode: props.languageCode || 'en-US',
    userSettings: props.userSettings,
    tenantUniqueId: props.tenantUniqueId,
    ssrInitAppData: props.ssrInitAppData,
  };
  return (
    <CommonServicesContext.Provider value={value}>
      {props.children}
    </CommonServicesContext.Provider>
  );
};
export const useApplicationInfo = (): IApplication => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useApplicationInfo must be used within a CommonServicesContextProvider'
    );
  }
  return context.applicationInfo;
};
export const useFMS = (): IFMSToggleSetting[] => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useFMS must be used within a CommonServicesContextProvider'
    );
  }
  return context.fmsToggleSettings;
};

export const useLaunchDarkly = (): ILaunchDarklyToggle[] => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useLaunchDarkly must be used within a CommonServicesContextProvider'
    );
  }
  return context.launchDarklyToggles;
};
export const useServiceAddress = (): any => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useServiceAddress must be used within a CommonServicesContextProvider'
    );
  }
  return context.serviceAddresses;
};
export const useAccessLevel = (): string => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useAccessLevel must be used within a CommonServicesContextProvider'
    );
  }
  return context.accessLevel.toLowerCase();
};

export const useMantleTranslations = (): ITranslations => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useMantleTranslations must be used within a CommonServicesContextProvider'
    );
  }
  return {
    languageCode: context.languageCode,
    mantleTranslations: context.mantleTranslations,
  };
};

export const useUserSettings = (): IUserSettings => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useTeamsites must be used within a CommonServicesContextProvider'
    );
  }
  return {
    teamsites: context.userSettings.teamsites,
    reportsFilterOption: context.userSettings.reportsFilterOption,
    tenantSettings: context.userSettings.tenantSettings,
    orderField: context.userSettings.orderField,
    orderBy: context.userSettings.orderBy,
  };
};

export const useTenantUniqueId = (): string => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useTenantUniqueId must be used within a CommonServicesContextProvider'
    );
  }
  return context.tenantUniqueId;
};

export const useSsrInitAppData = (): any => {
  const context = useContext(CommonServicesContext);
  if (context === undefined) {
    throw new Error(
      'useSsrInitAppData must be used within a CommonServicesContextProvider'
    );
  }
  return context.ssrInitAppData;
};