import React, { useReducer } from 'react';
import { IFieldAndFilterState } from '../interfaces/IFieldAndFilterTypes';
import * as ReducerActions from './types';
import { FieldAndFilterContext } from '.';
import { IReportMetadata } from '../interfaces/IReport';

export const FieldAndFilterActionsInitialState: IFieldAndFilterState = {
  currentActiveTab: 'Table',
  totalItems: 0,
  totalItemsSelected: 0,
  isDoneButtonClicked: false,
  isFieldsCancelClicked: false,
  isFiltersCancelClicked: false,
  currentCategorySelected: 'All',
  isToggled: false,
  finalUpdatedFields: [],
  isClearedClicked: false,
  initialFields: [],
  fields: [],
  updatedFields: [],
  finalUpdatedFilters: [],
  initialFilters: [],
  reportMetadata: {} as IReportMetadata,
  isSidePanelExpanded: false,
};

export const FieldAndFilterActionsReducer = (
  state: IFieldAndFilterState,
  action: any
) => {
  const newState = { ...state };
  switch (action.type) {
    case ReducerActions.SET_TOTAL_ITEMS:
      newState.totalItems = action.payload;
      break;
    case ReducerActions.SET_TOTAL_ITEMS_SELECTED:
      newState.totalItemsSelected = action.payload;
      break;
    case ReducerActions.SET_CURRENT_SELECTED_CATEGORY:
      newState.currentCategorySelected = action.payload;
      break;
    case ReducerActions.SET_IS_TOGGLE:
      newState.isToggled = action.payload;
      break;
    case ReducerActions.SET_FINAL_UPDATED_FIELDS:
      newState.finalUpdatedFields = action.payload;
      break;
    case ReducerActions.SET_IS_CLEARED_CLICKED:
      newState.isClearedClicked = action.payload;
      break;
    case ReducerActions.SET_IS_DONE_BUTTON_CLICKED:
      newState.isDoneButtonClicked = action.payload;
      break;
    case ReducerActions.RESET_FIELD_FILTER_STATES:
      let recentFields = [];
      if (newState.isDoneButtonClicked) {
        recentFields = action.payload.updatedFields;
      } else {
        recentFields = action.payload.fields;
      }
      const fieldsFromReport = recentFields
        .filter((f) => f.isDefault)
        .map((field) => field.name);
      const initialDefaultFields = JSON.parse(
        JSON.stringify(action.payload.reportMetadata.standardReportMetadata)
      ).fieldGroups?.map((group) => {
        return {
          fields: group.fields?.map((field) => {
            field.isDefault = fieldsFromReport.includes(field.name);
            return field;
          }),
          uxLabel: group.uxLabel,
        };
      });

      const initialTotalItems = initialDefaultFields
        ?.map((group) => group.fields)
        .flat();
      const intialTotalItemsSelectedLength = initialTotalItems?.filter(
        (f) => f.isDefault
      ).length;

      newState.totalItemsSelected = intialTotalItemsSelectedLength;
      newState.isToggled = false;
      newState.finalUpdatedFields = initialDefaultFields;
      newState.isClearedClicked = false;
      newState.currentCategorySelected = 'All';
      break;
    case ReducerActions.SET_CURRENT_ACTIVE_TAB:
      newState.currentActiveTab = action.payload;
      break;
    case ReducerActions.SET_FINAL_UPDATED_FILTERS:
      newState.finalUpdatedFilters = action.payload;
    case ReducerActions.SET_IS_SIDE_PANEL_EXPANDED:
      newState.isSidePanelExpanded = action.payload;
      break;
    default:
      break;
  }
  return newState;
};

const FieldAndFilterActionsState = ({ children, values }) => {
  const [state, dispatch] = useReducer(FieldAndFilterActionsReducer, values);

  const setTotalItems = (totalItems: number) => {
    dispatch({ type: ReducerActions.SET_TOTAL_ITEMS, payload: totalItems });
  };

  const setTotalItemsSelected = (totalItemsSelected: number) => {
    dispatch({
      type: ReducerActions.SET_TOTAL_ITEMS_SELECTED,
      payload: totalItemsSelected,
    });
  };

  const setCurrentCategorySelected = (currentCategorySelected: string) => {
    dispatch({
      type: ReducerActions.SET_CURRENT_SELECTED_CATEGORY,
      payload: currentCategorySelected,
    });
  };

  const setIsToggle = (isToggled: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_TOGGLE,
      payload: isToggled,
    });
  };

  const setFinalUpdatedFields = (finalUpdatedFields: []) => {
    dispatch({
      type: ReducerActions.SET_FINAL_UPDATED_FIELDS,
      payload: finalUpdatedFields,
    });
  };

  const setIsClearedClicked = (isClearedClicked: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_CLEARED_CLICKED,
      payload: isClearedClicked,
    });
  };

  const resetFieldFilterStates = (data: any) => {
    dispatch({
      type: ReducerActions.RESET_FIELD_FILTER_STATES,
      payload: data,
    });
  };

  const setIsDoneButtonClicked = (isDoneButtonClicked: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_DONE_BUTTON_CLICKED,
      payload: isDoneButtonClicked,
    });
  };

  const setCurrentActiveTab = (currentActiveTab: string) => {
    dispatch({
      type: ReducerActions.SET_CURRENT_ACTIVE_TAB,
      payload: currentActiveTab,
    });
  };

  const setFinalUpdatedFilters = (finalUpdatedFilters: []) => {
    dispatch({
      type: ReducerActions.SET_FINAL_UPDATED_FILTERS,
      payload: finalUpdatedFilters,
    });
  };

  const setIsSidePanelExpanded = (isSidePanelExpanded: boolean) => {
    dispatch({
      type: ReducerActions.SET_IS_SIDE_PANEL_EXPANDED,
      payload: isSidePanelExpanded,
    });
  };

  return (
    <FieldAndFilterContext.Provider
      value={{
        ...state,
        setCurrentActiveTab,
        setTotalItems,
        setTotalItemsSelected,
        setCurrentCategorySelected,
        setIsToggle,
        setFinalUpdatedFields,
        setIsClearedClicked,
        resetFieldFilterStates,
        setIsDoneButtonClicked,
        setFinalUpdatedFilters,
        setIsSidePanelExpanded,
      }}
    >
      {children}
    </FieldAndFilterContext.Provider>
  );
};

export default FieldAndFilterActionsState;
