import React, { useReducer, ReactNode } from 'react';
import * as ReducerActions from './types';
import { AllReportsLandingPageContext } from './index';
import { Screens } from './types';
import {
  ContextAction,
  IAllReportsLandingPageState,
} from '../interfaces/ISSRContextTpes';
import { IPagination } from '../interfaces/IReport';
interface AllReportsLandingPageProviderProps {
  children: ReactNode;
  values?: Partial<IAllReportsLandingPageState>;
}

const allReportsLandingPageInitialState: IAllReportsLandingPageState = {
  lastScreen: Screens.REPORTS_LIST,
  currentScreen: Screens.REPORTS_LIST,
  updatedReportsFilterOption: '',
  isCompileReportMode: false,
  hideEditButtOnError: false,
  orderBy: '',
  orderField: '',
  filterSearchText: '',
  enableSaveCopy: false,
  reportData: undefined,
  pagination: {
    skip: 0,
    take: 0,
    totalRecords: 0,
  },
  areSystemReportsEnabled: false,
};

export const allReportsLandingPageContextReducer = (
  state: IAllReportsLandingPageState,
  action: ContextAction
): IAllReportsLandingPageState => {
  switch (action.type) {
    case ReducerActions.SET_LAST_SCREEN:
      return { ...state, lastScreen: action.payload };
    case ReducerActions.SET_CURRENT_SCREEN:
      return { ...state, currentScreen: action.payload };
    case ReducerActions.SET_UPDATED_REPORTS_FILTER_OPTION:
      return { ...state, updatedReportsFilterOption: action.payload };
    case ReducerActions.SET_IS_COMPILE_REPORT_MODE:
      return { ...state, isCompileReportMode: action.payload };
    case ReducerActions.SET_HIDE_EDIT_BUTTON_ON_ERROR:
      return { ...state, hideEditButtOnError: action.payload };
    case ReducerActions.SET_FILTER_SEARCH_TEXT:
      return { ...state, filterSearchText: action.payload };
    case ReducerActions.SET_ENABLE_SAVE_COPY:
      return { ...state, enableSaveCopy: action.payload };
    case ReducerActions.SET_REPORT_DATA:
      return { ...state, reportData: action.payload };
    case ReducerActions.SET_PAGINATION:
      return { ...state, pagination: action.payload };
    case ReducerActions.SET_ARE_SYSTEM_REPORTS_ENABLED:
      return { ...state, areSystemReportsEnabled: action.payload };
    default:
      return state;
  }
};

const AllReportsLandingPageProvider: React.FC<
  AllReportsLandingPageProviderProps
> = ({ children, values = {} }) => {
  const [state, dispatch] = useReducer(allReportsLandingPageContextReducer, {
    ...allReportsLandingPageInitialState,
    ...values,
  });

  const setShowNewReportModal = (data: boolean): void => {
    dispatch({
      type: ReducerActions.SET_SHOW_NEW_REPORT_MODAL,
      payload: data,
    });
  };

  const setLastScreen = (data: Screens): void => {
    dispatch({
      type: ReducerActions.SET_LAST_SCREEN,
      payload: data,
    });
  };

  const setCurrentScreen = (data: Screens): void => {
    dispatch({
      type: ReducerActions.SET_CURRENT_SCREEN,
      payload: data,
    });
  };

  const setIsCompileReportMode = (data: boolean): void => {
    dispatch({
      type: ReducerActions.SET_IS_COMPILE_REPORT_MODE,
      payload: data,
    });
  };

  const setUpdatedReportsFilterOption = (data: string): void => {
    dispatch({
      type: ReducerActions.SET_UPDATED_REPORTS_FILTER_OPTION,
      payload: data,
    });
  };

  const setHideEditButtonOnError = (data: boolean): void => {
    dispatch({
      type: ReducerActions.SET_HIDE_EDIT_BUTTON_ON_ERROR,
      payload: data,
    });
  };

  const setOrderBy = (data: string) => {
    dispatch({
      type: ReducerActions.SET_ORDERBY,
      payload: data,
    });
  };

  const setOrderField = (data: string) => {
    dispatch({
      type: ReducerActions.SET_ORDER_FEILD,
      payload: data,
    });
  };

  const setFilterSearchText = (data: string): void => {
    dispatch({
      type: ReducerActions.SET_FILTER_SEARCH_TEXT,
      payload: data,
    });
  };

  const setEnableSaveCopy = (data: boolean): void => {
    dispatch({
      type: ReducerActions.SET_ENABLE_SAVE_COPY,
      payload: data,
    });
  };

  const setReportData = (data: any): void => {
    dispatch({
      type: ReducerActions.SET_REPORT_DATA,
      payload: data,
    });
  };

  const setPagination = (data: IPagination): void => {
    dispatch({
      type: ReducerActions.SET_PAGINATION,
      payload: data,
    });
  };

  const setAreSystemReportsEnabled = (data: boolean): void => {
    dispatch({
      type: ReducerActions.SET_ARE_SYSTEM_REPORTS_ENABLED,
      payload: data,
    });
  };

  const contextValue = {
    ...state,
    setShowNewReportModal,
    setLastScreen,
    setIsCompileReportMode,
    setCurrentScreen,
    setUpdatedReportsFilterOption,
    setHideEditButtonOnError,
    setOrderBy,
    setOrderField,
    setFilterSearchText,
    setEnableSaveCopy,
    setReportData,
    setPagination,
    setAreSystemReportsEnabled,
  };

  return (
    <AllReportsLandingPageContext.Provider value={contextValue}>
      {children}
    </AllReportsLandingPageContext.Provider>
  );
};

export default React.memo(AllReportsLandingPageProvider);
