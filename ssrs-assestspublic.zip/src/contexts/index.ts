import React from 'react';
import { ICompileReportContext } from '../interfaces/IReport';
import { IFieldAndFilterContext } from '../interfaces/IFieldAndFilterTypes';
import { IShareReportsContext } from '../interfaces/IShareReportsTypes';
import { IAllReportsLandingPage } from '../interfaces/ISSRContextTpes';

export const CompileReportContext = React.createContext<ICompileReportContext>(
    {} as ICompileReportContext
);
export const FieldAndFilterContext =
    React.createContext<IFieldAndFilterContext>({} as IFieldAndFilterContext);
export const ShareReportsContext = React.createContext<IShareReportsContext>(
    {} as IShareReportsContext
);
export const AllReportsLandingPageContext =
    React.createContext<IAllReportsLandingPage>({} as IAllReportsLandingPage);
export const ReportDataContext = React.createContext<any>({});