import React from 'react';
import ReactDOM from 'react-dom';
import { instance, EventService } from 'seismic-common';
import SelfServiceReportsUIWrapper from '../SelfServiceReportsUIWrapper';

// NextGen Entry Point - uses EventService to wait for page ready
const App = () => {
    return <SelfServiceReportsUIWrapper />;
};

// NextGen pattern: Wait for fullbundle.pageIsReady event before rendering
instance.getService(EventService).subscribe(
    'fullbundle.pageIsReady',
    () => {
        const container = document.getElementById('seismic-page-container');
        if (container) {
             ReactDOM.render(
                <React.StrictMode>
                    <App />
                </React.StrictMode>,
                container
            );
        }
    },
    true // This ensures the event will be triggered, even if it was dispatched before subscribing
);

export default App;