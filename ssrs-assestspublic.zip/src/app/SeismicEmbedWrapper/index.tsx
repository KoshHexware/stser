import React, { useEffect, useState } from 'react';
import '../../webpack-nonce';
import {
  ApplicationApiService,
  BrandingService,
  FMService,
  IApplication,
  IBranding,
  IServiceResult,
  LanguageService,
  LaunchDarklyService,
  ServiceAddressService,
  TenantService,
  instance,
  EntitlementsService
} from 'seismic-common';
import { IFMSToggleSetting, IUserSettings } from '../../interfaces/IAppData';
import { ILaunchDarklyToggle } from '../../interfaces/ILaunchDarkly';
import Translate from '../../i18n/i18nInstance';
import App from '../components/App';
import { FullScreenLoading } from '../components/common/FullScreenLoading';
import ReportService from '../../services/ReportService';
import { Translations } from '@seismic/mantle/dist/locale/translations';
import { LANDING_PAGE_REPORT_TYPE, PERMISSION_KEYS, EDITOR_ACCESS_LEVEL, CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, VIEWER_ACCESS_LEVEL, ENABLE_SSR_USE_ENTITLEMENTS } from '../../utils/constants';

const serviceAddressService = instance.getService(ServiceAddressService);
const languageService = instance.getService(LanguageService);
const fmService = instance.getService(FMService);
const launchDarklyService = instance.getService(LaunchDarklyService);
const applicationApiService = instance.getService(ApplicationApiService);
const brandingService = instance.getService(BrandingService);
const tenantService = instance.getService(TenantService);
const entitlementsService = instance.getService(EntitlementsService);

export default function SeismicEmbedWrapper() {
  const [fmsToggleSettings, setFMSToggleSettings] =
    useState<IFMSToggleSetting[]>();
  const [launchDarklyToggles, setLaunchDarklyToggles] =
    useState<ILaunchDarklyToggle[]>();
  const [serviceAddresses, setServiceAddresses] =
    useState<Record<string, string>>();
  const [applicationInfo, setApplicationInfo] =
    useState<IServiceResult<IApplication>>();
  const [globalBranding, setGlobalBranding] = useState<IBranding>();
  const [isLoading, setIsLoading] = useState(true);
  const [accessLevel, setAccessLevel] = useState<string>('');
  const [hasAccess, setHasAccess] = useState<boolean>(false);
  const [userSettings, setUserSettings] = useState<IUserSettings>();
  const [mantleTranslations, setMantleTranslations] =
    React.useState<Translations>({});

  useEffect(() => {
    setIsLoading(true);
    Promise.all([
      fmService.initializeFMSToggleSettings(),
      launchDarklyService.getAllFeatureToggleSettings(),
      serviceAddressService.getAllServiceAddresses(),
      applicationApiService.getApplicationInfo(),
      launchDarklyService.getValueAsBoolean(ENABLE_SSR_USE_ENTITLEMENTS),
      entitlementsService.checkPermission(PERMISSION_KEYS.VIEW_REPORT),
      entitlementsService.checkPermission(PERMISSION_KEYS.CREATE_NEW_REPORTS),
      ReportService.checkAccess(),
      ReportService.hasAccess(),
      ReportService.getUserSettings(),
      brandingService.getGlobalBranding(),
      languageService.getTranslations(
        languageService.getLanguage(),
        'Mantle',
        'Default'
      ),
      Translate.setLang(),
    ])
      .then(
        ([
          fmsToggleSettings,
          featureToggles,
          serviceAddresses,
          applicationInfo,
          isUseEntitlementsFlagEnabled,
          viewReportAccessLevel,
          createNewReportsAccessLevel,
          ssrsAccessLevel,
          hasAccess,
          userSettings,
          branding,
          translations,
        ]) => {
          setFMSToggleSettings(fmsToggleSettings as IFMSToggleSetting[]);
          setLaunchDarklyToggles(featureToggles);
          setServiceAddresses(serviceAddresses);
          setApplicationInfo(applicationInfo);

          let userAccessLevel = '';
          //This is for entitlesupport
          if (isUseEntitlementsFlagEnabled) {
            if (createNewReportsAccessLevel) {
              userAccessLevel = EDITOR_ACCESS_LEVEL;
            }
            else if (viewReportAccessLevel) {
              userAccessLevel = VIEWER_ACCESS_LEVEL;
            }
            else {
              userAccessLevel = 'None';
            }
          } else {
            userAccessLevel = ssrsAccessLevel;
          }

          setAccessLevel(userAccessLevel);
          setHasAccess(hasAccess);
          if (
            userAccessLevel.toLocaleLowerCase() === VIEWER_ACCESS_LEVEL &&
            (userSettings.reportsFilterOption === LANDING_PAGE_REPORT_TYPE.system ||
              userSettings.reportsFilterOption === LANDING_PAGE_REPORT_TYPE.all ||
              userSettings.reportsFilterOption === LANDING_PAGE_REPORT_TYPE.owned)
          ) {
            userSettings.reportsFilterOption = LANDING_PAGE_REPORT_TYPE.shared;
          } else if (userAccessLevel.toLocaleLowerCase() === CUSTOM_REPORT_EDITOR_ACCESS_LEVEL && userSettings.reportsFilterOption === 'system') {
            userSettings.reportsFilterOption = LANDING_PAGE_REPORT_TYPE.all;
          }
          setUserSettings(userSettings);
          setGlobalBranding(branding);
          setMantleTranslations(translations);
        }
      )
      .catch((error) => {
        console.error('Error fetching data:', error);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  return isLoading ? (
    <FullScreenLoading loading={isLoading} />
  ) : (
    <App
      applicationInfo={applicationInfo!.ServiceResult}
      serviceAddresses={serviceAddresses}
      fmsToggleSettings={fmsToggleSettings!}
      launchDarklyToggles={launchDarklyToggles!}
      globalBranding={globalBranding!}
      accessLevel={accessLevel.toLowerCase()}
      hasAccess={hasAccess}
      userSettings={userSettings}
      mantleTranslations={mantleTranslations}
      languageCode={languageService.getLanguage()}
      tenantUniqueId={tenantService.getTenantUniqueId()}
    />
  );
}
