import { Card, IconHost } from '@seismic/mantle';
import React from 'react';
import { ISelectedReport } from '../../../interfaces/IReport';
import './NewReportModal.scss';

export const StandardReportCard = ({ report, setModalVisibility, key, onClick, modalSelectedReportId }) => {

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLDivElement>,
    report: ISelectedReport
  ) => {
    if (e.key === 'Enter') {
      onClick(report);
    }
  };

  return (
    <>
      <Card
        className={`report-card-wrapper trk_link_ssrs-reports_list_new_report_modal-create_report_from ${
                    report.id === modalSelectedReportId ? 'report-card-selected' : ''}`}
        tabIndex={0}
        onClick={() => onClick(report as ISelectedReport)}
        onKeyDown={(e) => handleKeyDown(e, report as ISelectedReport)}
      >
        <div key={key} className='report-card'>
          <div className='report-card-title-icon'>
            <IconHost
              category='content-icons-v2'
              params={{ format: 'standard-report' }}
            />
            <div className='report-card-description-title'>
              <div className='report-card-title'>{report?.reportName}</div>
            </div>
          </div>
        </div>
      </Card>
    </>
  );
};
