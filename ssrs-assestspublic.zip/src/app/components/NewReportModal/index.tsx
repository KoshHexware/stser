import React, { useState, useEffect, useContext, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './NewReportModal.scss';
import { Modal, Input, SplitView, Button, IconSearch } from '@seismic/mantle';
import { ErrorBoundary } from '../common/ErrorBoundary';
import ReportService from '../../../services/ReportService';
import { FullScreenLoading } from '../common/FullScreenLoading';
import { ISystemReport } from '../../../interfaces/IReport';
import { FIXEDREPORTLISTPAGESIZE } from '../../../utils/constants';
import { StandardReportCard } from './StandardReportCard';
import { NoSearchItems } from '../common/EmptyState/NoSearchItems';
import { useHistory } from 'react-router-dom';
import {
  ReportDataContext,
  AllReportsLandingPageContext,
} from '../../../contexts';
import { formatNewLines } from '../../../utils/formatNewLines';

export const NewReportModal = (props) => {
  const { showModal, setModalVisibility } = props;
  const [isLoading, setIsLoading] = useState(true);
  const [values, setValues] = useState<ISystemReport[]>([]);
  const [isNoSearchResult, setIsNoSearchResult] = useState(false);
  const [searchString, setSearchString] = useState('');
  const { t } = useTranslation();
  const [expandedValue, setExpandedValue] = React.useState(false);
  const [modalSelectedReport, setModalSelectedReport] =
    useState<ISystemReport | null>(null);

  const { setSelectedReport } = useContext(ReportDataContext);
  const { setIsCompileReportMode } = useContext(AllReportsLandingPageContext);
  const history = useHistory();

  const fetchSystemReports = async () => {
    try {
      const response = await ReportService.getReports(
        0,
        FIXEDREPORTLISTPAGESIZE,
        'system',
        null,
        'reportName',
        'asc'
      );
      setValues(response?.data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching user stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSystemReports();
  }, []);

  const filteredItems = useMemo(() => {
  if (!searchString) {
    return values || [];
  }

  const localSearchTerm = searchString.toLowerCase();
  
  const nameMatches = values?.filter((value) => 
    value?.reportName?.toLowerCase()?.includes(localSearchTerm)
    || value?.description?.toLowerCase()?.includes(localSearchTerm)
  ) || [];
  
  return [...nameMatches];
}, [searchString, values]);

  useEffect(() => {
    if (filteredItems?.length === 0) {
      setIsNoSearchResult(true);
    } else {
      setIsNoSearchResult(false);
    }
  }, [searchString]);

  const onReportCardClick = (report) => {
    if (report?.id != modalSelectedReport?.id) {
      setModalSelectedReport(report);
      setExpandedValue(true);
    } else {
      setModalSelectedReport(null);
      setExpandedValue(false);
    }
  };

  const createNewReport = () => {
    const {
      id,
      reportName,
      reportType,
      ownerUserId,
      userId,
      systemReportName,
      description,
    } = modalSelectedReport;
    setModalVisibility(false);
    setSelectedReport({
      reportName: reportName,
      id: id,
      reportType: reportType,
      ownerUserId: ownerUserId,
      userId: userId,
      systemReportName: systemReportName,
      description: description,
    });
    setIsCompileReportMode(true);
    history.push(`/selfservicereports/report/view/${id}`);
  };

  const getReportDescription = (modalSelectedReport: ISystemReport | null) => {
    if (!modalSelectedReport || !modalSelectedReport.description) {
      return '';
    }
    return formatNewLines(modalSelectedReport.description);
  };

  return (
    <div className='NewReportModel' id='NewReportModel'>
      <ErrorBoundary>
        <Modal
          open={showModal}
          size='lg'
          onClose={() => setModalVisibility(false)}
          header={t(
            'self_service_reports_choose_standard_report',
            'Choose a standard report to start with'
          )}
          closeOnOutsideClick
          style={{ height: 760, width: 1040 }}
          className={`NewReportModel-modal${expandedValue ? '-expanded' : ''}`}
        >
          {isLoading || values?.length === 0 ? (
            <FullScreenLoading loading={true} />
          ) : (
            <SplitView
              isExpanded={expandedValue}
              extent='440px'
              position='end'
              showToggle={false}
            >
              <SplitView.Main style={{ height: '100%' }} className={` ${!expandedValue ? 'reports-list-new-report-modal-split-view' : ''}`}>
                <>
                  <Input
                    startAdornment={IconSearch}
                    size={16}
                    className={`NewReportModel-modal-input${expandedValue ? '-expanded' : ''
                      } trk_input_ssrs-reports_list_new_report_modal-search_standard_report`}
                    placeholder={t(
                      'self_service_reports_search_standard_report',
                      'Search for a standard report'
                    )}
                    onChange={(e) => {
                      setSearchString(e.target.value);
                      setExpandedValue(false);
                    }}
                  />
                  <ErrorBoundary>
                    <div
                      style={{ height: 'calc(100% - 50px)' }}
                      className={`mntl-scrollbar
                          ${isNoSearchResult && searchString !== ''
                          ? ' NewReportModel-card-container-wrapper'
                          : ''
                        }`}
                    >
                      {filteredItems && filteredItems?.length > 0 && (
                        <div
                          className={`NewReportModel-card-container${expandedValue ? '-expanded' : ' mntl-scrollbar'
                            }`}
                          id='NewReportModel'
                        >
                          {filteredItems?.map((report, index) => {
                            return (
                              <StandardReportCard
                                key={index}
                                modalSelectedReportId={modalSelectedReport?.id}
                                report={report}
                                setModalVisibility={setModalVisibility}
                                onClick={(report) => {
                                  onReportCardClick(report);
                                }}
                              />
                            );
                          })}
                        </div>
                      )}
                      {isNoSearchResult && searchString !== '' && (
                        <div className='NewReportModel-no-search-items'>
                          <NoSearchItems size='md' />
                        </div>
                      )}
                    </div>
                  </ErrorBoundary>
                </>
              </SplitView.Main>
              <SplitView.Panel
                aria-label={t(
                  'self_service_report_new_report_modal_panel_aria_label',
                  'New report modal panel'
                )}
              >
                <div className='NewReportModel-panel-container'>
                  <h2 className='NewReportModel-panel-container-report-title'>
                    {modalSelectedReport?.reportName}
                  </h2>
                  <div>{getReportDescription(modalSelectedReport)}</div>
                  <div className='NewReportModel-panel-container-btn'>
                    <Button
                      className='trk_button_ssrs-new-report-nodal-use-this-report'
                      label={t(
                        'self_service_report_use_this_report',
                        'Use this report'
                      )}
                      variant='primary'
                      onClick={() => {
                        createNewReport();
                      }}
                    />
                  </div>
                </div>
              </SplitView.Panel>
            </SplitView>
          )}
        </Modal>
      </ErrorBoundary>
    </div >
  );
};
