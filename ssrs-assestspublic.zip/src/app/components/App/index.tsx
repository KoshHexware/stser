import './App.scss';
import {
  LanguageCode,
  seismicTheme,
  Theme,
  ToastsContainer,
  ToastsContext,
} from '@seismic/mantle';
import {
  seismicVisualizationsTheme,
  VisualizationsTheme,
} from '@seismic/visualizations';
import { ILaunchDarklyToggle } from '../../../interfaces/ILaunchDarkly';
import { IFMSToggleSetting } from 'seismic-common/dist/interfaces/IAppData';
import { LicenseManager } from '@seismic/shared-datagrid';
import { HashRouter, Route, Switch, BrowserRouter } from 'react-router-dom';
import AllReportsLandingPageProvider from '../../../contexts/AllReportsLandingPageContext';
import ReportDataProvider from '../../../contexts/ReportDataContext';
import { CommonServicesContextProvider } from '../../../contexts/CommonServicesContext';
import { IApplication, IUserSettings } from '../../../interfaces/IAppData';
import CreateReport from '../CreateReport';
import NoAccess from '../NoAccess/NoAccess';
import { ErrorBoundary } from '../common/ErrorBoundary';
import { Translations } from '@seismic/mantle/dist/locale/translations';
import LandingPage from './LandingPage';
import { checkSSRNextGenEnabled } from '../../../utils/ssrPreloadDataUtils';

type IProps = {
  applicationInfo: IApplication;
  serviceAddresses: any;
  launchDarklyToggles: ILaunchDarklyToggle[];
  fmsToggleSettings: IFMSToggleSetting[];
  globalBranding: {
    logo?: string;
    primaryColor: string;
    secondaryColor: string;
    primaryVariantColor?: string | null;
  };
  accessLevel: string;
  hasAccess: boolean;
  mantleTranslations: Translations;
  languageCode: string;
  userSettings: IUserSettings;
  tenantUniqueId: string;
  ssrInitAppData?: any;
};

const App = (props: IProps) => {
  LicenseManager.setLicenseKey(
    'Using_this_{AG_Grid}_Enterprise_key_{AG-096919}_in_excess_of_the_licence_granted_is_not_permitted___Please_report_misuse_to_legal@ag-grid.com___For_help_with_changing_this_key_please_contact_info@ag-grid.com___{Seismic_Software_Holdings,_Inc.}_is_granted_a_{Multiple_Applications}_Developer_License_for_{24}_Front-End_JavaScript_developers___All_Front-End_JavaScript_developers_need_to_be_licensed_in_addition_to_the_ones_working_with_{AG_Grid}_Enterprise___This_key_has_been_granted_a_Deployment_License_Add-on_for_{2}_Production_Environments___This_key_works_with_{AG_Grid}_Enterprise_versions_released_before_{14_February_2027}____[v3]_[01]_MTgwMjU2MzIwMDAwMA==6fb55fe83e05045c6499ae51c8c643cc'
  );

  const isNextGen = process.env.NEXT_GEN === 'true';
  const isSSRNextGenEnabled = checkSSRNextGenEnabled(props.launchDarklyToggles);
  const RouterContructor = (isSSRNextGenEnabled && isNextGen) ? BrowserRouter : HashRouter;
  let basename = '';
  if (isSSRNextGenEnabled && isNextGen && window.parentRoute) {
    basename = window.parentRoute;
  }

  return (
    <div className='ssrs-container'>
      <Theme
        theme={seismicTheme({
          useGlobal: true,
          localization: {
            languageCode: props.languageCode as LanguageCode,
            translations: props.mantleTranslations,
          },
          customization: {
            colors: {
              primary: props?.globalBranding?.primaryColor || '#CF47CA',
              primaryVariant:
                props?.globalBranding?.primaryVariantColor || '#591F57',
            },
          },
          defaultPortalContainerSelector: '#self-service-reports-assests',
        })}
      >
        <VisualizationsTheme
          theme={seismicVisualizationsTheme({
            useGlobal: true,
          })}
        >
          <CommonServicesContextProvider {...props}>
            <AllReportsLandingPageProvider>
              <ReportDataProvider>
                <div className='ssrs-app'>
                  {props.hasAccess ? (
                    <RouterContructor basename={basename}>
                      <div className='ssrs-content'>
                        <div className='ssrs-content-wrapper'>
                          <ErrorBoundary>
                            <Switch>
                              <Route
                                exact
                                path='/selfservicereports'
                                render={() => <LandingPage />}
                              />
                              <Route
                                exact
                                path={['/selfservicereports/report/:id']}
                                render={() => (
                                  <>
                                    <ToastsContext>
                                      <ToastsContainer
                                        style={{ paddingInlineStart: '80px' }}
                                      />
                                      <CreateReport />
                                    </ToastsContext>
                                  </>
                                )}
                              />
                            </Switch>
                          </ErrorBoundary>
                        </div>
                      </div>
                    </RouterContructor>
                  ) : (
                    <NoAccess />
                  )}
                </div>
              </ReportDataProvider>
            </AllReportsLandingPageProvider>
          </CommonServicesContextProvider>

          <div id='self-service-reports-assests' />
        </VisualizationsTheme>
      </Theme>
    </div>
  );
};

export default App;
