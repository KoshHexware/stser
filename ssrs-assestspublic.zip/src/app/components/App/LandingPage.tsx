import React, { useEffect } from 'react';
import LandingPageTopNavigation from '../SSRTopNavigation/LandingPageTopNavigation';
import { ReportsList } from '../ReportsList';
import { triggerAuraPanelAction } from '../../../auraPanelEvents';
import {
	AuraPanelActionType,
	IAuraPanelAction,
} from '../../../auraPanelEvents/types/AuraPanelActionTypes';
import { removeAllDrillInParams } from '../../../utils/drillInReportUtils';
import {
	useApplicationInfo,
	useTenantUniqueId,
} from '../../../contexts/CommonServicesContext';

const LandingPage = () => {
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();

	useEffect(() => {
		const action: IAuraPanelAction = {
			type: AuraPanelActionType.LANDING_PAGE,
		};
		triggerAuraPanelAction(action);
	}, []);

	// Whenever pathname matches landing pages, strip all drill-in params and clear previous markers
	useEffect(() => {
		removeAllDrillInParams(UserId, tenantUniqId, location.pathname);
	}, [location.pathname]);

	return (
		<div>
			<LandingPageTopNavigation />
			<ReportsList />
		</div>
	);
};

export default LandingPage;
