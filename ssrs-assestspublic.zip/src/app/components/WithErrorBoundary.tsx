import React from 'react';
import { ErrorBoundary } from './common/ErrorBoundary';

const WithErrorBoundary = (Component: React.ComponentType) => {
  return (props: any) => (
    <ErrorBoundary>
      <Component {...props} />
    </ErrorBoundary>
  );
};

export default WithErrorBoundary;