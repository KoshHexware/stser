import { SELF_SERVICE_REPORTS_STORAGE_KEY } from '../../../utils/constants';
import ReportExporter from '../../../utils/ReportExporter';

/**
 * Merge applied filter objects with their metadata definition.
 *
 * This aligns user-applied filters (with values/operation) to the canonical
 * filter definitions coming from `filterGroup` so downstream consumers have
 * access to both metadata and runtime values in a single object.
 *
 * @param appliedFilters Array of filters currently applied by the user; each item may include `filterName`, `values`, `operation`, etc.
 * @param filterGroup Array of filter groups where each group contains a `filters` array with metadata entries (e.g., `filterName`, labels, types).
 * @returns A new array where each applied filter is shallow-merged with its matching metadata by `filterName`. Non-matching or invalid inputs return an empty array or the original item.
 */
export const mergeAppliedFiltersWithInfo = (
  appliedFilters: any[] | null | undefined,
  filterGroup: any[] | null | undefined
): any[] => {
  if (!appliedFilters || !Array.isArray(appliedFilters)) return [];
  if (!filterGroup || !Array.isArray(filterGroup)) return [];

  const map = new Map<string, any>();
  for (const group of filterGroup) {
    const filters = group?.filters;
    if (!Array.isArray(filters)) continue;
    for (const f of filters) {
      if (f?.filterName) map.set(String(f.filterName), f);
    }
  }

  return appliedFilters.map((af) => {
    const name = af?.filterName;
    if (!name) return af;
    const meta = map.get(String(name));
    if (!meta) return af;
    return { ...meta, ...af };
  });
};

/**
 * Dynamically loads the `@seismic/web-report-grid` module.
 *
 * Uses SystemJS via `window.System.import` to fetch the module at runtime,
 * returning an object with a `default` export compatible with consumers.
 *
 * @returns A promise resolving to `{ default: WebReportGrid }` where the default
 * export is taken from `module.default` or `module.WebReportGrid` as a fallback.
 */
export function loadWebReportGrid() {
  return (window as any).System.import('@seismic/web-report-grid').then(
    (module: any) => {
      return { default: module?.default ?? module.WebReportGrid };
    }
  );
}

/**
 * Dynamically loads types from `@seismic/web-report-grid` in environments where
 * type-only imports are unavailable at runtime.
 *
 * Returns an object with properties typed as the module's exported types.
 * These are `null as any as typeof ...` placeholders to expose the shapes
 * without carrying runtime values.
 *
 * @returns An object containing references to type shapes such as `IWebReportGridProps`, `IWebReportDataSource`, etc.
 */
export async function loadWebReportGridTypes() {
  const module = await (window as any).System.import(
    '@seismic/web-report-grid'
  );
  return {
    IWebReportGridProps: null as any as typeof module.IWebReportGridProps,
    IWebReportDataSource: null as any as typeof module.IWebReportDataSource,
    IWebReportColumnDef: null as any as typeof module.IWebReportColumnDef,
    IWebReportDrillInReportHeader:
      null as any as typeof module.IWebReportDrillInReportHeader,
    IWebReportTeamsites: null as any as typeof module.IWebReportTeamsites,
  };
}

/**
 * Constructs a drill-in report URL using the current app base URL.
 *
 * Builds a query string that includes encoded `filters`, `fields`, pagination
 * (`skip`, `take`) and optional sorting (`orderField`, `orderBy`). If the base
 * cannot be derived from the current location, falls back to a default path.
 *
 * @param targetReportId The ID of the drill-in report to navigate to.
 * @param fieldsDef Column/field definitions; each item should include a `field`.
 * @param filters Array of filter objects to apply in the target report.
 * @param pageSize Default page size used when `options.take` is not provided.
 * @param options Optional pagination and sorting options.
 * @returns A fully constructed URL string or an empty string if an error occurs.
 */
export const buildDrillInUrl = (
  targetReportId: string,
  fieldsDef: any[],
  filters: any[],
  pageSize: number,
  sourceReportId: string,
  sourceReportDrillInColumn: string,
  options?: {
    skip?: number;
    take?: number;
    orderField?: string;
    orderBy?: 'ASC' | 'DESC';
  }
): string => {
  try {
    const href = window.location?.href || '';
    const marker = '/selfservicereports/report/';
    const idx = href.indexOf(marker);
    const base =
      idx >= 0
        ? href.substring(0, idx + marker.length)
        : 'https://readinesscoachingqa.seismic.com/app#/selfservicereport/report/';

    const fields = (fieldsDef || [])
      .map((c: any) => String(c.field))
      .filter((name) => !!name && name.length > 0);

    const filtersPayload = Array.isArray(filters) ? filters : [];

    const qp: Record<string, string> = {
      filters: encodeURIComponent(JSON.stringify(filtersPayload)),
      fields: encodeURIComponent(JSON.stringify(fields)),
      skip: String(options?.skip ?? 0),
      take: String(options?.take ?? pageSize),
    };

    if (options?.orderField) {
      qp.orderField = options.orderField;
    }
    if (options?.orderBy) {
      qp.orderBy = options.orderBy;
    }

    const query =
      `filters=${qp.filters}&fields=${qp.fields}&skip=${qp.skip}&take=${qp.take}` +
      (qp.orderField ? `&orderField=${qp.orderField}` : '') +
      (qp.orderBy ? `&orderBy=${qp.orderBy}` : '') + 
      `&isDrillIn=true` +
      `&sourceReportId=${encodeURIComponent(sourceReportId)}` +
      `&sourceReportDrillInColumn=${encodeURIComponent(sourceReportDrillInColumn)}`;

    return `${base}${targetReportId}?${query}`;
  } catch (e) {
    console.error('Error constructing drill-in URL', e);
    return '';
  }
};

/**
 * Applies a stored column order (from `localStorage`) to a set of column defs.
 *
 * Reads the `SELF_SERVICE_REPORTS_STORAGE_KEY` from `localStorage`, finds the
 * entry for `reportId`, and reorders `cols` to match the saved order. Unknown
 * or missing columns are appended to the end, preserving input order.
 *
 * @param reportId The report identifier used to locate persisted preferences.
 * @param cols The current column definitions array; items should include `field`.
 * @returns A new array of column defs ordered per stored preferences or the original `cols` on failure.
 */
export const applyStoredOrder = (reportId: string, cols: any[]): any[] => {
  if (!reportId || !cols?.length) return cols;
  try {
    const raw = window?.localStorage?.getItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
    if (!raw) return cols;
    const parsed = JSON.parse(raw);
    let reportsArr = parsed?.reports;
    if (!Array.isArray(reportsArr)) {
      const allValues = Object.values(parsed || {}) as any[];
      for (const v of allValues) {
        if (Array.isArray((v as any)?.reports)) {
          reportsArr = (v as any).reports;
          break;
        }
      }
    }
    if (!Array.isArray(reportsArr)) return cols;
    const match = reportsArr.find((r: any) => r.reportId === reportId);
    if (!match || !match.columnOrder) return cols;
    const desiredOrder = match.columnOrder
      .split(',')
      .map((s: string) => s.trim())
      .filter((s: string) => s.length > 0);
    if (!desiredOrder.length) return cols;
    const colMap = cols.reduce((m: any, c: any) => {
      if (c.field) m[c.field.toUpperCase()] = c;
      return m;
    }, {} as any);
    const ordered: any[] = [];
    for (const name of desiredOrder) {
      const key = name.toUpperCase();
      if (colMap[key]) ordered.push(colMap[key]);
    }
    const picked = new Set(ordered.map((c: any) => c.field));
    for (const c of cols) {
      if (!picked.has(c.field)) ordered.push(c);
    }
    return ordered;
  } catch (e) {
    console.error('Error applying stored column order (drill-in):', e);
    return cols;
  }
};

/**
 * Builds drill-in filters from a source row, column definition, and report metadata.
 *
 * Includes a primary key filter if `data.PRIMARYKEYFIELD` is present, and merges
 * configured optional filters by mapping `sourceValue` from `reportMetadata.appliedFilters`
 * onto `targetFilter` with the same operation and values.
 *
 * @param data The source row data used for drill-in (e.g., clicked cell context).
 * @param colDef The column definition; may include `drillIn.optionalFilters`.
 * @param reportMetadata The current report metadata, including `appliedFilters`.
 * @returns An array of filters to apply in the drill-in report.
 */
export const getFiltersForDrillInReport = (
  data: any,
  colDef: any,
  reportMetadata: any
) => {
  const drillInFilters: any[] = [];

  if (data?.PRIMARYKEYFIELD) {
    drillInFilters.push({
      filterName: colDef?.drillIn?.targetFilter || 'PRIMARYKEYFIELD',
      values: [data.PRIMARYKEYFIELD],
      operation: 'IsOneOf',
    });
  }

  if (colDef?.drillIn?.optionalFilters && reportMetadata?.appliedFilters) {
    colDef.drillIn.optionalFilters.forEach((optionalFilter: any) => {
      const { targetFilter, sourceValue, targetFilterOperator, targetFilterValues } = optionalFilter;
      const matchingFilter = reportMetadata.appliedFilters.find(
        (filter: any) => filter.filterName === sourceValue
      );
      if (
        matchingFilter &&
        matchingFilter.values &&
        matchingFilter.values.length > 0
      ) {
        drillInFilters.push({
          filterName: targetFilter,
          values: matchingFilter.values,
          operation: matchingFilter.operation,
        });
      }
      else if (targetFilterValues && targetFilterValues.length > 0 && targetFilterOperator) {
        drillInFilters.push({
          filterName: targetFilter,
          values: targetFilterValues,
          operation: targetFilterOperator || 'IsOneOf',
        });
      }
    });
  }

  return drillInFilters;
};

/**
 * Exports a drill-in report as CSV using `ReportExporter`.
 *
 * Filters the provided `reportSchema` to only include `visibleColumns`, then
 * invokes `ReportExporter.exportReport` with sorting, filters, and teamsite IDs.
 * Marks the export as a drill-in (`isDrillIn=true`).
 *
 * @param selectedDrillInReport The target report metadata (expects `id`, `reportName`).
 * @param reportSchema The full report schema containing field descriptors.
 * @param visibleColumns Lowercased list of field names to include in the export.
 * @param sortField Field name used to sort the export.
 * @param sortOrder Sort direction: `'asc'` or `'desc'`.
 * @param filters Filters to apply to the export request.
 * @param teamsiteIds Teamsite identifiers used to scope the export.
 * @returns Export status: `'default' | 'loading' | 'success' | 'error'`.
 */
export const onExportAsCsv = async (
  selectedDrillInReport: any,
  reportSchema: any[],
  visibleColumns: string[],
  sortField: string,
  sortOrder: 'asc' | 'desc',
  filters: any[],
  teamsiteIds: any[],
  sourceReportId: string,
  sourceReportDrillInColumn: string,
): Promise<'default' | 'loading' | 'success' | 'error'> => {
  if (!reportSchema || !reportSchema.length) return 'error';

  const fields = reportSchema
    .filter((f: any) => visibleColumns.includes(f.name?.toLocaleLowerCase() || ''))
    .map((field: any) => ({
      name: field.name,
      isProperty: field.isProperty,
      propertyType: field.propertyType,
      propertyId: field.propertyId,
    }));

  const status = await ReportExporter.exportReport(
    selectedDrillInReport?.id,
    selectedDrillInReport?.reportName,
    fields as any, 
    sortField,
    sortOrder,
    filters,
    teamsiteIds,
    false,
    true, // isDrillIn=true
    sourceReportId,
    sourceReportDrillInColumn
  );
  return status;
};
