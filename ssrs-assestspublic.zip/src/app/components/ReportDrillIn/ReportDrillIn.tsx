import React, {
	Suspense,
	lazy,
	useEffect,
	useMemo,
	useState,
	useContext,
	useCallback,
} from 'react';
import ReportService from '../../../services/ReportService';
import { IQueryParamsTypes } from '../../../interfaces/IDeepLinkingTypes';
import { getReportsTablColumnDefs } from '../../../utils/getReportsTblColumnDefs';
import { ReportDataContext } from '../../../contexts/';
import {
	useApplicationInfo,
	useTenantUniqueId,
} from '../../../contexts/CommonServicesContext';
import { ColDef } from '@seismic/shared-datagrid';
import {
	mergeAppliedFiltersWithInfo,
	loadWebReportGrid,
	loadWebReportGridTypes,
	buildDrillInUrl,
	applyStoredOrder,
	getFiltersForDrillInReport as getFiltersForDrillInReportUtil,
	onExportAsCsv as onExportAsCsvUtil,
} from './reportDrillIn-utils';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from '../../../utils/constants';
import { useLocation } from 'react-router-dom';

type WebReportGridModule = Awaited<ReturnType<typeof loadWebReportGridTypes>>;
type IWebReportDataSource = WebReportGridModule['IWebReportDataSource'];
type IWebReportColumnDef = WebReportGridModule['IWebReportColumnDef'];
type IWebReportDrillInReportHeader =
	WebReportGridModule['IWebReportDrillInReportHeader'];
type IWebReportTeamsites = WebReportGridModule['IWebReportTeamsites'];

// Create lazy component - extract default export
const WebReportGrid = lazy(loadWebReportGrid);
interface ReportDrillInProps {
	showReportModal: boolean;
	setShowReportModal: (show: boolean) => void;
	colDef?: IWebReportColumnDef;
	data?: any;
}

type sortType = 'asc' | 'desc';

const ReportDrillIn = ({
	showReportModal,
	setShowReportModal,
	colDef,
	data,
}: ReportDrillInProps) => {
	const reportDisplayMode = 'modal';
	const {setDrillInReportExportPayload } =
		useContext(ReportDataContext);
	const [targetReport, setTargetReport] = useState<string>(
		colDef?.drillIn?.targetReport || ''
	);
	const [sourceReportDrillInColumn, setSourceReportDrillInColumn] =
		useState<string>(colDef?.field || '');

	const [sourceReportId, setSourceReportId] = useState<string>(
		colDef?.reportId || ''
	);

	const [targetReportMetadata, setTargetReportMetadata] = useState<any>(null);
	const [columnsDefs, setColumnsDefs] = useState<IWebReportColumnDef[]>([]);
	const [isLoading, setIsLoading] = useState(true);

	const [reportFilters, setReportFilters] = useState<any>(null);
	const [totalRowsCount, setTotalRowsCount] = useState<number>();
	const [selectedDrillInReport, setSelectedDrillInReport] = useState<any>(null);
	const { reportMetadata } = useContext(ReportDataContext);
	const [localReportSchema, setLocalReportSchema] = useState<ColDef<any>[]>([]);
	const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
	const [exportButtonStatus, setExportButtonStatus] = useState<
		'default' | 'loading' | 'success' | 'error'
	>('default');
	const defaultSortField = '';
	const defaultSortOrder = 'asc';
	const [sortData, setSortData] = useState<{ field: string; sort: sortType }>({
		field: defaultSortField,
		sort: defaultSortOrder as sortType,
	});

	const pageSize = 100;
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();
	const location = useLocation();

	useEffect(() => {
		const reportSchema = getReportsTablColumnDefs(columnsDefs, '', '');
		setLocalReportSchema(reportSchema);

		setVisibleColumns(
			columnsDefs
				?.filter((f) => f.isDefault)
				.map((col) => col.name.toLocaleLowerCase())
		);
	}, [columnsDefs]);

	useEffect(() => {
		if (colDef?.drillIn?.targetReport) {
			setTargetReport(colDef.drillIn.targetReport);
		}
	}, [colDef]);

	const buildDrillInExportPayload = useCallback(() => {
		const teamsiteIds = targetReportMetadata?.teamsites
			?.filter((teamsite: any) => teamsite.isSelected)
			.map((teamsite: any) => teamsite.id);
		const sourceReportDrillInColumn = colDef?.field || '';
		const sourceReportId = colDef?.reportId || '';
		const payload = {
			selectedDrillInReport: selectedDrillInReport,
			reportSchema: localReportSchema,
			//visibleColumns: visibleColumnsInWebReportGrid,
			sortField: sortData.field,
			sortOrder: sortData.sort,
			filters: getFiltersForDrillInReport(),
			teamsiteIds: teamsiteIds,
			sourceReportId: sourceReportId,
			sourceReportDrillInColumn: sourceReportDrillInColumn,
		};
		setDrillInReportExportPayload(payload);
	}, [
		targetReport,
		visibleColumns,
		sortData,
		sourceReportId,
		sourceReportDrillInColumn,
		setDrillInReportExportPayload,
	]);

	const onExportAsCsv = async (visibleColumnsInWebReportGrid: string[]) => {
		setExportButtonStatus('loading');
		const teamsiteIds = targetReportMetadata?.teamsites
			?.filter((teamsite: any) => teamsite.isSelected)
			.map((teamsite: any) => teamsite.id);
		const sourceReportDrillInColumn = colDef?.field || '';
		const sourceReportId = colDef?.reportId || '';
		const status = await onExportAsCsvUtil(
			selectedDrillInReport,
			localReportSchema as any,
			visibleColumnsInWebReportGrid,
			sortData.field,
			sortData.sort,
			getFiltersForDrillInReport(),
			teamsiteIds,
			sourceReportId,
			sourceReportDrillInColumn
		);
		setExportButtonStatus(status);
	};

	const getFiltersForDrillInReport = () => {
		return getFiltersForDrillInReportUtil(data, colDef, reportMetadata);
	};

	const drillInUrl = buildDrillInUrl(
		targetReport,
		columnsDefs as any,
		getFiltersForDrillInReport(),
		pageSize,
		sourceReportId || '',
		sourceReportDrillInColumn,
		{
			skip: 0,
			take: pageSize,
			// Best-effort: use first column as order field if present
			orderField: (columnsDefs?.[0]?.field as string) || undefined,
			orderBy: 'DESC',
		}
	);

	const handleOpenInNewTab = useCallback(() => {
		try {
			const currentUrl: string = `/selfservicereports/report/${targetReport}`;
			const getUserTenantKey = (userId: string, tenantId: string): string =>
				`${userId}_${tenantId}`;

			let userData: any = {};
			const existingUserData = localStorage.getItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY
			);
			if (existingUserData) {
				userData = JSON.parse(existingUserData);
			}

			const userTenantKey = getUserTenantKey(UserId, tenantUniqId);
			const reports: any[] = userData[userTenantKey].reports;

			const existingReport = reports.find(
				(report: { reportId: string }) => report.reportId === targetReport
			);

			const existingReportId = existingReport ? existingReport.reportId : null;

			const drillInReportData = {
				targetReport,
				filters: getFiltersForDrillInReport(),
				sourceReportDrillInColumn,
				isDrillIn: true,
				sourceReportId,
			};

			if (existingReportId) {
				// Update existing report drill-in params
				existingReport.drillInParams = drillInReportData;
				reports.map((report: any) => {
					if (report.reportId === targetReport) {
						return existingReport;
					}
					return report;
				});
			} else {
				// Add new report drill-in params
				reports.push({
					reportId: targetReport,
					hiddenColumnNames: [],
					columnOrder: '',
					drillInParams: drillInReportData,
				});
			}

			// Persist updated reports back to localStorage
			userData[userTenantKey] = {
				...(userData[userTenantKey] || {}),
				reports,
			};

			userData['previous_drillIn_url'] = currentUrl;
			userData['previous_drillIn_report_id'] = targetReport;

			localStorage.setItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY,
				JSON.stringify(userData)
			);
		} catch (error) {
			console.error(
				'Error saving drill-in open params to localStorage:',
				error
			);
		}
	}, [
		UserId,
		tenantUniqId,
		targetReport,
		columnsDefs,
		pageSize,
		sourceReportId,
		sourceReportDrillInColumn,
		drillInUrl,
	]);

	const [drillInReportHeader, setDrillInReportHeader] =
		useState<IWebReportDrillInReportHeader>({
			reportName: '',
			userName: '',
			reportType: '',
			onOpenInNewTab: handleOpenInNewTab,
		});

	const dataSource: IWebReportDataSource = useMemo(
		() => ({
			getRows: (params: { success?: any; fail?: any; request?: any }) => {
				const { request } = params;
				const startRow = request.startRow ?? 0;
				const endRow = request.endRow ?? pageSize;
				const sortModel = request?.sortModel ?? [];

				const orderField =
					sortModel.length > 0 ? sortModel[0].colId : defaultSortField;
				const orderBy =
					sortModel.length > 0 ? sortModel[0].sort : defaultSortOrder;

				setSortData({
					field: orderField,
					sort: orderBy as sortType,
				});

				// Calculate how many records to fetch
				const take = endRow - startRow;

				const options: IQueryParamsTypes = {};
				options.skip = startRow;
				options.take = take;
				options.orderBy = orderBy;
				options.orderField = orderField;
				options.isDrillIn = true;
				options.filters = getFiltersForDrillInReport();
				options.sourceReportId = sourceReportId;
				options.sourceReportDrillInColumn = sourceReportDrillInColumn;
				options.teamsiteIds = reportMetadata?.teamsites
					?.filter((teamsite: any) => teamsite.isSelected)
					.map((teamsite: any) => teamsite.id);

				ReportService.getReportDataWithDefaults(targetReport, options)
					.then(({ data: responseData, pagination, report }: any) => {
						const fetchedData: any[] = Array.isArray(responseData)
							? responseData
							: [];

						setTargetReportMetadata(report);

						// Update drill-in report header state
						setDrillInReportHeader({
							reportName: report?.reportName || '',
							userName: data?.PRIMARYKEYFIELD || '',
							reportType: report?.reportType || '',
							onOpenInNewTab: handleOpenInNewTab,
						});

						// Apply client-side sort using either the grid sort model
						// or fallback to component state `sortData` when sort model is empty

						const colId =
							Array.isArray(sortModel) && sortModel.length > 0
								? sortModel[0]?.colId
								: report?.orderField;
						const sort =
							Array.isArray(sortModel) && sortModel.length > 0
								? (sortModel[0]?.sort as sortType)
								: (report?.orderBy as sortType);

						if (colId && sort) {
							fetchedData.sort((a: any, b: any) => {
								const av = (a[colId] ?? '').toString().toLowerCase();
								const bv = (b[colId] ?? '').toString().toLowerCase();
								if (av < bv) return sort === 'asc' ? -1 : 1;
								if (av > bv) return sort === 'asc' ? 1 : -1;
								return 0;
							});
						}

						// Update selectedDrillInReport in context for downstream consumers
						const id = targetReport;
						setSelectedDrillInReport({
							reportName: report?.reportName,
							id: id,
							reportType: report?.reportType,
							systemReportName: report?.systemReportName,
							description: report?.description,
							ownerUserId: report?.ownerUserId,
						} as any);

						const filtersMetadata = report?.standardReportMetadata?.filterGroup;
						const mergedFilters = mergeAppliedFiltersWithInfo(
							report?.appliedFilters || [],
							filtersMetadata
						);
						setReportFilters(mergedFilters);
						// Only set columns on first load
						if (startRow === 0) {
							const reportSchema =
								getReportsTablColumnDefs(
									report?.requestedFields || [],
									report?.orderField || '',
									report?.orderBy as sortType,
									selectedDrillInReport,
									UserId,
									tenantUniqId
								) || [];

							const orderedSchema = applyStoredOrder(
								targetReport,
								reportSchema
							);
							setColumnsDefs(orderedSchema);
						}

						setTotalRowsCount(pagination.totalRecords);

						params.success({
							rowData: fetchedData,
							rowCount: pagination.totalRecords,
						});
					})
					.catch((res) => {
						console.log('Error in fetching reports data', res);
						params.fail();
					})
					.finally(() => {
						setIsLoading(false);
					});
			},
		}),
		[targetReport]
	);

	return (
		<Suspense fallback={<div>Loading...</div>}>
			<WebReportGrid
				columns={columnsDefs}
				dataSource={dataSource}
				reportDisplayMode={reportDisplayMode}
				modalProps={{ showReportModal, setShowReportModal }}
				totalRowsCount={totalRowsCount}
				cacheBlockSize={pageSize}
				drillInReportHeader={drillInReportHeader}
				reportFilters={reportFilters}
				reportUrl={drillInUrl}
				exportReport={{
					hideLabel: false,
					exportButtonStatus: exportButtonStatus,
					setExportButtonStatus: setExportButtonStatus,
					onExportAsCsv: onExportAsCsv,
					reportSchema: localReportSchema,
				}}
				teamsites={targetReportMetadata?.teamsites as IWebReportTeamsites[]}
			/>
		</Suspense>
	);
};

export default React.memo(ReportDrillIn);
