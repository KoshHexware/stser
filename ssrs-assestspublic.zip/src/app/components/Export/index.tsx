import React, { useContext, useState, useEffect, useMemo } from 'react';
import { ContextualButton, Tooltip } from '@seismic/mantle';
import { IconExport } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { CompileReportContext, ReportDataContext } from '../../../contexts';
import { getReportsTablColumnDefs } from '../../../utils/getReportsTblColumnDefs';
import { ColDef } from '@seismic/shared-datagrid';
import ReportExporter from '../../../utils/ReportExporter';
import {
	useApplicationInfo,
	useLaunchDarkly,
	useTenantUniqueId,
} from '../../../contexts/CommonServicesContext';
import { checkSSRWinterFY26FeatureFlag } from '../../../utils/featureFlagUtils';
import { getIsDrillInReport } from '../../../utils/drillInReportUtils';

const ExportReport = (props) => {
	const { hideLabel } = props;
	const { t } = useTranslation();
	const {
		updatedFields,
		updatedFilters,
		updatedOrderField,
		updatedOrderBy,
		updatedTeamsites,
		gridHiddenColumns,
		isChanged,
	} = useContext(CompileReportContext);
	const { selectedReport } = useContext(ReportDataContext);

	const launchDarklyToggles = useLaunchDarkly();
	const isSSRWinterFY26FeatureFlagEnabled =
		checkSSRWinterFY26FeatureFlag(launchDarklyToggles);

	const [localReportSchema, setLocalReportSchema] = useState<ColDef<any>[]>([]);
	const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
	const [exportButtonStatus, setExportButtonStatus] = useState<
		'default' | 'loading' | 'success' | 'error'
	>('default');
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();
	const { id, reportName } = selectedReport;

	// Generate the report schema and visible columns
	useEffect(() => {
		const visibleFieldsOnGrid =
			gridHiddenColumns?.length > 0
				? updatedFields.filter(
						(field) => !gridHiddenColumns.includes(field.name)
				  )
				: updatedFields;
		const reportSchema = getReportsTablColumnDefs(
			visibleFieldsOnGrid,
			updatedOrderField,
			updatedOrderBy,
			selectedReport,
			undefined,
			undefined,
			isSSRWinterFY26FeatureFlagEnabled
		);
		setLocalReportSchema(reportSchema);

		setVisibleColumns(
			visibleFieldsOnGrid
				?.filter((f) => f.isDefault)
				.map((col) => col.name.toLocaleLowerCase())
		);
	}, [updatedFields, updatedOrderField, updatedOrderBy, gridHiddenColumns]);

	// Set exportButtonStatus back to default
	useEffect(() => {
		if (exportButtonStatus !== 'default' && exportButtonStatus !== 'loading') {
			setTimeout(() => setExportButtonStatus('default'), 3000);
		}
	}, [exportButtonStatus]);

	// Export as CSV logic
	const onExportAsCsv = async () => {
		//Handle the drillIn reports here

		const { isDrillInReport, drillInParams } = getIsDrillInReport(
			UserId,
			tenantUniqId,
			id
		);

		if (!localReportSchema || !localReportSchema.length) return;
		setExportButtonStatus('loading');

		const fields = localReportSchema
			.filter((f) => visibleColumns.includes(f.name?.toLocaleLowerCase() || ''))
			.map((field: any) => ({
				name: field.name,
				isProperty: field.isProperty,
				propertyType: field.propertyType,
				propertyId: field.propertyId,
			}));

		const teamsiteIds = updatedTeamsites
			.filter((t) => t.isSelected)
			.map((t) => t.id);

		const status = await ReportExporter.exportReport(
			id,
			reportName,
			fields,
			updatedOrderField,
			updatedOrderBy,
			updatedFilters,
			teamsiteIds,
			isDrillInReport ? false : !isChanged,
			isDrillInReport ? true : false,
			isDrillInReport ? drillInParams?.sourceReportId : null,
			isDrillInReport ? drillInParams?.sourceReportDrillInColumn : null
		);
		setExportButtonStatus(status);
	};

	return (
		<Tooltip
			content={t('self_service_reports_export_report_tooltip', 'Export report')}
			position='top'
			size='sm'
		>
			<div>
				<ContextualButton
					label={t('self_service_reports_export', 'Export')}
					data-testid='export-button'
					className='ssrs-view-report-export trk_button_ssrs-report_view-export_report'
					errorLabel={t(
						'self_service_reports_export_failed',
						'Report export failed'
					)}
					successLabel={t(
						'self_service_reports_export_success',
						'Report export successful'
					)}
					hideLabel={hideLabel}
					loadingLabel={t('self_service_reports_exporting', 'Exporting...')}
					variant='tertiary'
					status={exportButtonStatus}
					disabled={
						exportButtonStatus === 'loading' || localReportSchema?.length === 0
					}
					startAdornment={<IconExport size={16} />}
					onClick={onExportAsCsv}
				/>
			</div>
		</Tooltip>
	);
};

export default ExportReport;
