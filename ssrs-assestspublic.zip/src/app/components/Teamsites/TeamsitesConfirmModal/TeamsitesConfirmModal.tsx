import React, { useContext } from 'react';
import './TeamsitesConfirmModal.scss';
import { Modal } from '@seismic/mantle';
import {
  CompileReportContext,
} from '../../../../contexts';
import { useTranslation } from 'react-i18next';
import ReportService from '../../../../services/ReportService';
import { CONTENT_CUSTOM_PROPERTY } from '../../../../utils/constants';

const TeamsitesConfirmModal = ({ setIsTeamsitesChangesLoading }) => {
  const {
    updatedFields,
    setUpdatedFields,
    updatedFilters,
    setUpdatedFilters,
    setIsChanged,
    isTeamsitesClicked,
    setIsTeamsitesClicked,
    updatedTeamsites,
    setUpdatedTeamsites,
    tempTeamsites,
    setTempTeamsites,
    setShouldTriggerWithDefaultsAPI
  } = useContext(CompileReportContext);

  const { t } = useTranslation();
  const selectedTeamsitesIds = tempTeamsites
    ?.filter((teamsite) => teamsite.isSelected)
    .map((teamsite) => teamsite.id);

  const filterItemsByTeamsites = (items) =>
    items.filter((item) => {
      if (item?.isProperty && item?.propertyType === CONTENT_CUSTOM_PROPERTY) {
        return item?.teamsiteIds?.some((id) =>
          selectedTeamsitesIds.includes(id)
        );
      }
      return true;
    });

  const handleFiltersOnNav = () => {
    const updatedFiltersClone = filterItemsByTeamsites(updatedFilters);
    updatedFiltersClone.forEach((filter) => {
      if (filter?.filterValuesByTeamsite) {
        filter.values = [];;
      }
    });
    setUpdatedFilters(
      updatedFiltersClone.length > 0 ? updatedFiltersClone : []
    );
  };

  const handleFieldsOnNav = () => {
    const updatedFieldsClone = filterItemsByTeamsites(updatedFields);
    setUpdatedFields(updatedFieldsClone.length > 0 ? updatedFieldsClone : []);
  };

  const handleTeamsitesOnConfirm = async () => {
    setIsTeamsitesChangesLoading(true);
    //update the teamsites in userSettings API
    const updatedTeamsiteIds = tempTeamsites
      ?.filter((teamsite) => teamsite.isSelected)
      .map((teamsite) => teamsite.id);

    try {
      const response = await ReportService.updateUserSettingsGlobalTeamsites(
        updatedTeamsiteIds
      );
      handleFieldsOnNav();
      handleFiltersOnNav();
      setUpdatedTeamsites(response);
      setTempTeamsites([]);
      setShouldTriggerWithDefaultsAPI(true);
    } catch (error) {
      console.error('Error updating teamsites:', error);
    } finally {
      setIsTeamsitesClicked(false);
      setIsTeamsitesChangesLoading(false);
    }
  };

  const handleTeamsitesOnCancel = () => {
    setTempTeamsites([]);
    setIsTeamsitesClicked(false);
  };

  return (
    <Modal
      open={isTeamsitesClicked}
      size='md'
      onClose={() => {
        setIsTeamsitesClicked(false);
      }}
      header={t(
        'self_service_reports_teamsites_confirm_modal_header',
        'You are changing teamsites'
      )}
      footerButtonProps={[
        {
          label: t('self_service_reports_cancel', 'Cancel'),
          variant: 'secondary',
          onClick: handleTeamsitesOnCancel,
        },
        {
          label: t('self_service_reports_confirm', 'Confirm'),
          variant: 'primary',
          onClick: handleTeamsitesOnConfirm,
        },
      ]}
      className='ssrs-teamsites-confirm-modal'
    >
      <div>
        {t(
          'self_service_reports_teamsites_changes_confirm_message',
          "This may change your report's applied filters and selected columns to match your new teamsite selection(s). Do you wish to proceed?"
        )}
      </div>
    </Modal>
  );
};

export default TeamsitesConfirmModal;
