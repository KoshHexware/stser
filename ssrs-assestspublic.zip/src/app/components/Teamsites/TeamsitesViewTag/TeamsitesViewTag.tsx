import React, { useContext } from 'react';
import './TeamsitesViewTag.scss';
import { Tag, Tooltip } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';

const TeamsitesViewTag = ({teamsites}) => {
  const { t } = useTranslation();
  const updatedTeamsitesCount = teamsites?.filter(
    (teamsite) => teamsite.isSelected
  ).length;
  const teamsitesCount = teamsites?.length;
  const selectedTeamsites = teamsites
    ?.filter((teamsite) => teamsite.isSelected)
    .map((teamsite) => teamsite.name)
    .join(', ');

  if (!teamsitesCount || teamsitesCount <= 1) {
      return null;
  }
  return (
    <Tooltip content={selectedTeamsites} zIndex={10050}>
      <div className='ssrs-teamsites-view-tag'>
        <Tag
          value={t(
            'self_service_reports_teamsites_selected',
            'Teamsites selected'
          )}
          startAdornment={
            <span className='ssrs-teamsites-view-tag-selected-count'>
              <span className='ssrs-teamsites-view-tag-selected-count-text'>
                {updatedTeamsitesCount}
              </span>
            </span>
          }
        />
      </div>
    </Tooltip>
  );
};

export default TeamsitesViewTag;
