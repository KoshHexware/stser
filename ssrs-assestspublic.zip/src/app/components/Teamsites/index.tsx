import React, { useContext, useEffect, useMemo, useState } from 'react';
import './Teamsites.scss';
import { useTranslation } from 'react-i18next';
import { Select } from '@seismic/mantle';
import { CompileReportContext } from '../../../contexts';

const Teamsites = () => {
  const { t } = useTranslation();
  const { updatedTeamsites, setIsTeamsitesClicked, setTempTeamsites, tempTeamsites } =
    useContext(CompileReportContext);

  const [localUpdatedTeamsites, setLocalUpdatedTeamsites] =
    useState(updatedTeamsites);

  const [isTeamsiteChanged, setIsTeamsiteChanged] = useState(false);

  const initialSelectedTeamsiteIds = useMemo(
    () =>
      updatedTeamsites
        .filter((teamsite) => teamsite.isSelected)
        .map((teamsite) => teamsite.id)
        .sort()
        .join(','),
    [updatedTeamsites]
  );

  useEffect(() => {
    const currentSelectedIds = localUpdatedTeamsites
      .filter((site) => site.isSelected)
      .map((site) => site.id)
      .sort()
      .join(',');

    setIsTeamsiteChanged(currentSelectedIds !== initialSelectedTeamsiteIds);
  }, [localUpdatedTeamsites, initialSelectedTeamsiteIds]);

  const selectedTeamsites = useMemo(
    () =>
      localUpdatedTeamsites
        ?.filter((teamsite) => teamsite.isSelected)
        .map((teamsite) => ({
          label: teamsite.name,
          value: teamsite.id,
          disabled: selectedItemsCount == 1 && teamsite.isSelected,
        })),
    [localUpdatedTeamsites]
  );

  const selectedTooltipTeamsites = updatedTeamsites
    ?.filter((teamsite) => teamsite.isSelected)
    .map((teamsite) => teamsite.name)
    .join(', ');

  const isAtleastOneTeamsiteSelected = useMemo(() => {
    return localUpdatedTeamsites?.some((teamsite) => teamsite.isSelected);
  }, [localUpdatedTeamsites]);

  const selectedItemsCount = useMemo(
    () => {
      const count = localUpdatedTeamsites?.filter((teamsite) => teamsite.isSelected).length;
      const tempCount = tempTeamsites?.filter((teamsite) => teamsite?.isSelected).length;
      if (tempCount > 0) {
        return tempCount;
      } else if (count > 0) {
        return count;
      } else {
        return 0;
      }
    },
    [localUpdatedTeamsites, tempTeamsites]
  );

  const allTeamsites = useMemo(
    () =>
      localUpdatedTeamsites?.map((teamsite) => ({
        label: teamsite.name,
        value: teamsite.id,
        disabled: selectedItemsCount == 1 && teamsite.isSelected,
        className: 'trk_chekbox_option_ssrs_teamsites_edit_report',
       isSelected: !!teamsite.isSelected,
      })),
    [localUpdatedTeamsites]
  );

  const handleTeamsitesChange = (selectedOptions) => {
    setLocalUpdatedTeamsites((prev) =>
      prev.map((teamsite) => ({
        ...teamsite,
        isSelected: selectedOptions.some(
          (option) => option.value === teamsite.id
        ),
      }))
    );
  };

  const renderOption = (option) => (
    <div
      role='checkbox'
      aria-checked={option.isSelected}
      aria-label={option.label}
      aria-labelledby={option.label}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
        }
      }}
      className='trk_chekbox_option_ssrs_teamsites_edit_report_label'
    >
      {option.label}
    </div>
  );

  const LabelRenderer = () => (
    <div className='ssrs-teamsites-label'>
      <span className='ssrs-teamsites-selected-count'>
        <span className='ssrs-teamsites-selected-count-text'>
          {selectedItemsCount}
        </span>
      </span>
      <span>
        {t('self_service_reports_teamsites_selected', 'Teamsites selected')}
      </span>
    </div>
  );

  const handleSaveTeamsites = () => {
    setIsTeamsitesClicked(true);
    setTempTeamsites(localUpdatedTeamsites);
  };

  return (
    <Select
      options={allTeamsites}
      multi
      searchable
      renderOption={(option) => renderOption(option)}
      value={selectedTeamsites}
      renderLabel={LabelRenderer}
      onChange={(selectedOptions) => {
        handleTeamsitesChange(selectedOptions);
      }}
      className='trk_select_ssrs_teamsites_edit_report ssrs-teamsites-select'
      onHide={() => {
        if (isTeamsiteChanged && isAtleastOneTeamsiteSelected) {
          handleSaveTeamsites();
        }
      }}
      aria-labelledby={t(
        'self_service_reports_teamsites_select_teamsites',
        'Select teamsites'
      )}
    />
  );
};

export default Teamsites;
