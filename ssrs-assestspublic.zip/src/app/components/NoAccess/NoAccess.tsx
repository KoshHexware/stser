import React from 'react';
import { useTranslation } from 'react-i18next';
import { IllustrationNoAccess } from '@seismic/mantle';
import './NoAccess.scss';

const NoAccess = () => {
  const { t } = useTranslation();

  return (
    <div className="no-access-state-view no-access">
      <div className="no-access-state-view-icon">
        <IllustrationNoAccess size="lg" />
      </div>
      <div className="no-access-state-view-message">
        {t("self_service_reports_no_access", 'To view this page you need access from your administrator.')}
      </div>
    </div>
  );
};

export default NoAccess;
