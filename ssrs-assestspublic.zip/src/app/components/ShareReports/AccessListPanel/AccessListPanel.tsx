import React, { useContext, useState, useEffect, useMemo, useRef } from 'react';
import './AccessListPanel.scss';
import { useTranslation } from 'react-i18next';
import { Button, IconSearch, Input, Spinner, Tag, Tooltip } from '@seismic/mantle';
import { AllAccessGroup } from '../AccessGroup/AccessGroup';
import { copyUrl } from '../../../../utils/copyUrl';
import {
  ReportDataContext,
  ShareReportsContext,
} from '../../../../contexts';
import { NoSearchItems } from '../../common/EmptyState/NoSearchItems';
import { useLaunchDarkly, useTenantUniqueId } from '../../../../contexts/CommonServicesContext';
import { ACCESS_UPDATE_DISPLAY_TIME, SEARCH_DEBOUNCE_DELAY, ENABLE_SSR_WINTER_FY26_RELEASE } from '../../../../utils/constants';
import ReportService from '../../../../services/ReportService';

const AccessListPanel = () => {
  const { t } = useTranslation();
  const {
    isAccessUpdated,
    setIsAccessUpdated,
    searchUser,
    setSearchUser,
    searchNoAccessUsersFound,
    usersNoAccess,
    setSearchNoAccessUsersFound,
    usersHasAccess,
    setUsersHasAccess,
    setUsersHasNoAccess,
    accessUpdatedAPIStatus,
  } = useContext(ShareReportsContext);
  const { setIsReportShared, selectedReport, reportMetadata } = useContext(
    ReportDataContext
  );
  const [
    usersWithAccessSearchResultNoFound,
    setUsersWithAccessSearchResultNoFound,
  ] = useState(false);
  const launchDarklyToggles = useLaunchDarkly();
  const isSSRWinterFY26ReleaseEnabled = launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_WINTER_FY26_RELEASE)?.FeatureState === "True";
  const tenantId = useTenantUniqueId();
  const [searchResults, setSearchResults] = useState<any[]>(usersHasAccess);
  const searchDebounceRef = useRef<number | null>(null);
  const searchRequestIdRef = useRef(0);
  const searchPageIndexRef = useRef(0);
  const activeSearchKeywordRef = useRef('');
  const [isSearchLoadingMore, setIsSearchLoadingMore] = useState(false);
  const [hasMoreSearchResults, setHasMoreSearchResults] = useState(false);
  const [isSearchLoading, setIsSearchLoading] = useState(false);
  const searchResultsRef = useRef<any[]>(usersHasAccess);


  useEffect(() => {
    searchResultsRef.current = searchResults;
  }, [searchResults]);

  const copyLinkTooltipDefaultText = t(
    'self_service_reports_permission_copy_link',
    'Copy link'
  );

  const [copyLinkTooltipText, setCopyLinkTooltipText] = useState(copyLinkTooltipDefaultText);

  const filteredUsersHasAccess = useMemo(() => {
    const localSearchUser = searchUser?.toLowerCase();
    return searchResults
      ?.filter((user) =>
        usersHasAccess?.some((accessUser) => {
          const accessUserId = accessUser?.legacyId || accessUser?.userGroupId;
          const userId = user?.legacyId || user?.userGroupId;
          const idsMatch = accessUserId === userId;
          const isGroupMatch = accessUser?.isGroup === user?.isGroup;
          
          if (searchUser === '') {
            return idsMatch && isGroupMatch;
          }
          
          const nameMatch = accessUser?.fullName
            ?.toLowerCase()
            ?.includes(localSearchUser) ||
            accessUser?.userGroupName
              ?.toLowerCase()
              ?.includes(localSearchUser);
          
          return nameMatch && idsMatch && isGroupMatch;
        })
      )
      .sort((a, b) => {
        // Ensure owner at top if present (only users, not groups)
        if (a?.legacyId === reportMetadata?.ownerUserId && !a?.isGroup) return -1;
        if (b?.legacyId === reportMetadata?.ownerUserId && !b?.isGroup) return 1;
        return (a?.fullName || a?.userGroupName || '').localeCompare(
          b?.fullName || b?.userGroupName || ''
        );
      });
  }, [searchUser, usersHasAccess, searchResults, reportMetadata]);

  const filterdUsersNoAccess = useMemo(() => {
    return searchResults?.filter((user) =>
      usersNoAccess?.some((accessUser) => {
        const accessUserId = accessUser?.legacyId || accessUser?.userGroupId;
        const userId = user?.legacyId || user?.userGroupId;
        return accessUserId === userId && accessUser?.isGroup === user?.isGroup;
      })
    );
  }, [searchUser, usersNoAccess, searchResults]);

  useEffect(() => {
    if (filteredUsersHasAccess?.length > 0) {
      setUsersWithAccessSearchResultNoFound(true);
    } else {
      setUsersWithAccessSearchResultNoFound(false);
    }
  }, [filteredUsersHasAccess]);

  useEffect(() => {
    if (filterdUsersNoAccess?.length > 0) {
      setSearchNoAccessUsersFound(true);
    } else {
      setSearchNoAccessUsersFound(false);
    }
  }, [filterdUsersNoAccess]);

  useEffect(() => {
    if (isAccessUpdated && accessUpdatedAPIStatus === 'success') {
      const timer = setTimeout(() => {
        setIsAccessUpdated(false);
      }, ACCESS_UPDATE_DISPLAY_TIME);
      return () => clearTimeout(timer);
    }
  }, [isAccessUpdated, accessUpdatedAPIStatus]);

  useEffect(() => {
    if (searchUser === '') {
      const sortedUsersHasAccess = [...usersHasAccess].sort((a, b) => {
        // Ensure the owner is at the top (only users, not groups)
        if (a?.legacyId === reportMetadata?.ownerUserId && !a?.isGroup) return -1;
        if (b?.legacyId === reportMetadata?.ownerUserId && !b?.isGroup) return 1;

        return (a?.fullName || a?.userGroupName || '').localeCompare(b?.fullName || b?.userGroupName || '');
      })
      const sortedUsersNoAccess = [...usersNoAccess].sort((a, b) => {
        return (a?.fullName || a?.userGroupName || '').localeCompare(b?.fullName || b?.userGroupName || '');
      });

      // Only dispatch if the sorted data is different from the current state 
      if (
        JSON.stringify(usersHasAccess) !== JSON.stringify(sortedUsersHasAccess)
      ) {
        setUsersHasAccess(sortedUsersHasAccess);
      }
      if (
        JSON.stringify(usersNoAccess) !== JSON.stringify(sortedUsersNoAccess)
      ) {
        setUsersHasNoAccess(sortedUsersNoAccess);
      }
      setSearchResults([...sortedUsersHasAccess]);
    }
  }, [searchUser, usersHasAccess, usersNoAccess]);

  useEffect(() => {
    const intervalId = setTimeout(() => {
      setCopyLinkTooltipText(copyLinkTooltipDefaultText);
    }, 2000);

    return () => {
      clearInterval(intervalId);
    };
  }, [copyLinkTooltipText]);

  const handleSearchChange: any = async (e) => {
    const keyword = e.target.value.trim();
    setSearchUser(keyword);
    searchPageIndexRef.current = 0;
    setHasMoreSearchResults(false);
    setIsSearchLoadingMore(false);
    if (!keyword || keyword?.length < 3) {
      if (searchDebounceRef.current) {
        clearTimeout(searchDebounceRef.current);
        searchDebounceRef.current = null;
      }
      searchRequestIdRef.current++;
      activeSearchKeywordRef.current = '';
      setIsSearchLoading(false);
      setSearchResults([...usersHasAccess]);
      setUsersHasNoAccess([]);
      return;
    }

    if (searchDebounceRef.current) {
      clearTimeout(searchDebounceRef.current);
    }

    const myRequestId = ++searchRequestIdRef.current;
    activeSearchKeywordRef.current = keyword;
    searchDebounceRef.current = window.setTimeout(async () => {
      setIsSearchLoading(true);
      try {
        const results = await ReportService.getShareRecipients(keyword, searchPageIndexRef.current);
        const mappedResults = (results?.items || []).filter(user => {
          if (!isSSRWinterFY26ReleaseEnabled && user?.isGroup === true) return false;
          return true;
        });

        if (myRequestId !== searchRequestIdRef.current) return;
        setSearchResults(mappedResults || []);
        setHasMoreSearchResults(results?.hasNextPage || false);

        const filteredNoAccess = mappedResults?.filter(
          (user) => !usersHasAccess.some((accessUser) => {
            const accessUserId = accessUser?.legacyId || accessUser?.userGroupId;
            const userId = user?.legacyId || user?.userGroupId;
            return accessUserId === userId && accessUser?.isGroup === user?.isGroup;
          })
        );
        setUsersHasNoAccess(filteredNoAccess || []);
      } catch (err) {
        if (myRequestId === searchRequestIdRef.current) {
          setSearchResults([]);
          setUsersHasNoAccess([]);
          setHasMoreSearchResults(false);
        }
      } finally {
        setIsSearchLoading(false);
        if (searchDebounceRef.current) {
          clearTimeout(searchDebounceRef.current);
          searchDebounceRef.current = null;
        }
      }
    }, SEARCH_DEBOUNCE_DELAY);
  };

  const loadMoreSearchResults = async () => {
    const keyword = (activeSearchKeywordRef.current || searchUser || '').trim();
    if (!keyword || keyword.length < 3) return;
    if (isSearchLoadingMore || !hasMoreSearchResults) return;

    const requestIdAtStart = searchRequestIdRef.current;
    const nextPageIndex = searchPageIndexRef.current + 1;

    setIsSearchLoadingMore(true);
    try {
      const results = await ReportService.getShareRecipients(keyword, nextPageIndex);

      if (requestIdAtStart !== searchRequestIdRef.current) {
        return;
      }

      const mappedResults = (results?.items || []).filter(user => {
        if (!isSSRWinterFY26ReleaseEnabled && user?.isGroup === true) return false;
        return true;
      });

      setHasMoreSearchResults(results?.hasNextPage || false);
      searchPageIndexRef.current = nextPageIndex;

      const prev = searchResultsRef.current || [];
      const seen = new Map<string, boolean>();
      const merged = [...prev, ...mappedResults].filter((u: any) => {
        const id = u?.legacyId || u?.userGroupId || u?.id;
        if (!id) return false;
        const key = `${id}_${u?.isGroup || false}`;
        if (seen.has(key)) return false;
        seen.set(key, true);
        return true;
      });

      setSearchResults(merged);

      const filteredNoAccess = merged?.filter(
        (user) =>
          !usersHasAccess.some(
            (accessUser) => {
              const accessUserId = accessUser?.legacyId || accessUser?.userGroupId;
              const userId = user?.legacyId || user?.userGroupId;
              return accessUserId === userId && accessUser?.isGroup === user?.isGroup;
            }
          )
      );

      setUsersHasNoAccess(filteredNoAccess || []);

    } catch (err) {
      console.error('Error loading more people/groups:', err);
    } finally {
      setIsSearchLoadingMore(false);
    }
  };

  useEffect(() => {
    return () => {
      if (searchDebounceRef.current) {
        clearTimeout(searchDebounceRef.current);
        searchDebounceRef.current = null;
      }
    };
  }, []);

  const renderLoading = () => {
    return (
      (isSearchLoading || (accessUpdatedAPIStatus === 'loading' &&
        !isAccessUpdated)) && (
        <div className='ssrs-access-panel-spinner-wrapper'>
          <Spinner />
        </div>
      )
    );
  };

  const renderList = () => {
    return (
      <div className='ssrs-access-panel-access-list-panel-content-wrapper'>
        <AllAccessGroup
          filteredUsersHasAccess={filteredUsersHasAccess}
          filteredUsersNoAccess={filterdUsersNoAccess}
          onLoadMore={loadMoreSearchResults}
          canLoadMore={
            hasMoreSearchResults &&
            !isSearchLoadingMore
          }
        />
      </div>
    )
  };

  const renderAccessMainPanel = () => {
    if (!isSearchLoading && !usersWithAccessSearchResultNoFound && !searchNoAccessUsersFound) {
      return (
        <div className='ssrs-access-panel-access-list-panel-content-wrapper'>
          <NoSearchItems size='md' />
        </div>
      );
    }
    return renderList();
  };

  const onCopyClick = (id: string) => {
    try {
      // IE
      setCopyLinkTooltipText(t('self_service_reports_link_copied_to_clipboard', 'Link copied'));
      return copyUrl(selectedReport?.id);
    } catch (err) {
      console.error('Error copying link:', err);
      return false;
    }
  };

  return (
		<div
			style={{ height: '100%', position: 'relative' }}
			className='ssrs-access-panel'
		>
			<div className='ssrs-access-panel-search-wrapper'>
				<Input
					defaultValue={''}
					startAdornment={<IconSearch size={16} />}
					placeholder={t(
						'self_service_reports_search_and_add_people_or_groups',
						'Search and add people or groups'
					)}
					onChange={handleSearchChange}
					style={{ width: '100%' }}
					className='trk_input_ssrs_share_report_user_search'
				/>
			</div>
			<div className='mntl-scrollbar ssrs-access-panel-access-list-panel-main-wrapper'>
				{renderAccessMainPanel()}
			</div>
			{renderLoading()}
			<div>
				<footer className='ssrs-access-panel-footer'>
					<div className='ssrs-access-panel-footer-button-wrapper'>
						<Tooltip content={copyLinkTooltipText} zIndex={100000110}>
							<Button
								variant='secondary'
								label={copyLinkTooltipDefaultText}
								onClick={() => onCopyClick(selectedReport?.id)}
								className='trk_input_ssrs_share_report_copy_link'
							/>
						</Tooltip>
						<div>
							{isAccessUpdated && accessUpdatedAPIStatus === 'success' && (
								<Tag style={{ marginRight: '12px' }} variant={'success'}>
									{t(
										'self_service_reports_permission_access_updated',
										'Access updated'
									)}
								</Tag>
							)}
							<Button
								onClick={() => {
									setIsReportShared(false);
								}}
								variant='primary'
								label={t('self_service_reports_permission_done', 'Done')}
							/>
						</div>
					</div>
				</footer>
			</div>
		</div>
	);
};

export default AccessListPanel;
