import { useState, useEffect } from 'react';
import ReportService from '../../../services/ReportService';
import { IShareReportData } from '../../../interfaces/IShareReportsTypes';

const useFetchShareReportData = (reportId: string, isSSRWinterFY26ReleaseEnabled: boolean) => {
  const [data, setData] = useState<IShareReportData>({
    ssrUsersList: [],
    sharedReportUsers: [],
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
          const [rawReportOwner, rawSharedReportUsers] = await Promise.all([
            ReportService.getReportOwnerDetails(reportId),
            ReportService.getReportSharedUserList(reportId),
          ]);

          const reportOwner = {
            ...rawReportOwner,
            isGroup: !!rawReportOwner?.isGroup || false,
            type: "User" as "User",
          };

          let sharedReportUsers: any[] = [];
          if (Array.isArray(rawSharedReportUsers) && rawSharedReportUsers.length > 0) {
            sharedReportUsers = rawSharedReportUsers.filter((user) => {
              if(!isSSRWinterFY26ReleaseEnabled && user?.isGroup) return false;
              return true;
            }).map((user) => ({
              ...user,
              legacyId: user?.legacyId || user?.userGroupId,
              fullName: user?.fullName || user?.userGroupName,
              isGroup: !!user?.isGroup,
              isDeactivated: user?.isDeactivated,
            }));
          }

          setData({
            ssrUsersList: [],
            sharedReportUsers: [reportOwner, ...sharedReportUsers],
          });
      } catch (error) {
        console.error('Error fetching share report data', error);
        setData({ ssrUsersList: [], sharedReportUsers: [] });
      } finally {
        setIsLoading(false);
      }
    };

    if (reportId) {
      fetchData();
    }
  }, [reportId]);

  return { data, isLoading };
};

export default useFetchShareReportData;
