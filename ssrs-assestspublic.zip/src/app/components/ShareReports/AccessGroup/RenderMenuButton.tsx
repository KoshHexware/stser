import React, { useEffect, useState, useContext } from 'react';
import './RenderMenuButton.scss';
import {
  Button,
  ButtonMenuContainer,
  ButtonMenuItem,
  ButtonMenuMenu,
  ButtonMenuTrigger,
  IconArrowDown,
  Tooltip,
} from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import TooltipContent from '../TooltipContent/TooltipContent';
import { ActionType } from '../../../../interfaces/IShareReportsTypes';
import ReportService from '../../../../services/ReportService';
import {
  ReportDataContext,
  ShareReportsContext,
} from '../../../../contexts';
import { useLaunchDarkly } from '../../../../contexts/CommonServicesContext';
import { ENABLE_SSR_WINTER_FY26_RELEASE } from '../../../../utils/constants';

const DropdownOption = (props: any) => {
  const { reportMetadata } = useContext(ReportDataContext);
  const { option, subject } = props;
  const { label } = option || {};
  const { isGroup } = subject || false;

  return (
    <div
      className={`ssrs-analytics-dropdown-option-wrapper ${label === 'Remove access'
        ? `ssrs-analytics-remove-user ${isGroup ? 'trk_button_ssrs_share_report_remove_user_group' : 'trk_button_ssrs_share_report_remove_user'}`
        : ''
        }`}
    >
      {label}
    </div>
  );
};

const RenderMenuButton = (props: any) => {
  const { t } = useTranslation();
  const {
    displayName,
    relationLabel,
    relationOptions,
    disabledAction,
    subject,
  } = props;
  const [currentRemovedUser, setCurrentRemovedUser] = useState<any>(null);
  const {
    updatedUsersAccessList,
    setUpdatedUsersAccessList,
    setIsAccessUpdated,
    usersNoAccess,
    setUsersHasNoAccess,
    usersHasAccess,
    setUsersHasAccess,
    setAccessUpdatedAPIStatus,
  } = useContext(ShareReportsContext);
  const { selectedReport } = useContext(ReportDataContext);
  const [accessType, setAccessType] = useState('view');
  const launchDarklyToggles = useLaunchDarkly();
  const isSSRWinterFY26ReleaseEnabled = launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_WINTER_FY26_RELEASE)?.FeatureState === "True";
  useEffect(() => {
    if (currentRemovedUser && accessType === ActionType.Remove) {
      (async () => {
        setAccessUpdatedAPIStatus('loading');
        ReportService.updateSharedReportsUsersAccessList(
          updatedUsersAccessList,
          selectedReport?.id
        )
          .then(() => {
            setIsAccessUpdated(true);
            revokeAccess(currentRemovedUser.legacyId, currentRemovedUser.isGroup);
            setAccessUpdatedAPIStatus('success');
          })
          .catch((error) => {
            console.error('Error while updating filter report type', error);
            setAccessUpdatedAPIStatus('error');
            throw error;
          });
      })();
    }
  }, [currentRemovedUser, accessType]);

  const handleAccessChange: any = (item: any) => {
    setAccessType(item.value);
    if (item.value === ActionType.Remove) {
      setCurrentRemovedUser(subject);
       if (isSSRWinterFY26ReleaseEnabled) {
        const updatedAccessUsers = {
          newSharedUserIds: [],
          newSharedGroupIds: [],
          removedUserIds: (!subject.isGroup) ? [subject.legacyId] : [],
          removedGroupIds: (subject.isGroup) ? [subject.legacyId] : [],
        };
        setUpdatedUsersAccessList(updatedAccessUsers);
      } else {
        const updatedAccessUsers = {
          newSharedUserIds: [],
          removedUserIds: [subject.legacyId],
        };
        setUpdatedUsersAccessList(updatedAccessUsers);
      }
    }
  };

  const revokeAccess = (legacyId: string, isGroup: boolean = false) => {
    const userIndex = usersHasAccess.findIndex(
      (user) => (user.legacyId === legacyId && user.isGroup === isGroup)
    );

    if (userIndex !== -1) {
      const user = usersHasAccess[userIndex];
      const usersUpdatedAceess = usersHasAccess.filter(
        (user) => (user.legacyId !== legacyId || user.isGroup !== isGroup)
      );
      setUsersHasAccess(usersUpdatedAceess);
      const usersUpdatedNoAccess = [...usersNoAccess, user];
      setUsersHasNoAccess(usersUpdatedNoAccess);
    } else {
      console.log(`User with legacyKey ${legacyId} not found in usersNoAccess`);
    }
  };

  const renderOptions = () => {
    return relationOptions?.map((item: any) => {
      const { value } = item;
      return (
        <ButtonMenuItem
          onActivate={() => {
            handleAccessChange(item);
          }}
          key={value}
          value={value}
        >
          <DropdownOption option={item} subject={subject} />
        </ButtonMenuItem>
      );
    });
  };

  const renderLabel = () => {
    return (
      <Tooltip
        inline
        zIndex={10005}
        size='lg'
        style={{ minWidth: '210px', padding: '4px 8px' }}
        position='left'
        content={
          <TooltipContent
            message={t(
              'self_service_reports_permission_you_do_not_have_permission_manage',
              'You don’t have permission to manage access'
            )}
            showLockIcon
          />
        }
        showing={disabledAction ? undefined : false}
      >
        <div className='ssrs-analytics-disabled-relation'>{relationLabel}</div>
      </Tooltip>
    );
  };

  if (disabledAction) {
    return renderLabel();
  }

  return (
    <ButtonMenuContainer zIndex={10005}>
      <ButtonMenuTrigger>
        <Button
          aria-label={t(
            'self_service_reports_permission_current_user_permission',
            `Current permission for ${displayName}: ${relationLabel}`
          )}
          label={relationLabel}
          variant='ghost'
          endAdornment={IconArrowDown}
        />
      </ButtonMenuTrigger>
      <ButtonMenuMenu>{renderOptions()}</ButtonMenuMenu>
    </ButtonMenuContainer>
  );
};

export default RenderMenuButton;
