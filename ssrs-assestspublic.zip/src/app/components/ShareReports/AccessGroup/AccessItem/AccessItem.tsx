import React, { useContext, useState } from 'react';
import styled from 'styled-components';
import { useTranslation } from 'react-i18next';
import {
  AvatarUser,
  IconStatusInformation,
  IconUserGroup,
  Tag,
  Tooltip,
} from '@seismic/mantle';
import RenderMenuButton from '../RenderMenuButton';
import { ReportDataContext } from '../../../../../contexts';

export interface IAccessItem {
  subject: any;
  trackingIds?: any;
  objectTitle: string;
  noPermissionTooltipMessage?: string;
  onAccessChange: (data: any) => void;
  showConfirmModalHandle: (data: any) => void;
}

const AccessItemWrapper = styled.div`
  display: flex;
  align-items: center;
  padding: 12px 0 13px 0;
  justify-content: space-between;
`;

const AccessName = styled.div`
  display: flex;
  align-items: center;
  flex-grow: 1;
`;

const AccessNameWrapper = styled.div`
  align-items: center;
  color: #343a40;
  font-size: 16px;
  margin-left: 8px;
  margin-right: 8px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  max-width: 250px;
  @media (max-width: 599px) {
    max-width: 150px;
  }
  @media (max-width: 399px) {
    max-width: 100px;
  }
  @media (max-width: 340px) {
    max-width: 60px;
  }
`;

const AccessTag = styled.div`
  flexshrink: 0;
  @media (max-width: 599px) {
    display: none;
  }
`;

const IconTag = styled.div`
  flexshrink: 0;
  display: none;
  @media (max-width: 599px) {
    display: block;
  }
`;

const AccessItem = (props) => {
  const { subject } = props;
  const { id, fullName, thumbnailUrl, legacyId, isGroup, userGroupName, isDeactivated } = subject;
  const { reportMetadata } = useContext(ReportDataContext);
  const { t } = useTranslation();
  const AccessTagWrapper = (props: any) => {
    const { accessTagMessage } = props;
    const [showTooltip, setShowTooltip] = useState(false);

    const handleClickIcon = () => {
      setShowTooltip(!showTooltip);
    };

    return accessTagMessage ? (
      <div>
        <AccessTag style={{ flexShrink: 0 }}>
          <Tag style={{ fontSize: 12 }} value={accessTagMessage} />
        </AccessTag>
        <IconTag>
          <Tooltip zIndex={10005} position='bottom' content={accessTagMessage}>
            <span>
              <IconStatusInformation
                size={16}
                color='#868e96'
                onClick={handleClickIcon}
              />
            </span>
          </Tooltip>
        </IconTag>
      </div>
    ) : null;
  };

  return (
    <AccessItemWrapper id={id}>
      <AccessName>
        {isGroup ? (
          <>
            <Tooltip
              content={userGroupName ? `${userGroupName}${isDeactivated ? ` ${t('self_service_reports_deactivated', '(Deactivated)')}` : ''}` : `${fullName}${isDeactivated ? ` ${t('self_service_reports_deactivated', '(Deactivated)')}` : ''}`}
              zIndex={10005}
              position='top'
            >
              <div className="ssrs-analytics-usergroup-avatar">
                <IconUserGroup color="#FFF" size={16} />
              </div>
            </Tooltip>
          </>
        ) : (
          <AvatarUser
            size='md'
            name={`${fullName}${isDeactivated ? ` ${t('self_service_reports_deactivated', '(Deactivated)')}` : ''}`}
            src={thumbnailUrl}
            tooltipProps={{ zIndex: 10005 }}
          />
        )}
        <AccessNameWrapper>{userGroupName ? `${userGroupName}${isDeactivated ? ` ${t('self_service_reports_deactivated', '(Deactivated)')}` : ''}`  : `${fullName}${isDeactivated ? ` ${t('self_service_reports_deactivated', '(Deactivated)')}` : ''}`}</AccessNameWrapper> 
        <AccessTagWrapper
          accessTagMessage={
            (reportMetadata?.ownerUserId === legacyId && !isGroup) ? t('self_service_reports_owner', 'Owner') : ''
          }
        />
      </AccessName>
      <div>
        <RenderMenuButton
          displayName={fullName}
          relationLabel={
            (reportMetadata?.ownerUserId === legacyId && !isGroup) ? t('self_service_reports_permission_can_manage', 'Can manage') : t('self_service_reports_permission_can_view', 'Can view')
          }
          relationOptions={[
            {
              label: t('self_service_reports_permission_can_view', 'Can view'),
              value: 'view',
              disabled: false,
              tooltipMessage: '',
            },
            {
              label: t('self_service_reports_permission_can_remove_access', 'Remove access'),
              value: 'remove',
              disabled: false,
              tooltipMessage: '',
            },
          ]}
          disabledAction={reportMetadata?.ownerUserId === legacyId && !isGroup}
          currentAction={'view'}
          subject={subject}
        />
      </div>
    </AccessItemWrapper>
  );
};

export default AccessItem;
