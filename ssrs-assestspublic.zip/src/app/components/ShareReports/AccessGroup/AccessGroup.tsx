import React, { useContext, useState, useCallback, useMemo, memo, useRef, useEffect } from 'react';
import './AccessGroup.scss';
import { useTranslation } from 'react-i18next';
import { IconStatusInformation, Tooltip } from '@seismic/mantle';
import AccessItem from './AccessItem/AccessItem';
import NoAccessItem from './NoAccessItem/NoAccessItem';
import { ShareReportsContext } from '../../../../contexts';
import { List, ListRowProps, InfiniteLoader } from 'react-virtualized';

interface IAccessGroup {
  withLazyLoad?: boolean;
  usersHasAccess: any;
  objectTitle: string;
  onAccessChange: (data: any) => void;
  showConfirmModalHandle: (data: any) => void;
  noPermissionTooltipMessage?: string;
  loadMoreAccessData?: () => void;
  filteredUsersHasAccess?: any;
}

const AccessGroupWithLazyLoad = (props: IAccessGroup) => {
  const { usersHasAccess } = useContext(ShareReportsContext);
  const { filteredUsersHasAccess } = props;
  const { t } = useTranslation();

  if (!usersHasAccess || usersHasAccess.length === 0) {
    return null;
  }

  const renderRecommendedInfo = () => {
    return (
      <Tooltip
        content={t(
          'self_service_reports_permission_recommended_info',
          'There is too much data. It is recommended that you use the search function to quickly find the user'
        )}
        zIndex={10005}
        position='right'
      >
        <span>
          <IconStatusInformation size={16} style={{ margin: '0 0 5px 2px' }} />
        </span>
      </Tooltip>
    );
  };

  return (
    <div>
      <div className='ssrs-analytics-access-group-list-wrapper'>
        <div className='ssrs-analytics-access-group-title-wrapper'>
          {t(
            'self_service_reports_permission_people_with_access',
            'People with access'
          )}
          {false && renderRecommendedInfo()}
          <span>{':'}</span>
        </div>
        <div className='ssrs-analytics-access-group-list-inner-wrapper'>
          {filteredUsersHasAccess &&
            filteredUsersHasAccess.map((item: any) => {
              return <AccessItem key={item.uniqueId} subject={item} />;
            })}
        </div>
      </div>
    </div>
  );
};

const AccessGroup = (props) => {
  const { withLazyLoad, ...rest } = props;
  return <AccessGroupWithLazyLoad {...rest} />;
};

const NoAccessGroup = (props) => {
  const {
    filterdUsersNoAccess,
    trackingIds,
    objectTitle,
    onAccessChange,
    showConfirmModalHandle,
    noPermissionTooltipMessage,
  } = props;
  const { t } = useTranslation();
  const { usersNoAccess } = useContext(ShareReportsContext);

  if (!usersNoAccess || usersNoAccess.length === 0) {
    return null;
  }

  return (
    <div className='ssrs-analytics-no-access-group-wrapper'>
      <div className='ssrs-analytics-no-access-group-mask'>
        <div className='ssrs-analytics-no-access-group-inner'>
          <div className='ssrs-analytics-no-access-title-wrapper'>
            {t(
              'self_service_reports_permission_people_without_access',
              'People without access'
            )}
            :
          </div>
          {filterdUsersNoAccess &&
            filterdUsersNoAccess.map((item: any) => {
              return (
                <NoAccessItem
                  key={item.uniqueId}
                  subject={item}
                  trackingIds={trackingIds}
                  objectTitle={objectTitle}
                  noPermissionTooltipMessage={noPermissionTooltipMessage}
                  onAccessChange={onAccessChange}
                  showConfirmModalHandle={showConfirmModalHandle}
                />
              );
            })}
        </div>
      </div>
    </div>
  );
};

const AllAccessGroup = memo((props: any) => {
  const {
    filteredUsersHasAccess,
    filteredUsersNoAccess,
    trackingIds,
    objectTitle,
    onAccessChange,
    showConfirmModalHandle,
    noPermissionTooltipMessage,
    onLoadMore,
    canLoadMore = false,
    loadMoreThreshold = 10,
  } = props;
  const { t } = useTranslation();
  const userHasAccess = useMemo(() => filteredUsersHasAccess || [], [filteredUsersHasAccess]);
  const userNoAccess = useMemo(() => filteredUsersNoAccess || [], [filteredUsersNoAccess]);

  const hasAccessCount = userHasAccess.length;
  const hasNoAccessCount = userNoAccess.length;

  const rowCount = useMemo(
    () =>
      (hasAccessCount > 0 ? 1 + hasAccessCount : 0) +
      (hasNoAccessCount > 0 ? 1 + hasNoAccessCount : 0),
    [hasAccessCount, hasNoAccessCount]
  );

  const [scrollTop, setScrollTop] = useState(0);

  const HEADER_HEIGHT = 30;
  const ROW_HEIGHT = 57;
  const MAXIMUM_DISPLAYED_ROWS = 400;

  const accessSectionHeight =
    hasAccessCount > 0 ? HEADER_HEIGHT + hasAccessCount * ROW_HEIGHT : 0;

  const showAccessSticky =
    hasAccessCount > 0 && scrollTop < accessSectionHeight;

  const showNoAccessSticky =
    hasNoAccessCount > 0 && (hasAccessCount === 0 || scrollTop >= accessSectionHeight);

  const renderRecommendedInfo = useCallback(() => {
    return (
      <Tooltip
        content={t(
          'self_service_reports_permission_recommended_info',
          'There is too much data. It is recommended that you use the search function to quickly find the user'
        )}
        zIndex={10005}
        position='right'
      >
        <span>
          <IconStatusInformation size={16} style={{ margin: '0 0 5px 2px' }} />
        </span>
      </Tooltip>
    );
  }, [t]);

  const rowRenderer = useCallback(({ index, key, style }: ListRowProps) => {
    let indx = index;
    if (hasAccessCount > 0) {
      if (!userHasAccess || userHasAccess.length === 0) {
        return null;
      }
      if (indx === 0) {
        return (
          <div key={key} style={style} className='ssrs-analytics-access-group-title-wrapper'>
            {t(
              'self_service_reports_permission_people_with_access',
              'People with access'
            )}
            {false && renderRecommendedInfo()}
            <span>{':'}</span>
          </div>
        );
      }
      indx -= 1;
      if (indx < hasAccessCount) {
        const item = userHasAccess[indx];
        const itemId = item.legacyId || item.userGroupId || item.id;
        const itemKey = itemId ? `${itemId}_${item.isGroup || false}` : `has-${indx}`;
        return (
          <div key={itemKey} style={style} className='ssrs-analytics-access-group-list-inner-wrapper'>
            <AccessItem key={item.uniqueId} subject={item} />
          </div>
        );
      }
      indx -= hasAccessCount;
    }

    if (hasNoAccessCount > 0) {
      if (!userNoAccess || userNoAccess.length === 0) {
        return null;
      }

      if (indx === 0) {
        return (
          <div key={key} style={style} className='ssrs-analytics-no-access-group-mask'>
            <div className='ssrs-analytics-no-access-group-inner'>
              <div className='ssrs-analytics-no-access-title-wrapper'>
                {t(
                  'self_service_reports_permission_people_without_access',
                  'People without access'
                )}
                :
              </div>
            </div>
          </div>
        );
      }
      indx -= 1;
      if (indx < hasNoAccessCount) {
        const item = userNoAccess[indx];
        const itemId = item.legacyId || item.userGroupId || item.id;
        const itemKey = itemId ? `${itemId}_${item.isGroup || false}` : `no-${indx}`;
        return (
          <div key={itemKey} style={style} className='ssrs-analytics-no-access-group-mask'>
            <div className='ssrs-analytics-no-access-group-inner-item'>
              <NoAccessItem
                key={item.uniqueId}
                subject={item}
                trackingIds={trackingIds}
                objectTitle={objectTitle}
                noPermissionTooltipMessage={noPermissionTooltipMessage}
                onAccessChange={onAccessChange}
                showConfirmModalHandle={showConfirmModalHandle}
              />
            </div>
          </div>
        );
      }
      indx -= hasNoAccessCount;
    }

    return null;
  },
    [
      hasAccessCount,
      hasNoAccessCount,
      userHasAccess,
      userNoAccess,
      t,
      trackingIds,
      objectTitle,
      noPermissionTooltipMessage,
      onAccessChange,
      showConfirmModalHandle,
    ]
  );

  const rowHeight = useCallback(({ index }: any) => {
    if (hasAccessCount > 0) {
      if (index === 0) {
        return 20;
      }
      index -= 1;
      if (index < hasAccessCount) {
        return 57;
      }
      index -= hasAccessCount;
    }
    if (hasNoAccessCount > 0) {
      if (index === 0) {
        return 20;
      }
      index -= 1;
      if (index < hasNoAccessCount) {
        return 57;
      }
      index -= hasNoAccessCount;
    }
    return 0;
  }, [hasAccessCount, hasNoAccessCount, HEADER_HEIGHT, ROW_HEIGHT]);

  const isRowLoaded = useCallback(({ index }: { index: number }) => {
    return index < rowCount;
  }, [rowCount]);

  const loadMoreRows = useCallback(({ startIndex, stopIndex }: { startIndex: number; stopIndex: number }) => {
    if (!canLoadMore) {
      return Promise.resolve();
    }
    onLoadMore();
    return Promise.resolve();
  }, [canLoadMore, onLoadMore]);

  const totalRowCount = canLoadMore ? rowCount + MAXIMUM_DISPLAYED_ROWS : rowCount;
  const listRef = useRef<List>(null);
  const prevRowCountRef = useRef(rowCount);
  const [listVersion, setListVersion] = useState(0);

  useEffect(() => {
    if (prevRowCountRef.current > rowCount) {
      setListVersion(v => v + 1);
    }
    prevRowCountRef.current = rowCount;
  }, [rowCount]);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.recomputeRowHeights();
    }
  }, [hasAccessCount, hasNoAccessCount]);

  return (
    <div className={`ssrs-analytics-access-group-list-wrapper ${rowCount <= 2 ? 'ssrs-analytics-access-group-small-list' : ''}`} style={{ position: 'relative', width: 598, height: 325 }}>
      <div
        style={{
          position: 'absolute',
          top: 0, left: 0, right: 0,
          zIndex: 2,
          pointerEvents: 'none'
        }}
      >
        {showAccessSticky && (
          <div
            className='ssrs-analytics-access-group-title-wrapper'
            style={{ height: HEADER_HEIGHT, background: '#fff' }}
          >
            {t('self_service_reports_permission_people_with_access', 'People with access')}
            <span>:</span>
          </div>
        )}
        {!showAccessSticky && showNoAccessSticky && (
          <div
            className='ssrs-analytics-no-access-title-wrapper'
            style={{ height: HEADER_HEIGHT, background: '#eceef0' }}
          >
            {t('self_service_reports_permission_people_without_access', 'People without access')}
            :
          </div>
        )}
      </div>
      <InfiniteLoader
        isRowLoaded={isRowLoaded}
        loadMoreRows={loadMoreRows}
        rowCount={totalRowCount}
        threshold={loadMoreThreshold}
      >
        {({ onRowsRendered, registerChild }) => (
          <List
            key={listVersion}
            ref={(ref) => {
              listRef.current = ref;
              registerChild(ref);
            }}
            width={598}
            height={325}
            rowCount={rowCount}
            rowHeight={rowHeight}
            rowRenderer={rowRenderer}
            overscanRowCount={10}
            style={{ position: 'relative' }}
            onScroll={({ scrollTop: st }) => setScrollTop(st)}
            onRowsRendered={onRowsRendered}
          />
        )}
      </InfiniteLoader>
    </div>
  );
});

export { AccessGroup, NoAccessGroup, AllAccessGroup };