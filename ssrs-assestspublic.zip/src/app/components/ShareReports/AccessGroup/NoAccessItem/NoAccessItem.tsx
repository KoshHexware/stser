import React, { useContext, useEffect } from 'react';
import { AvatarUser, IconUserGroup, LinkButton, Tooltip} from '@seismic/mantle';
import styled from 'styled-components';
import { useTranslation } from 'react-i18next';
import ReportService from '../../../../../services/ReportService';
import {
  ReportDataContext,
  ShareReportsContext,
} from '../../../../../contexts';
import { useLaunchDarkly } from '../../../../../contexts/CommonServicesContext';
import { ENABLE_SSR_WINTER_FY26_RELEASE } from '../../../../../utils/constants';
import './NoAccessItem.scss';
export interface IAccessItem {
  subject: any;
  trackingIds?: any;
  objectTitle: string;
  noPermissionTooltipMessage?: string;
  onAccessChange: (data: any) => void;
  showConfirmModalHandle: (data: any) => void;
}

const AccessItemWrapper = styled.div`
  display: flex;
  align-items: center;
  padding: 12px 0 13px 0;
  justify-content: space-between;
`;

const AccessName = styled.div`
  display: flex;
  align-items: center;
  flex-grow: 1;
`;

const AccessNameWrapper = styled.div`
  align-items: center;
  color: #343a40;
  font-size: 16px;
  margin-left: 8px;
  margin-right: 8px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  max-width: 250px;
  @media (max-width: 599px) {
    max-width: 200px;
  }
  @media (max-width: 399px) {
    max-width: 150px;
  }
  @media (max-width: 340px) {
    max-width: 100px;
  }
`;

const AccessButton = styled(LinkButton)`
  text-align: right;
  cursor: pointer;
  margin-right: 15px !important;
`;

const NoAccessItem = (props: IAccessItem) => {
  const { subject } = props;
  const { id, legacyId, fullName, thumbnailUrl, addAction, isGroup, userGroupName } = subject;
  const [currentNoAccessItem, setCurrentNoAccessItem] =
    React.useState<any>(null);
  const { t } = useTranslation();
  const {
    usersHasAccess,
    usersNoAccess,
    setUsersHasAccess,
    setUsersHasNoAccess,
    setUpdatedUsersAccessList,
    updatedUsersAccessList,
    setIsAccessUpdated,
    setAccessUpdatedAPIStatus,
  } = useContext(ShareReportsContext);
  const { selectedReport, reportMetadata } = useContext(ReportDataContext);
  const launchDarklyToggles = useLaunchDarkly();
  const isSSRWinterFY26ReleaseEnabled = launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_WINTER_FY26_RELEASE)?.FeatureState === "True";

  useEffect(() => {
    if (currentNoAccessItem) {
      (async () => {
        setAccessUpdatedAPIStatus('loading');
        ReportService.updateSharedReportsUsersAccessList(
          updatedUsersAccessList,
          selectedReport?.id
        )
          .then(() => {
            setIsAccessUpdated(true);
            grantAccess(legacyId);
            setAccessUpdatedAPIStatus('success');
          })
          .catch((error) => {
            console.error('Error while updating filter report type', error);
            setAccessUpdatedAPIStatus('error');
            throw error;
          });
      })();
    }
  }, [currentNoAccessItem]);

  const grantAccess = (legacyId: string) => {
    const userIndex = usersNoAccess.findIndex(
      (user) => user.legacyId === legacyId
    );

    if (userIndex !== -1) {
      const user = { ...usersNoAccess[userIndex] };
      const usersUpdatedNoAceess = usersNoAccess.filter(
        (user) => user.legacyId !== legacyId
      );
      setUsersHasNoAccess(usersUpdatedNoAceess);
      const usersUpdatedHasAccess = [...usersHasAccess, user];
      setUsersHasAccess(usersUpdatedHasAccess);
    } else {
      console.log(`User with legacyKey ${legacyId} not found in usersNoAccess`);
    }
  };

  const handleAddPermissionClick: any = () => {
    setCurrentNoAccessItem(subject);
    if (isSSRWinterFY26ReleaseEnabled) {
      setUpdatedUsersAccessList({
        newSharedUserIds: (!subject.isGroup) ? [subject.legacyId] : [],
        newSharedGroupIds: (subject.isGroup) ? [subject.legacyId] : [],
        removedUserIds: [],
        removedGroupIds: [],
      });
    }
    else {
      const updatedAccessUsers = {
        newSharedUserIds: [subject.legacyId],
        removedUserIds: [],
      };
      setUpdatedUsersAccessList(updatedAccessUsers);
    }
  };

  const getAriaLabel = () => {
    return typeof addAction?.ariaLabel === 'function'
      ? addAction?.ariaLabel(fullName)
      : addAction?.ariaLabel;
  };

  const renderRelation = () => {
    return (
      <AccessButton
        aria-label={getAriaLabel()}
        label={
          addAction?.label
            ? addAction?.label
            : t('self_service_reports_permission_add', 'Add')
        }
        onClick={handleAddPermissionClick}
        className={isGroup ? 'trk_link_button_ssrs_share_report_add_user_group' : 'trk_link_button_ssrs_share_report_add_user'}
      />
    );
  };

  return (
    <AccessItemWrapper id={id}>
      <AccessName>
        {isGroup ? (
          <>
            <Tooltip
              content={userGroupName ? userGroupName : fullName}
              zIndex={10005}
              position='top'
            >
              <div className="ssrs-analytics-usergroup-avatar">
                <IconUserGroup color="#FFF" size={16} />
              </div>
            </Tooltip>
            <AccessNameWrapper>{userGroupName ? userGroupName : fullName}</AccessNameWrapper>
          </>
        ) : (
          <>
            <AvatarUser
              size='md'
              name={fullName}
              src={thumbnailUrl}
              tooltipProps={{ zIndex: 10005 }}
            />
            <AccessNameWrapper>{fullName}</AccessNameWrapper>
          </>
        )}
      </AccessName>
      <div>{renderRelation()}</div>
    </AccessItemWrapper>
  );
};

export default NoAccessItem;
