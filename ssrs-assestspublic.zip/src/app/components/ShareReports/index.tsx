import React, { useContext } from 'react';
import './ShareReports.scss';
import { Modal } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import AccessListPanel from './AccessListPanel/AccessListPanel';
import { ReportDataContext } from '../../../contexts';

const Header = (props) => {
  const { title, titleId } = props;

  const renderHeader = () => {
    return (
      <div className='ssrs-analytics-header-wrapper'>
        <h3 className='ssrs-analytics-header-text' id={titleId}>
          {title}
        </h3>
      </div>
    );
  };
  return renderHeader();
};

const ShareReports = () => {
  const { t } = useTranslation();
  const { setIsReportShared } = useContext(ReportDataContext);

  return (
    <Modal
      className='ui-theme-root ecsc-permission-modal'
      style={{ width: '600px', height: '524px' }}
      onClose={() => setIsReportShared(false)}
      modalAriaLabel={t(
        'self_service_reports_share_report_with_others',
        'Share report with others'
      )}
      onKeyDown={(e: any) => e.stopPropagation()}
      header={(titleId) => {
        return (
          <Header
            title={t(
              'self_service_reports_share_report_with_others',
              'Share report with others'
            )}
            titleId={titleId}
            hideTitle={false}
          />
        );
      }}
    >
      {() => {
        return (
          <div className='ssrs-analytics-panel-wrapper'>
            <AccessListPanel />
          </div>
        );
      }}
    </Modal>
  );
};

export default ShareReports;
