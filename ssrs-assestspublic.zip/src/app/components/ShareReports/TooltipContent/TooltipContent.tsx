import React from 'react';
import './TooltipContent.scss';
import { IconLock } from '@seismic/mantle';


interface ITooltipContent {
  message?: string;
  showLockIcon?: boolean;
}

const TooltipContent = (props: ITooltipContent) => {
  const { message, showLockIcon } = props;
  return (
    <div className='ssrs-analytics-tooltip-content-wrapper'>
      {showLockIcon && <IconLock style={{ marginRight: '8px' }} size={20} />}
      {message}
    </div>
  );
};

export default TooltipContent;
