import React, { useContext } from 'react';
import ShareReportsState, {
  shareReportsInitialState,
} from '../../../contexts/ShareReportsContext';
import { ReportDataContext } from '../../../contexts';
import ShareReports from '.';
import useFetchShareReportData from './useFetchShareReportData';
import { INewUpdatedUserAccessList } from '../../../interfaces/IShareReportsTypes';
import { Modal, Spinner } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { useLaunchDarkly } from '../../../contexts/CommonServicesContext';
import { ENABLE_SSR_WINTER_FY26_RELEASE } from '../../../utils/constants';

const CompileShareReports = () => {
  const launchDarklyToggles = useLaunchDarkly();
  const isSSRWinterFY26ReleaseEnabled = launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_WINTER_FY26_RELEASE)?.FeatureState === "True";
  const { selectedReport, isReportShared, reportMetadata } = useContext(
    ReportDataContext
  );
  const { t } = useTranslation();
  const { id } = selectedReport;

  const Header = (props) => {
    const { title, titleId } = props;

    const renderHeader = () => {
      return (
        <div className='ssrs-analytics-header-wrapper'>
          <h3 className='ssrs-analytics-header-text' id={titleId}>
            {title}
          </h3>
        </div>
      );
    };
    return renderHeader();
  };

  // Use the custom hook to fetch data
  const { data, isLoading } = useFetchShareReportData(id, isSSRWinterFY26ReleaseEnabled);
  const { ssrUsersList, sharedReportUsers } = data;

  // Compute context values only when data is available
  const contextValues = React.useMemo(() => {
    if (!ssrUsersList || !sharedReportUsers) return shareReportsInitialState;
    
      // Sort users with access: owner first, then alphabetically
      const usersHasAccess = sharedReportUsers
        .sort((a, b) => {
          // Ensure owner at top if present (only users, not groups)
          if (a?.legacyId === reportMetadata?.ownerUserId && !a?.isGroup) return -1;
          if (b?.legacyId === reportMetadata?.ownerUserId && !b?.isGroup) return 1;
          return (a?.fullName || a?.userGroupName || '').localeCompare(b?.fullName || b?.userGroupName || '');
        });

      // Filter out users/groups that already have access and the owner
      const usersNoAccess = ssrUsersList
        .filter(
          (item) =>
            (item?.legacyId !== reportMetadata?.ownerUserId && !item?.isGroup) &&
            !sharedReportUsers.some((shared) => {
              const sharedId = shared?.legacyId || shared?.userGroupId;
              const itemId = item?.legacyId || item?.userGroupId;
              return sharedId === itemId && shared?.isGroup === item?.isGroup;
            })
        )
        .sort((a, b) => (a?.fullName || a?.userGroupName || '').localeCompare(b?.fullName || b?.userGroupName || '')); // includes groups and users
      return {
        showAccessMenuButton: false,
        sharedReportUsers,
        ssrsAccessUsersList: ssrUsersList,
        usersHasAccess,
        usersNoAccess,
        updatedUsersAccessList: {
          newSharedUserIds: [],
          newSharedGroupIds: [],
          removedUserIds: [],
          removedGroupIds: [],
        } as INewUpdatedUserAccessList,
        isAccessUpdated: false,
        searchUser: '',
        searchNoAccessUsersFound: false,
      };
  }, [ssrUsersList?.length, sharedReportUsers?.length, isLoading]);

  return (
    <>
      {isReportShared && ssrUsersList && sharedReportUsers && !isLoading ? (
        <ShareReportsState values={contextValues}>
          <ShareReports />
        </ShareReportsState>
      ) : (
        isReportShared && (
          <Modal
            className='ui-theme-root ecsc-permission-modal'
            displayCloseButton={false}
            style={{ width: '600px', height: '524px' }}
            modalAriaLabel={t(
              'self_service_reports_share_report_with_others',
              'Share report with others'
            )}
            onKeyDown={(e: any) => e.stopPropagation()}
            header={(titleId) => {
              return (
                <Header
                  title={t(
                    'self_service_reports_share_report_with_others',
                    'Share report with others'
                  )}
                  titleId={titleId}
                  hideTitle={false}
                />
              );
            }}
          >
            {isLoading ? (
              <div className='ssrs-analytics-loading-wrapper'>
                <Spinner />
              </div>
            ) : (
              <ShareReports />
            )}
          </Modal>
        )
      )}
    </>
  );
};

export default CompileShareReports;
