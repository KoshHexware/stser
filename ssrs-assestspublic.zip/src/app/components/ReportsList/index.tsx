import React, { useContext, useEffect, useRef, useState, useMemo } from 'react';
import './ReportsList.scss';
import { AsyncDataGrid, GridApi } from '@seismic/shared-datagrid';
import {
  IconDelete,
  LanguageCode,
  seismicTheme,
  Select,
} from '@seismic/mantle';
import { ErrorBoundary } from '../common/ErrorBoundary';
import {
  OwnerCell,
  NameCell,
  DateCell,
  DateTimeCell,
  columnTypes,
  DescriptionCell,
} from '../common/CustomCells';
import {
  ReportDataContext,
  AllReportsLandingPageContext,
} from '../../../contexts';
import ReportService from '../../../services/ReportService';
import { useHistory, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Screens } from '../../../contexts/types';
import {
  CUSTOM_REPORT_EDITOR_ACCESS_LEVEL,
  EDITOR_ACCESS_LEVEL,
  FIXEDREPORTLISTPAGESIZE,
  LANDING_PAGE_REPORT_TYPE,
} from '../../../utils/constants';
import { ISelectedReport } from '../../../interfaces/IReport';
import {
  useApplicationInfo,
  useMantleTranslations,
  useUserSettings,
  useAccessLevel,
  useLaunchDarkly,
  useSsrInitAppData
} from '../../../contexts/CommonServicesContext';
import { DeleteCustomReport } from '../DeleteCustomReport';
import {
  updateReportLandingPageStorage,
  getReportLandingPageStorage,
  handleColumnSortUpdate,
} from '../../../utils/landingPageUtils';
import { checkSSRNextGenEnabled } from '../../../utils/ssrPreloadDataUtils';

export const ReportsList = () => {
  const [totalReports, setTotalReports] = React.useState(0);
  const accessLevel = useAccessLevel();
  const launchDarklyToggles = useLaunchDarkly();
  const isEditor = accessLevel == EDITOR_ACCESS_LEVEL;
  const isCustomReportEditor = accessLevel == CUSTOM_REPORT_EDITOR_ACCESS_LEVEL;
  const { setSelectedReport } = useContext(ReportDataContext);
  const {
    setLastScreen,
    setCurrentScreen,
    setUpdatedReportsFilterOption,
    updatedReportsFilterOption,
    setAreSystemReportsEnabled,
  } = useContext(AllReportsLandingPageContext);
  const applicationInfo = useApplicationInfo();
  const { reportsFilterOption } = useUserSettings();
  const { UserId } = applicationInfo.User;
  const [selectedLandingReportType, setSelectedLandingReportType] = useState(
    updatedReportsFilterOption || reportsFilterOption
  );
  const [areRecentsEmpty, setAreRecentsEmpty] = React.useState(false);
  const [areMyReportsEmpty, setAreMyReportsEmpty] = React.useState(false);
  const [deleteCustomReport, setDeleteCustomReport] = useState({
    showModal: false,
    reportName: '',
    reportId: '',
  });
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const searchTextParam = queryParams.get('search');
  const [searchTerm, setSearchTerm] = useState(
    () =>
      searchTextParam || getReportLandingPageStorage().columnReportSearch || ''
  );

  const history = useHistory();
  const { t } = useTranslation();
  const { languageCode, mantleTranslations } = useMantleTranslations();
  const [loading, setLoading] = React.useState(true);
  const gridApiRef = useRef<GridApi | any>(null);
  const previousReportTypeRef = useRef<string | null>(null);

  const [showQuickActions, setShowQuickActions] = useState<boolean>(false);
  const QUICK_ACTIONS_ENABLED_TYPES: string[] = ['all', 'owned'];
  const ssrInitAppData = useSsrInitAppData();
  const isNextGen = process.env.NEXT_GEN === 'true';
  const isSSRNextGenEnabled = checkSSRNextGenEnabled(launchDarklyToggles);
  let orderField = null;
  let orderBy = null;
  if (isSSRNextGenEnabled && isNextGen) {
    orderField = window.appDatas.initApp['/selfservicereports'].userSettings?.orderField;
    orderBy = window.appDatas.initApp['/selfservicereports'].userSettings?.orderBy;
  }

  const reportsColumnDefs: any = [
    {
      headerName: t('self_service_reports_name', 'Name'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-report-name',
      field: 'reportName',
      type: 'text',
      cellRenderer: 'NameCell',
      cellStyle: { alignContent: 'center' },
    },
    {
      headerName: t('self_service_reports_description', 'Description'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-report-description',
      field: 'description',
      type: 'text',
      cellRenderer: 'DescriptionCell',
      cellStyle: { alignContent: 'center' },
      sortable: false,
    },
    {
      headerName: t('self_service_reports_standard_report', 'Standard Report'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-standard-report',
      field: 'systemReportName',
      cellStyle: { alignContent: 'center' },
    },
    {
      headerName: t('self_service_reports_shared_on', 'Shared on'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-shared-on',
      field: 'sharedOn',
      type: 'date',
      cellStyle: { alignContent: 'center' },
      cellRenderer: 'DateTimeCell',
    },
    {
      headerName: t('self_service_reports_owner', 'Owner'),
      headerClass: 'trk_button_ssrs-reports_list-sortable-column-header-owner',
      field: 'ownerUserName',
      cellRenderer: 'OwnerCell',
      cellStyle: { alignContent: 'center' },
    },
    {
      headerName: t('self_service_reports_last_viewed', 'Last viewed'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-last-viewed',
      field: 'lastViewed',
      type: 'date',
      cellStyle: { alignContent: 'center' },
      cellRenderer: 'DateTimeCell',
    },
    {
      headerName: t('self_service_reports_last_updated', 'Last updated'),
      headerClass:
        'trk_button_ssrs-reports_list-sortable-column-header-last-updated',
      field: 'lastUpdated',
      type: 'date',
      cellStyle: { alignContent: 'center' },
      cellRenderer: 'DateTimeCell',
    },
  ];

  const hasMountedRef = useRef(false);
  useEffect(() => {
    hasMountedRef.current = true;
  }, []);

  useEffect(() => {
    if (searchTextParam) {
      // Update storage with URL param value
      updateReportLandingPageStorage({ columnReportSearch: searchTextParam });
    }
  }, [searchTextParam]);

  useEffect(() => {
    setCurrentScreen(Screens.REPORTS_LIST);
    setLastScreen(Screens.REPORTS_LIST);
    setSelectedReport({});
  }, []);

  useEffect(() => {
    // Only update URL if searchTerm has changed
    if (searchTerm !== undefined) {
      if (!searchTextParam || searchTextParam !== searchTerm) {
        // If searchTerm is empty, remove the parameter from URL
        if (searchTerm === '') {
          history.push({ search: '' });
        } else {
          history.push({
            search: `?search=${encodeURIComponent(searchTerm)}`,
          });
        }
        // Update local storage with new search term
        updateReportLandingPageStorage({ columnReportSearch: searchTerm });
      }
    }
  }, [searchTerm, searchTextParam]);

  useEffect(() => {
    // Check for system reports availability once on component mount
    const checkSystemReportsAvailability = async () => {
      try {
        if (isSSRNextGenEnabled && isNextGen) {
          const hasSystemReportAccess = ssrInitAppData?.hasSystemReportAccess;
          if (hasSystemReportAccess !== null) {
            setAreSystemReportsEnabled(!!hasSystemReportAccess);
            return;
          }
        }
        const response = await getAllSystemReportsData(0, 1, null, ''); // Just check first record
        if (response.totalRecords > 0) {
          setAreSystemReportsEnabled(true);
        } else {
          setAreSystemReportsEnabled(false);
        }
      } catch (error) {
        console.error('Error checking system reports availability:', error);
        setAreSystemReportsEnabled(false);
      }
    };

    // Only call once on component mount
    checkSystemReportsAvailability();
  }, []);

  useEffect(() => {
    setShowQuickActions(QUICK_ACTIONS_ENABLED_TYPES.includes(selectedLandingReportType?.toLowerCase()));
  }, [selectedLandingReportType]);

  useEffect(() => {
    if (!!gridApiRef.current) {
      switch (selectedLandingReportType) {
        case 'all':
          gridApiRef.current.setServerSideDatasource(allReportsDataSource);
          break;
        case 'owned':
          gridApiRef.current.setServerSideDatasource(myReportsDataSource);
          break;
        case 'system':
          gridApiRef.current.setServerSideDatasource(systemReportsDataSource);
          break;
        case 'shared':
          gridApiRef.current.setServerSideDatasource(sharedReportsDataSource);
          break;
        default:
          gridApiRef.current.setServerSideDatasource(myReportsDataSource);
          break;
      }
    }
  }, [selectedLandingReportType]);

  useEffect(() => {
    (async () => {
      ReportService.updateReportFilterOption(selectedLandingReportType)
        .then(() => {
          if (isSSRNextGenEnabled && isNextGen) {
            window.appDatas.initApp['/selfservicereports'].userSettings.reportsFilterOption = selectedLandingReportType;
          }
          console.log(
            `/api/v1/user/filterOption/${selectedLandingReportType} API call is successful`
          );
        })
        .catch((error) => {
          console.error('Error while updating filter report type', error);
          throw error;
        });
    })();
    setUpdatedReportsFilterOption(selectedLandingReportType);
  }, [selectedLandingReportType]);

  const loadCurrentReport = (e: ISelectedReport) => {
    setSelectedReport({
      reportName: e.reportName,
      id: e.id,
      reportType: e.reportType,
      ownerUserId: e.ownerUserId,
      userId: e.userId,
      systemReportName: e.systemReportName,
      description: e.description,
    });
    history.push(`/selfservicereports/report/${e.id}`);
  };

  const reportSelectionArray = [
    {
      label: t('self_service_reports_all_reports', 'All reports'),
      value: 'all',
    },
    {
      label: t('self_service_reports_my_reports', 'My reports'),
      value: 'owned',
    },
    {
      label: t('self_service_reports_standard_report', 'Standard reports'),
      value: 'system',
    },
    {
      label: t('self_service_reports_shared_reports', 'Shared with me'),
      value: 'shared',
    },
  ];

  const isDomainAccessControlEnabled = launchDarklyToggles?.find(x => x.FeatureKey === "ssr-enable-domain-access-control")?.FeatureState;

  const reportSelection = (isCustomReportEditor && (isDomainAccessControlEnabled === 'False'))
    ? reportSelectionArray.filter(({ value }) => !(value === 'system'))
    : reportSelectionArray;

  const getPreloadedReportsData = (params: any): boolean => {
    if (isSSRNextGenEnabled && isNextGen && hasMountedRef.current && ssrInitAppData?.reportsList?.data) {
      const { data, totalRecords } = ssrInitAppData.reportsList;
      setTotalReports(totalRecords);
      if (totalRecords === 0) {
        setAreMyReportsEmpty(true);
      }
      params.successCallback(data, totalRecords);
      setLoading(false);
      hasMountedRef.current = false;
      return true;
    }
    return false;
  }

  const LabelRenderer = (option: any) => {
    return (
      <div>
        {t('self_service_reports_viewing', 'Viewing')}:{' '}
        <span style={{ fontWeight: 600 }}>{option.label}</span>
      </div>
    );
  };

  const renderOption = (reportTypeOptions) => {
    return (
      <div>
        <div className='trk_select_ssrs-reports_list-data_grid_toolbar-filter-option'>
          {reportTypeOptions.label}
        </div>
      </div>
    );
  };

  const getMyReportsData = async (skip, take, sortModel, searchTerm) => {
    let orderField = null;
    let orderBy = null;
    if (sortModel && sortModel.length > 0) {
      orderField = sortModel[0].colId;
      orderBy = sortModel[0].sort;
    }
    const response: any = await ReportService.getReports(
      skip,
      take,
      'owned',
      searchTerm,
      orderField,
      orderBy
    );
    return response;
  };

  const sharedReportsDataSource = {
    rowCount: undefined,
    getRows: (params) => {
      const { request } = params;
      const { startRow, endRow, sortModel, filterModel } = request;
      // If sortModel is provided, update local storage using the utility function
      handleColumnSortUpdate(sortModel);
      const { reportName: searchTerm } = filterModel;
      setSearchTerm(searchTerm);
      setLoading(true);
      if (getPreloadedReportsData(params)) {
        return;
      }
      getSharedReportsData(startRow, endRow - startRow, sortModel, searchTerm)
        .then(({ data, totalRecords }) => {
          setTotalReports(totalRecords);
          params.successCallback(data, totalRecords);
          if (isSSRNextGenEnabled && isNextGen) {
            window.appDatas.initApp['/selfservicereports'].reportsList = { data, skip: startRow, take: endRow - startRow, totalRecords };
            if (sortModel && sortModel.length > 0) {
              window.appDatas.initApp['/selfservicereports'].userSettings.orderField = sortModel[0].colId;
              window.appDatas.initApp['/selfservicereports'].userSettings.orderBy = sortModel[0].sort;
            }
          }
          setLoading(false);
        })
        .catch(params.fail);
    },
  };

  const getSharedReportsData = async (skip, take, sortModel, searchTerm) => {
    let orderField = null;
    let orderBy = null;
    if (sortModel && sortModel.length > 0) {
      orderField = sortModel[0].colId;
      orderBy = sortModel[0].sort;
    }
    const response: any = await ReportService.getReports(
      skip,
      take,
      'shared',
      searchTerm,
      orderField,
      orderBy
    );
    return response;
  };

  const myReportsDataSource = {
    rowCount: undefined,
    getRows: (params) => {
      const { request } = params;
      const { startRow, endRow, sortModel, filterModel } = request;
      // If sortModel is provided, update local storage using the utility function
      handleColumnSortUpdate(sortModel);
      const { reportName: searchTerm } = filterModel;
      setSearchTerm(searchTerm);
      setLoading(true);
      if (getPreloadedReportsData(params)) {
        return;
      }
      getMyReportsData(startRow, endRow - startRow, sortModel, searchTerm)
        .then(({ data, totalRecords }) => {
          setTotalReports(totalRecords);
          if (totalRecords === 0) {
            setAreMyReportsEmpty(true);
          }
          params.successCallback(data, totalRecords);
          if (isSSRNextGenEnabled && isNextGen) {
            window.appDatas.initApp['/selfservicereports'].reportsList = { data, skip: startRow, take: endRow - startRow, totalRecords };
            if (sortModel && sortModel.length > 0) {
              window.appDatas.initApp['/selfservicereports'].userSettings.orderField = sortModel[0].colId;
              window.appDatas.initApp['/selfservicereports'].userSettings.orderBy = sortModel[0].sort;
            }
          }
          setLoading(false);
        })
        .catch(params.fail);
    },
  };

  const getAllSystemReportsData = async (skip, take, sortModel, searchTerm) => {
    let orderField = "";
    let orderBy = "";
    if (sortModel && sortModel.length > 0) {
      orderField = sortModel[0].colId;
      orderBy = sortModel[0].sort;
    }
    const response: any = await ReportService.getReports(
      skip,
      take,
      'system',
      searchTerm,
      orderField,
      orderBy
    );
    return response;
  };

  const systemReportsDataSource = {
    rowCount: undefined,
    getRows: (params) => {
      const { request } = params;
      const { startRow, endRow, sortModel, filterModel } = request;
      // If sortModel is provided, update local storage using the utility function
      handleColumnSortUpdate(sortModel);
      const { reportName: searchTerm } = filterModel;
      setSearchTerm(searchTerm);
      setLoading(true);
      if (getPreloadedReportsData(params)) {
        return;
      }
      getAllSystemReportsData(
        startRow,
        endRow - startRow,
        sortModel,
        searchTerm
      )
        .then(({ data, totalRecords }) => {
          const updatedData = data.map((report: any) => {
            report.systemReportName = report.reportName;
            return report;
          });
          setTotalReports(totalRecords);
          params.successCallback(updatedData, totalRecords);
          if (isSSRNextGenEnabled && isNextGen) {
            window.appDatas.initApp['/selfservicereports'].reportsList = { data: updatedData, skip: startRow, take: endRow - startRow, totalRecords };
            if (sortModel && sortModel.length > 0) {
              window.appDatas.initApp['/selfservicereports'].userSettings.orderField = sortModel[0].colId;
              window.appDatas.initApp['/selfservicereports'].userSettings.orderBy = sortModel[0].sort;
            }
          }
          setLoading(false);
        })
        .catch(params.fail);
    },
  };

  const getAllReportsData = async (skip, take, sortModel, searchTerm) => {
    let orderField = null;
    let orderBy = null;
    if (sortModel && sortModel.length > 0) {
      orderField = sortModel[0].colId;
      orderBy = sortModel[0].sort;
    }
    const response: any = await ReportService.getReports(
      skip,
      take,
      'all',
      searchTerm,
      orderField,
      orderBy
    );
    return response;
  };

  const allReportsDataSource = {
    rowCount: undefined,
    getRows: (params) => {
      const { request } = params;
      const { startRow, endRow, sortModel, filterModel } = request;
      // If sortModel is provided, update local storage using the utility function
      handleColumnSortUpdate(sortModel);
      const { reportName: searchTerm } = filterModel;
      setSearchTerm(searchTerm);
      setLoading(true);
      if (getPreloadedReportsData(params)) {
        return;
      }
      getAllReportsData(startRow, endRow - startRow, sortModel, searchTerm)
        .then(({ data, totalRecords }) => {
          setTotalReports(totalRecords);
          const updatedData = data.map((report: any) => {
            if (report.reportType.toLowerCase() === 'system') {
              report.systemReportName = report.reportName;
            }
            return report;
          });
          params.successCallback(updatedData, totalRecords);
          if (isSSRNextGenEnabled && isNextGen) {
            window.appDatas.initApp['/selfservicereports'].reportsList = { data: updatedData, skip: startRow, take: endRow - startRow, totalRecords };
            if (sortModel && sortModel.length > 0) {
              window.appDatas.initApp['/selfservicereports'].userSettings.orderField = sortModel[0].colId;
              window.appDatas.initApp['/selfservicereports'].userSettings.orderBy = sortModel[0].sort;
            }
          }
          setLoading(false);
        })
        .catch(params.fail);
    },
  };

  const deleteReport = async (rowData: any) => {
    setDeleteCustomReport({
      showModal: true,
      reportName: rowData?.reportName,
      reportId: rowData?.id,
    });
  };

  const quickActions = (params: any) => {
    if (
      params?.rowData?.reportType?.toLowerCase() === 'system' ||
      params?.rowData?.ownerUserId != UserId
    ) {
      return { primary: [] };
    }
    return {
      primary: [
        {
          label: t('self_service_reports_delete', 'Delete'),
          icon: <IconDelete size={16} className='delete-icon' />,
          children: (
            <div className='delete-container'>
              <IconDelete size={16} className='delete-icon' />
              <span>{t('self_service_reports_delete', 'Delete')}</span>
            </div>
          ),
          onClick: () => deleteReport(params.rowData),
        },
      ],
    };
  };
  const getColDefs = () => {
    // Get sort info from local storage first
    const storage = getReportLandingPageStorage();
    const storedSortField = orderField || storage.columnSortBy;
    const storedSortOrder = orderBy || storage.columnSortOrder;

    // Define column filters based on the report type
    let columnDefs: any[] = [];

    if (selectedLandingReportType === 'owned') {
      columnDefs = reportsColumnDefs.filter((col) => col.field !== 'sharedOn');
    } else if (selectedLandingReportType === 'system') {
      columnDefs = reportsColumnDefs.filter(
        (col) => col.field !== 'ownerUserName' && col.field !== 'sharedOn'
      );
    } else if (selectedLandingReportType === 'all') {
      columnDefs = reportsColumnDefs.filter((col) => col.field !== 'sharedOn');
    } else {
      // shared
      columnDefs = reportsColumnDefs;
    }

    // Check if report type has changed since last render
    const reportTypeChanged = previousReportTypeRef.current !== null &&
      previousReportTypeRef.current !== selectedLandingReportType;

    // Update the ref with current report type for next comparison
    previousReportTypeRef.current = selectedLandingReportType;

    // Check if storedSortField exists and is present in current columnDefs
    const sortFieldExists = storedSortField &&
      columnDefs.some((col) => col.field === storedSortField);

    // If report type didn't change and we have valid stored sort, use stored sort
    if (!reportTypeChanged && sortFieldExists && storedSortOrder) {
      return columnDefs.map((col) =>
        col.field === storedSortField
          ? { ...col, initialSort: storedSortOrder }
          : col
      );
    }
    // Use default sorting when report type changed or no valid stored sort
    else {
      // Determine default sort field based on report type
      let defaultSortField: string;

      switch (selectedLandingReportType) {
        case 'shared':
          defaultSortField = 'sharedOn';
          break;
        case 'all':
        case 'owned':
          defaultSortField = 'lastUpdated';
          break;
        case 'system':
          defaultSortField = 'lastViewed';
          break;
        default:
          defaultSortField = 'lastViewed';
          break;
      }

      // Update stored sort when report type changes
      if (reportTypeChanged) {
        updateReportLandingPageStorage({
          columnSortBy: defaultSortField,
          columnSortOrder: 'desc'
        });
        if (isSSRNextGenEnabled && isNextGen) {
          window.appDatas.initApp['/selfservicereports'].userSettings.orderField = defaultSortField;
          window.appDatas.initApp['/selfservicereports'].userSettings.orderBy = 'desc';
        }
      }

      return columnDefs.map((col) =>
        col.field === defaultSortField ? { ...col, initialSort: 'desc' } : col
      );
    }
  };

  const handleKeyDown = (e: {
    event: { key: string };
    colDef: { field: string };
    data: {
      reportName: any;
      id: any;
      reportType: any;
      ownerUserId: any;
      userId: any;
      systemReportName: any;
      description: any;
    };
  }) => {
    if (e.event.key === 'Enter' && e.colDef.field !== 'quickActions') {
      setSelectedReport({
        reportName: e.data.reportName,
        id: e.data.id,
        reportType: e.data.reportType,
        ownerUserId: e.data.ownerUserId,
        userId: e.data.userId,
        systemReportName: e.data.systemReportName,
        description: e.data.description,
      });
      history.push(`/selfservicereports/report/${e.data.id}`);
    }
  };

  const getRowClass = (params: any) => {
    return `trk_button_ssrs-reports_list-btn_open_report`;
  };

  const noRowsOverlayContent = useMemo(() => {
    const contactAdminMsg = t(
      'self_service_reports_contact_admin_for_access',
      'Due to your current data access settings, you don’t have adequate permissions to view any standard reports. Please contact your administrator to update access.'
    );

    const descriptions: Record<string, string> = {
      [LANDING_PAGE_REPORT_TYPE.all]: contactAdminMsg,
      [LANDING_PAGE_REPORT_TYPE.system]: contactAdminMsg,
      [LANDING_PAGE_REPORT_TYPE.shared]: t(
        'self_service_reports_no_shared_reports_description',
        'No reports are shared with you.'
      ),
      [LANDING_PAGE_REPORT_TYPE.owned]: t(
        'self_service_reports_no_owned_reports_description',
        'You have not created any reports.'
      ),
      default: contactAdminMsg,
    };

    const noDataDescription =
      descriptions[selectedLandingReportType as string] ?? descriptions.default;

    return {
      noDataTitle: t(
        'self_service_reports_no_reports_available',
        'No Reports Available'
      ),
      noDataDescription,
      noMatchesTitle: t(
        'self_service_reports_no_search_results_title',
        'No search results'
      ),
      noMatchesDescription: t(
        'self_service_reports_no_search_results_description_message',
        'We couldn’t find anything matching your search query'
      ),
    };
  }, [t, selectedLandingReportType]);

  return (
    <div className='report-list-container'>
      <ErrorBoundary>
        <AsyncDataGrid
          tooltipShowDelay={0}
          getRowClass={getRowClass}
          className={loading ? 'skeleton sk-table' : ''}
          onGridReady={(e: any) => {
            gridApiRef.current = e.api;
          }}
          hideColumnSelector
          hideSortingSelector
          noRowsOverlayContent={noRowsOverlayContent}
          {...(showQuickActions && { quickActions: quickActions })}
          toolbarAuxControls={
            (isEditor || isCustomReportEditor) && (
              <div
                id='report-list-filters-container'
                className='report-list-filters-container'
              >
                <Select
                  options={reportSelection}
                  renderOption={(option) => renderOption(option)}
                  value={selectedLandingReportType}
                  renderLabel={LabelRenderer}
                  onChange={(opt: any) =>
                    setSelectedLandingReportType(opt.value)
                  }
                  aria-label={t(
                    'self_service_reports_select_report_type',
                    'Select report type'
                  )}
                  aria-labelledby='report-list-filters-container'
                  className={`trk_select_ssrs-reports_list-data_grid_toolbar-filter`}
                  data-testid='filter-dropdown'
                />
                <div className='report-list-count'>{`${totalReports.toLocaleString(
                  languageCode
                )} ${t('self_service_reports_items', 'Items')}`}</div>
              </div>
            )
          }
          filterValues={{ reportName: searchTextParam || searchTerm || '' }}
          onFilterChanged={(values) => {
            const newSearchTerm = values.reportName || '';
            setSearchTerm(newSearchTerm);
          }}
          filterDefs={{
            reportName: {
              quickFilter: true,
              control: {
                placeholder: t(
                  'self_service_reports_search_report_v1',
                  'Search for reports'
                ),
              },
              className:
                'trk_input_ssrs-reports_list-data_grid_toolbar-search_reports',
            },
          }}
          columnDefs={(() => {
            const unorderedColDefs = getColDefs();
            const storage = getReportLandingPageStorage();

            // If column order exists in local storage, reorder columns accordingly
            if (storage.columnOrder) {
              try {
                const savedOrder = JSON.parse(storage.columnOrder);
                if (Array.isArray(savedOrder) && savedOrder.length > 0) {
                  // Create a map of field to column definition for quick lookup
                  const colDefMap = unorderedColDefs.reduce((map, colDef) => {
                    map[colDef.field] = colDef;
                    return map;
                  }, {});

                  // Create a new array in the saved order
                  const orderedCols = savedOrder
                    .map((fieldId) => colDefMap[fieldId])
                    .filter(Boolean); // Remove undefined columns (in case of stale storage)

                  // Add any columns that aren't in the saved order at the end
                  const orderedFieldIds = new Set(savedOrder);
                  const remainingCols = unorderedColDefs.filter(
                    (col) => !orderedFieldIds.has(col.field)
                  );

                  return [...orderedCols, ...remainingCols];
                }
              } catch (e) {
                console.error(
                  'Error parsing column order from local storage:',
                  e
                );
              }
            }

            // Fall back to default ordering if local storage order is unavailable
            return unorderedColDefs;
          })()}
          columnTypes={columnTypes}
          components={{
            NameCell,
            OwnerCell,
            DateCell,
            DateTimeCell,
            DescriptionCell,
          }}
          serverSideDatasource={
            selectedLandingReportType === 'owned'
              ? myReportsDataSource
              : selectedLandingReportType === 'system'
                ? systemReportsDataSource
                : selectedLandingReportType === 'shared'
                  ? sharedReportsDataSource
                  : allReportsDataSource
          }
          showNoRowsOverlayOnEmpty
          onItemClicked={loadCurrentReport}
          onCellKeyDown={handleKeyDown}
          defaultColDef={{ sortable: true }}
          rowSelection='single'
          rowModelType='infinite'
          cacheBlockSize={FIXEDREPORTLISTPAGESIZE}
          context={searchTerm}
          onColumnMoved={(e) => {
            const allColumnIds = e.columnApi?.columnModel?.displayedColumns
              ?.map((column) => column.colId)
              // Filter out specific columns that should be excluded from the saved order
              ?.filter((colId) => {
                // Exclude action columns or any other special columns you don't want to save
                const columnsToExclude = ['quickActions'];
                return !columnsToExclude.includes(colId);
              });

            // Save to local storage
            updateReportLandingPageStorage({
              columnOrder: JSON.stringify(allColumnIds),
            });
          }}
          theme={seismicTheme({
            useGlobal: true,
            defaultPortalContainerSelector: '.mntl-portals',
            localization: {
              languageCode: languageCode as LanguageCode,
              translations: mantleTranslations,
            },
          })}
        />
        <div id='portals' />
        {deleteCustomReport?.showModal && (
          <DeleteCustomReport
            deleteCustomReport={deleteCustomReport.showModal}
            setDeleteCustomReport={(value: boolean) =>
              setDeleteCustomReport({ ...deleteCustomReport, showModal: value })
            }
            customReportTitle={deleteCustomReport?.reportName}
            reportId={deleteCustomReport?.reportId}
            onDeleted={() => gridApiRef?.current?.refreshServerSide()}
          />
        )}
      </ErrorBoundary>
    </div>
  );
};
