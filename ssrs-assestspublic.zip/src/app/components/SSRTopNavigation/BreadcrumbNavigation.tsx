import React, { useContext } from 'react';
import {
  Breadcrumb,
  BreadcrumbItem,
  Button,
  IconArrowBack,
  Tooltip,
} from '@seismic/mantle';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  AllReportsLandingPageContext,
  CompileReportContext,
  ReportDataContext,
} from '../../../contexts';
import LeaveWithoutSaveModal from '../common/LeaveWithoutSaveModal/LeaveWithoutSaveModal';
import { useAccessLevel, useLaunchDarkly } from '../../../contexts/CommonServicesContext';
import { CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, EDITOR_ACCESS_LEVEL } from '../../../utils/constants';
import { checkSSRNextGenEnabled } from '../../../utils/ssrPreloadDataUtils';
import { navigateToUrl } from '../../../utils/navigationUtils';

interface BreadcrumbNavigationProps {
  onSave: (closeAfterSave: boolean, isSaveCopyClicked: boolean) => void;
  onSaveCopy: () => void;
}

const BreadcrumbNavigation: React.FC<BreadcrumbNavigationProps> = ({ onSave, onSaveCopy }) => {
  const history = useHistory();
  const { t } = useTranslation();

  const { setSelectedReport, setReportMetadata } =
    useContext(ReportDataContext);

  const { setHideEditButtonOnError, currentScreen } = useContext(
    AllReportsLandingPageContext
  );
  const accessLevel = useAccessLevel();
  const isEditor = accessLevel == EDITOR_ACCESS_LEVEL;
  const isCustomReportEditor = accessLevel == CUSTOM_REPORT_EDITOR_ACCESS_LEVEL;

  const { showLeaveWithoutSaveModal, setShowLeaveWithoutSaveModal, isChanged } =
    useContext(CompileReportContext);

  const goToReportsList = () => {
    setSelectedReport({});
    setReportMetadata({});
    setHideEditButtonOnError(false);
    history.push('/selfservicereports');
  };

  const handleBackClick = () => {
    if (isChanged && (isEditor || isCustomReportEditor)) {
      setShowLeaveWithoutSaveModal(true);
    } else {
      goToReportsList();
    }
  };

  const launchDarklyToggles = useLaunchDarkly();
  const isSSRNextGenEnabled = checkSSRNextGenEnabled(launchDarklyToggles);

  return (
    <div className='ssrs-navigation-left'>
      <Tooltip
        content={t(
          'self_service_reports_back',
          'Back'
        )}
        zIndex={10000}
        size='sm'
      >
        <Button
          label={t('self_service_reports_back', 'Back')}
          hideLabel
          variant='tertiary'
          onClick={() => {
            if (currentScreen === 'EDIT_REPORT') {
              handleBackClick();
            } else {
              navigateToUrl('/insights', isSSRNextGenEnabled) ? null : history.push('/insights');
            }
          }}
          startAdornment={IconArrowBack}
          className='trk_button_ssrs-reports_list-goto_previous_page'
          data-atmt-id='seismic.self-service-reports.breadcum.go-back'
        />
      </Tooltip>

      <Breadcrumb
        placeholder={undefined}
        onPointerEnterCapture={undefined}
        onPointerLeaveCapture={undefined}
      >
        <BreadcrumbItem
          className='trk_link_ssrs-reports_list-goto_insights'
          data-atmt-id='seismic.self-service-reports.breadcum.go-to-insights'
          label={t('self_service_reports_breadcrum_insights', 'Insights')}
          onClick={() => {
            if (currentScreen === 'EDIT_REPORT') {
              handleBackClick();
            } else {
              navigateToUrl('/insights', isSSRNextGenEnabled) ? null : history.push('/insights');
            }
          }}
        />
        <BreadcrumbItem
          className='trk_link_ssrs-reports_list-open_reports_list'
          data-atmt-id='seismic.self-service-reports.breadcum.go-to-reports-list'
          label={<h1>{t(
            'self_service_reports_breadcrum_self_service_reports',
            'Self-service reports'
          )}</h1>}
          onClick={() => {
            handleBackClick();
          }}
        />
      </Breadcrumb>
      {showLeaveWithoutSaveModal && isChanged && (
        <LeaveWithoutSaveModal onSave={onSave} onSaveCopy={onSaveCopy} goToReportsList={goToReportsList} />
      )}
    </div>
  );
};

export default BreadcrumbNavigation;
