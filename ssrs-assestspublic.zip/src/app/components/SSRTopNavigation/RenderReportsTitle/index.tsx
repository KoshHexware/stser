import { useContext, useEffect, useState } from 'react';
import './RenderReportsTitle.scss';
import { CompileReportContext, ReportDataContext } from '../../../../contexts';
import {
  IconHost,
  ActivateToEdit,
  Input,
  Textarea,
  useToasts,
  Tooltip,
} from '@seismic/mantle';
import { FullScreenLoading } from '../../common/FullScreenLoading';
import { useTranslation } from 'react-i18next';
import SystemReportNameLabel from '../SystemReportNameLabel';
import { useApplicationInfo } from '../../../../contexts/CommonServicesContext';
import ReportService from '../../../../services/ReportService';
import { isEmpty } from 'lodash';
import { ReportNameError, validateReportName } from '../../../../utils/reportNameValidator';
import { formatNewLines } from '../../../../utils/formatNewLines';

export const RenderReportsTitle = () => {
  const { selectedReport } = useContext(ReportDataContext);
  const
    {
      ownerUserId,
      updatedReportName,
      updatedDescription,
      allReportsSummary,
      setUpdatedReportName,
      setUpdatedDescription,
      setShouldFetchOwnedReports

    } = useContext(CompileReportContext);
  const { t } = useTranslation();
  const {
    User: { UserId },
  } = useApplicationInfo();
  const isOwner =
    selectedReport?.ownerUserId === UserId || ownerUserId === UserId;

  const [localReportName, setLocalReportName] = useState(updatedReportName || selectedReport?.reportName);
  const [localReportDescription, setLocalReportDescription] = useState(updatedDescription || selectedReport?.description);
  const [isEditingReportName, setIsEditingReportName] = useState<boolean>(false);
  const { addToast } = useToasts();

  useEffect(() => {
    setUpdatedReportName(localReportName.trim() || selectedReport?.reportName);
  }, [localReportName, selectedReport]);

  useEffect(() => {
    if (localReportDescription) {
      setUpdatedDescription(localReportDescription.trim() || selectedReport?.description);
    }
  }, [localReportDescription, selectedReport]);

  useEffect(() => {
    if (selectedReport?.reportName) {
      setLocalReportName(selectedReport.reportName);
    }
    if (selectedReport?.description) {
      setLocalReportDescription(selectedReport.description);
    }
  }, [selectedReport]);

  const editReportNameHandler = (reportName: string) => {
    if (reportName != localReportName) {
      setUpdatedReportName(reportName.trim());
      setIsEditingReportName(false);
      ReportService.updateReportName(selectedReport?.id, reportName)
        .then(() => {
          addToast({
            content: t(
              'self_service_reports_report_name_change_toast_content_success',
              'Report name updated successfully.'
            ),
            variant: 'success',
          });
          setLocalReportName(reportName);
          setShouldFetchOwnedReports(true);
        })
        .catch((error) => {
          setUpdatedReportName(localReportName)
          if (error && error.title && error.title.includes('already exists in your reports. Please select an alternative name.')) {
            addToast({
              content: t(
                'self_service_reports_report_name_change_toast_content_custom_report_exists_error',
                {
                  reportName: reportName,
                  defaultValue: `"${reportName}" already exists in your reports. Please select an alternative name.`,
                }
              ),
              variant: 'error',
            });

          } else if (error && error.title && error.title.includes('is a Standard report name. Please select an alternative name.')) {
            addToast({
              content: t(
                'self_service_reports_report_name_change_toast_content_system_report_exists_error',
                {
                  reportName: reportName,
                  defaultValue: `"${reportName}" is a Standard report name. Please select an alternative name.`,
                }
              ),
              variant: 'error',
            });
          }
          else {
            addToast({
              content: t(
                'self_service_reports_report_name_and_description_change_toast_content_error',
                'Something went wrong. Please try again later.'
              ),
              variant: 'error',
            });
          }
        });
    }
  };

  const editReportDescriptionHandler = (reportDescription: string) => {
    if (reportDescription != localReportDescription) {
      setUpdatedDescription(reportDescription.trim());
      ReportService.updateReportDescription(
        selectedReport?.id,
        reportDescription
      )
        .then(() => {
          addToast({
            content: t(
              'self_service_reports_report_description_change_toast_content_success',
              'Report description updated successfully.'
            ),
            variant: 'success',
          });
          setLocalReportDescription(reportDescription);
        })
        .catch((error) => {
          setUpdatedDescription(localReportDescription);
          addToast({
            content: t(
              'self_service_reports_component_failure_description',
              'Something went wrong. Please try again later.'
            ),
            variant: 'error',
          });
        });
    }
  };

  const onValidateReportName = (state: string) => {
    const inputReportName = state.trim();

    // If the report name hasn't changed, no validation is needed
    if (inputReportName?.trim() === updatedReportName?.trim()) {
      return undefined;
    }

    const err = validateReportName(inputReportName, allReportsSummary);

    if (err === ReportNameError.CONTAINS_SPECIAL_CHARACTERS || err === ReportNameError.MAX_LENGTH_EXCEEDED) {
      return {
        message: t("self_service_reports_invalid_characters_error_message", "The report name should have less than 100 characters and may contain only text, number or special characters like \"_\", \"-\", \"(\" and \")\".")
      };
    }

    if (err === ReportNameError.EMPTY_OR_WHITESPACE) {
      return {
        message: t("self_service_reports_name_cannot_be_empty", "Name can not be empty")
      };
    }
    if (err === ReportNameError.VIOLATES_CUSTOM_REPORTS_UNIQUENESS) {
      return {
        message: t(
          'self_service_reports_report_name_change_toast_content_custom_report_exists_error',
          {
            reportName: inputReportName,
            defaultValue: `"${inputReportName}" already exists in your reports. Please select an alternative name.`,
          }
        ),
      };
    }
    if (err === ReportNameError.VIOLATES_SYSTEM_REPORTS_UNIQUENESS) {
      return {
        message: t(
          'self_service_reports_report_name_change_toast_content_system_report_exists_error',
          {
            reportName: inputReportName,
            defaultValue: `"${inputReportName}" is a Standard report name. Please select an alternative name.`,
          }
        ),
      };
    }

    return undefined;
  };

  const onValidateReportDescription = (state) => {
    if (state.trim().length == 0) {
      return {
        message: t(
          'self_service_reports_description_cannot_be_empty',
          'Description can not be empty'
        ),
      };
    } else if (state.trim().length > 500) {
      return {
        message: t(
          'self_service_reports_description_cannot_exceed_500_characters',
          'Description can not be more than 500 characters'
        ),
      };
    }

    return undefined;
  };

  return (
    <>
      {selectedReport?.id && selectedReport?.reportName ? (
        <div className='render-reports-title'>
          <div className='render-report-icon'>
            <IconHost
              category='content-icons-v2'
              params={{
                format:
                  selectedReport?.reportType === 'Custom'
                    ? 'custom-report'
                    : 'standard-report',
              }}
              size={32}
            />
          </div>
          <div className='ssr-top-navigation-title-wrapper'>
            <div
              className='ssr-top-navigation-title-div'
              style={{ display: isEditingReportName ? 'block' : 'flex' }}
            >
              <ActivateToEdit
                value={updatedReportName || localReportName}
                readOnly={!isOwner}
                readView={
                  <div className='ssr-top-navigation-title'>
                    <h2 tabIndex={0} aria-label={localReportName} className='ssr-top-navigation-title-report-name'>
                      {updatedReportName || localReportName}
                    </h2>
                  </div>
                }
                writeView={({
                  state,
                  setState,
                  focusRef,
                  validationResponse,
                }) => {
                  setIsEditingReportName(true);
                  return (
                    <div className='ssr-top-navigation-title-edit'>
                      <Input
                        className='h3 ssr-top-navigation-title-edit-input'
                        ref={focusRef}
                        value={state}
                        maxLength={100}
                        onChange={(event) => setState(event.target.value)}
                        size={48}
                        error={!!validationResponse}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                          }
                        }}
                        data-testid='report-name-input'
                        aria-label={t('self_service_reports_custom_report_name', 'Custom report name')}
                      />
                    </div>
                  );
                }}
                onValidate={onValidateReportName}
                onConfirm={(state) => editReportNameHandler(state.trim())}
                onCancel={() => setIsEditingReportName(false)}
                onBlur={() => {
                  setIsEditingReportName(false);
                }}
              />
              {!isEditingReportName && <SystemReportNameLabel />}
            </div>
            <div className='render-reports-title-description-wrapper'>
              <ActivateToEdit
                value={updatedDescription || localReportDescription}
                readOnly={!isOwner}
                readView={
                  <Tooltip
                    content={formatNewLines(updatedDescription || localReportDescription)}
                    position='bottom'
                    variant='light'
                    size='lg'
                    interactive={true}
                    interactiveDelay={100}
                    zIndex={10000011}
                    className='render-reports-title-definition-tooltip'
                  >
                    <div
                      tabIndex={0}
                      className='render-reports-title-description'
                      aria-label={localReportDescription}
                    >
                      {updatedDescription || localReportDescription}
                    </div>
                  </Tooltip>
                }
                writeView={({ state, setState, focusRef, validationResponse }) => {
                  return (
                    <div
                      tabIndex={0}
                      className='render-reports-title-description-edit'
                      aria-label={localReportDescription}
                      style={{ position: 'relative' }}
                    >
                      <Textarea
                        className='render-reports-title-description-edit-input'
                        ref={focusRef}
                        value={state}
                        onChange={(event) => setState(event.target.value)}
                        maxLength={500}
                        rows={3}
                        error={!!validationResponse}
                        data-testid='report-description-input'
                        aria-label={t('self_service_reports_custom_report_description', 'Custom report description')}
                      />
                      <div style={{
                        display: 'flex',
                        justifyContent: 'flex-end',
                        fontSize: 12,
                        color: state.length > 500 ? '#d32f2f' : '#888',
                      }}>
                        {state.length} / 500
                      </div>
                    </div>
                  );
                }}
                onValidate={onValidateReportDescription}
                onConfirm={(state) => editReportDescriptionHandler(state)}
              />
            </div>
          </div>
        </div>
      ) : (
        <FullScreenLoading loading={true} />
      )}
    </>
  );
};
