import React, { useContext } from 'react';
import './SystemReportNameLabel.scss';
import { ReportDataContext } from '../../../contexts';
import { IconHost } from '@seismic/mantle';

const SystemReportNameLabel = () => {
  const { selectedReport } = useContext(ReportDataContext);
  return (
    <>
      {selectedReport?.reportType === 'Custom' && (
        <div className='ssr-top-navigation-report-title-div  mntl-modal-header-mid'>
          <div className='ssr-top-navigation-report-title'>
            <IconHost
              category='content-icons-v2'
              params={{ format: 'standard-report' }}
              size={16}
              style={{ marginRight: 8, marginBottom: 2 }}
            />
            <span> {selectedReport?.systemReportName} </span>
          </div>
        </div>
      )}
    </>
  );
};

export default SystemReportNameLabel;
