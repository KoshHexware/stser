import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useCallback,
} from 'react';
import './SystemReportHeader.scss';
import { Button, Tooltip, IconCopy, IconUpdate } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { IReportStatusType } from '../../../../interfaces/IReport';
import { CompileReportContext } from '../../../../contexts';
import ExportReport from '../../Export';
import { AllReportsLandingPageContext } from '../../../../contexts';
import { useAccessLevel } from '../../../../contexts/CommonServicesContext';
import { EDITOR_ACCESS_LEVEL, VIEWER_ACCESS_LEVEL } from '../../../../utils/constants';

const SystemReportHeader = ({ onSaveCopy, onReset, hideLabel = false }) => {
  const { isChanged, updatedFields } = useContext(CompileReportContext);
  const { setEnableSaveCopy  } = useContext(AllReportsLandingPageContext);
  const { t } = useTranslation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [isReportTitleEditable, setIsReportTitleEditable] = useState(false);
  const [reportStatus, setReportStatus] = useState<IReportStatusType>(
    IReportStatusType.NOT_MADE_CHANGES
  );
  const { enableSaveCopy } = useContext(AllReportsLandingPageContext);
  const accessLevel = useAccessLevel();

  // Memoize the handler to prevent recreating it on each render
  const handleClickOutside = useCallback((event: MouseEvent) => {
    if (inputRef.current && !inputRef.current.contains(event.target as Node)) {
      setIsReportTitleEditable(false);
    }
  }, []);

  useEffect(() => {
    // Update status when isChanged changes
    setReportStatus(
      isChanged
        ? IReportStatusType.UNSAVED_CHANGES
        : IReportStatusType.NOT_MADE_CHANGES
    );
  }, [isChanged]);

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [handleClickOutside]);

  useEffect(() => {
    if (isReportTitleEditable && inputRef?.current) {
      inputRef.current.focus();
    }
  }, [isReportTitleEditable]);

  const isSaveDisabled = !updatedFields?.length;

  const renderSaveCopyButton = (disabled = isSaveDisabled) => {
    return (
      <>
      {accessLevel.toLowerCase() !== VIEWER_ACCESS_LEVEL ? 
        <Tooltip
          content={t('self_service_reports_save_copy_tooltip', 'Save copy')}
          zIndex={10000}
          size='lg'
        >
          <Button
            startAdornment={IconCopy}
            className='ssrs-view-report-save-copy trk_button_ssrs-report_analyze_standard_open_save_as_copy_modal'
            label={t('self_service_reports_save_copy', 'Save copy')}
            hideLabel={hideLabel}
            variant={hideLabel ? 'tertiary' : 'primary'}
            onClick={onSaveCopy}
            disabled={disabled}
          />
        </Tooltip>
      : null
      }
    </>
    );
  };

  return (
    <div className='ssrs-system-report-header'>
      <ExportReport hideLabel={true} />
      <div className='ssrs-system-report-header-container'>
        
          {reportStatus === IReportStatusType.UNSAVED_CHANGES && accessLevel.toLowerCase() !== VIEWER_ACCESS_LEVEL ? (
          <>
            <Button
              label={t('self_service_reports_reset_changes', 'Reset changes')}
              className='ssrs-system-report-header-container-reset-button trk_button_ssrs-report_analyze_standard_open_reset_changes_modal'
              data-atmt-id='seismic.self-service-reports.edit-report.reset-changes'
              onClick={() => { onReset(); setEnableSaveCopy(false); }}
            />
            {renderSaveCopyButton()}
          </>
        ) : (
          <>{renderSaveCopyButton(!enableSaveCopy)}</>
        )}
      </div>
    </div>
  );
};

export default React.memo(SystemReportHeader);
