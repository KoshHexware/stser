import { useContext, useEffect, useState } from 'react';
import '../SSRTopNavigation.scss';
import './ViewReportTopNavigation.scss';
import {
  Button,
  IconDelete,
  IconShare,
  IconLink,
  Tooltip,
  Popover,
  IconMore,
  IconCopy,
} from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import {
  AllReportsLandingPageContext,
  ReportDataContext,
} from '../../../../contexts';
import { RenderReportsTitle } from '../RenderReportsTitle';
import {
  useApplicationInfo,
  useAccessLevel,
} from '../../../../contexts/CommonServicesContext';
import { DeleteCustomReport } from '../../DeleteCustomReport';
import CompileShareReports from '../../ShareReports/CompileShareReports';
import { copyUrl } from '../../../../utils/copyUrl';
import BreadcrumbNavigation from '../BreadcrumbNavigation';
import { CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, EDITOR_ACCESS_LEVEL, SSRS_REPORT_TYPE, VIEWER_ACCESS_LEVEL } from '../../../../utils/constants';
import ExportReport from '../../Export';
import SystemReportHeader from '../SystemReportHeader';
import CustomReportHeader from '../CustomReportHeader';

export const ViewReportTopNavigation = ({
  onSaveCopy,
  onReset,
  onSave,
  setIsSidePanelVisible,
}) => {
  const { setHideEditButtonOnError } = useContext(AllReportsLandingPageContext);

  const { isReportShared, setIsReportShared } = useContext(ReportDataContext);
  const {
    setSelectedReport,
    selectedReport,
    reportMetadata,
    setReportMetadata,
  } = useContext(ReportDataContext);
  const { t } = useTranslation();
  const [isReportOwner, setIsReportOwner] = useState(false);
  const [deleteCustomReport, setDeleteCustomReport] = useState(false);

  const copyLinkTooltipDefaultText = t(
    'self_service_reports_permission_copy_link',
    'Copy link'
  );

  const [copyLinkTooltipText, setCopyLinkTooltipText] = useState(
    copyLinkTooltipDefaultText
  );
  const history = useHistory();
  const applicationInfo = useApplicationInfo();
  const { UserId } = applicationInfo.User;
  const accessLevel = useAccessLevel();
  const isEditor = accessLevel == EDITOR_ACCESS_LEVEL;
  const isViewer = accessLevel == VIEWER_ACCESS_LEVEL;
  const isCustomReportEditor = accessLevel == CUSTOM_REPORT_EDITOR_ACCESS_LEVEL;

  const goToReportsList = () => {
    setSelectedReport({});
    setReportMetadata({});
    setHideEditButtonOnError(false);
    history.push('/selfservicereports');
  };

  useEffect(() => {
    if (!selectedReport?.id) setIsReportOwner(false);
  }, [selectedReport]);

  useEffect(() => {
    if (reportMetadata?.ownerUserId)
      setIsReportOwner(reportMetadata?.ownerUserId === UserId);
  }, [reportMetadata]);

  useEffect(() => {
    const intervalId = setTimeout(() => {
      setCopyLinkTooltipText(copyLinkTooltipDefaultText);
    }, 2000);

    return () => {
      clearInterval(intervalId);
    };
  }, [copyLinkTooltipText]);

  const onCopyClick = () => {
    try {
      // IE
      setCopyLinkTooltipText(
        t('self_service_reports_link_copied_to_clipboard', 'Link copied')
      );
      return copyUrl(selectedReport?.id);
    } catch (err) {
      console.error('Error copying link:', err);
      return false;
    }
  };

  const renderSaveCopyButton = (hideLabel) => (
    <Tooltip
      content={t(
        'self_service_reports_save_copy_tooltip',
        'Save copy'
      )}
      zIndex={10000}
      size='sm'
    >
      <Button
        startAdornment={IconCopy}
        className='ssrs-custom-report-header-save-copy trk_button_ssrs-report_view_custom_save_copy'
        label={t('self_service_reports_save_copy_tooltip', 'Save copy')}
        hideLabel={!hideLabel}
        onClick={onSaveCopy}
      />
    </Tooltip>
  );

  const renderShareReport = () => {
    return (
      <>
        <Tooltip
          content={t(
            'self_service_reports_share_reports_tooltip',
            'Share report'
          )}
          zIndex={10000}
          size='sm'
        >
          <Button
            startAdornment={IconShare}
            label={t('self_service_reports_share_report', 'Share')}
            onClick={() => setIsReportShared(true)}
            className='trk_button_ssrs-share-report'
          />
        </Tooltip>
      </>
    );
  };

  const renderReportLink = () => {
    return (
      <Tooltip content={copyLinkTooltipText} zIndex={10000} size='sm'>
        <Button
          startAdornment={IconLink}
          hideLabel
          label={copyLinkTooltipDefaultText}
          onClick={onCopyClick}
          className='trk_button_ssrs_copy_report'
        />
      </Tooltip>
    );
  };

  const renderDeleteReport = () => {
    return (
      <>
        {isReportOwner && (isEditor || isCustomReportEditor) && (
          <div>
            <Tooltip
              content={t('self_service_reports_delete_report', 'Delete report')}
              zIndex={10000}
              size='sm'
            >
              <Button
                startAdornment={IconDelete}
                // hideLabel
                label={t('self_service_reports_delete','Delete')}
                onClick={() => setDeleteCustomReport(true)}
                className='trk_button_ssrs-report_view_custom-delete_report ssrs-view-report-delete'
                data-atmt-id='seismic.self-service-reports.view-report.delete'
              />
            </Tooltip>
          </div>
        )}
        {deleteCustomReport && (
          <DeleteCustomReport
            deleteCustomReport={deleteCustomReport}
            setDeleteCustomReport={setDeleteCustomReport}
            customReportTitle={selectedReport?.reportName}
            reportId={selectedReport?.id}
            onDeleted={goToReportsList}
          />
        )}
      </>
    );
  };

  const renderSystemReporActions = () => {
    return <SystemReportHeader onSaveCopy={onSaveCopy} onReset={onReset} />;
  };

  return (
    <div className='ssrs-top-panel'>
      {/* for Breadcrumb and Buttons controls*/}
      <div className='ssrs-navigation'>
        <BreadcrumbNavigation onSave={onSave} onSaveCopy={onSaveCopy} />
        <div className='ssrs-navigation-right'>
          {selectedReport?.reportType === SSRS_REPORT_TYPE.SYSTEM &&
            renderSystemReporActions()}
          {(isEditor || isCustomReportEditor) &&
            isReportOwner &&
            selectedReport?.reportType === SSRS_REPORT_TYPE.CUSTOM && (
              <>
                {renderSaveCopyButton(false)}
                {renderReportLink()}
                {renderShareReport()}
                <CustomReportHeader
                  onSave={onSave}
                  onReset={onReset}
                  setIsSidePanelVisible={setIsSidePanelVisible}
                />
                <Popover
                  className='ssrs-view-report-popover'
                  popoverAriaLabel='More options'
                  content={
                    <div className='ssrs-view-report-popover-content'>
                      <ExportReport />
                      {renderDeleteReport()}
                    </div>
                  }
                  hideDismissButton
                  trigger={
                    <Button startAdornment={IconMore} hideLabel label='More' />
                  }
                />
              </>
            )}
          {(isEditor || isCustomReportEditor) &&
            !isReportOwner &&
            selectedReport?.reportType === SSRS_REPORT_TYPE.CUSTOM && (
              <>
                <ExportReport hideLabel={true} />
                <CustomReportHeader
                  onSave={onSave}
                  onReset={onReset}
                  hideLabel={!isReportOwner}
                />
                {renderSaveCopyButton(true)}
              </>
            )}
          {isViewer &&
            !isReportOwner &&
            selectedReport?.reportType === SSRS_REPORT_TYPE.CUSTOM && (
              <ExportReport />
            )}
          {isReportShared && <CompileShareReports />}
        </div>
      </div>
      <div className='ssrs-title'>
        <RenderReportsTitle />
      </div>
    </div>
  );
};

export default ViewReportTopNavigation;
