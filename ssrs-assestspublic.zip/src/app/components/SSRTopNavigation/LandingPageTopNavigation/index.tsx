import React,{ useContext, useState } from 'react';
import '../SSRTopNavigation.scss';
import { Button, IconAdd } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { NewReportModal } from '../../NewReportModal';
import { useAccessLevel } from '../../../../contexts/CommonServicesContext';
import BreadcrumbNavigation from '../BreadcrumbNavigation';
import { EDITOR_ACCESS_LEVEL } from '../../../../utils/constants';
import { AllReportsLandingPageContext } from '../../../../contexts';

export const LandingPageTopNavigation = () => {
  const { t } = useTranslation();
  const [showNewReportModal, setShowNewReportModal] = useState(false);
  const { areSystemReportsEnabled } = useContext(AllReportsLandingPageContext);
  const accessLevel = useAccessLevel();
  const isEditor = accessLevel == EDITOR_ACCESS_LEVEL;
  
  return (
    <div className='ssrs-top-panel'>
      {/* for Breadcrumb and Buttons controls*/}
      <div className='ssrs-navigation'>
        <BreadcrumbNavigation />
        <div className='ssrs-navigation-right'>
          {isEditor && (
            <Button
              className='ssrs-new-report-button trk_button_ssrs-reports_list-open_new_report_modal'
              data-atmt-id='seismic.self-service-reports.reports-list.create-new-report'
              label={t('self_service_reports_new_report_v1', 'New report')}
              variant='primary'
              startAdornment={IconAdd}
              onClick={() => setShowNewReportModal(true)}
              disabled={!areSystemReportsEnabled}
            />
          )}
          {showNewReportModal && (
            <NewReportModal
              showModal={showNewReportModal}
              setModalVisibility={() => setShowNewReportModal(false)}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default LandingPageTopNavigation;
