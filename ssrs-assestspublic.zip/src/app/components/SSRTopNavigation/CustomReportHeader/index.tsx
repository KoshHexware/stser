import { useContext, useEffect } from 'react';
import './CustomReportHeader.scss';
import {
  Button,
  IconSave,
  IconUpdate,
  Toasts,
  useToasts,
} from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import { IReportStatusType } from '../../../../interfaces/IReport';
import { useApplicationInfo } from '../../../../contexts/CommonServicesContext';
import { CompileReportContext, ReportDataContext } from '../../../../contexts';

// Define the component with proper TypeScript interfaces
interface CustomReportHeaderProps {
  onSave: (closeAfterSave: boolean, isSaveCopyClicked: boolean) => void;
  onReset: () => void;
  hideLabel?: boolean;
  setIsSidePanelVisible?: (isVisible: boolean) => void;
}

const CustomReportHeader = ({
  onSave,
  onReset,
  hideLabel = false,
  setIsSidePanelVisible,
}: CustomReportHeaderProps) => {
  const { ownerUserId, isChanged, isSaved, setShouldTriggerWithDefaultsAPI } = useContext(CompileReportContext);
  const { selectedReport, showReportSavedToast, setShowReportSavedToast } = useContext(ReportDataContext);
  const { t } = useTranslation();
  const { addToast } = useToasts();
  const {
    User: { UserId },
  } = useApplicationInfo();



  useEffect(() => {
    if (showReportSavedToast) {
      if (setIsSidePanelVisible) setIsSidePanelVisible(true);
      addToast({
        content: t(
          'self_service_reports_custom_report_saved',
          'Custom report has been saved'
        ),
        variant: 'success',
      });

      setTimeout(() => {
        setShowReportSavedToast(false);
      }, 2000);
    }
  }, [showReportSavedToast]);


  // Determine report status directly without state
  const reportStatus = isChanged
    ? IReportStatusType.UNSAVED_CHANGES
    : isSaved
      ? IReportStatusType.SAVED_CHANGES
      : IReportStatusType.NOT_MADE_CHANGES;

  // Check if user is owner to determine if save buttons should be shown
  const isOwner =
    selectedReport?.ownerUserId === UserId || ownerUserId === UserId;

  const handleOnSave = () => {
    onSave(false, false);
    setShouldTriggerWithDefaultsAPI(true);
  };

  // Reusable save button
  const renderSaveButton = (disabled = false) => {
    return (
      <Button
        className='srs-view-report-save-copy trk_button_ssrs-report-custom-report-save-btn'
        data-atmt-id={`seismic.self-service-reports.edit-report.${disabled ? 'save' : 'reset'
          }-report-changes${disabled ? '-disabled' : ''}`}
        disabled={disabled}
        label={t('self_service_reports_save', 'Save')}
        startAdornment={IconSave}
        hideLabel={hideLabel}
        variant={hideLabel ? 'tertiary' : 'primary'}
        onClick={disabled ? undefined : () => handleOnSave()}
      />
    );
  };

  // Reusable reset button
  const renderResetButton = () => (
    <Button
      label={t('self_service_reports_reset_changes', 'Reset changes')}
      className='ssrs-custom-report-header-reset-button trk_button_ssrs-report-edit-custom-open-reset-changes-modal'
      onClick={onReset}
      data-atmt-id='seismic.self-service-reports.edit-report.reset-report-changes'
    />
  );

  return (
    <div className='ssrs-custom-report-header'>
      <div>
        {reportStatus === IReportStatusType.UNSAVED_CHANGES &&
          renderResetButton()}

        {
          isOwner && renderSaveButton(reportStatus !== IReportStatusType.UNSAVED_CHANGES)
        }
      </div>
    </div>
  );
};

export default CustomReportHeader;
