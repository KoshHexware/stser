import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';
import './FilterCard.scss';
import { Badge, Button, ContentItem, IconClose, Tooltip } from '@seismic/mantle';
import {
  FILTER_TYPE,
  IBooleanOperations,
  IDateOperations,
  IFilter,
  IFilterDataType,
  INullishOperations,
} from '../../../../interfaces/IFilterTypes';
import {
  AllReportsLandingPageContext,
  CompileReportContext,
} from '../../../../contexts';
import { Screens } from '../../../../contexts/types';
import { convertDateToString } from '../../../../utils/reportFiltersUtils';
import { useTranslation } from 'react-i18next';
import { useAccessLevel } from '../../../../contexts/CommonServicesContext';
import { VIEWER_ACCESS_LEVEL, EMPTY_FILTER_VALUE } from '../../../../utils/constants';
import { USER_SCOPE_OPERATOR_CURRENT_USER_OPERATION_LABEL, USER_SCOPE_OPERATOR_MY_TEAM_OPERATION_LABEL, UserScopeTextMyTeamSubOperators } from '../../../../utils/userScopeOperatorsConstants';

type IFilterFolderCard = {
  filter: IFilter;
  onRemoveFilter?: (filter: IFilter) => void;
};

const FilterCard = (props: IFilterFolderCard) => {
  const { filter, onRemoveFilter } = props;
  const {
    setIsFilterCardClicked,
    isFilterCardClicked,
    setCurrentSelectedFilter,
    currentSelectedFilter,
    id,
    reportName,
  } = useContext(CompileReportContext);
  const { currentScreen } = useContext(AllReportsLandingPageContext);
  const [isMouseHovered, setIsMouseHovered] = useState(false);
  const { t } = useTranslation();
  const filterRef = React.useRef<HTMLDivElement>(null);
  const accessLevel = useAccessLevel();
  const isViewer = accessLevel == VIEWER_ACCESS_LEVEL;

  useEffect(() => {
    if (filter?.isNewlyAdded && filterRef.current) {
      filterRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  const { uxLabel, values } = filter;
  let { operation } = filter;

  const isTrue =
    isFilterCardClicked &&
    currentSelectedFilter.filterName === filter.filterName;

  const popoverControlRef = useRef<HTMLDivElement | null>(null);

  // Add this useEffect to handle the dynamically added div
  useEffect(() => {
    if (isTrue) {
      // When filter card is clicked and popover shows
      setTimeout(() => {
        // Find the dynamically added div that controls the popover
        const popoverControl = filterRef.current?.previousElementSibling as HTMLDivElement;
        if (popoverControl &&
          popoverControl.getAttribute('aria-haspopup') === 'dialog' &&
          !popoverControl.getAttribute('aria-label')) {

          // Add proper aria-label to the control
          popoverControl.setAttribute(
            'aria-label',
            `${uxLabel} ${t('self_service_reports_filter', 'Filter')}`
          );

          // Store reference to update later if needed
          popoverControlRef.current = popoverControl;
        }
      }, 100); // Small delay to ensure the DOM has been updated
    }
  }, [isTrue, uxLabel, t]);

  const getFilterValue = () => {
    // Handle boolean filters with default values but no operation
    if (filter.dataType === IFilterDataType.BOOLEAN &&
      (filter.filterDefaultValues ?? []).length > 0 && (!operation || operation.toLowerCase() === 'none')) {
      filter.operation = IBooleanOperations.EQUALS;
      operation = IBooleanOperations.EQUALS;
    }

    const selectedOperator = filter?.allowedOperators?.find(
      (f) => f.name === operation
    );

    selectedOperator && (selectedOperator.uxLabel = t(`self_service_reports_filters_operations_${selectedOperator.name}`, selectedOperator.uxLabel));

    const isCurrentUserString = t('self_service_reports_filters_operations_IsCurrentUser', USER_SCOPE_OPERATOR_CURRENT_USER_OPERATION_LABEL);
    const isMyTeamString = t('self_service_reports_filters_operations_IsMyTeam', USER_SCOPE_OPERATOR_MY_TEAM_OPERATION_LABEL);

    if (values !== undefined && values?.length === 0) {
      return '-';
    }

    if (
      selectedOperator?.name === INullishOperations.BLANK ||
      selectedOperator?.name === INullishOperations.NOT_BLANK
    ) {
      return `${selectedOperator.uxLabel}`;
    }

    if (values.length === 1) {
      if (
        filter.dataType === IFilterDataType.DATE ||
        filter.dataType === IFilterDataType.DATE_TIME
      ) {

        // If the operator is greater than or less than, we need to change the label
        // to "After" or "Before" respectively.
        if (selectedOperator?.name === IDateOperations.GREATER_THAN || selectedOperator?.name === IDateOperations.LESS_THAN) {
          selectedOperator.uxLabel = selectedOperator.name === IDateOperations.GREATER_THAN
            ? t('self_service_reports_filters_operations_After', 'After')
            : t('self_service_reports_filters_operations_Before', 'Before');
        }

        // If the operator is named range, we need to show the value as "is".
        // Otherwise, we convert the date to a string.
        if (selectedOperator?.name === IDateOperations.NAMED_RANGE) {
          return (
            <>
              {t('self_service_reports_filters_operations_is', 'is')}{' '}
              <span className='bold-text'>{`${values[0]}`}</span>
            </>
          );
        }
        return (
          <>
            {`${selectedOperator?.uxLabel}`}{' '}
            <span className='bold-text'>
              {convertDateToString(values[0], true)}
            </span>
          </>
        );
      }
      if (values[0] === UserScopeTextMyTeamSubOperators.IncludeDirectReports ||
        (values[0] == UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue &&
          selectedOperator?.uxLabel === isCurrentUserString)) {
        if (selectedOperator?.uxLabel === isCurrentUserString) {
          return <>
            {t('self_service_reports_filters_operations_is', 'is')}{' '}
            <span className='bold-text'>{t('self_service_reports_filters_operations_CurrentUser', '[Current user]')}</span>
          </>;
        } else if (selectedOperator?.uxLabel === isMyTeamString) {
          return <>
            {t('self_service_reports_filters_operations_is', 'is')}{' '}
            <span className='bold-text'>{t('self_service_reports_filters_operations_MyTeam', '[My team]')}</span>
          </>;
        }
        return `${selectedOperator?.uxLabel}`;
      }
      return (
        <>
          {selectedOperator?.uxLabel === isMyTeamString ? (
            <>
              {t('self_service_reports_filters_operations_is', 'is')}{' '}
              <span className='bold-text'>
                {t('self_service_reports_filters_operations_MyTeam', '[My team]')}
              </span>{' '}
            </>
          ) : `${selectedOperator?.uxLabel}`}{' '}
          <span className='bold-text'>
            {(() => {
              const hasDirect = values.includes(UserScopeTextMyTeamSubOperators.IncludeIndirectReportsValue);
              const hasCurrent = values.includes(UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue);
              if (hasDirect && hasCurrent) {
                return `(${t('self_service_reports_filters_operations_include_indirect_reports_and_current_user', 'include indirect reports and current user')})`;
              }
              if (hasDirect) {
                return `(${t('self_service_reports_filters_operations_label_includes_indirect_reports', 'include indirect reports')})`;
              }
              if (hasCurrent) {
                return `(${t('self_service_reports_filters_operations_label_includes_current_user', 'include current user')})`;
              }
              return values[0];
            })()}
          </span>
        </>
      );
    } else {
      if (
        (filter.dataType === IFilterDataType.TEXT || filter.dataType === IFilterDataType.CSV) &&
        (filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES ||
          filter.filterType === FILTER_TYPE.PICKLIST)
      ) {
        if (values == undefined || values.length === 0 || values[0] === EMPTY_FILTER_VALUE) {
          if (selectedOperator?.uxLabel === isCurrentUserString || selectedOperator?.uxLabel === isMyTeamString) {
            return <span className='bold-text'>{`${selectedOperator?.uxLabel}`}</span>;
          }
          return `${selectedOperator?.uxLabel}`;
        }

        if (values?.length === 1) {
          return (
            <>
              {`${selectedOperator?.uxLabel}`}{' '}
              <Tooltip
                content={values[0]}
                position='bottom'
                variant='light'
                interactive={true}
                interactiveDelay={100}
                zIndex={10000011}
              >
                <span className='bold-text'>
                  {typeof values[0] === 'string' && values[0].length > 25 ?
                    `${values[0].substring(0, 25)}...  ` : values[0]}
                </span>
              </Tooltip>
              <span className='filter-value-count'></span>
            </>
          );
        } else if (values?.length > 1 && (selectedOperator?.uxLabel === isMyTeamString ||
          selectedOperator?.uxLabel === isCurrentUserString)) {
          return (
            <>
              {(selectedOperator?.uxLabel === isMyTeamString ||
                selectedOperator?.uxLabel === isCurrentUserString) && (
                  <>
                    {t('self_service_reports_filters_operations_is', 'is')}{' '}
                    <span className='bold-text'>
                      {t('self_service_reports_filters_operations_MyTeam', '[My team]')}
                    </span>{' '}
                    <span className='bold-text'>
                      {(() => {
                        const hasDirect = values.includes(UserScopeTextMyTeamSubOperators.IncludeIndirectReportsValue);
                        const hasCurrent = values.includes(UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue);
                        if (hasDirect && hasCurrent) {
                          return `(${t('self_service_reports_filters_operations_include_indirect_reports_and_current_user', 'include indirect reports and current user')})`;
                        }
                        if (hasDirect) {
                          return `(${t('self_service_reports_filters_operations_label_include_indirect_reports', 'include indirect reports')})`;
                        }
                        if (hasCurrent) {
                          return `(${t('self_service_reports_filters_operations_label_include_current_user', 'include current user')})`;
                        }
                        return values[0];
                      })()}
                    </span>
                  </>
                )}
            </>
          )
        }
        else {
          const sortedValues = values.slice().sort((a, b) => a.localeCompare(b));
          return (
            <>
              {`${selectedOperator?.uxLabel}`}{' '}
              <span className='bold-text'>
                {typeof sortedValues[0] === 'string' && sortedValues[0].length > 18 ?
                  `${sortedValues[0].substring(0, 18)}... ` : sortedValues[0]}
              </span>
              {sortedValues?.length > 1 ?
                <Tooltip
                  content={sortedValues.join(', ')}
                  position='bottom'
                  variant='light'
                  interactive={true}
                  interactiveDelay={100}
                  zIndex={10000011}
                >
                  <Badge className='filter-value-count' count={`+${sortedValues.length - 1}`} variant='ghost' />
                </Tooltip> :
                null
              }
            </>
          );
        }
      }

      if (selectedOperator?.name === IDateOperations.IN_THE_LAST ||
        selectedOperator?.name === IDateOperations.IN_THE_NEXT) {
        return (
          <>
            {`${selectedOperator?.uxLabel}`}{' '}
            <span className='bold-text'>{`${values[0]} ${values[1]}`}</span>
          </>
        );
      }

      return (
        <>
          {`${selectedOperator?.uxLabel}`}{' '}
          <span className='bold-text'>{values.join(' - ')}</span>
        </>
      );
    }
  };

  const clickHandler = useCallback(() => {
    if (
      !isViewer &&
      (currentScreen === Screens.EDIT_REPORT ||
        currentScreen === Screens.NEW_REPORT)
    ) {
      setIsFilterCardClicked(true);
      setCurrentSelectedFilter(filter);
    } else {
      return;
    }
  }, [filter]);

  const keyDownHandler = useCallback((event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      clickHandler();
    }
  }, []);

  return (
    <div className='filter-card' ref={filterRef}>
      <ContentItem
        status={isTrue ? 'selected' : 'default'}
        variant='chip'
        className={`${isTrue ? 'filter-card-content-item-active' : ''
          } filter-card-content-item`}
        onClick={clickHandler}
        tabIndex={0}
        role='button'
        aria-label={`${uxLabel} ${t('self_service_reports_filter', 'Filter')}`}
        onKeyDown={keyDownHandler}
        onMouseEnter={() => setIsMouseHovered(true)}
        onMouseLeave={() => setIsMouseHovered(false)}
        onFocus={() => setIsMouseHovered(true)}
      >
        <ContentItem.Content>
          <ContentItem.Content.Title className='filter-card-content-item-title'>
            {uxLabel}
          </ContentItem.Content.Title>
          <ContentItem.Content.Description className='filter-card-content-item-value'>
            {getFilterValue()}
          </ContentItem.Content.Description>
        </ContentItem.Content>
        {(isMouseHovered || isTrue) &&
          currentScreen !== Screens.VIEW_REPORT &&
          !isViewer && (
            <ContentItem.Actions>
              <ContentItem.Actions.Hover>
                <Button
                  hideLabel
                  label={t(
                    'self_service_reports_remove_filter',
                    'Remove filter'
                  )}
                  startAdornment={IconClose}
                  className='filter-card-remove trk_button_ssrs-report_edit-remove_filter'
                  data-atmt-id='seismic.self-service-reports.edit-report-filters.remove-filter'
                  onClick={(event) => {
                    event.stopPropagation();
                    onRemoveFilter && onRemoveFilter(filter);
                    setIsFilterCardClicked(false);
                  }}
                  tabIndex={0}
                />
              </ContentItem.Actions.Hover>
            </ContentItem.Actions>
          )}
      </ContentItem>
    </div>
  );
};

export default React.memo(FilterCard);
