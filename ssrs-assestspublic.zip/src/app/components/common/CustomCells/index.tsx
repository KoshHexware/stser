import React, { useState, useEffect, useRef } from 'react';
import {
	AvatarUser,
	IconCopy,
	IconEmail,
	IconExternal,
	IconHost,
	Timestamp,
	Tooltip,
	IconStatusCheckFilled,
	Button,
	LinkButton,
} from '@seismic/mantle';
import './CustomCells.scss';
import Highlighter from 'react-highlight-words';
import { formatNewLines } from '../../../../utils/formatNewLines';
import { useTranslation } from 'react-i18next';
import ReportDrillIn from '../../ReportDrillIn/ReportDrillIn';

// Custom hook for tooltip overflow detection
const useOverflowTooltip = (value: any) => {
	const [showTooltip, setShowTooltip] = useState(false);
	const textRef = useRef<HTMLElement>(null);

	const checkOverflow = () => {
		const element = textRef.current;
		if (element && value) {
			setShowTooltip(element.scrollWidth > element.clientWidth);
		}
	};

	const handleMouseEnter = () => {
		checkOverflow();
	};

	useEffect(() => {
		checkOverflow();
	}, [value]);

	return { showTooltip, textRef, handleMouseEnter };
};

export const NameCell = (props: any) => {
	const { data } = props;
	const searchTerm = props.context;
	if (!props?.value) {
		return <p>-</p>;
	}

	return (
		<div className='name-cell-container'>
			<div className='icon-container'>
				<IconHost
					className='icon-host'
					category='content-icons-v2'
					params={{
						format:
							data.reportType === 'Custom'
								? 'custom-report'
								: 'standard-report',
					}}
				/>
			</div>
			<div className='report-name-container'>
				<h5 className='report-name'>
					<Highlighter
						highlightClassName='YourHighlightClass custom-highlighter-mark-tag'
						searchWords={[searchTerm]}
						autoEscape={true}
						textToHighlight={data.reportName}
					/>
				</h5>
			</div>
		</div>
	);
};

export const DescriptionCell = (props: any) => {
	const { data } = props;
	const searchTerm = props.context;
	if (!props?.value) {
		return <p>-</p>;
	}

	return (
		<>
			<div className='description-cell-container'>
				<Tooltip
					content={formatNewLines(data?.description)}
					position='bottom'
					variant='light'
					size='lg'
					interactive={true}
					interactiveDelay={100}
					zIndex={10000011}
					className='ssrs-field-definition-tooltip'
				>
					<p className='description-text'>
						<Highlighter
							highlightClassName='YourHighlightClass custom-highlighter-mark-tag'
							searchWords={[searchTerm]}
							autoEscape={true}
							textToHighlight={data.description}
						/>
					</p>
				</Tooltip>
			</div>
		</>
	);
};

export const OwnerCell = (props) => {
	return (
		<div className='owner-cell'>
			{props?.value?.toLowerCase() != 'system' ? (
				<div style={{ marginTop: '7px' }}>
					<AvatarUser
						className='avatar-user'
						src={props.data.ownerThumbnailUrl}
						name={props.value}
						size='md'
						placeholder={props.value}
					/>
				</div>
			) : (
				<></>
			)}
			{props?.value ? (
				<Tooltip content={props.value}>
					<div className='owner-cell'>
						<p>{props.value}</p>
					</div>
				</Tooltip>
			) : (
				<div className='owner-cell'>
					<p>-</p>
				</div>
			)}
		</div>
	);
};

export const DateCell = (props) => {
	if (props?.value) {
		return <Timestamp variant='dateOnly' date={props.value} />;
	} else {
		return <p>-</p>;
	}
};

export const DateTimeCell = (props) => {
	if (props?.value) {
		return <Timestamp date={props.value} />;
	} else {
		return <p>-</p>;
	}
};

export const ExternalIconCell = (props: { value: string }) => {
	const [isUrlCopied, setIsUrlCopied] = useState(false);

	if (!props?.value) {
		return <p>-</p>;
	}
	return (
		<div aria-label={`External link to ${props.value}`}>
			<Tooltip
				style={{ maxWidth: 'fit-content' }}
				onHide={() => setIsUrlCopied(false)}
				content={
					<div>
						{props.value.length > 50
							? `${props.value.substring(0, 50)}...  `
							: props.value}
						<>
							{isUrlCopied == false ? (
								<IconCopy
									className='copy-icon'
									onClick={() => {
										setIsUrlCopied(true);
										navigator.clipboard.writeText(props.value);
									}}
									size={16}
								/>
							) : (
								<IconStatusCheckFilled className='check-filled' size={16} />
							)}
						</>
					</div>
				}
				interactive={true}
				interactiveDelay={200}
				position='bottom'
				zIndex={1000001}
			>
				<div className='external-link-cell'>
					<a href={props.value} onClick={(e) => e.preventDefault()}>
						<IconExternal
							onClick={(e) => window.open(props.value, '_blank')}
							size={16}
						/>
					</a>
				</div>
			</Tooltip>
		</div>
	);
};

export const EmailCell = (props: { value: string }) => {
	if (!props?.value) {
		return <p>-</p>;
	}

	return (
		<div className='email-cell' aria-label={`Email to ${props.value}`}>
			<a href={`mailto: ${props.value}`}>
				<IconEmail size={16} />
				<span className='email-value'> {props.value} </span>
			</a>
		</div>
	);
};

export const ReportOwnerCell = (props) => {
	const { showTooltip, textRef, handleMouseEnter } = useOverflowTooltip(
		props.value
	);
	if (!props?.value) {
		return <></>;
	}

	const textContent = (
		<p
			ref={textRef}
			onMouseEnter={handleMouseEnter}
			className='report-owner-text'
		>
			{props.value}
		</p>
	);

	return (
		<div className='owner-cell'>
			{props?.value?.toLowerCase() != 'system' ? (
				<div style={{ marginTop: '7px' }}>
					<AvatarUser
						className='avatar-user'
						src={props.data.ownerThumbnailUrl}
						name={props.value}
						size='md'
						placeholder={props.value}
					/>
				</div>
			) : (
				<></>
			)}
			<div className='report-owner-cell'>
				{showTooltip ? (
					<Tooltip
						className='report-custom-cell-tooltip'
						content={props.value}
						size='sm'
						zIndex={10000011}
					>
						{textContent}
					</Tooltip>
				) : (
					textContent
				)}
			</div>
		</div>
	);
};

export const ReportDateCell = (props: { value: string }) => {
	if (!props?.value) {
		return <></>;
	}

	return <Timestamp variant='dateOnly' date={props.value} />;
};

export const ReportDateTimeCell = (props: { value: string }) => {
	if (!props?.value) {
		return <></>;
	}

	return <Timestamp date={props.value} />;
};

export const ReportExternalIconCell = (props: { value: string }) => {
	const [isUrlCopied, setIsUrlCopied] = useState(false);

	if (!props?.value) {
		return <></>;
	}
	return (
		<div aria-label={`External link to ${props.value}`}>
			<Tooltip
				style={{ maxWidth: 'fit-content' }}
				onHide={() => setIsUrlCopied(false)}
				content={
					<div>
						{props.value.length > 50
							? `${props.value.substring(0, 50)}...  `
							: props.value}
						<>
							{isUrlCopied == false ? (
								<IconCopy
									className='copy-icon'
									onClick={() => {
										setIsUrlCopied(true);
										navigator.clipboard.writeText(props.value);
									}}
									size={16}
								/>
							) : (
								<IconStatusCheckFilled className='check-filled' size={16} />
							)}
						</>
					</div>
				}
				interactive={true}
				interactiveDelay={200}
				position='bottom'
				zIndex={1000001}
			>
				<div className='external-link-cell'>
					<a
						href={props.value}
						onClick={(e) => e.preventDefault()}
						aria-label={props.value}
					>
						<IconExternal
							onClick={(e) => window.open(props.value, '_blank')}
							size={16}
						/>
					</a>
				</div>
			</Tooltip>
		</div>
	);
};

export const ReportEmailCell = (props: { value: string }) => {
	const { showTooltip, textRef, handleMouseEnter } = useOverflowTooltip(
		props.value
	);
	if (!props?.value) {
		return <></>;
	}
	const testContent = (
		<a
			href={`mailto: ${props.value}`}
			ref={textRef}
			onMouseEnter={handleMouseEnter}
		>
			<IconEmail size={16} />
			<span className='report-email-value'> {props.value} </span>
		</a>
	);

	return (
		<div className='report-email-cell' aria-label={`Email to ${props.value}`}>
			{showTooltip ? (
				<Tooltip
					className='report-custom-cell-tooltip'
					size='sm'
					zIndex={10000011}
					content={props.value}
				>
					{testContent}
				</Tooltip>
			) : (
				testContent
			)}
		</div>
	);
};

export const ReportCustomCell = (props: any) => {
	const { showTooltip, textRef, handleMouseEnter } = useOverflowTooltip(
		props.value
	);

	if (!props?.value) {
		return <></>;
	}

	let value = props.value;
	if (props.colDef?.dataType === 'Csv') {
		value = value.replaceAll('\x1F', ', ');
	}

	const textContent = (
		<p
			ref={textRef}
			onMouseEnter={handleMouseEnter}
			className='report-custom-cell-text'
		>
			<span>{value}</span>
		</p>
	);

	return (
		<div className='report-custom-cell-container'>
			{showTooltip ? (
				<Tooltip
					className='report-custom-cell-tooltip'
					content={value}
					size='sm'
					zIndex={10000011}
				>
					{textContent}
				</Tooltip>
			) : (
				textContent
			)}
		</div>
	);
};

export const ReportNumberCell = (props: { value: number | string }) => {
	const { i18n } = useTranslation();
	if (props?.value == null || props?.value === '') return <></>;
	const raw = String(props?.value).trim();
	const decimalCount = raw.includes('.') ? raw.split('.')[1]?.length || 0 : 0;
	const formattedValue = new Intl.NumberFormat(i18n.language, {
		style: 'decimal',
		minimumFractionDigits: decimalCount,
		maximumFractionDigits: decimalCount || 100,
	}).format(Number(props.value));
	const { showTooltip, textRef, handleMouseEnter } =
		useOverflowTooltip(formattedValue);
	const textContent = (
		<p
			ref={textRef}
			onMouseEnter={handleMouseEnter}
			className='report-number-cell-text'
		>
			<span>{formattedValue}</span>
		</p>
	);

	return (
		<div className='report-number-cell-container'>
			{showTooltip ? (
				<Tooltip
					className='report-custom-cell-tooltip'
					content={formattedValue}
					size='sm'
					zIndex={10000011}
				>
					{textContent}
				</Tooltip>
			) : (
				textContent
			)}
		</div>
	);
};

export const ReportRateCell = (props: { value: number | string }) => {
	const { i18n } = useTranslation();
	if (props?.value == null || props?.value === '') return <></>;
	const formattedValue = `${props?.value}%`;
	const { showTooltip, textRef, handleMouseEnter } =
		useOverflowTooltip(formattedValue);
	const textContent = (
		<p
			ref={textRef}
			onMouseEnter={handleMouseEnter}
			className='report-rate-cell-text'
		>
			<span>{formattedValue}</span>
		</p>
	);

	return (
		<div className='report-rate-cell-container'>
			{showTooltip ? (
				<Tooltip
					className='report-custom-cell-tooltip'
					content={formattedValue}
					size='sm'
					zIndex={10000011}
				>
					{textContent}
				</Tooltip>
			) : (
				textContent
			)}
		</div>
	);
};

export const ReportLinkCell = (props: {
	value: string;
	onClick: () => void;
	onDrillInClick?: () => void;
	colDef: any;
	data: any;
}) => {
	const [showReportModal, setShowReportModal] = useState(false);

	if (!props?.value) {
		return <></>;
	}

	if (Number(props.value) <= 0) {
		return <span>{props.value}</span>;
	}

	return (
		<>
			<div className={`trk_link_button_ssrs_report_drill_in_${props.colDef.name}_${props.data.PRIMARYKEYFIELD}`}>
				<LinkButton
					label={props.value}
					variant='primary'
					onClick={() => setShowReportModal(true)}
				/>
			</div>

			{showReportModal && (
				<ReportDrillIn
					showReportModal={showReportModal}
					setShowReportModal={setShowReportModal}
					colDef={props.colDef}
					data={props.data}
				/>
			)}
		</>
	);
};

export const columnTypes = {
	Text: {},
	text: {},
	Integer: {},
	integer: {},
	Boolean: {},
	boolean: {},
	Decimal: {},
	decimal: {},
	Date: {},
	date: {},
	DateTime: {},
	datetime: {},
};
