import React, { useContext, useEffect, useMemo, useState, useRef } from 'react';
import {
	AsyncDataGrid,
	ColDef,
	ColumnVisibleEvent,
	GridApi,
	GridReadyEvent,
	ClipboardModule,
	CsvExportModule,
	RangeSelectionModule,
} from '@seismic/shared-datagrid';
import { ErrorBoundary } from '../ErrorBoundary';
import {
	columnTypes,
	ReportDateCell,
	ReportDateTimeCell,
	ReportEmailCell,
	ReportExternalIconCell,
	ReportOwnerCell,
	ReportCustomCell,
	ReportNumberCell,
	ReportRateCell,
	ReportLinkCell,
} from '../CustomCells';
import ReportService from '../../../../services/ReportService';
import {
	ContextualButtonStatus,
	FIXEDPAGESIZE,
	VIEWER_ACCESS_LEVEL,
} from '../../../../utils/constants';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import { IField } from '../../../../interfaces/IReport';
import { IFilter, IFilterDataType } from '../../../../interfaces/IFilterTypes';
import { getReportsTablColumnDefs } from '../../../../utils/getReportsTblColumnDefs';
import { LanguageCode } from '@seismic/mantle/dist/styles/themes/themes';
import {
	areFiltersChanged,
	getFilterDetails,
} from '../../../../utils/reportFiltersUtils';
import {
	LinkButton,
	seismicTheme,
	ContextualButton,
	IconExport,
	Button,
	IconColumns,
	IconTableGrid,
	IconFilter,
} from '@seismic/mantle';
import './AsyncReportGrid.scss';
import {
	useApplicationInfo,
	useLaunchDarkly,
	useMantleTranslations,
	useTenantUniqueId,
} from '../../../../contexts/CommonServicesContext';
import {
	CompileReportContext,
	FieldAndFilterContext,
	AllReportsLandingPageContext,
	ReportDataContext,
} from '../../../../contexts';
import TeamsitesViewTag from '../../Teamsites/TeamsitesViewTag/TeamsitesViewTag';
import Teamsites from '../../Teamsites';
import { ITeamsites } from '../../../../interfaces/IAppData';
import { useAccessLevel } from '../../../../contexts/CommonServicesContext';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from '../../../../utils/constants';
import { IQueryParamsTypes } from '../../../../interfaces/IDeepLinkingTypes';
import { checkSSRWinterFY26FeatureFlag } from '../../../../utils/featureFlagUtils';

type sortType = 'asc' | 'desc';
type ISortModal = {
	field: string;
	sort: sortType;
};
type AsyncReportGridProps = {
	reportId: string;
	reportName: string;
	fields: IField[];
	filters: IFilter[];
	defaultSortField: string;
	defaultSortOrder?: string;
	initialSkip?: number;
	pageSize?: number;
	resetRefreshPreview?: boolean; // to reset refresh preview on save
	hideColumns?: boolean; // Used to hide columns button in the grid tool panel
	hideFilters?: boolean; // Used to hide filters button in the grid tool panel
	hideExport?: boolean;
	enableRefreshPreview?: boolean;
	onColumnVisibilityChange?: (columns: any[]) => void;
	onSortUpdated?: (sortmodal: ISortModal) => void;
	setReportGridApi?: (gridApi: GridApi<any>) => void;
	teamsites: ITeamsites[];
	showTeamsitePicker: boolean;
	setCurrentVisibleTab: (currentVisibleTab: number) => void;
	setIsSidePanelVisible: (isSidePanelVisible: boolean) => void;
	isSidePanelVisible: boolean;
	columnVisibility: Record<string, boolean>;
};

// Types for persisted user preferences in localStorage
type ReportPreferences = {
	reportId: string;
	hiddenColumnNames?: string[];
	columnOrder?: string;
};
type UserTenantPreferences = {
	reports: ReportPreferences[];
};
type UserPreferencesStore = Record<string, UserTenantPreferences>;

export const AsyncReportGrid: React.FC<AsyncReportGridProps> = ({
	reportId,
	reportName,
	fields,
	filters,
	defaultSortField,
	resetRefreshPreview = undefined,
	defaultSortOrder = 'asc',
	initialSkip = 0,
	pageSize = FIXEDPAGESIZE,
	hideFilters = false,
	hideColumns = false,
	hideExport = false,
	enableRefreshPreview = false,
	onColumnVisibilityChange = () => {},
	onSortUpdated = () => {},
	setReportGridApi = () => {},
	teamsites,
	showTeamsitePicker = false,
	setCurrentVisibleTab,
	setIsSidePanelVisible,
	isSidePanelVisible = false,
	columnVisibility,
}) => {
	const { t } = useTranslation();
	const history = useHistory();
	const { languageCode, mantleTranslations } = useMantleTranslations();
	const { selectedReport, setReportMetadata } = useContext(ReportDataContext);

	const [localReportSchema, setLocalReportSchema] = useState<ColDef<any>[]>([]);
	const [localFields, setLocalFields] = useState(fields); //for checking if fields are changed irrespective of order
	const [localFilters, setLocalFilters] = useState(filters); //for showing refresh preview
	const [localTeamsites, setLocalTeamsites] = useState(teamsites); //for showing refresh preview
	const [loading, setLoading] = React.useState(true);
	const [showRefreshPreview, setShowRefreshPreview] = useState(false);
	const [updatedSkip, setUpdatedSkip] = useState(undefined);
	const [totalCounts, setTotalCounts] = useState<number>();
	const [gridApi, setGridApis] = useState<GridApi<any>>();
	const [sortData, setSortData] = useState<{ field: string; sort: sortType }>({
		field: defaultSortField,
		sort: defaultSortOrder as sortType,
	});
	const [exportButtonStatus, setExportButtonStatus] =
		React.useState<ContextualButtonStatus>('default');
	const [visibleColumns, setVisibleColumns] = useState<Array<string>>([]);
	const {
		updatedTeamsites,
		updatedFilters,
		gridHiddenColumns,
		setGridHiddenColumns,
		isChanged,
		shouldTriggerWithDefaultsAPI,
		setShouldTriggerWithDefaultsAPI,
		updatedFields,
		setUpdatedFields,
	} = useContext(CompileReportContext);
	const { currentActiveTab, setCurrentActiveTab } = useContext(
		FieldAndFilterContext
	);
	const accessLevel = useAccessLevel();
	const isViewer = accessLevel == VIEWER_ACCESS_LEVEL;
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();
	const { reportData, pagination, setReportData, setPagination } = useContext(
		AllReportsLandingPageContext
	);
	const shouldFetchDataRef = useRef(false);
	const reportDataRef = useRef(reportData);
	const paginationRef = useRef(pagination);
	const isChangedRef = useRef(isChanged);
	const [refreshTrigger, setRefreshTrigger] = useState(0);

	// Debounce + guard for external sort updates
	const sortDebounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
	const lastSentSortRef = useRef<{ field: string; sort: sortType } | null>(null);

	const launchDarklyToggles = useLaunchDarkly();
	const isSSRWinterFY26FeatureFlagEnabled = checkSSRWinterFY26FeatureFlag(launchDarklyToggles);

	const getUserTenantKey = (userId: string, tenantId: string): string => {
		return `${userId}_${tenantId}`;
	};

	const visibleFieldsOnGrid =
		gridHiddenColumns?.length > 0
			? fields.filter((field) => !gridHiddenColumns.includes(field.name))
			: fields;

	const defaultColDef = useMemo(
		() => ({ sortingOrder: ['desc' as 'desc', 'asc' as 'asc'] }),
		[]
	);
	const localizationDefs = useMemo(
		() => ({ languageCode: languageCode as LanguageCode }),
		[]
	);

	useEffect(() => {
		isChangedRef.current = isChanged;
	}, [isChanged]);

	const filterDef = useMemo(() => {
		return {
			gridData: {
				label: '',
				control: { filters: localFilters },
			},
		};
	}, [localFilters]);

	const filterValues = useMemo(() => {
		return {
			gridData: {
				filters: localFilters,
				fields: localFields,
				reportId: reportId,
				teamsites: localTeamsites,
			},
		};
	}, [localFilters, localFields, reportId, showRefreshPreview, localTeamsites]);

	const trackingIds = useMemo(() => {
		const ids = {
			toolbarFiltersButton:
				'trk_button_ssrs-reports-view-data-grid-toolbar-expand-collapse-filters-section',
			toolbarColumnVisibilityButton:
				'trk_button_ssrs-reports_view-data_grid_toolbar-open_dropdown_for_hide_show_fields',
		};
		if (hideFilters) {
			ids.toolbarFiltersButton += ' hide-filter-btn';
		}
		if (hideColumns) {
			ids.toolbarColumnVisibilityButton += ' hide-column-btn';
		}
		ids.toolbarFiltersButton += ' inactive-filter-btn';
		return ids;
	}, [hideFilters, filters, hideColumns]);

	const components = useMemo(
		() => ({
			ReportOwnerCell,
			ReportDateCell,
			ReportDateTimeCell,
			ReportExternalIconCell,
			ReportEmailCell,
			ReportCustomCell,
			ReportNumberCell,
			ReportRateCell,
			ReportLinkCell,
		}),
		[]
	);

	const noRowsOverlayContent = useMemo(() => {
		return {
			noDataTitle: t(
				'self_service_reports_no_toggle_results_title',
				'Nothing to view'
			),
			noDataDescription: t(
				'self_service_reports_empty_state_heading',
				'No data to see'
			),
			noMatchesTitle: t(
				'self_service_reports_no_search_results_title',
				'No search results'
			),
			noMatchesDescription: t(
				'self_service_reports_no_search_results_description_message',
				'We couldn’t find anything matching your search query'
			),
		};
	}, [t]);

	// check if all fields from updated fields are present in localFields irrespective of order
	const areFieldsChanged = (
		fields: IField[],
		localFields: IField[]
	): boolean => {
		if (fields.length > localFields.length) {
			return true;
		}

		const fieldNames = fields.map((field) => field.name.toLowerCase());
		const localFieldNames = localFields.map((field) =>
			field.name.toLowerCase()
		);

		return !fieldNames.every((fieldName) =>
			localFieldNames.includes(fieldName)
		);
	};

	const areTeamsitesChanged = (
		teamsites: ITeamsites[],
		localTeamsites: ITeamsites[]
	): boolean => {
		const teamSiteObj = teamsites.filter((teamsite) => teamsite?.isSelected);
		const localTeamSiteObj = localTeamsites.filter(
			(teamsite) => teamsite?.isSelected
		);

		// Compare IDs of selected teamsites
		const selectedIds = teamSiteObj.map((t) => t.id).sort();
		const selectedLocalIds = localTeamSiteObj.map((t) => t.id).sort();
		if (selectedIds?.length != selectedLocalIds.length) {
			return true;
		}
		return !selectedIds.every((id, index) => id === selectedLocalIds[index]);
	};

	useEffect(() => {
		const div = document.querySelector('.mdg-form');
		div?.classList.add('mntl-scrollbar');
	}, []);

	const updateRefreshPreviewStatus = () => {
		const removedFilters = localFilters.filter(
			(localFilter) =>
				!filters.find(
					(newFilter) =>
						newFilter.filterName.toLowerCase() ===
						localFilter.filterName.toLowerCase()
				)
		);

		// Find added filters (present in filters but not in localFilters)
		const addedFilters = filters.filter(
			(newFilter) =>
				!localFilters.find(
					(localFilter) =>
						localFilter.filterName.toLowerCase() ===
						newFilter.filterName.toLowerCase()
				)
		);

		// Find filters that exist in both but may have changed values/operations
		const commonFilters = filters.filter((newFilter) =>
			localFilters.find(
				(localFilter) =>
					localFilter.filterName.toLowerCase() ===
					newFilter.filterName.toLowerCase()
			)
		);

		// Check removed filters - show refresh if any removed filter had meaningful values
		const hasRemovedMeaningfulFilters = removedFilters.some((removedFilter) => {
			if (removedFilter.dataType === IFilterDataType.BOOLEAN) {
				return (
					removedFilter.filterDefaultValues &&
					removedFilter.filterDefaultValues.length > 0
				);
			}
			return (
				removedFilter.values &&
				removedFilter.values.length > 0 &&
				removedFilter.operation &&
				removedFilter.operation.toLowerCase() !== 'none'
			);
		});

		// Check added filters - show refresh if any added filter has meaningful values
		const hasAddedMeaningfulFilters = addedFilters.some((addedFilter) => {
			if (addedFilter.dataType === IFilterDataType.BOOLEAN) {
				return (
					addedFilter.filterDefaultValues &&
					addedFilter.filterDefaultValues.length > 0
				);
			}
			return (
				addedFilter.values &&
				addedFilter.values.length > 0 &&
				addedFilter.operation &&
				addedFilter.operation.toLowerCase() !== 'none'
			);
		});

		// Check common filters for value/operation changes - show refresh if any meaningful changes
		const hasCommonFilterChanges = commonFilters.some((newFilter) => {
			const localFilter = localFilters.find(
				(localFilter) =>
					localFilter.filterName.toLowerCase() ===
					newFilter.filterName.toLowerCase()
			);

			if (!localFilter) return false;

			// Check for value or operation changes
			const valuesChanged =
				JSON.stringify(newFilter.values) !== JSON.stringify(localFilter.values);
			const operationChanged = newFilter.operation !== localFilter.operation;

			if (valuesChanged || operationChanged) {
				// If either filter has meaningful values, show refresh
				const newFilterHasValues =
					newFilter.dataType === IFilterDataType.BOOLEAN
						? newFilter.filterDefaultValues &&
						  newFilter.filterDefaultValues.length > 0
						: newFilter.values &&
						  newFilter.values.length > 0 &&
						  newFilter.operation &&
						  newFilter.operation.toLowerCase() !== 'none';

				const localFilterHasValues =
					localFilter.dataType === IFilterDataType.BOOLEAN
						? localFilter.filterDefaultValues &&
						  localFilter.filterDefaultValues.length > 0
						: localFilter.values &&
						  localFilter.values.length > 0 &&
						  localFilter.operation &&
						  localFilter.operation.toLowerCase() !== 'none';

				return newFilterHasValues || localFilterHasValues;
			}

			return false;
		});

		return (
			hasRemovedMeaningfulFilters ||
			hasAddedMeaningfulFilters ||
			hasCommonFilterChanges
		);
	};

	useEffect(() => {
		const filtersChanged = areFiltersChanged(filters, localFilters, true);
		let fieldsChanged = areFieldsChanged(fields, localFields);

		// Additional check for filter values to determine if refresh preview should be shown
		let shouldShowRefreshForFilters = false;

		if (filtersChanged) {
			// Find removed filters (present in localFilters but not in filters)
			shouldShowRefreshForFilters = updateRefreshPreviewStatus();
		}

		// update the report schema dicrectly if view mode or preview modal is not open
		if (
			!enableRefreshPreview ||
			(enableRefreshPreview &&
				!showRefreshPreview &&
				!fieldsChanged &&
				!shouldShowRefreshForFilters)
		) {
			const reportSchema = getReportsTablColumnDefs(
				visibleFieldsOnGrid,
				defaultSortField,
				defaultSortOrder,
				selectedReport,
				UserId,
				tenantUniqId,
				isSSRWinterFY26FeatureFlagEnabled
			);
			setLocalReportSchema(reportSchema); // trigger soft refresh grid
		}
		if (fieldsChanged) {
			if (enableRefreshPreview) {
				setShowRefreshPreview(true); // show refresh preview
			} else {
				setLocalFields(fields); // trigger hard refresh grid
			}
		}
		if (shouldShowRefreshForFilters) {
			if (enableRefreshPreview) {
				setShowRefreshPreview(true); // show refresh preview
			} else setLocalFilters(filters); // trigger hard refresh grid
		}
		if (
			(!shouldShowRefreshForFilters && !fieldsChanged) ||
			(fields && fields.length === 0)
		) {
			setShowRefreshPreview(false);
		}
	}, [fields, filters, columnVisibility, gridHiddenColumns]);

	useEffect(() => {
		let teamsitesChanged = areTeamsitesChanged(teamsites, localTeamsites);
		if (teamsitesChanged) {
			setLocalTeamsites(teamsites);
			const reportSchema = getReportsTablColumnDefs(
				visibleFieldsOnGrid,
				defaultSortField,
				defaultSortOrder,
				selectedReport,
				UserId,
				tenantUniqId,
				isSSRWinterFY26FeatureFlagEnabled
			);
			setLocalReportSchema(reportSchema);
			setLocalFields(fields);
			setLocalFilters(filters);
			setTotalCounts((prev) => (prev === undefined ? 0 : prev)); // hide total counts when loading if filters updated
			setShowRefreshPreview(false);
		}
	}, [teamsites]);

	useEffect(() => {
		let userData: UserPreferencesStore = {};

		try {
			const existingUserData = localStorage.getItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY
			);
			if (existingUserData && UserId && tenantUniqId) {
				userData = JSON.parse(existingUserData) as UserPreferencesStore;
				const userTenantKey = getUserTenantKey(UserId, tenantUniqId);
				setGridHiddenColumns(
					userData[userTenantKey]?.reports?.find(
						(report: { reportId: string }) => report.reportId === reportId
					)?.hiddenColumnNames
				);
			}
		} catch (error) {
			console.error('Error parsing user data from localStorage:', error);
		}
	}, [columnVisibility, UserId, tenantUniqId, reportId]);

	useEffect(() => {
		if (!showRefreshPreview) {
			const reportSchema = getReportsTablColumnDefs(
				visibleFieldsOnGrid,
				defaultSortField,
				defaultSortOrder,
				selectedReport,
				UserId,
				tenantUniqId,
				isSSRWinterFY26FeatureFlagEnabled
			);
			setLocalReportSchema(reportSchema);
			setLocalFields(fields);
			setLocalFilters(filters);
			setLocalTeamsites(teamsites);
			setTotalCounts((prev) => (prev === undefined ? 0 : prev)); // hide total counts when loading if filters updated
		}
	}, [showRefreshPreview]);

	// hide refresh preview on save
	useEffect(() => {
		if (enableRefreshPreview && resetRefreshPreview !== undefined) {
			setShowRefreshPreview(false);
		}
	}, [resetRefreshPreview]);

	//for updating export button status
	useEffect(() => {
		if (exportButtonStatus !== 'default' && exportButtonStatus !== 'loading') {
			setTimeout(() => setExportButtonStatus('default'), 1000);
		}
	}, [exportButtonStatus]);

	useEffect(() => {
		const localFieldNames = localFields
			.filter((f) => f.isDefault)
			.map((field) => field.name.toLocaleLowerCase());
		if (
			visibleColumns.length &&
			!visibleColumns.every((fieldName) => localFieldNames.includes(fieldName))
		) {
			setLocalFields((prev) =>
				prev.map((f) => ({
					...f,
					isDefault: visibleColumns.includes(f.name.toLocaleLowerCase()),
				}))
			);
		}
	}, [visibleColumns]);

	useEffect(() => {
		reportDataRef.current = reportData;
		paginationRef.current = pagination;
	}, [reportData, pagination]);

	useEffect(() => {
		if (shouldTriggerWithDefaultsAPI) {
			shouldFetchDataRef.current = true; // reset shouldFetchData to true to fetch data again
			setRefreshTrigger((prev) => prev + 1);
		}
	}, [shouldTriggerWithDefaultsAPI]);

	const dataSource = useMemo(
		() => ({
			getRows: (params: { success?: any; fail?: any; request?: any }) => {
				const { request } = params;
				const { startRow, sortModel, filterModel } = request;
				const { gridData } = filterModel;
				const { filters, fields, reportId, teamsites } = gridData;

				const orderField =
					sortModel.length > 0 ? sortModel[0].colId : defaultSortField;
				const orderBy =
					sortModel.length > 0 ? sortModel[0].sort : defaultSortOrder;
				const executeReportFilters = filters.filter(
					(f: { values: string | any[] }) => f.values.length > 0
				);

				const executeReportTeamsites = teamsites
					.filter((t: { isSelected: any }) => t.isSelected)
					.map((t: { id: any }) => t.id);
				const options: IQueryParamsTypes = {};

				options.fields = fields;
				options.filters = executeReportFilters;
				options.teamsiteIds = executeReportTeamsites;
				options.skip = startRow;
				options.take = pageSize;
				options.orderBy = orderBy;
				options.orderField = orderField;
				options.isSavedReport = !isChangedRef.current;
				if (paginationRef.current?.skip !== startRow) {
					shouldFetchDataRef.current = true;
				}

				if (shouldFetchDataRef.current) {
					// Use API call when shouldFetchData is true
					ReportService.getReportDataWithDefaults(reportId, options)
						.then(({ data, pagination, report }: any) => {
							setTotalCounts(pagination.totalRecords);
							setUpdatedSkip(startRow);
							params.success({
								rowData: data,
								rowCount: pagination.totalRecords === 0 ? 0 : -1,
							});
							setReportData(data);
							setPagination(pagination);
							setReportMetadata(report);
						})
						.catch((res) => {
							console.log('Error in fetching reports data', res);
							params.fail();
						})
						.finally(() => {
							setLoading(false);
							shouldFetchDataRef.current = false;
							setShouldTriggerWithDefaultsAPI(false);
						});
				} else {
					// Use context data when shouldFetchData is false
					if (reportDataRef.current && paginationRef.current) {
						setTotalCounts(paginationRef.current.totalRecords);
						setUpdatedSkip(startRow);
						params.success({
							rowData: reportDataRef.current,
							rowCount: paginationRef.current.totalRecords === 0 ? 0 : -1,
						});
						setLoading(false);
					} else {
						console.log('No report data available in context');
						params.fail();
						setLoading(false);
					}
				}
			},
		}),
		[refreshTrigger]
	);

	const renderteamsites = () => {
		return (
			<>
				{showTeamsitePicker && (
					<div className='generic-report-count-container-teamsites-tag'>
						{isViewer && teamsites?.length > 1 ? (
							<TeamsitesViewTag teamsites={teamsites} />
						) : (
							!isViewer &&
							teamsites?.length > 1 &&
							updatedTeamsites && <Teamsites />
						)}
					</div>
				)}
			</>
		);
	};

	const ToolbarControls = () => {
		function handleFilterBtnClick() {
			if (currentActiveTab == 'Filters' && isSidePanelVisible) {
				setIsSidePanelVisible(false);
			} else if (currentActiveTab == 'Filters') {
				setIsSidePanelVisible(!isSidePanelVisible);
			} else {
				setCurrentActiveTab('Filters');
				setCurrentVisibleTab(1);
				if (!isSidePanelVisible) {
					setIsSidePanelVisible(!isSidePanelVisible);
				}
			}
		}
		function handleEditTableBtnClick() {
			if (currentActiveTab == 'Table' && isSidePanelVisible) {
				setIsSidePanelVisible(false);
				return;
			} else if (currentActiveTab == 'Table') {
				setIsSidePanelVisible(!isSidePanelVisible);
			} else {
				setCurrentActiveTab('Table');
				setCurrentVisibleTab(0);
				if (!isSidePanelVisible) {
					setIsSidePanelVisible(!isSidePanelVisible);
				}
			}
		}

		const filterCount = Array.isArray(updatedFilters)
			? updatedFilters.filter((x) => {
					// Handle boolean filters differently
					if (x?.dataType === IFilterDataType.BOOLEAN) {
						return x.values && x.values.length > 0;
					}

					// Handle regular filters
					return (
						x?.operation &&
						x.operation.toLowerCase() !== 'none' &&
						x?.values?.length > 0
					);
			  })
			: [];

		return (
			<div className='generic-report-count-container'>
				{renderteamsites()}
				<div className='generic-report-filter-btn-div'>
					<Button
						className='trk_button_ssrs-reports-view-data-grid-toolbar-expand-collapse-filters-section'
						label={t('self_service_reports_filters', 'Filters')}
						variant='tertiary'
						startAdornment={IconFilter}
						badge={{
							count: filterCount?.length,
							label: `${filterCount.length} Applied Filters`,
						}}
						onClick={() => {
							handleFilterBtnClick();
						}}
					/>
				</div>
				<div className='generic-report-edit-table-btn-div'>
					<Button
						className='trk_button_ssrs-reports-edit-data-grid-toolbar-expand-collapse-add-column-section'
						label={t('self_service_reports_edit_table', 'Edit table')}
						variant='tertiary'
						startAdornment={IconTableGrid}
						onClick={() => {
							handleEditTableBtnClick();
						}}
						data-atmt-id='seismic.self-service-reports.view-report.Edit-table'
					/>
				</div>

				<div className='generic-report-count'>
					{totalCounts?.toLocaleString(languageCode)}{' '}
					{t('self_service_reports_items', 'Items')}
				</div>
			</div>
		);
	};

	const handleRefresh = () => {
		// Set the local data sources
		setLocalFields(fields);
		setLocalFilters(filters);
		setLocalTeamsites(teamsites);
		setTotalCounts(undefined);

		// Update the ref value instead of state directly
		shouldFetchDataRef.current = true;

		// Hide refresh preview immediately
		setShowRefreshPreview(false);
	};

	const GridRefreshTag = useMemo(() => {
		if (!showRefreshPreview) return <></>;

		return (
			<div className='compile-report-preview-container'>
				<div className='compile-report-info-tag'>
					<span style={{ paddingTop: '3px' }}>
						{t(
							'self_service_reports_changes_made',
							'You’ve made changes. Refresh to see the latest edits.'
						)}
					</span>
					<span>
						<LinkButton
							className='trk_button_ssrs-report_edit_refresh_preview_grid'
							style={{
								padding: '5px',
							}}
							label={t('self_service_reports_refresh', 'Refresh')}
							onClick={handleRefresh}
						></LinkButton>
					</span>
				</div>
			</div>
		);
	}, [showRefreshPreview]);

	const onColumnMoved = (event: any) => {
		if (event && event.api && event.finished) {
			const tableColumns = event.columnApi
				.getColumnState()
				.filter((c) => !c.hide)
				.map((x) => x.colId.toLocaleLowerCase());
			const orderedFieldsFromTable: any[] = [];
			const updatedFieldsMap = new Map(
				updatedFields.map((f: any) => [String(f?.name).toLocaleLowerCase(), f])
			);

			if (tableColumns.length !== updatedFields.length) {
				const tableColsSet = new Set(tableColumns);
				const notVisibleColumns = updatedFields
					.filter(
						(f: any) =>
							!tableColsSet.has(String(f?.name ?? '').toLocaleLowerCase())
					)
					.map((f: any) => String(f?.name).toLocaleLowerCase());

				let notVisibleIdx = 0;
				let visibleIdx = 0;
				for (const field of updatedFields) {
					const fieldName = field.name.toLocaleLowerCase();

					if (
						notVisibleIdx < notVisibleColumns.length &&
						fieldName === notVisibleColumns[notVisibleIdx]
					) {
						const fld = updatedFieldsMap.get(fieldName);
						if (fld) {
							orderedFieldsFromTable.push(fld);
							notVisibleIdx++;
						}
						continue;
					}
					if (visibleIdx < tableColumns.length) {
						const tableName = tableColumns[visibleIdx].toLocaleLowerCase();
						const fld = updatedFieldsMap.get(tableName);
						if (fld) {
							orderedFieldsFromTable.push(fld);
							visibleIdx++;
						}
					}
				}
			} else {
				for (const id of tableColumns) {
					const fld = updatedFieldsMap.get(id);
					if (fld) {
						orderedFieldsFromTable.push(fld);
					}
				}
			}
			setUpdatedFields(orderedFieldsFromTable);

			//Get column order
			const colOrder = event.columnApi
				.getColumnState()
				.map((c) => c.colId)
				.join(',');

			// Save column order to localStorage
			saveColumnPreferences(colOrder);
		}
	};

	const onColumnVisible = (event: ColumnVisibleEvent<any, any>) => {
		if (event && event.api) {
			const tableColumns = event.columnApi
				.getColumnState()
				.filter((c) => !c.hide)
				.map((x) => x.colId.toLocaleLowerCase());
			setVisibleColumns(tableColumns.map((col) => col.toLocaleLowerCase()));
			const newFields = localFields
				.filter((f) => tableColumns.includes(f.name.toLocaleLowerCase()))
				.map((col) => ({
					name: col.name.toLocaleLowerCase(),
					isProperty: col.isProperty,
					propertyType: col.propertyType,
					propertyId: col.propertyId,
				}));
			onColumnVisibilityChange(newFields);
		}
	};

	const onFirstDataRendered = () => {
		if (initialSkip && pageSize && !loading && gridApi) {
			// if initial skip is provided, then scroll to that row
			let displayRowCount = gridApi.getDisplayedRowCount();
			if ((displayRowCount || 0) < initialSkip + 1) {
				gridApi.setRowCount(initialSkip + 1, false);
			}
			gridApi.ensureIndexVisible(initialSkip, 'top');
		}
	};

	const onGridReady = (event: GridReadyEvent) => {
		setGridApis(event.api);
		if (setReportGridApi) {
			setReportGridApi(event.api);
		}
		if (onColumnVisibilityChange) {
			setVisibleColumns(
				localFields
					.filter((f) => f.isDefault)
					.map((col) => col.name.toLocaleLowerCase())
			);
			onColumnVisibilityChange(
				localFields
					.filter((f) => f.isDefault)
					.map((col) => ({
						name: col.name.toLocaleLowerCase(),
						isProperty: col.isProperty,
						propertyType: col.propertyType,
						propertyId: col.propertyId,
					}))
			);
		}
		if (onSortUpdated) {
			onSortUpdated({
				field: defaultSortField,
				sort: defaultSortOrder as sortType,
			});
			setSortData({
				field: defaultSortField,
				sort: defaultSortOrder as sortType,
			});
			// Initialize last sent sort to prevent immediate duplicate effect
			lastSentSortRef.current = {
				field: defaultSortField,
				sort: defaultSortOrder as sortType,
			};
		}
	};

	const onSortChanged = (event: {
		columnApi: { getColumnState: () => any[] };
	}) => {
		const sortModal = event.columnApi
			.getColumnState()
			.filter((c: { sort: null }) => c.sort != null)
			.map((s: { colId: any; sort: any; sortIndex: any }) => ({
				colId: s.colId,
				sort: s.sort,
				sortIndex: s.sortIndex,
			}));

		if (sortModal.length > 0) {
			const { colId, sort } = sortModal[0];
			//onSortUpdated({ field: colId, sort: sort as sortType });
			 setSortData({ field: colId, sort: sort as sortType });
			shouldFetchDataRef.current = true; // reset shouldFetchData to true to fetch data again
		}
		// Use latest columnOrder state (or better: recompute)
		const currentOrder = event.columnApi
			.getColumnState()
			.map((c) => c.colId)
			.join(',');
		// Save sorting and column order to localStorage
		saveColumnPreferences(currentOrder);
	};

	// Debounced external sort notification to avoid feedback loops
	useEffect(() => {
		if (!onSortUpdated) return;
		const current = sortData;
		const last = lastSentSortRef.current;
		// Skip if identical to last notified sort
		if (last && last.field === current.field && last.sort === current.sort) {
			return;
		}
		// Debounce calls to parent
		if (sortDebounceTimerRef.current) {
			clearTimeout(sortDebounceTimerRef.current);
		}
		sortDebounceTimerRef.current = setTimeout(() => {
			try {
				onSortUpdated({ field: current.field, sort: current.sort });
				lastSentSortRef.current = { field: current.field, sort: current.sort };
			} catch (err) {
				console.error('Error in onSortUpdated callback:', err);
			}
		}, 200);
		return () => {
			if (sortDebounceTimerRef.current) {
				clearTimeout(sortDebounceTimerRef.current);
				sortDebounceTimerRef.current = null;
			}
		};
	}, [sortData, onSortUpdated]);

	// Add new function to save column preferences
	const saveColumnPreferences = (columnOrder: string) => {
		if (!UserId || !tenantUniqId) return;

		try {
			let userData: UserPreferencesStore = {};
			const existingUserData = localStorage.getItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY
			);

			if (existingUserData) {
				userData = JSON.parse(existingUserData) as UserPreferencesStore;
			}

			const userTenantKey = getUserTenantKey(UserId, tenantUniqId);

			// Initialize structure if it doesn't exist
			if (!userData[userTenantKey]) {
				userData[userTenantKey] = { reports: [] };
			}

			if (!userData[userTenantKey].reports) {
				userData[userTenantKey].reports = [];
			}

			// Find existing report or create new one
			// Merge preferences without overwriting other stored fields
			const existingReports = userData[userTenantKey].reports;
			const existingReportData = existingReports.find(
				(report: { reportId: string }) => report.reportId === reportId
			);

			const updatedReportData: ReportPreferences = {
				...(existingReportData || {}),
				reportId: reportId,
				hiddenColumnNames:
					gridHiddenColumns ?? existingReportData?.hiddenColumnNames ?? [],
				columnOrder: columnOrder ?? existingReportData?.columnOrder ?? '',
			};

			userData[userTenantKey].reports = [
				...existingReports.filter(
					(report: { reportId: string }) => report.reportId !== reportId
				),
				updatedReportData,
			];

			// Save the updated structure back to localStorage
			localStorage.setItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY,
				JSON.stringify(userData)
			);
		} catch (error) {
			console.error('Error saving column preferences to localStorage:', error);
		}
	};

	return (
		<div className='async-report-grid-container'>
			{enableRefreshPreview && GridRefreshTag}
			<div
				className={
					enableRefreshPreview
						? 'async-report-grid-padded'
						: 'async-report-grid'
				}
			>
				<ErrorBoundary>
					<AsyncDataGrid
						//Aux controls
						toolbarAuxControls={<ToolbarControls />}
						//empty state
						showNoRowsOverlayOnEmpty
						noRowsOverlayContent={noRowsOverlayContent}
						//style
						hideSortingSelector
						components={components}
						//loading
						className={loading ? 'skeleton sk-table' : ''}
						// data section
						columnTypes={columnTypes}
						columnDefs={localReportSchema}
						serverSideDatasource={dataSource}
						//infinite scroll
						rowModelType={'infinite'}
						cacheBlockSize={pageSize}
						cacheOverflowSize={1}
						infiniteInitialRowCount={1}
						//events
						onGridReady={onGridReady}
						onColumnVisible={onColumnVisible}
						onFirstDataRendered={onFirstDataRendered}
						onSortChanged={onSortChanged}
						onColumnMoved={onColumnMoved}
						//defs
						defaultColDef={defaultColDef}
						filterDefs={filterDef}
						localization={localizationDefs}
						tooltipShowDelay={0}
						//filter //used to inject extra fields to be recieved in getrows method
						filterValues={filterValues}
						//tracking
						trackingIds={trackingIds}
						theme={seismicTheme({
							useGlobal: true,
							defaultPortalContainerSelector: '.mntl-portals',
							localization: {
								languageCode: languageCode as LanguageCode,
								translations: mantleTranslations,
							},
						})}
						//modules
						modules={[CsvExportModule, RangeSelectionModule, ClipboardModule]}
					/>
				</ErrorBoundary>
			</div>
		</div>
	);
};
