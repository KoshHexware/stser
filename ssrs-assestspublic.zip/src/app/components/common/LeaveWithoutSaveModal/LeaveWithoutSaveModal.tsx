import React, { useContext, useEffect, useState } from 'react';
import './LeaveWithoutSaveModal.scss';
import { Button, Modal } from '@seismic/mantle';

import { CompileReportContext, ReportDataContext } from '../../../../contexts';
import { useTranslation } from 'react-i18next';
import { useAccessLevel, useApplicationInfo } from '../../../../contexts/CommonServicesContext';
import { CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, EDITOR_ACCESS_LEVEL } from '../../../../utils/constants';

interface LeaveWithoutSaveModalProps {
  onSave: (closeAfterSave: boolean, isSaveCopyClicked: boolean) => void;
  onSaveCopy: () => void;
  goToReportsList: () => void;
}

const LeaveWithoutSaveModal: React.FC<LeaveWithoutSaveModalProps> = ({ onSave, onSaveCopy, goToReportsList }) => {
  const { t } = useTranslation();
  const { showLeaveWithoutSaveModal, setShowLeaveWithoutSaveModal } =
    useContext(CompileReportContext);

  const {
    selectedReport,
    reportMetadata,
  } = useContext(ReportDataContext);

  const accessLevel = useAccessLevel();
  const isEditor = accessLevel == EDITOR_ACCESS_LEVEL
  const isCustomReportEditor = accessLevel == CUSTOM_REPORT_EDITOR_ACCESS_LEVEL;

  const applicationInfo = useApplicationInfo();
  const { UserId } = applicationInfo.User;
  const [isReportOwner, setIsReportOwner] = useState(false);

  useEffect(() => {
    if (reportMetadata?.ownerUserId)
      setIsReportOwner(reportMetadata?.ownerUserId === UserId);
  }, [reportMetadata]);

  const Header = (props) => {
    const { title, titleId } = props;
    const renderHeader = () => {
      return (
        <div className='leave-without-save-modal-header-div'>
          <h3 className='leave-without-save-modal-header-text' id={titleId}>
            {title}
          </h3>
        </div>
      );
    };
    return renderHeader();
  };

  const Footer = (props) => {
    return (
      <div className='leave-without-save-modal-footer-div'>
        <Button
          data-atmt-id='MY.MODAL.FOOTER.BUTTON.CANCEL'
          className='trk_button_ssrs-report-leave-without-save-modal-footer-cancel-button'
          onClick={() => {
            setShowLeaveWithoutSaveModal(false);
            goToReportsList();
          }}
          label={t('self_service_reports_discard_changes', 'Discard changes')}
          variant='tertiary'
        />
        <Button
          data-atmt-id='MY.MODAL.FOOTER.BUTTON.CTA'
          label={t('self_service_reports_Save_and_leave', 'Save and leave')}
          className='trk_button_ssrs-report-leave-without-save-modal-footer-save-button'
          variant='primary'
          onClick={() => {
            setShowLeaveWithoutSaveModal(false);
            if ((selectedReport?.reportType?.toLowerCase() === 'system')
              || ((isEditor || isCustomReportEditor) && !isReportOwner)) {
              onSaveCopy();
            } else {
              onSave(true, false);
            }
          }}
        />
      </div>
    );
  };

  return (
    <>
      <Modal
        className='ui-theme-root ecsc-permission-modal leave-without-save-modal-main-mntl-component'
        open={showLeaveWithoutSaveModal}
        onClose={() => setShowLeaveWithoutSaveModal(false)}
        modalAriaLabel={t(
          'self_service_reports_leave_without_save_modal_arialabel',
          'Leave without save modal'
        )}
        closeOnOutsideClick
        header={(titleId) => {
          return (
            <Header
              title={t(
                'self_service_reports_leave_without_save_modal_header',
                'Leave without saving?'
              )}
              titleId={titleId}
              hideTitle={false}
            />
          );
        }}
      >
        {() => (
          <>
            <section className='leave-without-save-modal-description-section'>
              <div className='leave-without-save-modal-description-text-div'>
                {t(
                  'self_service_reports_leave_without_save_modal_description',
                  'You have unsaved changes. Are you sure you’d like to navigate away without saving?'
                )}
              </div>
            </section>
            <Footer />
          </>
        )}
      </Modal>
    </>
  );
};

export default LeaveWithoutSaveModal;
