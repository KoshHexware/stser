import React from "react";
import "./FullScreenLoading.scss";
import { Spinner } from "@seismic/mantle";

type FullScreenLoadingProps = {
  loading: boolean;
};

export const FullScreenLoading = ({ loading }: FullScreenLoadingProps) => {
  if (loading === false) return <></>;

  return (
    <div className="ssrs-scorecard-loader">
      <Spinner size={48} />
    </div>
  );
};
