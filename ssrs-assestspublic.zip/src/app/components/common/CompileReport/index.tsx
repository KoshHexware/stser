import { useEffect, useState } from 'react';
import { default as CompileReportWithoutWrapper } from './CompileReport';
import CompileReportState, {
  compileReportInitialState,
} from '../../../../contexts/CompileReportState';
import { FullScreenLoading } from '../FullScreenLoading';
import { Modal } from '@seismic/mantle';
import { getRefinedFilters } from '../../../../utils/reportFiltersUtils';
import { ErrorBoundary } from '../ErrorBoundary';
import FieldAndFilterActionsState from '../../../../contexts/FieldAndFilterActionsState';
import { FieldAndFilterActionsInitialState } from '../../../../contexts/FieldAndFilterActionsState';
import { IReportMetadata } from '../../../../interfaces/IReport';

type ICompileReport = {
  reportMetadata: IReportMetadata;
  isLoading: boolean;
  onSave: (reportMetadata: IReportMetadata) => void;
  isSaving: boolean;
  isSaved: boolean;
  flashErrorMessage: {
    triggerFlash: boolean;
    message: string;
  };
  resetFlashErrorMessage: () => void;
  saveAndClose: () => void;
  isEditStandard?: boolean;
  isSaveCopyClicked?: boolean;
  isNew?: boolean;
  isEditReportMode?: boolean;
  mode?: string;
}

const CompileReport = (props : ICompileReport) => {
  const {
    reportMetadata,
    isLoading,
    onSave,
    isSaving,
    isSaved,
    flashErrorMessage,
    resetFlashErrorMessage,
    saveAndClose,
    isEditStandard = false,
    isSaveCopyClicked = false,
    isNew = false,
    isEditReportMode = false,
    mode,
  } = props;
  const [compileStates, setCompileStates] = useState<any>();
  const [compileFieldAndFilterStates, setCompileFieldAndFilterStates] =
    useState<any>();

  useEffect(() => {
    if (
      !isLoading &&
      !isSaving &&
      reportMetadata &&
      !flashErrorMessage?.triggerFlash
    ) {
      const {
        id,
        systemReportId,
        reportName,
        description,
        orderField,
        orderBy,
        standardReportMetadata,
        ownerUserId,
        showTeamsitePicker,
        teamsites,
        appliedFilters,
        requestedFields,
      } = reportMetadata as IReportMetadata;
      const { filterGroup, fieldGroups, filterCategoryOrder } = standardReportMetadata;
      const fieldsFromReport = requestedFields
        ?.filter((f) => f.isDefault)
        ?.map((field) => field.name);
      const addColumnFields = fieldGroups
        .map((group) => group.fields)
        .flat()
        .map((field) => {
          fieldsFromReport?.includes(field.name)
            ? (field.isDefault = true)
            : (field.isDefault = false);
          return field;
        });
      const refinedFilters = getRefinedFilters(appliedFilters, filterGroup);
      setCompileStates({
        id,
        reportName,
        description,
        orderField,
        orderBy,
        ownerUserId,
        fields: requestedFields?.filter((f) => f.isDefault),
        filters: JSON.parse(JSON.stringify(refinedFilters)),
        updatedFilters: JSON.parse(JSON.stringify(refinedFilters)),
        isChanged: false,
        isSaved: isSaved,
        systemReportId: isNew ? id : systemReportId,
        updatedReportName: reportName,
        updatedDescription: description,
        updatedFields: requestedFields ? JSON.parse(
          JSON.stringify(requestedFields?.filter((f) => f.isDefault))
        ) : [],
        updatedOrderBy: orderBy,
        updatedOrderField: orderField,
        addColumnFields: addColumnFields,
        showTeamsitePicker: showTeamsitePicker,
        teamsites: teamsites,
      });

      const initialDefaultFields = standardReportMetadata ? JSON.parse(
        JSON.stringify(standardReportMetadata)
      ).fieldGroups?.map((group) => {
        return {
          fields: group.fields?.map((field) => {
            field.isDefault = fieldsFromReport?.includes(field.name);
            return field;
          }),
          uxLabel: group.uxLabel,
        };
      }) : [];
      const filtersFromReport = appliedFilters?.map((filter) => filter.filterName);
      const initialDefaultFilters = filterGroup ? JSON.parse(
        JSON.stringify(filterGroup)
      )?.map((filterGroup) => {
        return {
          filters: filterGroup.filters?.map((filter) => {
            filter.isDefault = filtersFromReport?.includes(filter.filterName);
            return filter;
          }),
          uxLabel: filterGroup.uxLabel,
        };
      }) : [];

      if (filterCategoryOrder && filterCategoryOrder?.length > 0) {
        initialDefaultFilters.sort((a, b) => {
          const indexA = filterCategoryOrder.indexOf(a.uxLabel);
          const indexB = filterCategoryOrder.indexOf(b.uxLabel);

          if (indexA !== -1 && indexB !== -1) {
            return indexA - indexB;
          }
          if (indexA !== -1) return -1;
          if (indexB !== -1) return 1;

          return a.uxLabel.localeCompare(b.uxLabel);
        });
      }

      const totalItems = fieldGroups
        .map((group) => group.fields)
        .flat();
      const totalItemsSelected = totalItems?.filter((f) => f.isDefault)?.length;
      setCompileFieldAndFilterStates({
        totalItemsSelected: totalItemsSelected,
        isFieldsDoneClicked: false,
        isFieldsCancelClicked: false,
        isFiltersDoneClicked: false,
        isFiltersCancelClicked: false,
        currentCategorySelected: 'All',
        isToggled: false,
        finalUpdatedFields: fieldGroups,
        initialFields: initialDefaultFields,
        fields: requestedFields?.filter((f) => f.isDefault),
        updatedFields: requestedFields?.filter((f) => f.isDefault),
        initialFilters: initialDefaultFilters,
        finalUpdatedFilters: initialDefaultFilters,
        currentActiveTab: 'Table',
        reportMetadata: reportMetadata,
      });
    }
  }, [isLoading, isSaved, isSaving]);

  return compileStates && !isLoading && compileFieldAndFilterStates ? (
    <ErrorBoundary>
      <FieldAndFilterActionsState
        values={{
          ...FieldAndFilterActionsInitialState,
          ...compileFieldAndFilterStates,
        }}
      >
        <CompileReportState
          values={{ ...compileReportInitialState, ...compileStates }}
        >
          <CompileReportWithoutWrapper
            isLoading={isLoading}
            onSave={onSave}
            reportMetadata={reportMetadata}
            flashErrorMessage={flashErrorMessage}
            isSaving={isSaving}
            isSaved={isSaved}
            resetFlashErrorMessage={resetFlashErrorMessage}
            compileStates={compileStates}
            isEditStandard={isEditStandard}
            isEditReportMode={isEditReportMode}
            isSaveCopyClicked={isSaveCopyClicked}
            mode={mode}
          />
        </CompileReportState>
      </FieldAndFilterActionsState>
    </ErrorBoundary>
  ) : (
    //NOTE: Will Remove spinner
    <div className='compile-report-container'>
      <Modal fullscreen inverted displayCloseButton={false}>
        {() => <FullScreenLoading loading={isLoading} />}
      </Modal>
    </div>
  );
};

export default CompileReport;
