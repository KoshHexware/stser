import React, { useContext, useState, useEffect, useMemo } from 'react';
import './CompileFieldAndFilterAction.scss';
import { Banner, Button, IconAdd, Modal } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import {
  CompileReportContext,
  FieldAndFilterContext,
} from '../../../../../../contexts';
import FieldAndFilterActions from '../CompileFieldAndFilterActions/FieldAndFilterActions/FieldAndFilterActions';
import FieldAndFilterCategories from '../CompileFieldAndFilterActions/FieldAndFilterCategories/FieldAndFilterCategories';
import SearchItems from './SearchItems/SearchItems';
import {
  COLOMNSELECTIONLIMIT,
  COMPILE_FIELD_FILTERS_ACTIONS,
  EDITOR_ACCESS_LEVEL,
  VIEWER_ACCESS_LEVEL,
} from '../../../../../../utils/constants';
import RenderColumns from './RenderColumns/RenderColumns';
import RenderFilters from './RenderFilters/RenderFilters';
import {
  getSelectedSortItems,
  getDisplayFilters,
  sortItems,
} from '../../../../../../utils/reportFiltersUtils';
import { ErrorBoundary } from '../../../ErrorBoundary';
import { useAccessLevel } from '../../../../../../contexts/CommonServicesContext';
import { vi } from 'date-fns/locale';

const CompileFieldAndFilterActions = () => {
  const [showModal, setModalVisibility] = useState<boolean>(false);
  const [showErrorBanner, setShowErrorBanner] = useState<boolean>(false);
  const { setUpdatedFields } = useContext(CompileReportContext);
  const [searchColumn, setSearchColumn] = useState<string>('');
  const {
    COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE,
    COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL,
    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS,
  } = COMPILE_FIELD_FILTERS_ACTIONS;

  const {
    totalItemsSelected,
    setTotalItemsSelected,
    currentCategorySelected,
    finalUpdatedFields,
    setFinalUpdatedFields,
    isToggled,
    isClearedClicked,
    setIsToggle,
    resetFieldFilterStates,
    setIsDoneButtonClicked,
    currentActiveTab,
    finalUpdatedFilters,
    setFinalUpdatedFilters,
    reportMetadata,
    setCurrentCategorySelected,
  } = useContext(FieldAndFilterContext);

  const accessLevel = useAccessLevel();
  const isEditor = accessLevel === EDITOR_ACCESS_LEVEL;
  const isViewer = accessLevel === VIEWER_ACCESS_LEVEL;

  const {
    updatedFields,
    fields,
    updatedFilters,
    setIsFilterCardClicked,
    currentSelectedFilter,
    setUpdatedFilters,
    setIsNewFilterAdding,
  } = useContext(CompileReportContext);

  const [filterColumns, setFilterColumns] = useState([]);
  const [isFilterListIsClicked, setIsFilterListIsClicked] =
    useState<boolean>(false);
  const { t } = useTranslation();
  const [recentCheckedFields, setRecentCheckedFields] = useState([]);
  const [isNoSearchResult, setIsNoSearchResult] = useState<boolean>(false);
  const [clearedItems, setIsClearedItems] = useState([]);

  const allUpdatedFilters = useMemo(() => {
    return JSON.parse(JSON.stringify(finalUpdatedFilters))
      ?.map((item) => {
        return item.filters;
      })
      .flat();
  }, [finalUpdatedFilters]);

  useEffect(() => {
    if (currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS) {
      if (
        currentCategorySelected === COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL
      ) {
        setFilterColumns(sortItems(allUpdatedFilters));
      } else {
        const reqUpdatedFilterGroup = finalUpdatedFilters?.find((filter) => {
          return filter?.uxLabel === currentCategorySelected;
        });
        setFilterColumns(sortItems(reqUpdatedFilterGroup?.filters));
      }
    }
  }, [currentCategorySelected, finalUpdatedFilters]);

  const allUpdatedFeilds = useMemo(() => {
    return finalUpdatedFields
      ?.map((item) => {
        return item.fields;
      })
      .flat();
  }, [finalUpdatedFields]);

  useEffect(() => {
    if (currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE) {
      if (
        currentCategorySelected === COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL
      ) {
        if (isToggled) {
          setFilterColumns(getSelectedSortItems(allUpdatedFeilds));
        } else {
          setFilterColumns(sortItems(allUpdatedFeilds));
        }
      } else {
        const reqUpdatedFieldGroup = finalUpdatedFields?.find((field) => {
          return field?.uxLabel === currentCategorySelected;
        });
        if (isToggled) {
          setFilterColumns(getSelectedSortItems(reqUpdatedFieldGroup?.fields));
        } else {
          setFilterColumns(sortItems(reqUpdatedFieldGroup?.fields));
        }
      }
    }
  }, [
    currentCategorySelected,
    finalUpdatedFields,
    isClearedClicked,
    isToggled,
  ]);

  useEffect(() => {
    setFinalUpdatedFilters(
      JSON.parse(
        JSON.stringify(getDisplayFilters(finalUpdatedFilters, updatedFilters))
      )
    );
  }, [updatedFilters]);

  useEffect(() => {
    if (totalItemsSelected >= COLOMNSELECTIONLIMIT) {
      setShowErrorBanner(true);
    } else {
      setShowErrorBanner(false);
    }
  }, [totalItemsSelected]);

  const updateCheckedFields = (e) => {
    const { id, checked } = e.target;
    let updatedGroupFields;
    setTotalItemsSelected(totalItemsSelected + 1);
    if (
      currentCategorySelected === COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL
    ) {
      updatedGroupFields = finalUpdatedFields.map((field) => {
        field.fields = field.fields.map((column) => {
          if (column.name === id) {
            column.isDefault = checked;
            setRecentCheckedFields([...recentCheckedFields, column]);
          }
          return column;
        });
        return field;
      });
    } else {
      updatedGroupFields = finalUpdatedFields?.map((field) => {
        if (field.uxLabel === currentCategorySelected) {
          field.fields?.map((column) => {
            if (column.name === id) {
              column.isDefault = checked;
              setRecentCheckedFields([...recentCheckedFields, column]);
            }
            return column;
          });
        }
        return field;
      });
    }
    if (checked) {
      setTotalItemsSelected(totalItemsSelected + 1);
    } else {
      setTotalItemsSelected(totalItemsSelected - 1);
    }
    setFinalUpdatedFields(updatedGroupFields);
  };

  const clearItemsFromUpdatedFields = (clearedItem, updatedFields) => {
    const updatedFieldsClone = [...updatedFields];
    updatedFieldsClone?.map((updatedField) => {
      if (clearedItem.name === updatedField.name) {
        updatedField.isDefault = false;
      }
      return updatedField;
    });
    return updatedFieldsClone;
  };

  const constructUpdatedFields = (recentCheckedField, updatedFields) => {
    const updatedFieldsClone = [...updatedFields];
    let isFound = false;
    updatedFieldsClone?.map((updatedField) => {
      if (recentCheckedField.name === updatedField.name) {
        isFound = true;
        updatedField.isDefault = recentCheckedField.isDefault;
      }
      return updatedField;
    });
    if (!isFound) {
      updatedFieldsClone.push(recentCheckedField);
    }
    return updatedFieldsClone;
  };

  return (
    <>
      {!isViewer && (
        <Button
          className={`compile-field-filter-btn ${
            currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
              ? 'trk_button_ssrs-report_edit-add-column'
              : 'trk_button_ssrs-report_edit-add-filters'
          }`}
          variant='secondary'
          startAdornment={IconAdd}
          onClick={() => setModalVisibility(true)}
          label={
            currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
              ? t('self_service_reports_add_column', 'Add column')
              : t('self_service_reports_add_filter', 'Add filter')
          }
        />
      )}
      <Modal
        open={showModal}
        onClose={() => {
          resetFieldFilterStates({ reportMetadata, updatedFields, fields });
          setModalVisibility(false);
          setSearchColumn('');
          setIsFilterListIsClicked(false);
          setRecentCheckedFields([]);
          setIsClearedItems([]);
        }}
        className='compile-field-filter-modal'
        closeOnOutsideClick={false}
        header={() => {
          return (
            <>
              <h2>
                {currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                  ? t(
                      'self_service_reports_search_column_selection',
                      'Column selection'
                    )
                  : t(
                      'self_service_reports_search_filter_selection',
                      'Filter selection'
                    )}
              </h2>
            </>
          );
        }}
        style={{ width: 924, height: 558 }}
        footer={
          <footer
            className={`${
              currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                ? 'compile-field-filter-modal-footer'
                : ''
            }`}
          >
            {currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE ? (
              <div>
                {showErrorBanner ? (
                  <Banner
                    variant='warning'
                    message={t(
                      'self_service_reports_col_selection_limit_reach_msg',
                      {
                        columnSelectionLimit: COLOMNSELECTIONLIMIT,
                        defaultValue: `You have reached a maximum limit of ${COLOMNSELECTIONLIMIT} columns. Kindly review.`,
                      }
                    )}
                    onDismiss={() => {
                      setShowErrorBanner(false);
                    }}
                  />
                ) : (
                  <span className='compile-field-filter-total-selected'>
                    {`${t(
                      'self_service_reports_fields_total_selected',
                      'Total Selected'
                    )}  (${totalItemsSelected})`}
                  </span>
                )}
              </div>
            ) : (
              <></>
            )}
            <div
              className={`${
                currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS
                  ? 'compile-field-filter-modal-filter-footer'
                  : ''
              }`}
            >
              <Button
                variant='secondary'
                label={t('self_service_reports_cancel', 'Cancel')}
                onClick={() => {
                  if (
                    currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS
                  ) {
                    setCurrentCategorySelected('All');
                    setIsFilterListIsClicked(false);
                  } else if (
                    currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                  ) {
                    resetFieldFilterStates({
                      reportMetadata,
                      updatedFields,
                      fields,
                    });
                  }
                  setModalVisibility(false);
                  setSearchColumn('');
                  setRecentCheckedFields([]);
                  setIsClearedItems([]);
                }}
                type='button'
                className={`compile-field-filter-cancel ${
                  currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                    ? 'trk_button_ssrs-report-add-column-cancel-modal'
                    : 'trk_button_ssrs-report-add-filter-cancel-modal'
                  }`}
              />
              <Button
                variant='primary'
                label={t('self_service_reports_fields_filters_done', 'Done')}
                onClick={() => {
                  if (
                    currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS
                  ) {
                    const newFilter = currentSelectedFilter;
                    newFilter.values = [];
                    newFilter.isNewlyAdded = true;
                    setUpdatedFilters([...updatedFilters, newFilter]);
                    setIsFilterCardClicked(true);
                    setIsNewFilterAdding(true);
                    setIsFilterCardClicked(true);

                    const updatedIsDefaultFilters = finalUpdatedFilters?.map(
                      (groupFilters) => {
                        if (
                          groupFilters?.uxLabel ===
                          currentSelectedFilter?.category
                        ) {
                          groupFilters?.filters?.map((filter) => {
                            if (
                              filter?.filterName ===
                              currentSelectedFilter?.filterName
                            ) {
                              filter.isDefault = true;
                            }
                            return filter;
                          });
                        }
                        return groupFilters;
                      }
                    );
                    setFinalUpdatedFilters(updatedIsDefaultFilters);
                    setIsFilterListIsClicked(false);
                  } else if (
                    currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                  ) {
                    let updatedFieldsClone = [...updatedFields];
                    if (clearedItems.length > 0) {
                      clearedItems?.forEach((clearedItem) => {
                        updatedFieldsClone = clearItemsFromUpdatedFields(
                          clearedItem,
                          updatedFieldsClone
                        );
                      });
                    }
                    recentCheckedFields?.forEach((field) => {
                      updatedFieldsClone = constructUpdatedFields(
                        field,
                        updatedFieldsClone
                      );
                    });
                    const finalVisibleUpdatedFields = updatedFieldsClone.filter(
                      (field) => {
                        return field.isDefault;
                      }
                    );
                    setUpdatedFields(finalVisibleUpdatedFields);
                    setRecentCheckedFields([]);
                    setIsClearedItems([]);
                  }
                  setModalVisibility(false);
                  setIsDoneButtonClicked(true);
                  setIsToggle(false);
                  setSearchColumn('');
                }}
                type='button'
                className={`compile-field-filter-done ${
                  currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                    ? 'trk_button_ssrs-report_add-column-done_modal'
                    : 'trk_button_ssrs-report_add-filter-done_modal'
                }`}
                disabled={
                  (currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE &&
                    totalItemsSelected < 1) ||
                  (currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS &&
                    !isFilterListIsClicked)
                }
              />
            </div>
          </footer>
        }
      >
        <>
          <ErrorBoundary>
            <div className='field-filter-container'>
              <div className='mntl-scrollbar field-filter-categories-container'>
                <FieldAndFilterCategories setSearchColumn={setSearchColumn} />
              </div>
              <div className='field-filter-devider'></div>
              <div className='compile-field-filter'>
                <div
                  className={`compile-field-filter-top ${
                    currentActiveTab ===
                    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS
                      ? 'compile-field-filter-top-filters-css'
                      : ''
                  }`}
                >
                  <SearchItems
                    searchColumn={searchColumn}
                    setSearchColumn={setSearchColumn}
                  />
                  {currentActiveTab ===
                  COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE ? (
                    <>
                      <FieldAndFilterActions
                        items={filterColumns}
                        setSearchColumn={setSearchColumn}
                        clearedItems={clearedItems}
                        setIsClearedItems={setIsClearedItems}
                      />
                    </>
                  ) : (
                    <></>
                  )}
                </div>
                <div className='compile-field-filter-hr'>
                  <hr />
                </div>
                <div className='compile-field-filter-content-items'>
                  {currentActiveTab ===
                  COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE ? (
                    <RenderColumns
                      itemsToRender={filterColumns}
                      updateCheckedFields={updateCheckedFields}
                      isNoSearchResult={isNoSearchResult}
                      searchColumn={searchColumn}
                      setIsNoSearchResult={setIsNoSearchResult}
                    />
                  ) : (
                    <RenderFilters
                      itemsToRender={filterColumns}
                      setIsFilterListIsClicked={setIsFilterListIsClicked}
                      isNoSearchResult={isNoSearchResult}
                      searchColumn={searchColumn}
                      setIsNoSearchResult={setIsNoSearchResult}
                    />
                  )}
                </div>
              </div>
            </div>
          </ErrorBoundary>
        </>
      </Modal>
    </>
  );
};

export default React.memo(CompileFieldAndFilterActions);
