import React, { useContext, useEffect, useMemo } from 'react';
import { Checkbox } from '@seismic/mantle';
import getTypeIcon from '../../../../../../../utils/getTypeIcons';
import { NoSearchItems } from '../../../../EmptyState/NoSearchItems';
import {
  FieldAndFilterContext,
} from '../../../../../../../contexts';
import { NothingToView } from '../../../../EmptyState/NothingToView';
import { CompileReportContext } from '../../../../../../../contexts';
import { COLOMNSELECTIONLIMIT, CONTENT_CUSTOM_PROPERTY } from '../../../../../../../utils/constants';

type RenderColumnsProps = {
  itemsToRender: any;
  updateCheckedFields: (e: any) => void;
  isNoSearchResult: boolean;
  searchColumn: string;
  setIsNoSearchResult: (isNoSearchResult: boolean) => void;
};

const RenderColumns = (props: RenderColumnsProps) => {
  const {
    itemsToRender,
    updateCheckedFields,
    isNoSearchResult,
    searchColumn,
    setIsNoSearchResult,
  } = props;
  const noCheckedItemsPresent = JSON.parse(JSON.stringify(itemsToRender))?.some(
    (item) => item.isDefault
  );
  const { isToggled, totalItemsSelected, reportMetadata } = useContext(
    FieldAndFilterContext
  );
  const { id, reportName, updatedTeamsites } = useContext(CompileReportContext);

  const selectedTeamsitesIds = updatedTeamsites
    ?.filter((teamsite) => teamsite.isSelected)
    .map((teamsite) => teamsite.id);

  const filteredItems = useMemo(() => {
    const localSearchColumn = searchColumn.toLowerCase();
    return itemsToRender.filter((value) => {
      return searchColumn === ''
        ? value
        : value?.uxLabel?.toLowerCase()?.includes(localSearchColumn) ||
        value?.uxDescription?.toLowerCase()?.includes(localSearchColumn);
    });
  }, [searchColumn, itemsToRender]);

  useEffect(() => {
    if (filteredItems.length === 0) {
      setIsNoSearchResult(true);
    } else {
      setIsNoSearchResult(false);
    }
  }, [searchColumn]);

  return (
    <div className='mntl-scrollbar compile-field-filter-container'>
      <>
        {filteredItems &&
          filteredItems.map((column) => {
            if (
              column?.isProperty &&
              column?.propertyType === CONTENT_CUSTOM_PROPERTY
            ) {
              const isMatch = column.teamsiteIds?.some((teamsiteId: string) =>
                selectedTeamsitesIds.includes(teamsiteId)
              );
              if (!isMatch) {
                return null;
              }
            }
            return (
              <div className='compile-field-filter-item' id={column.name}>
                <div className='compile-field-filter-item-checkbox'>
                  <Checkbox
                    checked={column.isDefault}
                    onChange={(e) => {
                      if (
                        totalItemsSelected < COLOMNSELECTIONLIMIT ||
                        !e.target.checked
                      ) {
                        updateCheckedFields(e);
                      }
                    }}
                    id={column.name}
                    aria-label={column.uxLabel}
                    className='trk_checkbox_ssrs-report_add_column'
                    disabled={
                      totalItemsSelected >= COLOMNSELECTIONLIMIT &&
                      !column.isDefault
                    }
                  />
                </div>
                <div className='compile-field-filter-item-icon'>
                  {getTypeIcon(column.dataType)}
                </div>
                <div className='compile-field-filter-item-name-container'>
                  <div className='compile-field-filter-item-name'>
                    {column.uxLabel}
                  </div>
                  <div className='compile-field-filter-item-description'>
                    {column.uxDescription}
                  </div>
                </div>
              </div>
            );
          })}
        {isNoSearchResult && searchColumn !== '' && !isToggled && (
          <NoSearchItems size='md' />
        )}
        {(!noCheckedItemsPresent || isNoSearchResult) && isToggled && (
          <NothingToView />
        )}
      </>
    </div>
  );
};

export default React.memo(RenderColumns);
