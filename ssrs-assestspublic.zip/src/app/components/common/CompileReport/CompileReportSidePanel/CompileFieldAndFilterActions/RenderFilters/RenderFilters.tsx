import React, { useContext, useEffect, useState, useMemo } from 'react';
import './RenderFilters.scss';
import getTypeIcon from '../../../../../../../utils/getTypeIcons';
import {
  CompileReportContext,
} from '../../../../../../../contexts';
import { NoSearchItems } from '../../../../EmptyState/NoSearchItems';

type RenderFiltersProps = {
  itemsToRender: any;
  setIsFilterListIsClicked: (isFilterListIsClicked: boolean) => void;
  isNoSearchResult: boolean;
  searchColumn: string;
  setIsNoSearchResult: (isNoSearchResult: boolean) => void;
};

const RenderFilters = (props: RenderFiltersProps) => {
  const {
    itemsToRender,
    setIsFilterListIsClicked,
    isNoSearchResult,
    searchColumn,
    setIsNoSearchResult,
  } = props;
  const [selectedFilter, setSelectedFilter] = useState();
  const { setCurrentSelectedFilter } = useContext(CompileReportContext);
  const { id, reportName, updatedTeamsites } = useContext(CompileReportContext);

  const selectedTeamsitesIds = updatedTeamsites
    ?.filter((teamsite) => teamsite.isSelected)
    .map((teamsite) => teamsite.id);

  const filteredItems = useMemo(() => {
    const localSearchColumn = searchColumn.toLowerCase();
    return itemsToRender.filter((value) => {
      return searchColumn === ''
        ? value
        : value?.uxLabel?.toLowerCase()?.includes(localSearchColumn) ||
        value?.uxDescription?.toLowerCase()?.includes(localSearchColumn);
    });
  }, [searchColumn, itemsToRender]);

  useEffect(() => {
    if (filteredItems.length === 0) {
      setIsNoSearchResult(true);
    } else {
      setIsNoSearchResult(false);
    }
  }, [searchColumn]);

  return (
    <div className='mntl-scrollbar compile-field-filter-container'>
      <>
        {filteredItems &&
          filteredItems.map((filter) => {
            if (
              filter?.isProperty &&
              filter?.propertyType === 'ContentCustomProperty'
            ) {
              const isMatch = filter.teamsiteIds?.some((teamsiteId: string) =>
                selectedTeamsitesIds.includes(teamsiteId)
              );
              if (!isMatch) {
                return null;
              }
            }
            return (
              <div
                className={`trk_list_item_ssrs-report_add_filter add-extra-filters-item ${selectedFilter === filter.filterName && !filter.isDefault
                  ? 'add-extra-filters-selected-bg'
                  : ''
                  }`}
                style={{ cursor: filter.isDefault ? 'text' : 'pointer' }}
                key={filter.filterName}
                aria-label={filter.uxLabel}
                aria-disabled={filter.isDefault}
                tabIndex={0}
                onClick={(e) => {
                  if (filter.isDefault) {
                    e.stopPropagation();
                    e.preventDefault();
                    return;
                  }
                  setSelectedFilter(filter.filterName);
                  setCurrentSelectedFilter(filter);
                  setIsFilterListIsClicked(true);
                }}
                onKeyDown={(e) => {
                  if (filter.isDefault) {
                    e.stopPropagation();
                    return;
                  }
                  if (e.key === ' ') {
                    e.preventDefault();
                    setSelectedFilter(filter.filterName);
                    setCurrentSelectedFilter(filter);
                    setIsFilterListIsClicked(true);
                  }
                }}
                id={filter.filterName}
              >
                <div className='add-extra-filters-icon'>
                  {getTypeIcon(filter.dataType)}
                </div>
                <div className='add-extra-filters-item-name-container'>
                  <div
                    className={` ${filter.isDefault
                      ? 'add-extra-filters-disabled-item-name'
                      : 'add-extra-filters-item-name'
                      }`}
                  >
                    {filter.uxLabel}
                  </div>
                  <div
                    className={`${filter.isDefault
                      ? 'add-extra-filters--disabled-item-description'
                      : 'add-extra-filters-item-description'
                      }`}
                  >
                    {filter.uxDescription}
                  </div>
                </div>
              </div>
            );
          })}
      </>
      {isNoSearchResult && searchColumn !== '' && <NoSearchItems size='md' />}
    </div>
  );
};

export default React.memo(RenderFilters);
