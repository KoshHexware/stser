import React, { useContext } from 'react';
import { Input } from '@seismic/mantle';
import { FieldAndFilterContext } from '../../../../../../../contexts';
import { useTranslation } from 'react-i18next';
import { COMPILE_FIELD_FILTERS_ACTIONS } from '../../../../../../../utils/constants';

type SearchItemsProps = {
  searchColumn: string;
  setSearchColumn: (searchColumn: string) => void;
};

const SearchItems = (props: SearchItemsProps) => {
  const { searchColumn, setSearchColumn } = props;
  const { currentActiveTab } = useContext(FieldAndFilterContext);
  const { COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE } = COMPILE_FIELD_FILTERS_ACTIONS;
  const { t } = useTranslation();

  return (
    <div className="add-column-search">
      <Input
        aria-label={
          currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
            ? t('self_service_reports_search_columns', 'Search columns')
            : t('self_service_reports_search_filters', 'Search')
        }
        className={currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
              ? 'trk_input_ssrs-report_edit-search-fields'
              : 'trk_input_ssrs-report_edit-search-filters'
        }
        style={{ width: 326 }}
        value={searchColumn}
        placeholder={
          currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
            ? t('self_service_reports_search_columns', 'Search columns')
            : t('self_service_reports_search_filters', 'Search')
        }
        onChange={e => setSearchColumn(e.target.value)}
      />
    </div>
  );
};

export default React.memo(SearchItems);
