import React, { useContext, useEffect, useState, useMemo } from 'react';
import './FieldAndFilterCategories.scss';
import { NavList, Tooltip } from '@seismic/mantle';
import { FieldAndFilterContext, CompileReportContext } from '../../../../../../../contexts';
import { COMPILE_FIELD_FILTERS_ACTIONS } from '../../../../../../../utils/constants';
import { getDisplayFilters } from '../../../../../../../utils/reportFiltersUtils';
import { useTranslation } from 'react-i18next';

type FieldAndFilterActionsProps = {
  setSearchColumn: (searchColumn: string) => void;
};

const FieldAndFilterCategories = (props: FieldAndFilterActionsProps) => {
  const { setSearchColumn } = props;
  const { t } = useTranslation();
  const { setCurrentCategorySelected, currentCategorySelected, finalUpdatedFilters, currentActiveTab, reportMetadata } =
    useContext(FieldAndFilterContext);
  const { updatedFilters } = useContext(CompileReportContext);
  const [currentActiveCategoryTab, setCurrentActiveCategoryTab] = useState<string>(currentCategorySelected);
  const [totalItems, setTotalItems] = useState<number>(0);
  const {
    COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE,
    COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL,
    COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS,
  } = COMPILE_FIELD_FILTERS_ACTIONS;

  const categories =
    currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
      ? reportMetadata &&
        reportMetadata?.standardReportMetadata?.fieldGroups &&
        reportMetadata?.standardReportMetadata?.fieldGroups
      : finalUpdatedFilters;

  const fieldGroupLength = useMemo(() => {
    return reportMetadata?.standardReportMetadata?.fieldGroups?.map(group => group.fields).flat().length;
  }, [reportMetadata]);

  const filterGroupLength = useMemo(() => {
    return JSON.parse(JSON.stringify(getDisplayFilters(finalUpdatedFilters, updatedFilters)))
      ?.map(item => {
        return item.filters;
      })
      .flat()
      ?.filter(item => !item.isDefault).length;
  }, [finalUpdatedFilters, updatedFilters]);

  useEffect(() => {
    if (currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE) {
      setTotalItems(fieldGroupLength);
    } else if (currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS) {
      setTotalItems(filterGroupLength);
    }
  }, [currentActiveTab]);

  const handleCurrentCategoryItems = category => {
    setCurrentCategorySelected(category);
    setCurrentActiveCategoryTab(category);
  };

  return (
    <>
      <section className="field-filter-categories">
        <NavList className="field-filter-categories-navlist-nav" aria-labelledby="demoNavList1">
          <NavList.Item
            isActive={currentActiveCategoryTab === COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL}
            onClick={() => {
              handleCurrentCategoryItems(COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL);
              setSearchColumn('');
            }}
            className="field-filter-categories-navlist-item">
            <label>
              {t('self_service_reports_fields_filters_all', 'All')} ({totalItems})
            </label>
          </NavList.Item>
          {categories?.map(category => {
            return (
              <Tooltip position="bottom" interactiveDelay={100} zIndex={30000} content={category?.uxLabel}>
                <NavList.Item
                  isActive={currentActiveCategoryTab === category.uxLabel}
                  onClick={() => {
                    handleCurrentCategoryItems(category.uxLabel);
                    setSearchColumn('');
                  }}
                  className={`field-filter-categories-navlist-item ${
                  currentActiveTab === COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE
                    ? 'trk_button_ssrs-report-add-column-category'
                    : 'trk_button_ssrs-report-add-filter-category'
                  }`}
                >
                  <label>{category.uxLabel}</label>
                </NavList.Item>
              </Tooltip>
            );
          })}
        </NavList>
      </section>
    </>
  );
};

export default React.memo(FieldAndFilterCategories);
