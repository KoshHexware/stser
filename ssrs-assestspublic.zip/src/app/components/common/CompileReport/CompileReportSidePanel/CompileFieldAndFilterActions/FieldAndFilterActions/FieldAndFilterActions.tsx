import React, { useContext } from 'react';
import './FieldAndFilterActions.scss';
import { useTranslation } from 'react-i18next';
import { Button, Toggle } from '@seismic/mantle';
import { FieldAndFilterContext } from '../../../../../../../contexts';

type FieldAndFilterActionsProps = {
  items: any;
  setSearchColumn: (searchColumn: string) => void;
  clearedItems: any;
  setIsClearedItems: (clearedItems: any) => void;
};

const FieldAndFilterActions = (props: FieldAndFilterActionsProps) => {
  const { items, setSearchColumn, clearedItems, setIsClearedItems } = props;
  const {
    setTotalItemsSelected,
    setIsToggle,
    isToggled,
    finalUpdatedFields,
    setFinalUpdatedFields,
    currentCategorySelected,
    totalItemsSelected,
    setIsClearedClicked,
  } = useContext(FieldAndFilterContext);
  const { t } = useTranslation();
  const noCheckedItemsPresent = JSON.parse(JSON.stringify(items))?.some(item => item.isDefault);

  const clearAll = () => {
    let itemsCleared;
    let recentItemsCleared = [];
    if (currentCategorySelected === 'All') {
      itemsCleared = finalUpdatedFields.map(field => {
        field.fields = field.fields.map(item => {
          if (item.isDefault) {
            item.isDefault = false;
            recentItemsCleared.push(item);
          }
          return item;
        });
        return field;
      });
      setTotalItemsSelected(0);
    } else {
      let itemsClearedLength = 0;
      itemsCleared = finalUpdatedFields.map(field => {
        if (field.uxLabel === currentCategorySelected) {
          field.fields = field.fields.map(item => {
            if (item.isDefault) {
              itemsClearedLength++;
              item.isDefault = false;
              recentItemsCleared.push(item);
            }
            return item;
          });
        }
        return field;
      });
      setTotalItemsSelected(totalItemsSelected - itemsClearedLength);
      setSearchColumn('');
    }
    if (isToggled) {
      setIsToggle(false);
    }
    setIsClearedItems([...clearedItems, ...recentItemsCleared]);
    setFinalUpdatedFields(itemsCleared);
    setIsClearedClicked(true);
  };

  return (
    <div className="field-actions">
      <div className="field-actions-toggle-div">
        <Toggle
          checked={isToggled}
          onChange={event => {
            setIsToggle(event.target.checked);
          }}
          className="field-actions-toggle trk_checkbox_ssrs-report_add_column_filter-show_selected_column"
          size={16}
          aria-label={
            isToggled
              ? t('self_service_reports_only_show_selected_columns_is_on', 'Only show selected columns is on')
              : t('self_service_reports_only_show_selected_columns_is_off', 'Only show selected columns is off')
          }
          aria-labelledby={
            isToggled
              ? t('self_service_reports_only_show_selected_columns_is_on', 'Only show selected columns is on')
              : t('self_service_reports_only_show_selected_columns_is_off', 'Only show selected columns is off')
          }
        />
        <span className="field-actions-toggle-text">
          {t('self_service_reports_only_show_selected_columns', 'Only show selected columns')}
        </span>
      </div>
      <div>
        <Button
          className="field-actions-clear-all trk_button_ssrs-report_add_column_filter-clear_all"
          variant="secondary"
          label={t('self_service_reports_fields_filters_clear_all', 'Clear all')}
          onClick={clearAll}
          disabled={!noCheckedItemsPresent}
        />
      </div>
    </div>
  );
};

export default React.memo(FieldAndFilterActions);
