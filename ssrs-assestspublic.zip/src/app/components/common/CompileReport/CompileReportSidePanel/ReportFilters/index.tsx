import React, { useEffect, useState, useContext, useCallback } from 'react';
import './ReportFilters.scss';
import FilterCard from '../../../FilterCard/FilterCard';
import AddFilter from '../AddFilter';
import { useTranslation } from 'react-i18next';
import { IFilter } from '../../../../../../interfaces/IFilterTypes';
import { CompileReportContext } from '../../../../../../contexts';
import CompileFieldAndFilterActions from '../CompileFieldAndFilterActions';
import { ErrorBoundary } from '../../../ErrorBoundary';

const ReportFilters = ({totalHeight}) => {
  const { isFilterCardClicked, updatedFilters, setUpdatedFilters, setIsFilterCardClicked, currentSelectedFilter } =
    useContext(CompileReportContext);
  const { t } = useTranslation();
  const [visibleFilters, setVisibleShowFilters] = useState<IFilter[]>(updatedFilters);

  useEffect(() => {
    setVisibleShowFilters(updatedFilters);
  }, [updatedFilters]);

  const onRemoveFilter = useCallback(
    (filter: IFilter) => {
      const updatedFilters = visibleFilters && visibleFilters?.filter(f => f.filterName !== filter.filterName);
      setVisibleShowFilters(updatedFilters);
      setUpdatedFilters(updatedFilters);
      setIsFilterCardClicked(false);
    },
    [visibleFilters]
  );

  return (
    <ErrorBoundary>
      <div className="report-filters">
        <div className="report-filters-title-add-filter">
          <div className="report-filters-title">{t('self_service_reports_filters', 'Filters')}</div>
          <div>
            <CompileFieldAndFilterActions />
          </div>
        </div>
        <div
          className="edit-report-filters-container mntl-scrollbar"
          style={{ height: `calc(100vh - ${totalHeight + 116}px)` }}>
          <ErrorBoundary>
            {visibleFilters &&
              visibleFilters?.map(filter => {
                let isSelected =
                  isFilterCardClicked &&
                  currentSelectedFilter?.filterName?.toLowerCase() === filter?.filterName?.toLowerCase();
                return (
                  <>
                    {isSelected && <AddFilter />}
                    <FilterCard key={filter.filterName} filter={filter} onRemoveFilter={onRemoveFilter} />
                  </>
                );
              })}
          </ErrorBoundary>
        </div>
      </div>
    </ErrorBoundary>
  );
};

export default React.memo(ReportFilters);
