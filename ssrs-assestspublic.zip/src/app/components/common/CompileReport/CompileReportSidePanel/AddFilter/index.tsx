import React, { useState, useContext, useEffect } from 'react';
import './AddFilter.scss';
import { Button, Popover, Select, Spinner, Tooltip } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import GetContentType from '../GetContentType';
import {
  FILTER_TYPE,
  IBooleanOperations,
  IDateOperations,
  IFilter,
  IFilterDataType,
  IFilterError,
  INullishOperations,
  INumberOperations,
  ITextOperations,
} from '../../../../../../interfaces/IFilterTypes';
import { CompileReportContext } from '../../../../../../contexts';
import ReportService from '../../../../../../services/ReportService';
import { getRefinedAllowedOperators } from '../../../../../../utils/reportFiltersUtils';
import { ErrorBoundary } from '../../../ErrorBoundary';
import { FLOAT_MAX, FLOAT_MIN, INT_MAX, INT_MIN, EMPTY_FILTER_VALUE } from '../../../../../../utils/constants';
import { UserScopeTextMyTeamSubOperators } from '../../../../../../utils/userScopeOperatorsConstants';
const AddFilter = () => {
  const {
    setIsFilterCardClicked,
    isFilterCardClicked,
    currentSelectedFilter,
    isNewFilterAdding,
    setIsNewFilterAdding,
    setUpdatedFilters,
    updatedFilters,
    filtersPickList,
    systemReportId,
    addToFiltersPicklist,
    showTeamsitePicker,
    updatedTeamsites,
    tempTeamsites
  } = useContext(CompileReportContext);

  const { t } = useTranslation();

  const isContainsOperation = (operator?: string) => {
    return operator === ITextOperations.CONTAINS || operator === ITextOperations.DOES_NOT_CONTAIN;
  };

  const [currentSelectedOperator, setCurrentSelectedOperator] = useState<string | undefined>(
    currentSelectedFilter?.operation
  );
  const [disableApplyButton, setDisableApplyButton] = useState<boolean>(true);
  const [newUpdatedFilter, setNewUpdatedFilter] = useState<IFilter>({} as IFilter);
  const [updatedValues, setUpdatedValues] = useState<Array<any>>(currentSelectedFilter?.values || []);
  const twoValuesOperators = [IDateOperations.BETWEEN.toLowerCase(), INumberOperations.IN.toLowerCase()];
  const [isOpratorChanged, setIsOpratorChanged] = useState<number>(0);
  const [inputError, setInputError] = useState<IFilterError>({
    isError: false,
    errorMessage: '',
  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showDoneButton, setShowDoneButton] = useState<boolean>(true);
  const [clearFilter, setClearFilter] = useState<boolean>(false);
  const [previousOperator, setPreviousOperator] = useState<string | undefined>(currentSelectedFilter?.operation);

  useEffect(() => {
    if (currentSelectedFilter) {
      const { filterType, dataType, filterName } = currentSelectedFilter;
      const picklistExist = filtersPickList?.has(filterName) && filtersPickList?.get(filterName)?.length;
      const reloadValues = showTeamsitePicker && currentSelectedFilter.filterValuesByTeamsite;
      if ((!picklistExist || reloadValues) && (dataType === IFilterDataType.TEXT || dataType === IFilterDataType.CSV) && filterType === FILTER_TYPE.PICKLIST) {
        setIsLoading(true);
        const teamsiteIds = showTeamsitePicker && currentSelectedFilter.filterValuesByTeamsite ? updatedTeamsites
          .filter((t) => t.isSelected)
          .map((t) => t.id) : [];
        (async () => {
          ReportService.getPickListFilters(filterName, systemReportId, teamsiteIds)
            .then(filterPickList => {
              addToFiltersPicklist({
                key: filterName,
                values: filterPickList.flat(),
              });
              setIsLoading(false);
            })
            .catch(error => {
              console.error('Error while fetching filters picklist', error);
              throw error;
            });
        })();
      }
    }
  }, [currentSelectedFilter]);

  useEffect(() => {
    const filteredValues =
      updatedValues &&
      updatedValues?.filter(v => v !== '' && v !== null && v !== undefined && v?.toLowerCase() !== 'invalid date');
    if (filteredValues.length === 0 && !currentSelectedOperator) {
      setDisableApplyButton(true);
    } else {
      if (!twoValuesOperators.includes(currentSelectedOperator?.toLowerCase() || '')) {
        if (
          (currentSelectedFilter?.dataType === IFilterDataType.TEXT || currentSelectedFilter.dataType === IFilterDataType.CSV) &&
          (currentSelectedFilter?.filterType === FILTER_TYPE.DOMAIN_OF_VALUES ||
            currentSelectedFilter?.filterType === FILTER_TYPE.PICKLIST)
        ) {
          let isCurrentAndPrevValuesEqual =
            JSON.stringify(currentSelectedFilter?.values) === JSON.stringify(filteredValues);
          if (isCurrentAndPrevValuesEqual && isOpratorChanged) {
            if (currentSelectedFilter?.operation !== currentSelectedOperator) {
              setDisableApplyButton(false);
            } else {
              setDisableApplyButton(true);
            }
          } else if (isCurrentAndPrevValuesEqual && !isOpratorChanged) {
            setDisableApplyButton(true);
          } else if (!isCurrentAndPrevValuesEqual) {
            setDisableApplyButton(false);
          }
        } else if (currentSelectedFilter?.values) {
          let isCurrentAndPrevValuesEqual =
            filteredValues &&
            filteredValues?.every(v =>
              currentSelectedFilter?.values?.map(v => v?.toLowerCase())?.includes(v?.toLowerCase())
            );
          if (isCurrentAndPrevValuesEqual && isOpratorChanged) {
            // if (currentSelectedFilter?.operation !== currentSelectedOperator) {
            //   setDisableApplyButton(false);
            // } else {
            setDisableApplyButton(false);
            //}
          } else if (isCurrentAndPrevValuesEqual && !isOpratorChanged) {
            if (currentSelectedFilter?.operation === currentSelectedOperator) {
              setDisableApplyButton(false);
            } else {
              setDisableApplyButton(true);
            }
          } else if (!isCurrentAndPrevValuesEqual) {
            setDisableApplyButton(false);
          }
        }
      } else {
        if (filteredValues?.length < 2 && !currentSelectedOperator) {
          setDisableApplyButton(true);
        } else {
          if ((currentSelectedOperator === INumberOperations.BETWEEN ||
            currentSelectedOperator === IDateOperations.BETWEEN) &&
            (filteredValues?.length === 1)
          ) {
            setDisableApplyButton(true);
          } else {
            setDisableApplyButton(false);
          }
        }
      }
    }
  }, [updatedValues, isOpratorChanged]);

  useEffect(() => {
    setInputError({ isError: false, errorMessage: '' });
    // Update the previous operator when current operator changes
    if (currentSelectedOperator && currentSelectedOperator !== previousOperator) {
      setPreviousOperator(currentSelectedOperator);
    }
  }, [currentSelectedOperator])

  useEffect(() => {
    if (
      isFilterCardClicked &&
      updatedValues.length &&
      currentSelectedOperator !== INullishOperations.BLANK &&
      currentSelectedOperator !== INullishOperations.NOT_BLANK
    ) {
      isUserInputValidated();
    }
  }, [currentSelectedOperator, updatedValues]);

  useEffect(() => {
    if (
      currentSelectedOperator === INullishOperations.BLANK ||
      currentSelectedOperator === INullishOperations.NOT_BLANK
    ) {
      setUpdatedValues([EMPTY_FILTER_VALUE]);
    } else if (currentSelectedOperator === ITextOperations.IS_CURRENT_USER) {
      setUpdatedValues([UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue]);
    } else if (currentSelectedOperator === ITextOperations.IS_MY_TEAM) {
      setUpdatedValues([UserScopeTextMyTeamSubOperators.IncludeDirectReports]);
    } else if (
      currentSelectedFilter?.filterType !== FILTER_TYPE.DOMAIN_OF_VALUES &&
      currentSelectedFilter?.filterType !== FILTER_TYPE.PICKLIST &&
      !isOpratorChanged
    ) {
      setUpdatedValues(currentSelectedFilter?.values || []);
    } else if (
      previousOperator === ITextOperations.IS_CURRENT_USER ||
      previousOperator === ITextOperations.IS_MY_TEAM ||
      previousOperator === INullishOperations.BLANK ||
      previousOperator === INullishOperations.NOT_BLANK
    ) {
      setUpdatedValues([]);
    }
  }, [currentSelectedOperator]);

  useEffect(() => {
    let shouldShowDoneButton = currentSelectedOperator == undefined ||
      currentSelectedOperator?.toLowerCase() === 'none' && updatedValues.length === 0;

    setShowDoneButton(shouldShowDoneButton);

    if (isNewFilterAdding && currentSelectedFilter?.dataType === IFilterDataType.BOOLEAN && updatedValues.length !== 0) {
      setShowDoneButton(false);
    } else if (!isNewFilterAdding && currentSelectedFilter?.dataType === IFilterDataType.BOOLEAN && updatedValues.length === 0) {
      setShowDoneButton(true);
    }

  }, [currentSelectedOperator, updatedValues, isNewFilterAdding]);

  const handleOperatorsChange = (selectedOperator: any) => {
    const preOperator = currentSelectedOperator;
    setCurrentSelectedOperator(selectedOperator.value);
    if (preOperator !== selectedOperator.value) {
      setIsOpratorChanged(prev => ++prev);
    }
  };

  const handleCancel = () => {
    setIsFilterCardClicked(false);
    setIsNewFilterAdding(false);
    //Remove added filter if user don't enter values and uparations
    if (
      (isNewFilterAdding && !newUpdatedFilter?.values && !newUpdatedFilter?.operation) ||
      (twoValuesOperators.includes(newUpdatedFilter?.operation?.toLowerCase()) && newUpdatedFilter?.values?.length < 2)
    ) {
      setUpdatedFilters(updatedFilters.filter(filter => filter.filterName !== currentSelectedFilter?.filterName));
    }
  };

  const isUserInputValidated = () => {
    let date0, date1;
    const isIngtegerType = currentSelectedFilter?.dataType === IFilterDataType.INTEGER;
    const floatTypes = [IFilterDataType.FLOAT, IFilterDataType.DECIMAL, IFilterDataType.DOUBLE, IFilterDataType.SFLOAT, IFilterDataType.SDOUBLE, IFilterDataType.SDECIMAL];
    const isFloatType = floatTypes.includes(currentSelectedFilter?.dataType);
    if (
      currentSelectedOperator === IDateOperations.BETWEEN &&
      (currentSelectedFilter.dataType === IFilterDataType.DATE ||
        currentSelectedFilter.dataType === IFilterDataType.DATE_TIME)
    ) {
      date0 = new Date(updatedValues[0]);
      date1 = new Date(updatedValues[1]);
    }
    if (
      currentSelectedOperator === IDateOperations.BETWEEN && updatedValues.length === 2 &&
      (currentSelectedFilter.dataType === IFilterDataType.DATE ||
        currentSelectedFilter.dataType === IFilterDataType.DATE_TIME) &&
      (date1 <= date0)
    ) {
      setInputError({ isError: true, errorMessage: 'Invalid date range' });
      setDisableApplyButton(true);
    } else if (isIngtegerType && currentSelectedOperator === INumberOperations.BETWEEN && updatedValues.length === 2 &&
      (updatedValues.some(value => (typeof value === 'number' && Number.isNaN(value)) || value > INT_MAX || value < INT_MIN) ||
        ((Number(updatedValues[1]) <= Number(updatedValues[0]))))
    ) {
      setInputError({ isError: true, errorMessage: 'Invalid number range' });
      setDisableApplyButton(true);
    } else if (isFloatType && currentSelectedOperator === INumberOperations.BETWEEN && updatedValues.length === 2 &&
      (updatedValues.some(value => (typeof value === 'number' && Number.isNaN(value)) || value > FLOAT_MAX || value < FLOAT_MIN) ||
        (Number(updatedValues[1]) <= Number(updatedValues[0]))
      )
    ) {
      setInputError({ isError: true, errorMessage: 'Invalid number range' });
      setDisableApplyButton(true);
    } else if (
      (currentSelectedFilter.dataType === IFilterDataType.TEXT || currentSelectedFilter.dataType === IFilterDataType.CSV) &&
      (currentSelectedFilter.filterType === FILTER_TYPE.FREETEXT ||
        isContainsOperation(currentSelectedOperator)) &&
      updatedValues[0].trim() === ''
    ) {
      setInputError({ isError: true, errorMessage: 'Enter valid text' });
      setDisableApplyButton(true);
    } else {
      setInputError({ isError: false, errorMessage: '' });
    }
  };

  const applyChanges = () => {
    let updatedFiltersClone = [...updatedFilters];
    updatedFiltersClone &&
      updatedFiltersClone?.map(filter => {
        if (
          filter.filterName === currentSelectedFilter?.filterName &&
          (currentSelectedOperator || filter.dataType === IFilterDataType.BOOLEAN)
        ) {
          filter.values = updatedValues;
          filter.operation = filter.dataType === IFilterDataType.BOOLEAN && (!currentSelectedOperator || currentSelectedOperator.toLowerCase() === 'none') ? IBooleanOperations.EQUALS : currentSelectedOperator;
        }
        if (
          filter.filterName === currentSelectedFilter?.filterName &&
          filter.filterType === FILTER_TYPE.FREETEXT &&
          updatedValues.length < 2
        ) {
          filter.values = updatedValues.length > 0 ? [updatedValues[0].trim()] : [];
        }
        if (filter.filterName === currentSelectedFilter?.filterName &&
          (filter.dataType === IFilterDataType.DATE || filter.dataType === IFilterDataType.DATE_TIME) &&
          (filter.operation === IDateOperations.IN_THE_LAST || filter.operation === IDateOperations.IN_THE_NEXT) &&
          (updatedValues.length < 2 || updatedValues[0] === "" || updatedValues[1] === "")) {
          filter.values = [];
        }
        return filter;
      });
    setUpdatedFilters(updatedFiltersClone);
    setDisableApplyButton(true);
    setIsFilterCardClicked(false);
    setIsNewFilterAdding(false);
    setClearFilter(false);
  };

  const addNewEmptyFilter = () => {
    let updatedFiltersClone = [...updatedFilters];
    updatedFiltersClone &&
      updatedFiltersClone?.map(filter => {
        if (filter.filterName === currentSelectedFilter?.filterName) {
          filter.values = [];
          filter.operation = 'None';
        }
        return filter;
      });

    setUpdatedFilters(updatedFiltersClone);
    setDisableApplyButton(true);
    setIsFilterCardClicked(false);
    setIsNewFilterAdding(false);
    setClearFilter(false);
  }

  const renderOpratorSelector = () => {
    let defaultOption = {
      label: t('self_service_reports_select', 'Select'),
      value: '',
    }
    let opearators = getRefinedAllowedOperators(currentSelectedFilter?.allowedOperators, t,
      currentSelectedFilter.dataType, currentSelectedFilter.isNullable,
      currentSelectedFilter.filterType, currentSelectedFilter.enableRelativeUserFilterField);
    if (opearators.length === 1 && currentSelectedFilter.dataType === IFilterDataType.BOOLEAN) {
      return <></>;
    }

    const renderOption = (option) => {
      const isCurrentUserOrTeamLabel =
        typeof option.label === 'string' &&
        (option.label.includes('[Current user]') || option.label.includes('[My team]'));

      // Helper to highlight text inside brackets
      const highlightBracketText = (label: string) => {
        return label.replace(
          /(\[.*?\])/g,
          '<span class="relative-filters-label">$1</span>'
        );
      };

      if (option.disabled) {
        return (
          <Tooltip zIndex={110000} content={option.reason} position="bottom" showDelay={300}>
            {isCurrentUserOrTeamLabel ? (
              <div
                className="operations-disabled-option"
                aria-disabled="true"
                dangerouslySetInnerHTML={{ __html: highlightBracketText(option.label) }}
              />
            ) : (
              <div className="operations-disabled-option" aria-disabled="true">
                {option.label}
              </div>
            )}
          </Tooltip>
        );
      }

      return isCurrentUserOrTeamLabel ? (
        <div
          dangerouslySetInnerHTML={{ __html: highlightBracketText(option.label) }}
        />
      ) : (
        <div>{option.label}</div>
      );
    };

    return (
      currentSelectedFilter && (
        <div className="add-filter-popover-content-field-ops">
          <Select
            options={opearators}
            onChange={(e: any) => {
              handleOperatorsChange(e);
            }}
            renderOption={operator => renderOption(operator)}
            defaultOption={defaultOption}
            //@ts-ignore
            value={currentSelectedOperator}
          />
        </div>
      )
    );
  };

  const renderValueTaker = () => {
    if (
      currentSelectedOperator &&
      (currentSelectedOperator === INullishOperations.BLANK ||
        currentSelectedOperator === INullishOperations.NOT_BLANK ||
        (currentSelectedOperator.toLowerCase() === 'none' && currentSelectedFilter?.dataType !== IFilterDataType.BOOLEAN))
    ) {
      return <></>;
    }
    return (
      ((isNewFilterAdding && currentSelectedOperator) ||
        !isNewFilterAdding ||
        (isNewFilterAdding && currentSelectedFilter?.dataType === IFilterDataType.BOOLEAN && !currentSelectedFilter.isNullable)) && (
        <div className="add-filter-popover-content-field-content">
          <GetContentType
            filter={currentSelectedFilter as any}
            currentSelectedOperator={currentSelectedOperator}
            setUpdatedValues={setUpdatedValues}
            defaultValue={currentSelectedFilter?.values || []}
            isOpratorChanged={isOpratorChanged}
            filterPickList={filtersPickList?.get(currentSelectedFilter?.filterName) || []}
            clearFilter={clearFilter}
          />
        </div>
      )
    );
  };

  const renderErrorMessage = () => {
    if (inputError.isError && isFilterCardClicked) {
      return (
        <div className="add-filter-popover-content-error">
          <span aria-label={inputError.errorMessage}>
            {inputError.errorMessage}
          </span>
        </div>
      );
    }
  };

  const clearAll = () => {
    setClearFilter(true);
    setCurrentSelectedOperator('None');
    setIsOpratorChanged(1);
    setUpdatedValues([]);
  };

  return (
    <Popover
      showing={isFilterCardClicked}
      dismissOnOutsideClick={false}
      onHide={handleCancel}
      className="add-filter-popover"
      header={
        isNewFilterAdding
          ? t('self_service_reports_add_filter', 'Add filter')
          : t('self_service_reports_edit_filter', 'Edit filter')
      }
      content={isLoading ?
        <div className='ssrs-picklist-filter-spinner-container'>
          <Spinner size={32} />
        </div> :
        <div className="add-filter-popover-content">
          <div className="add-filter-popover-content-field">
            <span>{currentSelectedFilter?.uxLabel}</span>
            {!showDoneButton ? <Button
              className="add-filter-popover-content-field-clear-all trk_button_ssrs-report-add-filter-clear-all"
              variant="secondary"
              label={t('self_service_reports_fields_filters_clear_all', 'Clear all')}
              onClick={clearAll}
            /> : <></>
            }
          </div>
          <ErrorBoundary>
            {renderOpratorSelector()}
            {renderValueTaker()}
            {renderErrorMessage()}
          </ErrorBoundary>
        </div>
      }
      CTAs={[
        {
          label: t('self_service_reports_cancel', 'Cancel'),
          variant: 'secondary',
          onClick: handleCancel,
          className: 'add-filter-cancel-button trk-button-ssrs-cancel-filter-edit-modal',
        },
        // Conditionally determine which CTA to use
        showDoneButton
          ? {
            label: t('self_service_reports_filter_done_btn', 'Done'),
            onClick: addNewEmptyFilter,
            className: 'add-filter-apply-button',
          }
          : {
            label: t('self_service_reports_apply', 'Apply'),
            onClick: applyChanges,
            className: `${disableApplyButton ? 'add-filter-apply-button-disabled' : 'add-filter-apply-button'} trk-button-ssrs-apply-filter-edit-modal`,
            disabled: disableApplyButton,
          },
      ]}
      trigger={<div></div>}
      zIndex={100000}
      placement="right-end"
    />
  );
};

export default React.memo(AddFilter);