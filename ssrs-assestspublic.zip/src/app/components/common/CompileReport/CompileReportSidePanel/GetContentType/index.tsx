import React, { useEffect, useState } from 'react';
import './GetContentType.scss';
import { Input, Select, DateInput, IconClose, Button, Tooltip, LinkButton, CheckboxGroup, Banner } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import {
  IFilter,
  IFilterDataType,
  FILTER_TYPE,
  ITextOperations,
  INumberOperations,
  IDateOperations,
} from '../../../../../../interfaces/IFilterTypes';
import {
  convertDateToString,
  convertStringToDate,
  getRefinedDomainOfValuesAndPickList,
} from '../../../../../../utils/reportFiltersUtils';
import {
  FLOAT_MAX,
  FLOAT_MIN,
  INT_MAX,
  INT_MIN,
  EMPTY_FILTER_VALUE
} from '../../../../../../utils/constants';
import { UserScopeTextMyTeamSubOperators } from '../../../../../../utils/userScopeOperatorsConstants';
import { CheckboxItemValue } from '@seismic/mantle/dist/components/CheckboxGroup/types';

type IGetContentTypeProps = {
  filter: IFilter;
  currentSelectedOperator?: string;
  defaultValue: string[] | number[];
  setUpdatedValues: (values: any) => void;
  isOpratorChanged: number;
  filterPickList: string[];
  clearFilter?: boolean;
};

const GetContentType = (props: IGetContentTypeProps) => {
  const {
    filter,
    currentSelectedOperator,
    defaultValue,
    setUpdatedValues,
    isOpratorChanged: hasOperatorChanged,
    filterPickList = [],
    clearFilter,
  } = props;
  const { t } = useTranslation();

  const [fromValue, setFromValue] = useState<any>();
  const [toValue, setToValue] = useState<any>();

  // Add this state at the top of your component
  const [previousOperator, setPreviousOperator] = useState<string>();

  // Add this helper function
  const isPreviousOperatorContains = () => {
    return previousOperator === ITextOperations.CONTAINS ||
      previousOperator === ITextOperations.DOES_NOT_CONTAIN;
  };

  const isContainsOperation = (operator?: string) => {
    return operator === ITextOperations.CONTAINS || operator === ITextOperations.DOES_NOT_CONTAIN;
  };

  const isNotPickListAndDomainOfValuesValue = (value: any) => {
    if (!value || value.length === 0) return true;
    return (
      value[0] === EMPTY_FILTER_VALUE ||
      value[0] === UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue ||
      value[0] === UserScopeTextMyTeamSubOperators.IncludeIndirectReportsValue
    );
  };

  useEffect(() => {
    if (
      filter.dataType === IFilterDataType.DATE ||
      filter.dataType === IFilterDataType.DATE_TIME
    ) {
      if (filter.operation === IDateOperations.IN_THE_LAST || filter.operation === IDateOperations.IN_THE_NEXT) {
        setFromValue(defaultValue[0] ? defaultValue[0].toString() : '');
        setToValue(
          defaultValue[1]
            ? { label: defaultValue[1], value: defaultValue[1] }
            : timeframeOptions[0]
        );
      } else if (filter.operation === IDateOperations.NAMED_RANGE) {
        setFromValue(
          defaultValue[0] ? { label: defaultValue[0], value: defaultValue[0] } : ''
        );
      }
      else if (filter.operation === IDateOperations.BETWEEN) {
        setFromValue(
          defaultValue[0] ? convertStringToDate(defaultValue[0].toString()) : ''
        );
        setToValue(
          defaultValue[1] ? convertStringToDate(defaultValue[1].toString()) : ''
        );
      } else {
        setFromValue(
          defaultValue[0] ? convertStringToDate(defaultValue[0].toString()) : ''
        );
      }
    } else if (filter.dataType === IFilterDataType.BOOLEAN) {
      if (!defaultValue || defaultValue.length === 0) {
        setFromValue(''); // Default to 'False' if no value is provided
      } else {
        // If the default value is an array, we assume it contains
        setFromValue(
          defaultValue[0]?.toLowerCase() === 'true' ? 'True' : 'False'
        );
      }
    } else if (
      (filter.dataType === IFilterDataType.TEXT || filter.dataType === IFilterDataType.CSV) &&
      (filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES ||
        filter.filterType === FILTER_TYPE.PICKLIST)
    ) {
      if (isContainsOperation(currentSelectedOperator)) {
        setFromValue(defaultValue[0] || '');
      } else if (currentSelectedOperator === ITextOperations.IS_MY_TEAM && (filter.values == undefined || filter.values.length === 0)) {
        setFromValue([UserScopeTextMyTeamSubOperators.IncludeDirectReports]);
      } else if (currentSelectedOperator === ITextOperations.IS_CURRENT_USER) {
        setFromValue([UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue]);
      } else if (
        (currentSelectedOperator === ITextOperations.IS_ONE_OF ||
          currentSelectedOperator === ITextOperations.IS_NOT_ONE_OF) &&
        isNotPickListAndDomainOfValuesValue(defaultValue)
      ) {
        setFromValue('');
      } else {
        setFromValue(defaultValue.map((v) => v));
      }
    } else if (defaultValue) {
      if (defaultValue.length === 1) {
        setFromValue(defaultValue[0]);
      } else if (defaultValue.length === 2) {
        setFromValue(defaultValue[0]);
        setToValue(defaultValue[1]);
      }
    }
  }, [defaultValue]);

  useEffect(() => {
    if (hasOperatorChanged) {
      if (
        filter.filterType !== FILTER_TYPE.DOMAIN_OF_VALUES &&
        filter.filterType !== FILTER_TYPE.PICKLIST
      ) {
        setFromValue('');
        setToValue('');
      } else {
        if (isContainsOperation(currentSelectedOperator)) {
          setFromValue('');
          setToValue('');
        }
        else if (
          (filter.filterType === FILTER_TYPE.PICKLIST || filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES) &&
          isPreviousOperatorContains()
        ) {
          if (currentSelectedOperator !== ITextOperations.IS_CURRENT_USER &&
            currentSelectedOperator !== ITextOperations.IS_MY_TEAM) {
            setFromValue('');
            setToValue('');
          }
        }
      }
    }

    if (
      hasOperatorChanged &&
      (currentSelectedOperator === IDateOperations.IN_THE_LAST ||
        currentSelectedOperator === IDateOperations.IN_THE_NEXT)
    ) {
      setToValue(timeframeOptions[0]);
    }
  }, [hasOperatorChanged]);

  // Update the previous operator when current operator changes
  useEffect(() => {
    if (
      previousOperator === ITextOperations.IS_CURRENT_USER &&
      currentSelectedOperator === ITextOperations.IS_MY_TEAM
    ) {
      setFromValue([UserScopeTextMyTeamSubOperators.IncludeDirectReports]);
    }
    if (currentSelectedOperator && currentSelectedOperator !== previousOperator) {
      setPreviousOperator(currentSelectedOperator);
    }
  }, [currentSelectedOperator]);

  useEffect(() => {
    if (fromValue || toValue) {
      if (
        filter.dataType === IFilterDataType.DATE ||
        filter.dataType === IFilterDataType.DATE_TIME
      ) {
        if (currentSelectedOperator === IDateOperations.IN_THE_LAST || currentSelectedOperator === IDateOperations.IN_THE_NEXT) {
          setUpdatedValues([fromValue, toValue.value || toValue]);
        } else if (currentSelectedOperator === IDateOperations.NAMED_RANGE) {
          setUpdatedValues([fromValue.value || fromValue]);
        } else if (currentSelectedOperator === IDateOperations.BETWEEN) {
          setUpdatedValues([
            convertDateToString(fromValue),
            convertDateToString(toValue),
          ]);
        } else {
          setUpdatedValues([convertDateToString(fromValue)]);
        }
      } else if (currentSelectedOperator === INumberOperations.BETWEEN) {
        setUpdatedValues([fromValue, toValue]);
      } else if (
        (filter.dataType === IFilterDataType.TEXT || filter.dataType === IFilterDataType.CSV) &&
        (filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES ||
          filter.filterType === FILTER_TYPE.PICKLIST)
      ) {
        setUpdatedValues(Array.isArray(fromValue) ? fromValue.flat() : [fromValue]);
      } else {
        setUpdatedValues((prev) => new Array(fromValue));
      }
    } else {
      setUpdatedValues([]);
    }
  }, [fromValue, toValue]);

  useEffect(() => {
    if (clearFilter) {
      setFromValue('');
      setToValue('');
      setUpdatedValues([]);
    }
  }, [clearFilter]);

  const booleanOperators = [
    { label: 'True', value: 'True' },
    { label: 'False', value: 'False' },
  ];

  const handleTextDomainOfValuesAndPickListType = (value: any[]) => {
    if (value && currentSelectedOperator) {
      setFromValue(value.filter(v => v?.value !== undefined).map((v) => v.value));
    } else {
      setFromValue([]);
    }
  };

  // Utility function to handle numeric input changes
  const handleNumericInputChange = (
    val: string,
    setValue: (value: any) => void,
    isIntegerType: boolean,
    MIN: number,
    MAX: number
  ) => {
    // Allow empty input
    if (val === '') {
      setValue('');
      return;
    }

    // Allow typing just "-" while user enters negative numbers
    if (val === '-') {
      setValue(val);
      return;
    }

    let numericVal: number;
    if (isIntegerType) {
      // For integer types, parse the value as an integer
      numericVal = parseInt(val);
    } else {
      // For float types, parse the value as a float
      numericVal = parseFloat(val);
    }

    // Check if value is within the allowed range
    if (!isNaN(numericVal) && numericVal >= MIN && numericVal <= MAX) {
      setValue(
        isIntegerType ? val.replace(/[^0-9-]/g, '') : val // allow digits and one "-"
      );
    }
  };

  const removeAddedValue = () => {
    // Clear the input value
    setFromValue('');

    // Update the parent component with empty values
    setUpdatedValues([]);
  };

  const removeToValue = () => {
    setToValue('');
    setUpdatedValues([]);
  }

  // Compose options as per your logic
  const options =
    filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES
      ? getRefinedDomainOfValuesAndPickList(filter.domainValues, t)
      : getRefinedDomainOfValuesAndPickList(filterPickList, t);

  const timeframeOptions = [
    { label: t('self_service_reports_filters_timeframe_days', 'Days'), value: 'Days' },
    { label: t('self_service_reports_filters_timeframe_weeks', 'Weeks'), value: 'Weeks' },
    { label: t('self_service_reports_filters_timeframe_months', 'Months'), value: 'Months' }
  ]

  const namedRangeOptions = [
    { label: t('self_service_reports_filters_timeframe_today', 'Today'), value: 'Today' },
    { label: t('self_service_reports_filters_timeframe_this_week', 'This week'), value: 'This week' },
    { label: t('self_service_reports_filters_timeframe_last_week', 'Last week'), value: 'Last week' },
    { label: t('self_service_reports_filters_timeframe_this_month', 'This month'), value: 'This month' },
    { label: t('self_service_reports_filters_timeframe_last_month', 'Last month'), value: 'Last month' },
    { label: t('self_service_reports_filters_timeframe_this_year', 'This year'), value: 'This year' },
    { label: t('self_service_reports_filters_timeframe_last_year', 'Last year'), value: 'Last year' },
    { label: t('self_service_reports_filters_timeframe_year_to_date', 'Year to date'), value: 'Year to date' },
  ]

  const setMyTeamOperatorValues = (values: CheckboxItemValue[]) => {
    if (values == undefined || values.length === 0) {
      setFromValue([UserScopeTextMyTeamSubOperators.IncludeDirectReports]);
    } else {
      setFromValue(values.map(value => String(value)));
    }
  };


  const renderEditModal = () => {
    switch (filter.dataType) {
      case IFilterDataType.TEXT:
      case IFilterDataType.CSV:
        if (filter.filterType === FILTER_TYPE.FREETEXT) {
          if (
            currentSelectedOperator &&
            Object.values(ITextOperations).includes(currentSelectedOperator)
          ) {
            return (
              <Input
                value={fromValue}
                placeholder={t(
                  'self_service_reports_input_text_field',
                  'Enter [text field]'
                )}
                className='get-content-type-text'
                onChange={(e) => setFromValue(e.target.value)}
                endAdornment={
                  fromValue ? (
                    <Tooltip
                      content={t('self_service_reports_clear_field', 'Clear field')}
                      position='bottom'
                      zIndex={99999999}
                    >
                      <Button
                        className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                        startAdornment={IconClose}
                        label=""
                        hideLabel
                        variant="ghost"
                        onClick={removeAddedValue}
                        aria-label={t('self_service_reports_clear_field', 'Clear field')}
                      />
                    </Tooltip>
                  ) : null
                }
              />
            );
          }
        } else if (
          filter.filterType === FILTER_TYPE.DOMAIN_OF_VALUES ||
          filter.filterType === FILTER_TYPE.PICKLIST
        ) {
          if (isContainsOperation(currentSelectedOperator)) {
            return (
              <Input
                value={fromValue}
                placeholder={t(
                  'self_service_reports_input_text_field',
                  'Enter [text field]'
                )}
                className='get-content-type-text'
                onChange={(e) => setFromValue(e.target.value)}
                endAdornment={
                  fromValue ? (
                    <Tooltip
                      content={t('self_service_reports_clear_field', 'Clear field')}
                      position='bottom'
                      zIndex={99999999}
                    >
                      <Button
                        className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                        startAdornment={IconClose}
                        label=""
                        hideLabel
                        variant="ghost"
                        onClick={removeAddedValue}
                        aria-label={t('self_service_reports_clear_field', 'Clear field')}
                      />
                    </Tooltip>
                  ) : null
                }
              />
            );
          }

          if (currentSelectedOperator === ITextOperations.IS_CURRENT_USER) {
            return (
              <Banner className='ssrs-current-user-banner' variant='info' message={t('self_service_reports_current_user_banner', "Displays data of current viewer")} onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined} placeholder={undefined} />
            );
          }
          if (currentSelectedOperator === ITextOperations.IS_MY_TEAM) {
            return (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <Banner className='ssrs-my-team-banner' variant='info' message={t('self_service_reports_current_user_team_banner', "Displays data of current viewer's team")} onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined} placeholder={undefined} />
                <div className="ssrs-edit-filter-my-team-checkboxes">
                  <CheckboxGroup
                    value={Array.isArray(fromValue) ? fromValue : []}
                    onChange={values => { setMyTeamOperatorValues(values) }}
                    items={[
                      {
                        className: 'trk_checkbox_ssrs-edit-filter-my-team-include-indirect-reports',
                        value: UserScopeTextMyTeamSubOperators.IncludeIndirectReportsValue,
                        label: t("self_service_reports_filters_operations_IncludesIndirectReports", UserScopeTextMyTeamSubOperators.IncludeIndirectReportsLabel),
                      },
                      {
                        className: 'trk_checkbox_ssrs-edit-filter-my-team-include-current-user',
                        value: UserScopeTextMyTeamSubOperators.IncludeCurrentUserValue,
                        label: (
                          <span>
                            <span>{t("self_service_reports_filters_operations_Include", "Include")}</span>{' '}
                            <span style={{ color: '#535b64' }}>{t("self_service_reports_filters_operations_CurrentUser", "[Current user]")}</span>
                          </span>
                        ),
                      },
                    ]}
                  />
                </div>
              </div>
            );
          }

          return (
            <Select
              containerSelector={`#ssrs-compile-report-modal`}
              multi
              searchable
              value={fromValue}
              options={options}
              onChange={(e: any) => handleTextDomainOfValuesAndPickListType(e)}
              virtualized={true}
              defaultOption={{ label: 'No Selection', value: 'no selection' }}
              className='ssrs-edit-filter-picklist-select'
              footer={
                options && options.length > 0 && fromValue && fromValue.length > 0 ? (
                  <div style={{ padding: '8px 16px', borderTop: '1px solid #eee', background: '#fff' }}>
                    <LinkButton
                      label={t('self_service_reports_deselect_all', 'Deselect all')}
                      onClick={() => setFromValue([])}
                      className='trk_link_button_ssrs-edit-filter-picklist-deselect-all'
                    />
                  </div>
                ) : null
              }
            />
          );
        }
        break;
      case IFilterDataType.DECIMAL:
      case IFilterDataType.SDECIMAL:
      case IFilterDataType.FLOAT:
      case IFilterDataType.SFLOAT:
      case IFilterDataType.DOUBLE:
      case IFilterDataType.SDOUBLE:
      case IFilterDataType.INTEGER:
        const isIntegerType = filter.dataType === IFilterDataType.INTEGER;
        const isDecimalType = filter.dataType === IFilterDataType.DECIMAL;
        const MAX = isIntegerType || isDecimalType ? INT_MAX : FLOAT_MAX;
        const MIN = isIntegerType || isDecimalType ? INT_MIN : FLOAT_MIN;

        if (currentSelectedOperator === INumberOperations.BETWEEN) {
          return (
            <div className='get-content-type-between'>
              <div className='get-content-type-between-number-1'>
                <Input
                  value={fromValue}
                  type='number'
                  min={MIN}
                  max={MAX}
                  step={isIntegerType ? 1 : 0.1}
                  placeholder={t(
                    'self_service_reports_input_number_field',
                    'Enter [number field]'
                  )}
                  className='get-content-type-text'
                  onKeyDown={(e) =>
                    isIntegerType && e.key === '.' ? e.preventDefault() : null
                  }
                  onChange={(e) =>
                    handleNumericInputChange(
                      e.target.value,
                      setFromValue,
                      isIntegerType,
                      MIN,
                      MAX
                    )
                  }
                  endAdornment={
                    fromValue ? (
                      <Tooltip
                        content={t('self_service_reports_clear_field', 'Clear field')}
                        position='bottom'
                        zIndex={99999999}
                      >
                        <Button
                          className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                          startAdornment={IconClose}
                          label=""
                          hideLabel
                          variant="ghost"
                          onClick={removeAddedValue}
                          aria-label={t('self_service_reports_clear_field', 'Clear field')}
                        />
                      </Tooltip>
                    ) : null
                  }
                />
              </div>

              <span className='get-content-type-between-and'> and </span>
              <div className='get-content-type-between-number-2'>
                <Input
                  value={toValue}
                  type='number'
                  min={MIN}
                  max={MAX}
                  step={isIntegerType ? 1 : 0.1}
                  placeholder={t(
                    'self_service_reports_input_number_field',
                    'Enter [number field]'
                  )}
                  className='get-content-type-text'
                  onKeyDown={(e) =>
                    isIntegerType && e.key === '.' ? e.preventDefault() : null
                  }
                  onChange={(e) =>
                    handleNumericInputChange(
                      e.target.value,
                      setToValue,
                      isIntegerType,
                      MIN,
                      MAX
                    )
                  }
                  endAdornment={
                    toValue ? (
                      <Tooltip
                        content={t('self_service_reports_clear_field', 'Clear field')}
                        position='bottom'
                        zIndex={99999999}
                      >
                        <Button
                          className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                          startAdornment={IconClose}
                          label=""
                          hideLabel
                          variant="ghost"
                          onClick={removeToValue}
                          aria-label={t('self_service_reports_clear_field', 'Clear field')}
                        />
                      </Tooltip>
                    ) : null
                  }
                />
              </div>
            </div>
          );
        } else if (
          currentSelectedOperator &&
          Object.values(INumberOperations).includes(currentSelectedOperator)
        ) {
          return (
            <Input
              value={fromValue}
              type='number'
              min={MIN}
              max={MAX}
              step={isIntegerType ? 1 : 0.1}
              placeholder={t(
                'self_service_reports_input_number_field',
                'Enter [number field]'
              )}
              className='get-content-type-text'
              onKeyDown={(e) =>
                isIntegerType && e.key === '.' ? e.preventDefault() : null
              }
              onChange={(e) =>
                handleNumericInputChange(
                  e.target.value,
                  setFromValue,
                  isIntegerType,
                  MIN,
                  MAX
                )
              }
              endAdornment={
                fromValue ? (
                  <Tooltip
                    content={t('self_service_reports_clear_field', 'Clear field')}
                    position='bottom'
                    zIndex={99999999}
                  >
                    <Button
                      className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                      startAdornment={IconClose}
                      label=""
                      hideLabel
                      variant="ghost"
                      onClick={removeAddedValue}
                      aria-label={t('self_service_reports_clear_field', 'Clear field')}
                    />
                  </Tooltip>
                ) : null
              }
            />
          );
        }
        break;
      case IFilterDataType.DATE:
      case IFilterDataType.DATE_TIME:
        if (currentSelectedOperator === IDateOperations.IN_THE_LAST || currentSelectedOperator === IDateOperations.IN_THE_NEXT) {
          return (
            <div className='get-content-type-in-the-last-next'>
              <Input
                value={fromValue}
                type='number'
                placeholder={t(
                  'self_service_reports_input_number_field',
                  'Enter [number field]'
                )}
                className='get-content-type-in-the-last-next-input'
                onChange={(e) => setFromValue(e.target.value)}
                endAdornment={
                  fromValue ? (
                    <Tooltip
                      content={t('self_service_reports_clear_field', 'Clear field')}
                      position='bottom'
                      zIndex={99999999}
                    >
                      <Button
                        className='ssrs-edit-filter-text-remove-button trk_button_ssrs-edit-filter-text-remove-button'
                        startAdornment={IconClose}
                        label=""
                        hideLabel
                        variant="ghost"
                        onClick={removeAddedValue}
                        aria-label={t('self_service_reports_clear_field', 'Clear field')}
                      />
                    </Tooltip>
                  ) : null
                }
              />
              <Select
                value={toValue}
                options={timeframeOptions}
                className='get-content-type-in-the-last-next-select'
                onChange={(e) => setToValue(e)}
              />
            </div>
          );
        } else if (currentSelectedOperator === IDateOperations.NAMED_RANGE) {
          return (
            <div className='get-content-type-named-range'>
              <Select
                value={fromValue}
                className='get-content-type-named-range-select'
                options={namedRangeOptions}
                onChange={(e) => setFromValue(e)}
                defaultOption={{ label: t('self_service_reports_select_a_named_range', 'Select a named range'), value: 'named range' }}
              />
            </div>
          );

        } else if (currentSelectedOperator === IDateOperations.BETWEEN) {
          var value1 = fromValue
          if (hasOperatorChanged && fromValue && !(fromValue instanceof Date)) {
            value1 = '';
          }
          var value2 = toValue
          if (hasOperatorChanged && toValue && !(toValue instanceof Date)) {
            value2 = '';
          }
          return (
            <div className='get-content-type-between'>
              <div className='get-content-type-between-date1'>
                <DateInput
                  aria-label={t(
                    'self_service_reports_select_first_date',
                    'Select first date'
                  )}
                  className='get-content-type-date'
                  onChange={(e) => setFromValue(e)}
                  placeholder={t(
                    'self_service_reports_select_a_date',
                    'Select date'
                  )}
                  value={value1}
                  openTo={value1 ? value1 : new Date()}
                  closeOnSelect
                />
              </div>
              <span className='get-content-type-between-and'> and </span>
              <div className='get-content-type-between-date2'>
                <DateInput
                  aria-label={t(
                    'self_service_reports_select_second_date',
                    'Select second date'
                  )}
                  className='get-content-type-date'
                  onChange={(e) => setToValue(e)}
                  placeholder={t(
                    'self_service_reports_select_a_date',
                    'Select date'
                  )}
                  value={value2}
                  openTo={value2 ? value2 : new Date()}
                  closeOnSelect
                />
              </div>
            </div>
          );
        } else if (
          currentSelectedOperator &&
          Object.values(IDateOperations).includes(currentSelectedOperator)
        ) {
          var value = fromValue
          if (hasOperatorChanged && fromValue && !(fromValue instanceof Date)) {
            value = '';
          }
          return (
            <DateInput
              aria-label={t(
                'self_service_reports_select_a_date',
                'Select date'
              )}
              className='get-content-type-date'
              onChange={(e) => setFromValue(e)}
              placeholder={t(
                'self_service_reports_select_a_date',
                'Select date'
              )}
              value={value}
              openTo={value ? value : new Date()}
              closeOnSelect
            />
          );
        }
        break;
      case IFilterDataType.BOOLEAN:
        return (
          <div className='add-filter-popover-content-field-ops'>
            <Select
              options={booleanOperators}
              onChange={(e: any) => setFromValue(e.value)}
              //@ts-ignore
              value={fromValue}
              defaultOption={{ label: 'No Selection', value: 'no selection' }}
            />
          </div>
        );
    }
  };

  return renderEditModal();
};

export default React.memo(GetContentType);
