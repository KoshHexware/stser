import React, { useContext } from 'react';
import { SidePanel, Tabs } from '@seismic/mantle';
import TableColumns from './TableColumns/TableColumns';
import { useTranslation } from 'react-i18next';
import './CompileReportSidePanel.scss';
import { FieldAndFilterContext } from '../../../../../contexts';
import ReportFilters from './ReportFilters';
import { ErrorBoundary } from '../../ErrorBoundary';

export const CompileReportSidePanel = ({
  currentVisibleTab = 0,
  setCurrentVisibleTab,
  isSidePanelVisible = true,
  setIsSidePanelVisible,
  totalHeight,
  columnVisibility,
  toggleColumnVisibility,
  setColumnVisibility
}) => {
  const { setCurrentActiveTab } = useContext(FieldAndFilterContext);
  const { t } = useTranslation();

  return (
    <SidePanel
      aria-label={t(
        'self_service_report_edit_report_navigation_panel',
        'Edit the report navigation panel to add or remove columns and filters'
      )}
      position='start'
      className='edit-side-panel'
      style={{ height: `calc(100vh - ${totalHeight}px)` }}
      isExpanded={isSidePanelVisible}
      onToggle={(isExpanded) => {
        setIsSidePanelVisible(isExpanded);
      }}
    >
      <ErrorBoundary>
        <div className='edit-side-panel-container'>
          <div className='tabs-container mntl-scrollbar'>
            <Tabs
              aria-label={t('self_service_reports_tabs', 'Tabs')}
              initialValue={currentVisibleTab}
              tabs={[
                {
                  tabProps: {
                    children: `${t('self_service_reports_table', 'Table')}`,
                    className: 'trk_tab_ssrs-table-view-selected-columns-tab',
                    onClick: () => {
                      setCurrentActiveTab('Table');
                      setCurrentVisibleTab(0);
                    },
                    onKeyDown: (e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        setCurrentActiveTab('Table');
                        setCurrentVisibleTab(0);
                      }
                    },
                  },
                  tabPanelProps: {
                    children: (
                      <ErrorBoundary>
                        <TableColumns
                          totalHeight={totalHeight}
                          columnVisibility={columnVisibility}
                          toggleColumnVisibility={toggleColumnVisibility}
                          setColumnVisibility={setColumnVisibility}
                        />
                      </ErrorBoundary>
                    ),
                  },
                },
                {
                  tabProps: {
                    children: `${t('self_service_reports_filters', 'Filters')}`,
                    className: 'trk_tab_ssrs-view-selected-filter-tab',
                    onClick: () => {
                      setCurrentActiveTab('Filters');
                      setCurrentVisibleTab(1);
                    },
                    onKeyDown: (e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        setCurrentActiveTab('Filters');
                        setCurrentVisibleTab(1);
                      }
                    },
                  },
                  tabPanelProps: {
                    children: (
                      <ErrorBoundary>
                        <ReportFilters totalHeight={totalHeight} />
                      </ErrorBoundary>
                    ),
                  },
                },
              ]}
            />
          </div>
        </div>
      </ErrorBoundary>
    </SidePanel>
  );
};
