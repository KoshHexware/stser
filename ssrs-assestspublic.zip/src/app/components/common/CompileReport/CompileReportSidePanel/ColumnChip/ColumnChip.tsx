import React, { useMemo, useState } from 'react';
import './ColumnChip.scss';
import {
  IconStatusInformation,
  IconClose,
  Button,
  ContentItem,
  Popover,
  IconPreview,
  IconPreviewOff,
} from '@seismic/mantle';
import getTypeIcon from '../../../../../../utils/getTypeIcons';
import { useTranslation } from 'react-i18next';
import { useAccessLevel } from '../../../../../../contexts/CommonServicesContext';
import { VIEWER_ACCESS_LEVEL } from '../../../../../../utils/constants';
import { formatNewLines } from '../../../../../../utils/formatNewLines';

type IColumnChipProps = {
  column: any;
  onRemove: (e: any, name: any) => void;
  reportId: any;
  reportName: any;
  showHideColumn: boolean;
  setShowHideColumn: (show: boolean) => void;
};

const ColumnChip = (props: IColumnChipProps) => {
  const {
    column,
    onRemove,
    reportId,
    reportName,
    showHideColumn,
    setShowHideColumn,
  } = props;
  const { t } = useTranslation();
  const [showFieldDefinition, setShowFieldDefinition] = useState(false);

  const accessLevel = useAccessLevel();
  const isViewer = accessLevel == VIEWER_ACCESS_LEVEL;

  const columnInfoContainer = () => {
    return (
      <div
        className='info-icon-container trk_button_ssrs-report-view-field-metadata'
        tabIndex={0}
        aria-label={column?.description}
      >
        <IconStatusInformation
          color='#535b64'
          size={16}
          onClick={() => setShowFieldDefinition(true)}
        />
        <Popover
          showing={showFieldDefinition}
          className='ssrs-field-definition-popover'
          content={
            <>
              <div className='ssrs-field-definition-popover-content'>
                <div className='ssrs-field-definition-popover-content-description'>
                  {column?.description || ''}
                </div>
                <div className='ssrs-field-definition-popover-content-type-row'>
                  <div className='ssrs-field-definition-popover-content-type'>
                    {t('self_service_reports_field_definition_type', 'Type:')}
                  </div>
                  {getTypeIcon(column.dataType)}
                  <div className='ssrs-field-definition-popover-content-type_value'>
                    {column?.dataType || ''}
                  </div>
                </div>
                {column?.definition ? (
                  <div className='ssrs-field-definition-popover-content-defined-row'>
                    <div className='ssrs-field-definition-popover-content-defined'>
                      {t(
                        'self_service_reports_field_definition_defined_as',
                        'Defined as:'
                      )}
                    </div>
                    <div className='ssrs-field-definition-popover-content-defined_value'>
                      {column?.definition
                        ?
                        formatNewLines(column.definition)
                        : ''}
                    </div>
                  </div>
                ) : null}
              </div>
            </>
          }
          onHide={() => setShowFieldDefinition(false)}
          header={column.title}
          trigger={<div></div>}
          zIndex={100000}
          placement='right-start'
        />
      </div>
    );
  };

  const columnShow = () => {
    return (
      <>
        {showHideColumn && (
          <Button
            hideLabel
            label={t('self_service_report_show_column', 'Show column')}
            startAdornment={IconPreview}
            onClick={() => {
              setShowHideColumn(true);
            }}
            variant='ghost'
            className={'trk_button_ssrs-report-field-show-column'}
            aria-label={t('self_service_report_show_column', 'Show column')}
          />
        )}
      </>
    );
  };

  const columnHide = () => {
    return (
      <>
        {!showHideColumn && (
          <Button
            hideLabel
            label={t('self_service_report_hide_column', 'Hide column')}
            startAdornment={IconPreviewOff}
            onClick={() => {
              setShowHideColumn(false);
            }}
            variant='ghost'
            className={'trk_button_ssrs-report-field-hide-column'}
            aria-label={t('self_service_report_hide_column', 'Hide column')}
          />
        )}
      </>
    );
  };

  const removeColumn = () => {
    return (
      <Button
        hideLabel
        label={t('self_service_reports_remove_column', 'Remove')}
        startAdornment={IconClose}
        onClick={(e) => onRemove(e, column.id)}
        onKeyDown={(e) => e.key === 'Enter' && onRemove(e, column.id)}
        variant='ghost'
        className='trk_button_ssrs-report-field-remove-column'
        data-atmt-id={`seismic.self-service-reports.edit-report-fields.remove-column`}
        aria-label={t('self_service_report_remove_column', 'Remove column')}
      />
    );
  };

  return (
    <>
      <ContentItem
        variant='chip'
        style={{ maxWidth: 600 }}
        className={`${showHideColumn
          ? 'table-column-chip-visible'
          : 'table-column-chip-disabled'
          }  trk-draggable-columnchip-ssrs ${showFieldDefinition ? ' ssrs-field-definition-active-popover' : ''
          }`}
        tabIndex={0}
        aria-label={column.title}
      >
        <ContentItem.DragHandle />

        <ContentItem.Content>
          <ContentItem.Content.Icon aria-label={column.dataType}>
            {getTypeIcon(column.dataType)}
          </ContentItem.Content.Icon>
          <ContentItem.Content.Title style={{ paddingInlineStart: '20px' }}>
            <div className='ssrs-column-chip-info'>
              <div className='ssrs-column-chip-title'>{column.title}</div>
              {columnInfoContainer()}
            </div>
          </ContentItem.Content.Title>
        </ContentItem.Content>

        {!isViewer && (
          <ContentItem.Actions>
            {!showHideColumn && columnHide()}
            <ContentItem.Actions.Hover>
              {showHideColumn ? columnShow() : columnHide()}
              {removeColumn()}
            </ContentItem.Actions.Hover>
          </ContentItem.Actions>
        )}

        {isViewer && (
          <ContentItem.Actions>
            {!showHideColumn && columnHide()}
            <ContentItem.Actions.Hover>
              {showHideColumn ? columnShow() : columnHide()}
            </ContentItem.Actions.Hover>
          </ContentItem.Actions>
        )}
      </ContentItem>
    </>
  );
};

export default React.memo(ColumnChip);
