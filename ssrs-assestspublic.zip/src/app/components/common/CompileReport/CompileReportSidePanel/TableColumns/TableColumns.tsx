import React, { useContext, useEffect, useMemo } from 'react';
import './TableColumns.scss';
import { DndContextV2, DndDraggableV2, DndDroppableV2 } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import {
	CompileReportContext,
	FieldAndFilterContext,
	ReportDataContext,
} from '../../../../../../contexts';
import getTypeIcon from '../../../../../../utils/getTypeIcons';
import ColumnChip from '../ColumnChip/ColumnChip';
import { ErrorBoundary } from '../../../ErrorBoundary';
import CompileFieldAndFilterActions from '../CompileFieldAndFilterActions';
import {
	useApplicationInfo,
	useTenantUniqueId,
} from '../../../../../../contexts/CommonServicesContext';
import { SelfServiceReportsUserDataStorage } from '../../../../../../interfaces/SSRTypes';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from '../../../../../../utils/constants';

const TableColumns = ({
	totalHeight,
	columnVisibility,
	toggleColumnVisibility,
	setColumnVisibility,
}) => {
	const { updatedFields, setUpdatedFields, reportName } =
		useContext(CompileReportContext);
	const { selectedReport } = useContext(ReportDataContext);
	const {
		setFinalUpdatedFields,
		finalUpdatedFields,
		setTotalItemsSelected,
		totalItemsSelected,
		setIsDoneButtonClicked,
	} = useContext(FieldAndFilterContext);
	const { t } = useTranslation();
	const [content, setContent] = React.useState<any>([]);
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();
	const [columnOrder, setColumnOrder] = React.useState<string>('');

	const getUserTenantKey = (userId: string, tenantId: string): string => {
		return `${userId}_${tenantId}`;
	};

	useEffect(() => {
		if (!updatedFields?.length) {
			setContent([]);
			return;
		}
		const extractedReportSchemaChips = updatedFields
			.filter((column) => column.isDefault)
			.map((column) => {
				return {
					id: column.name,
					title: column.uxLabel,
					startAdornment: getTypeIcon(column.dataType),
					description: column?.uxDescription || '',
					dataType: column.dataType,
					definition: column.definition,
				};
			});
		setContent(extractedReportSchemaChips);

		// Load saved visibility from localStorage with the nested structure
		let hiddenColumnNames: string[] = [];
		if (UserId && tenantUniqId && selectedReport?.id) {
			try {
				const columnVisibilityData = localStorage.getItem(
					SELF_SERVICE_REPORTS_STORAGE_KEY
				);
				if (columnVisibilityData) {
					const userData: SelfServiceReportsUserDataStorage =
						JSON.parse(columnVisibilityData);
					const userTenantKey = getUserTenantKey(UserId, tenantUniqId);
					const userReports = userData[userTenantKey]?.reports || [];
					const reportData = userReports.find(
						(report) => report.reportId === selectedReport?.id
					);

					if (reportData) {
						hiddenColumnNames = reportData.hiddenColumnNames || [];
						setColumnOrder(reportData.columnOrder || '');
					}
				}
			} catch (error) {
				console.error(
					'Error loading column visibility from localStorage:',
					error
				);
			}
		}

		// Initialize visibility state
		const initialVisibility = {};
		extractedReportSchemaChips.forEach((column) => {
			// If column ID is in hiddenColumnNames, set it to false (hidden), otherwise true (visible)
			initialVisibility[column.id] = !hiddenColumnNames.includes(column.id);
		});

		setColumnVisibility(initialVisibility);
	}, [updatedFields, selectedReport?.id, UserId, tenantUniqId]);

	// Save visibility to localStorage with the nested structure whenever it changes
	useEffect(() => {
		if (
			Object.keys(columnVisibility).length > 0 &&
			selectedReport?.id &&
			UserId &&
			tenantUniqId
		) {
			// Get only the hidden column names
			const hiddenColumnNames = Object.entries(columnVisibility)
				.filter(([_, isVisible]) => !isVisible) // Filter for hidden columns
				.map(([columnId]) => columnId);

			// Get existing user data from localStorage
			let userData: SelfServiceReportsUserDataStorage = {};
			try {
				const existingUserData = localStorage.getItem(
					SELF_SERVICE_REPORTS_STORAGE_KEY
				);
				if (existingUserData) {
					userData = JSON.parse(existingUserData);
				}
			} catch (error) {
				console.error('Error parsing user data from localStorage:', error);
			}

			const userTenantKey = getUserTenantKey(UserId, tenantUniqId);

			// Update the user's data structure
			// Preserve any previously stored fields for this report
			const existingReports = userData[userTenantKey]?.reports || [];
			const existingReportData = existingReports.find(
				(report) => report.reportId === selectedReport?.id
			);

			const updatedReportData = {
				...(existingReportData || {}),
				reportId: selectedReport?.id,
				hiddenColumnNames: hiddenColumnNames,
				columnOrder: columnOrder,
			};

			const updatedUserData = {
				...userData,
				[userTenantKey]: {
					...(userData[userTenantKey] || {}),
					reports: [
						// Keep existing reports but filter out the current one
						...existingReports.filter(
							(report) => report.reportId !== selectedReport?.id
						),
						// Add the merged report data so other fields are preserved
						updatedReportData,
					],
				},
			};

			// Save the updated structure back to localStorage
			localStorage.setItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY,
				JSON.stringify(updatedUserData)
			);
		}
	}, [
		columnVisibility,
		selectedReport?.id,
		UserId,
		tenantUniqId
	]);

	const onDragEnd = ({ sourceIndex, targetIndex }) => {
		const contentClone = [...content];
		const itemToMove = contentClone.splice(sourceIndex, 1)[0];
		contentClone.splice(targetIndex, 0, itemToMove);
		const updatedFieldsClone = [
			...updatedFields.filter((column) => column.isDefault),
		];
		const fieldToMove = updatedFieldsClone.splice(sourceIndex, 1)[0];
		updatedFieldsClone.splice(targetIndex, 0, fieldToMove);
		setUpdatedFields(updatedFieldsClone);
		setContent(contentClone);
	};

	const removeColumn = useMemo(
		() => (e, name) => {
			e.stopPropagation();
			const updatedFieldsClone = [...updatedFields];
			const updatedUnDeletedFields = updatedFieldsClone.filter(
				(column) => column.name !== name
			);

			if (updatedUnDeletedFields.length > 0) {
				setUpdatedFields(updatedUnDeletedFields);
			} else if (updatedUnDeletedFields.length === 0) {
				setUpdatedFields([]);
			}

			const updatedUnDeletedFieldGroups = JSON.parse(
				JSON.stringify(finalUpdatedFields)
			)?.map((field) => {
				return {
					fields: field?.fields.map((item) => {
						if (item.name === name) {
							item.isDefault = false;
						}
						return item;
					}),
					uxLabel: field.uxLabel,
				};
			});
			setTotalItemsSelected(totalItemsSelected - 1);
			setIsDoneButtonClicked(true);
			setFinalUpdatedFields(
				JSON.parse(JSON.stringify(updatedUnDeletedFieldGroups)) as any
			);
		},
		[
			updatedFields,
			finalUpdatedFields,
			setFinalUpdatedFields,
			setUpdatedFields,
			totalItemsSelected,
			setTotalItemsSelected,
			setIsDoneButtonClicked,
		]
	);

	const draggableContentChips = useMemo(() => {
		return (
			content &&
			content?.map((field) => {
				return (
					<DndDraggableV2 key={field.id} draggableId={field.id}>
						<ColumnChip
							column={field}
							onRemove={removeColumn}
							reportId={selectedReport?.id}
							reportName={selectedReport?.reportName}
							showHideColumn={columnVisibility[field.id] ?? true}
							setShowHideColumn={() => toggleColumnVisibility(field.id)}
						/>
					</DndDraggableV2>
				);
			})
		);
	}, [content, columnVisibility, removeColumn, selectedReport?.id, reportName]);

	return (
		<ErrorBoundary>
			<div className='table-columns'>
				<div className='table-columns-container'>
					<div className='table-columns-title'>
						{t('self_service_reports_columns', 'Columns')}
					</div>
					<div className='table-columns-add-column'>
						<CompileFieldAndFilterActions />
					</div>
				</div>
				<div
					style={{ height: `calc(100vh - ${totalHeight + 116}px)` }}
					className='edit-fields-container mntl-scrollbar'
				>
					<DndContextV2
						activationConstraint={{ distance: 1 }}
						onDragEnd={onDragEnd}
					>
						<DndDroppableV2
							direction='vertical'
							droppableId='droppable-1'
							items={content}
						>
							<div className='table-columns-chips-container'>
								{draggableContentChips}
							</div>
						</DndDroppableV2>
					</DndContextV2>
				</div>
			</div>
		</ErrorBoundary>
	);
};

export default React.memo(TableColumns);
