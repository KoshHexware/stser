import React, { useContext, useEffect, useState } from 'react';
import { Modal, Spinner, Toast } from '@seismic/mantle';
import { CompileReportSidePanel } from './CompileReportSidePanel';
import ReportService from '../../../../services/ReportService';
import { FullScreenLoading } from '../FullScreenLoading';
import './CompileReport.scss';
import ViewReportTopNavigation from '../../SSRTopNavigation/ViewReportTopNavigation/ViewReportTopNavigation';

import {
  CompileReportContext,
  FieldAndFilterContext,
  ReportDataContext,
} from '../../../../contexts';
import { useTranslation } from 'react-i18next';
import SaveCopyModal from '../SaveCopyModal/SaveCopyModal';
import {
  getRefinedFilters,
  getUpdatedFiltersToApply,
} from '../../../../utils/reportFiltersUtils';
import { ErrorBoundary } from '../ErrorBoundary';
import { AsyncReportGrid } from '../GenericReport/AsyncReportGrid';
import TeamsitesConfirmModal from '../../Teamsites/TeamsitesConfirmModal/TeamsitesConfirmModal';
import {
  IReportMetadata,
  UpdatedReportMetadata,
} from '../../../../interfaces/IReport';
import { generateIncrementalReportTitle } from '../../../../utils/generateIncrementalReportTitle';

type ICompileReportProps = {
  isLoading: boolean;
  onSave: (
    reportMetadata: UpdatedReportMetadata,
    closeAfterSave?: boolean,
    isSaveCopyClicked?: boolean
  ) => void;
  reportMetadata: IReportMetadata;
  flashErrorMessage: {
    triggerFlash: boolean;
    message: string;
  };
  isSaving: boolean;
  isSaved: boolean;
  resetFlashErrorMessage: () => void;
  compileStates: any;
  isEditStandard?: boolean;
};

const CompileReport = (props: ICompileReportProps) => {
  const {
    isLoading,
    onSave,
    reportMetadata,
    flashErrorMessage,
    isSaving,
    isSaved,
    resetFlashErrorMessage,
    compileStates,
    isEditStandard,
  } = props;

  const {
    fields,
    setUpdatedReportName,
    setUpdatedDescription,
    setUpdatedFields,
    resetCompileReportState,
    id,
    reportName,
    systemReportId,
    updatedReportName,
    updatedDescription,
    updatedFields,
    updatedFilters,
    updatedOrderBy,
    updatedOrderField,
    allReportsSummary,
    setAllReportsSummary,
    setUpdatedOrderBy,
    setUpdatedOrderField,
    isChanged,
    resetCompileReportOriginalState,
    setUpdatedFilters,
    updatedTeamsites,
    originalTeamsites,
    setUpdatedTeamsites,
    setOriginalTeamsites,
    setTempTeamsites,
    shouldFetchOwnedReports,
    setShouldFetchOwnedReports
  } = useContext(CompileReportContext);

  const { selectedReport } = useContext(ReportDataContext);

  const { resetFieldFilterStates, setIsDoneButtonClicked } = useContext(
    FieldAndFilterContext
  );
  const [showResetModal, setShowResetModal] = useState(false);
  // const [showCloseWithoutSaveModal, setShowCloseWithoutSaveModal] =
  //   useState(false);
  const [showSaveCopyModal, setShowSaveCopyModal] = useState(false);
  const [isSaveCopyWithClose, setSaveCopyWithClose] = useState(false);
  const [previewReportMetadata, setPreviewMetadata] = useState<any>();
  const [resetRefreshPreview, setResetRefreshPreview] = useState<
    boolean | undefined
  >(undefined);
  const [isSaveCopyClicked, setIsSaveCopyClicked] = useState(false);
  const [isTeamsitesChangesLoading, setIsTeamsitesChangesLoading] =
    useState(false);
  const [currentVisibleTab, setCurrentVisibleTab] = useState(0);
  const [isSidePanelVisible, setIsSidePanelVisible] = useState(false);
  const { t } = useTranslation();
  const [fullHeight, setFullHeight] = useState(0);
  const [columnVisibility, setColumnVisibility] = useState<
    Record<string, boolean>
  >({});
  const [isLoadingAllReports, setIsLoadingAllReports] = useState(false);
  const [suggestedReportName, setSuggestedReportName] = useState<string>(
    updatedReportName || selectedReport?.reportName || reportName || ''
  );

  // This effect fetches all reports summary when the component mounts or when shouldFetchOwnedReports changes
  // It also generates a new report title suggestion for create copy if updatedReportName is provided
  useEffect(() => {
    const fetchReports = async () => {
      try {
        setIsLoadingAllReports(true);
        const reports = await ReportService.getReportsSummary();
        setAllReportsSummary(reports);

        // Only generate new title if we have a report name
        if (updatedReportName) {
          const newTitle = generateIncrementalReportTitle(
            updatedReportName,
            reports
          );
          setSuggestedReportName(newTitle);
        }
      } catch (error) {
        console.error('Error fetching reports:', error);
      } finally {
        setShouldFetchOwnedReports(false);
        setIsLoadingAllReports(false);
      }
    };

    if (shouldFetchOwnedReports) {
      fetchReports();
    }
  }, [shouldFetchOwnedReports]);

  useEffect(() => {
    const {
      reportName,
      description,
      requestedFields: fields,
      appliedFilters: filters,
      teamsites,
      standardReportMetadata: { filterGroup },
    } = reportMetadata;
    setUpdatedReportName(reportName);
    setUpdatedDescription(description);
    setUpdatedFields(
      JSON.parse(JSON.stringify(fields?.filter((field) => field.isDefault)))
    );
    const refinedFilters = JSON.parse(
      JSON.stringify(getRefinedFilters(filters, filterGroup))
    );
    setUpdatedFilters(refinedFilters);
    setUpdatedTeamsites(JSON.parse(JSON.stringify(teamsites)));
    setOriginalTeamsites(JSON.parse(JSON.stringify(teamsites)));
    updatePreviewData();
  }, [reportMetadata]);

  // for reseting refresh preview in grid
  useEffect(() => {
    if (!isSaving && isSaved) {
      setResetRefreshPreview((prev) => !prev);
    }
  }, [isSaving, isSaved]);

  useEffect(() => {
    updatePreviewData();
  }, [
    updatedFields,
    updatedOrderField,
    updatedOrderBy,
    updatedFilters,
    updatedTeamsites,
  ]);

  const updatePreviewData = () => {
    setPreviewMetadata({
      ...reportMetadata,
      fields: updatedFields?.filter((field) => field.isDefault),
      filters: getUpdatedFiltersToApply(updatedFilters),
      orderBy: updatedOrderBy,
      orderField: updatedOrderField,
      teamsites: updatedTeamsites,
      showTeamsitePicker: reportMetadata?.showTeamsitePicker,
    });
  };

  useEffect(() => {
    const box1 = document.querySelector('.ssrs-top-panel');
    const box2 = document.querySelector('.seismic-top-header');

    if (box1 && box2) {
      const getFullHeight = (element) => {
        const rect = element.getBoundingClientRect(); // includes padding + border
        const styles = window.getComputedStyle(element);
        const marginTop = parseFloat(styles.marginTop);
        const marginBottom = parseFloat(styles.marginBottom);
        return rect.height + marginTop + marginBottom;
      };

      const height1 = getFullHeight(box1);
      const height2 = getFullHeight(box2);

      setFullHeight(height1 + height2);
    }
  }, []);

  useEffect(() => {
    if (!isSaving && compileStates && !flashErrorMessage?.triggerFlash) {
      resetCompileReportOriginalState(compileStates);
    }
  }, [compileStates, isSaved]);

  const handleSave = (
    closeAfterSave: boolean = false,
    isSaveCopyClicked: boolean = false,
    newReportName?: string,
    newDescription?: string
  ) => {
    onSave(
      getUpdatedReportMetadata(newReportName, newDescription),
      closeAfterSave,
      isSaveCopyClicked
    );
  };

  const handleReset = async () => {
    const updatedTeamsiteIds = originalTeamsites
      ?.filter((teamsite) => teamsite.isSelected)
      .map((teamsite) => teamsite.id);

    try {
      const response = await ReportService.updateUserSettingsGlobalTeamsites(
        updatedTeamsiteIds
      );
      setUpdatedTeamsites(originalTeamsites);
      setTempTeamsites([]);
      resetCompileReportState();
      setShowResetModal(false);
      setIsDoneButtonClicked(false);
      resetFieldFilterStates({ reportMetadata, updatedFields, fields });
    } catch (error) {
      console.error('Error updating teamsites:', error);
    }
  };

  const getUpdatedTeamsitesIds = (updatedTeamsites) => {
    return updatedTeamsites
      ?.filter((teamsite) => teamsite.isSelected)
      .map((teamsite) => teamsite.id);
  };

  const getUpdatedReportMetadata = (
    newReportName?: string,
    newDescription?: string
  ) => {
    const updatedReportMetadata: UpdatedReportMetadata = {
      id,
      reportName: newReportName ?? updatedReportName,
      systemReportId,
      description: newDescription ?? updatedDescription,
      fields: updatedFields.filter((field) => field.isDefault),
      filters: getUpdatedFiltersToApply(updatedFilters),
      orderBy: updatedOrderBy,
      orderField: updatedOrderField,
      teamsiteIds: getUpdatedTeamsitesIds(updatedTeamsites),
    };
    return updatedReportMetadata;
  };

  const toggleColumnVisibility = (columnId: string) => {
    setColumnVisibility((prev) => ({
      ...prev,
      [columnId]: !prev[columnId],
    }));
  };

  const renderModalContent = () => {
    return (
      <>
        {isLoading || !fields ? (
          <FullScreenLoading loading={isLoading} />
        ) : (
          <ErrorBoundary>
            <div className='wrapper'>
              <div
                className='compile-report-modal-content'
                style={{ height: `calc(100vh - ${fullHeight}px)` }}
              >
                <ErrorBoundary>
                  <CompileReportSidePanel
                    currentVisibleTab={currentVisibleTab}
                    setCurrentVisibleTab={setCurrentVisibleTab}
                    isSidePanelVisible={isSidePanelVisible}
                    setIsSidePanelVisible={setIsSidePanelVisible}
                    totalHeight={fullHeight}
                    columnVisibility={columnVisibility}
                    toggleColumnVisibility={toggleColumnVisibility}
                    setColumnVisibility={setColumnVisibility}
                  />
                </ErrorBoundary>
                <div
                  style={{ height: `calc(100vh - ${fullHeight}px)` }}
                  className='compile-report-model-content-report-container'
                >
                  {previewReportMetadata && (
                    <ErrorBoundary>
                      <AsyncReportGrid
                        reportId={previewReportMetadata?.id}
                        reportName={previewReportMetadata?.reportName}
                        fields={previewReportMetadata?.fields}
                        filters={previewReportMetadata?.filters}
                        defaultSortField={previewReportMetadata?.orderField}
                        defaultSortOrder={previewReportMetadata?.orderBy}
                        resetRefreshPreview={resetRefreshPreview}
                        hideFilters
                        hideColumns
                        enableRefreshPreview
                        onSortUpdated={(sortModal) => {
                          setUpdatedOrderField(sortModal.field);
                          setUpdatedOrderBy(sortModal.sort);
                        }}
                        teamsites={previewReportMetadata?.teamsites}
                        showTeamsitePicker={
                          previewReportMetadata?.showTeamsitePicker
                        }
                        setCurrentVisibleTab={setCurrentVisibleTab}
                        setIsSidePanelVisible={setIsSidePanelVisible}
                        isSidePanelVisible={isSidePanelVisible}
                        columnVisibility={columnVisibility}
                      />
                    </ErrorBoundary>
                  )}
                </div>
              </div>
            </div>
          </ErrorBoundary>
        )}
      </>
    );
  };

  const renderWarningModals = () => {
    const header = showResetModal
      ? t('self_service_reports_reset_changes_confirmation', 'Reset changes?')
      : t('self_service_reports_unsaved_changes', 'Unsaved changes');
    const message = t(
      'self_service_reports_reset_changes_confirmation_description',
      'Are you sure you would like to reset all changes to the last save? You may not undo this action.'
    );

    const footerButtonProps = [
      {
        label: t('self_service_reports_cancel', 'Cancel'),
        variant: 'secondary',
        onClick: () => setShowResetModal(false),
        className: 'trk_button_ssrs-report_edit_reset_close_reset_modal',
      },
      {
        label: t('self_service_reports_reset', 'Reset'),
        variant: 'primary',
        onClick: () => {
          handleReset();
        },
        className: 'trk_button_ssrs-report_edit_reset_changes_to_original',
      },
    ];

    return (
      <>
        <Modal
          open={showResetModal}
          header={header}
          onClose={() => setShowResetModal(false)}
          style={{ width: '320px' }}
          footerButtonProps={footerButtonProps}
        >
          <div className='close-without-save-modal-content'>
            <p>{message}</p>
          </div>
        </Modal>
      </>
    );
  };

  const renderSavingModal = (isSaving: boolean) => {
    return (
      <>
        {isSaving ? (
          <Modal
            open={isSaving}
            displayCloseButton={false}
            size='xxs'
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              boxShadow: 'none',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <Spinner size={48} />
            </div>
          </Modal>
        ) : null}
      </>
    );
  };

  const renderErrorModals = () => {
    return (
      <>
        {flashErrorMessage?.triggerFlash && (
          <Modal
            open={flashErrorMessage?.triggerFlash}
            displayCloseButton={false}
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              boxShadow: 'none',
            }}
            size='xs'
          >
            <Toast
              variant='error'
              content={flashErrorMessage?.message}
              autoDismiss
              onClose={resetFlashErrorMessage}
              onDismiss={resetFlashErrorMessage}
            />
          </Modal>
        )}
      </>
    );
  };

  const renderSaveCopyModal = () => {
    return (
      <>
        {showSaveCopyModal && (
          <>
            {isLoadingAllReports ? (
              <FullScreenLoading loading={isLoadingAllReports} />
            ) : (
              <SaveCopyModal
                onClose={() => setShowSaveCopyModal(false)}
                onSaveCopy={(newReportName: string, newDescription: string) => {
                  handleSave(
                    isSaveCopyWithClose,
                    isSaveCopyClicked,
                    newReportName,
                    newDescription
                  );
                  setShowSaveCopyModal(false);
                }}
                suggestedReportName={suggestedReportName}
              />
            )}
          </>
        )}
      </>
    );
  };

  const renderTeamsitesConfirmModal = () => {
    if (isTeamsitesChangesLoading) {
      return renderSavingModal(isTeamsitesChangesLoading);
    } else {
      return (
        <>
          {updatedTeamsites?.length > 0 && (
            <TeamsitesConfirmModal
              onSave={() => {
                handleSave();
              }}
              setIsTeamsitesChangesLoading={setIsTeamsitesChangesLoading}
            />
          )}
        </>
      );
    }
  };

  return (
    <>
      <div className='compile-report-container'>
        <ViewReportTopNavigation
          onSaveCopy={() => {
            if (isEditStandard) {
              setShowSaveCopyModal(true);
            } else {
              setShowSaveCopyModal(true);
              setIsSaveCopyClicked(true);
            }
          }}
          onReset={() => setShowResetModal(true)}
          onSave={handleSave}
          setIsSidePanelVisible={setIsSidePanelVisible}
        />
        {renderModalContent()}
        {renderWarningModals()}
        {renderSavingModal(isSaving)}
        {renderErrorModals()}
        {renderSaveCopyModal()}
        {renderTeamsitesConfirmModal()}
      </div>
    </>
  );
};

export default CompileReport;
