import React from 'react';
import { Illustration500, Illustration404, IllustrationNoAccess, IllustrationPageLoadingTakingAWhile } from '@seismic/mantle';
import './ErrorBoundary.scss';
import { Trans } from 'react-i18next';
import { CustomComponentError } from './CustomComponentError';
import {
  getFieldAndFiltersModelErrorBoundaryComponents,
  getIllustrationSize,
} from '../../../../utils/reportFiltersUtils';
import BreadcrumbNavigation from '../../SSRTopNavigation/BreadcrumbNavigation';

export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    (this as any).state = {
      hasError: false,
      error: null,
      errorInfo: null,
      topErrorComponentName: null,
    };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error: error };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    console.log({ error }, { errorInfo }, errorInfo.componentStack);
    this.setState({
      error: error,
      errorInfo: errorInfo,
      topErrorComponentName: this.getLastComponentName(errorInfo.componentStack),
    });
  }

  getLastComponentName(componentStack) {
    const lines = componentStack.split('\n');
    for (let line of lines) {
      if (line.trim()) {
        const match = line.match(/in (\w+)/);
        if (match && match[1]) {
          return match[1];
        }
      }
    }
    return null;
  }

  render() {
    if ((this as any).state.hasError) {
      let statusCode = this.state.error?.httpRequestInfo?.statusCode || this.state.error?.status;
      let illustration;
      let errorTitle;
      let description;
      let i18nKeyTitle;
      let i18nKeyDescription;

      switch (statusCode) {
        case 404:
        case 500:
          illustration = <Illustration404 size="md" />;
          i18nKeyTitle = 'self_service_reports_404_error_title';
          i18nKeyDescription = 'self_service_reports_404_error_description';
          errorTitle = this.state.error?.title || 'Page Not Found';
          description =
            'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.';
          break;
        case 403:
        case 400:
          illustration = <IllustrationNoAccess size="lg" />;
          i18nKeyTitle = 'self_service_reports_403_error_title';
          i18nKeyDescription = 'self_service_reports_403_error_description';
          errorTitle = 'No access or no permissions';
          if (this.state?.error?.title && this.state?.error?.title?.toLowerCase().includes('inaccessible teamsites')) {
            i18nKeyDescription = 'self_service_reports_teamsites_access_error_description';
            description = 'You do not have access to the applied Teamsites.';
          } else if (this.state?.error?.title && this.state?.error?.title?.toLowerCase().includes('data area')) {
            i18nKeyDescription = 'self_service_reports_data_access_error_description';
            description = 'Your data access is restricted so this report is not available. This is controlled by your admin.';
          } else {
            description = 'You do not have the access to this report.';
          }
          break;
        case 502:
          illustration = <IllustrationPageLoadingTakingAWhile size="lg" />;
          i18nKeyTitle = 'self_service_reports_502_error_title';
          i18nKeyDescription = 'self_service_reports_502_error_description';
          errorTitle = 'Page/content loading taking a while';
          description =
            'Loading is taking longer than expected. We\'re looking into it.';
          break;
        default:
          if (this.state.topErrorComponentName) {
            if (
              this.state.topErrorComponentName ===
              getFieldAndFiltersModelErrorBoundaryComponents(this.state.topErrorComponentName)
            ) {
              i18nKeyDescription = 'self_service_reports_component_failure_description';
              description = 'Please select different operation to proceed.';
              return (
                <CustomComponentError
                  illustrationSize={getIllustrationSize(this.state.topErrorComponentName)}
                  i18nKeyDescription={i18nKeyDescription}
                  description={description}
                />
              );
            }
          } else {
            illustration = <Illustration500 size="md" />;
            i18nKeyTitle = 'self_service_reports_500_error_title';
            i18nKeyDescription = 'self_service_reports_500_error_description';
            errorTitle = 'Unable to connect';
            description =
              'We could not connect your account due to some technical error on our end. Please try connecting again.';
          }

          break;
      }

      return (
        <>
          <div className='ssrs-top-panel'>
            <div className='ssrs-navigation'>
              <BreadcrumbNavigation />
            </div>
          </div>
          <div className="mntl-state-view">
            <div className="mntl-state-view-icon">{illustration}</div>
            <div className="mntl-state-view-message">
              <div className="mntl-state-view-title">
                <Trans i18nKey={i18nKeyTitle} defaults={errorTitle} />
              </div>
              <div className="mntl-state-view-description">
                <Trans i18nKey={i18nKeyDescription} defaults={description} />
              </div>
            </div>
          </div>
        </>
      );
    }

    return (this as any).props.children;
  }
}
