import React from 'react';
import './CustomComponentError.scss';
import { Trans } from 'react-i18next';
import { Illustration404 } from '@seismic/mantle';

export const CustomComponentError = ({ illustrationSize, i18nKeyDescription, description }) => {
  return (
    <div className="custom-error-boundary">
      <div className="custom-error-boundary">
        <Illustration404 size={illustrationSize} />
      </div>
      <div className="custom-error-boundary-view-message">
        <div className="custom-error-boundary-view-message-description">
          <Trans i18nKey={i18nKeyDescription} defaults={description} />
        </div>
      </div>
    </div>
  );
};
