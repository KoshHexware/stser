import React from "react";
import "./NoSearchItems.scss";
import { IllustrationNothingToView } from "@seismic/mantle";
import { useTranslation } from "react-i18next";

export const NothingToView = () => {
  const { t } = useTranslation();
  return (
    <div className="no-search-items">
      <div>
        <IllustrationNothingToView size="md" />
      </div>
      <div className="no-search-items-view-message">
        <div className="no-search-items-view-message-title">
          {t("self_service_reports_no_toggle_results_title", "Nothing to view")}
        </div>
        <div className="no-search-items-view-message-description">
          {t(
            "self_service_reports_no_toggle_results_description",
            "There are no selected field items to view"
          )}
        </div>
      </div>
    </div>
  );
};
