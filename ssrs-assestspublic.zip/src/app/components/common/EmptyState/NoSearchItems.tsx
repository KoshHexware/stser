import React from 'react';
import './NoSearchItems.scss';
import { IllustrationNoSearchResults } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';

type NoSearchItemsProps = {
  size: 'sm' | 'md' | 'lg';
};

export const NoSearchItems = (props: NoSearchItemsProps) => {
  const { t } = useTranslation();
  return (
    <div className='no-search-items'>
      <div>
        <IllustrationNoSearchResults size={props.size} />
      </div>
      <div className='no-search-items-view-message'>
        <div className='no-search-items-view-message-title'>
          {t(
            'self_service_reports_no_search_results_title',
            'No search results'
          )}
        </div>
        <div className='no-search-items-view-message-description'>
          {t(
            'self_service_reports_no_search_results_description_message',
            'We couldn’t find anything matching your search query'
          )}
        </div>
      </div>
    </div>
  );
};
