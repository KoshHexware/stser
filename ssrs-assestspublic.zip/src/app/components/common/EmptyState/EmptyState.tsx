import React  from "react";
import "./EmptyState.scss";
import { useTranslation } from "react-i18next";
import { IllustrationAddNewContent } from "@seismic/mantle";

interface EmptyStateProps {
  isLarge?: boolean;
}

const EmptyStateLarge = () => {
  return (
    <div>
      <IllustrationAddNewContent size="md" />
    </div>
  );
};

const EmptyStateSmall = () => {
  return (
    <div>
      <IllustrationAddNewContent size="sm" />
    </div>
  );
};

export const EmptyState = ({isLarge}: boolean) => {
  const { t } = useTranslation();
  return (
    <div className={`emptyText ${isLarge && "emptyText-large"}`}>
      {isLarge ? <EmptyStateLarge /> : <EmptyStateSmall />}
      <div className={`emptyText-text ${isLarge && "emptyText-text-large"}`}>
        <p className="emptyText-heading">
          {t(
            "self_service_reports_empty_state_heading",
            "No data to see"
          )}
        </p>
        <span className="emptyText-content">
          {t(
            "self_service_reports_empty_state_content",
            "Edit your report fields or filters in order to see data."
          )}
        </span>
      </div>
    </div>
  );
};
