import React, { useContext, useEffect, useRef } from 'react';
import { FormField, Modal, Textarea } from '@seismic/mantle';
import { useTranslation } from 'react-i18next';
import autosize from 'autosize';
import './SaveCopyModal.scss';
import { CompileReportContext, ReportDataContext } from '../../../../contexts';
import { isEmpty } from 'lodash';
import { ReportNameError, validateReportName } from '../../../../utils/reportNameValidator';

interface SaveCopyModalProps {
  onClose: (value: boolean) => void;
  onSaveCopy: (newReportName: string, newDescription: string) => void;
  suggestedReportName?: string;
}

const SaveCopyModal = ({ onClose, onSaveCopy, suggestedReportName }: SaveCopyModalProps) => {
  const {
    updatedReportName,
    updatedDescription,
    setUpdatedReportName,
    setUpdatedDescription,
    id,
    reportName,
    description: defaultDescription,
    allReportsSummary,
    setShouldTriggerWithDefaultsAPI
  } = useContext(CompileReportContext);

  const { selectedReport } = useContext(ReportDataContext);

  const [showModal, setModalVisibility] = React.useState(true);
  const [title, setTitle] = React.useState(suggestedReportName || updatedReportName || selectedReport?.reportName || reportName || '');
  const [description, setDescription] = React.useState(updatedDescription || selectedReport?.description || defaultDescription || '');

  const [isInvalidReportName, setIsInvalidReportName] = React.useState(false);
  const [validationError, setValidationError] = React.useState('');
  const { t } = useTranslation();
  const descRef = useRef(null);
  const titleRef = useRef(null);

  useEffect(() => {
    if (descRef?.current) {
      autosize(descRef.current);
    }
    if (titleRef?.current) {
      autosize(titleRef.current);
    }
  }, []);

  useEffect(() => {
    const err = validateReportName(title, allReportsSummary);

    if (err === ReportNameError.CONTAINS_SPECIAL_CHARACTERS || err === ReportNameError.MAX_LENGTH_EXCEEDED) {
      setValidationError(t("self_service_reports_invalid_characters_error_message", "The report name should have less than 100 characters and may contain only text, number or special characters like \"_\", \"-\", \"(\" and \")\"."));
    }

    if (err === ReportNameError.EMPTY_OR_WHITESPACE) {
      setValidationError(t("self_service_reports_required_field_error_message", "This field is required."));
    }
    if (err === ReportNameError.VIOLATES_CUSTOM_REPORTS_UNIQUENESS) {
      setValidationError(
        t(
          'self_service_reports_report_name_change_toast_content_custom_report_exists_error',
          {
            reportName: title,
            defaultValue: `"${title}" already exists in your reports. Please select an alternative name.`,
          }
        ),
      )
    }
    if (err === ReportNameError.VIOLATES_SYSTEM_REPORTS_UNIQUENESS) {
      setValidationError(
        t(
          'self_service_reports_report_name_change_toast_content_system_report_exists_error',
          {
            reportName: title,
            defaultValue: `"${title}" is a Standard report name. Please select an alternative name.`,
          }
        ),
      )
    }
    setIsInvalidReportName(err !== ReportNameError.NONE);
  }, [title]);

  const isReportNameChanged = title.trim() !== updatedReportName.trim();


  const handleSaveCopy = () => {
    onSaveCopy(title.trim(), description.trim());
    setShouldTriggerWithDefaultsAPI(true);
    setModalVisibility(false);

  };

  return (
    <Modal
      open={showModal}
      className="savecopy-modal"
      onClose={() => {
        onClose(false);
      }}
      header={t('self_service_reports_save_copy', 'Save copy')}
      size="md"
      footerButtonProps={[
        {
          label: t('self_service_reports_cancel', 'Cancel'),
          variant: 'secondary',
          onClick: () => {
            onClose(false);
          },
          className: `trk_button_ssrs-report-cancel-save-copy-confirm-btn-${selectedReport?.reportType === 'System' ? 'standard' : 'custom'}-report`,
        },
        {
          label: t('self_service_reports_save_copy', 'Save copy'),
          variant: 'primary',
          id: 'btnSaveCopy',
          onClick: () => handleSaveCopy(),
          className: `trk_button_ssrs-report-save-copy-of-${selectedReport?.reportType === 'System' ? 'standard' : 'custom'}-report`,
          disabled: isInvalidReportName || !isReportNameChanged || isEmpty(description) || description.trim().length === 0,
        },
      ]}>

      <div className="savecopy-modal-container">
        <div>
          {t(
            'self_service_reports_save_copy_description',
            'Saving a copy of this standard report as a custom report will allow you to have full edit capabilities.'
          )}
        </div>
        <FormField
          className='form-field'
          error={isInvalidReportName ? validationError : undefined}
        >
          <div>
            <div className="formfield">
              <span>
                <div className="label">{t('self_service_reports_custom_report_name', 'Custom report name')}</div>
              </span>
            </div>
            <div>
              <Textarea
                value={title}
                className="custom-report-name"
                onChange={e => setTitle(e.target.value)}
                ref={titleRef}
                rows={1}
                maxLength={100}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                  }
                }}
                aria-label={t('self_service_reports_custom_report_name', 'Custom report name')}
              />
            </div>
          </div>
        </FormField>
        <FormField
          className='form-field'
          error={isEmpty(description) ? t("self_service_reports_required_field_error_message", "This field is required.") : undefined}>
          <div>
            <div className="formfield">
              <div className="label">
                <span>{t('self_service_reports_custom_report_description', 'Custom report description')}</span>
              </div>
              <div className="desc-count">{500 - description.length}</div>
            </div>
            <div>
              <Textarea
                value={description}
                className="custom-report-description mntl-scrollbar"
                onChange={e => setDescription(e.target.value)}
                ref={descRef}
                rows={2}
                maxLength={500}
                aria-label={t('self_service_reports_custom_report_description', 'Custom report description')}
              />
            </div>
          </div>
        </FormField>
      </div>
    </Modal>
  );
};

export default SaveCopyModal;
