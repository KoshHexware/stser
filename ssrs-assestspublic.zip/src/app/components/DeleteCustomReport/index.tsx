import React, { useContext } from 'react';
import { Modal } from '@seismic/mantle';
import ReportService from '../../../services/ReportService';
import {
  ReportDataContext,
  AllReportsLandingPageContext,
} from '../../../contexts';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

type IDeleteCustomReportProps = {
  deleteCustomReport: boolean;
  setDeleteCustomReport: (value: boolean) => void;
  customReportTitle: string;
  reportId?: string;
  onDeleted: () => void;
};

export const DeleteCustomReport = (props: IDeleteCustomReportProps) => {
  const {
    deleteCustomReport,
    setDeleteCustomReport,
    customReportTitle,
    reportId,
  } = props;
  const { selectedReport } = useContext(ReportDataContext);
  const { lastScreen } = useContext(AllReportsLandingPageContext);
  const isViewReportMode = lastScreen === 'VIEW_REPORT';
  const history = useHistory();
  const { t } = useTranslation();
  return (
    <Modal
      open={deleteCustomReport}
      onClose={() => setDeleteCustomReport(false)}
      header={() => {
        return (
          <h4>
            {t('self_service_reports_delete', 'Delete')} &lsquo;{`${customReportTitle}`}&rsquo;?
          </h4>
        );
      }}
      modalAriaLabel={t('self_service_reports_custom_report_delete_modal_arialabel', 'Custom report delete modal')}
      closeOnOutsideClick
      footerButtonProps={[
        {
          label: `${t('self_service_reports_go_back', 'Go back')}`,
          variant: 'secondary',
          onClick: () => setDeleteCustomReport(false),
          className: 'delete-custom-report-go-back trk-button-ssrs-cancel-delete',
        },
        {
          label: `${t('self_service_reports_delete', 'Delete')}`,
          variant: 'primary',
          onClick: () => {
            (async () => {
              await ReportService.deleteReportById(props?.reportId || selectedReport.id);
              setDeleteCustomReport(false);
              isViewReportMode ? history.push(`/selfservicereports`) : props?.onDeleted();
            })();
          },
          className: 'delete-custom-report-delete trk-button-ssrs-confirm-delete',
        },
      ]}
      className="delete-custom-report-modal"
    >
      <section>
        <div>
          {t(
            'self_service_reports_delete_confirmation',
            'Deleting will permenently remove this custom report. Are you sure you would like to delete ?'
          )}
        </div>
      </section>
    </Modal>
  );
};
