import React, { useContext, useEffect, useState } from 'react';
import { useHistory, useParams, useLocation } from 'react-router-dom';
import { Modal } from '@seismic/mantle';
import ReportService from '../../../services/ReportService';
import {
	IReportMetadata,
	UpdatedReportMetadata,
} from '../../../interfaces/IReport';
import {
	AllReportsLandingPageContext,
	ReportDataContext,
} from '../../../contexts';
import { Screens } from '../../../contexts/types';
import CompileReport from '../common/CompileReport';
import { ErrorBoundary } from '../common/ErrorBoundary';
import WithErrorBoundary from '../WithErrorBoundary';
import { FullScreenLoading } from '../common/FullScreenLoading';
import {
	isDeepLinkForSystemReport,
	caputureQueryParamsFromURl,
} from '../../../utils/deepLinkingUtils';
import { IQueryParamsTypes } from '../../../interfaces/IDeepLinkingTypes';
import {
	useAccessLevel,
	useApplicationInfo,
	useTenantUniqueId,
} from '../../../contexts/CommonServicesContext';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from '../../../utils/constants';
import {
	AuraPanelActionType,
	IAuraPanelAction,
} from '../../../auraPanelEvents/types/AuraPanelActionTypes';
import { triggerAuraPanelAction } from '../../../auraPanelEvents';
import {
	removeDrillInParamsForPreviousReport,
	getIsDrillInReport,
} from '../../../utils/drillInReportUtils';

const CreateReport = () => {
	const {
		setSelectedReport,
		lastScreen,
		setReportMetadata,
		reportMetadata,
		selectedReport,
		setShowReportSavedToast,
	} = useContext(ReportDataContext);
	const {
		setHideEditButtonOnError,
		setIsCompileReportMode,
		setCurrentScreen,
		setEnableSaveCopy,
		setReportData,
		setPagination,
	} = useContext(AllReportsLandingPageContext);
	const [fetchedReportMetadata, setFetchedReportMetadata] =
		useState<IReportMetadata>();
	const [isLoading, setIsLoading] = useState(true);
	const [isSaving, setIsSaving] = useState(false);
	const [flashErrorMessage, setFlashErrorMessage] = useState({
		triggerFlash: false,
		message: '',
	});
	const [isError, setIsError] = React.useState();
	const [isEditStandardReport, setIsEditStandardReport] = useState(false);
	const [isSavedOnce, setIsSavedOnce] = useState(false);

	const { id } = useParams<{ id: string }>();
	const history = useHistory();
	const { hasParams, params } = caputureQueryParamsFromURl();
	const applicationInfo = useApplicationInfo();
	const { UserId } = applicationInfo.User;
	const tenantUniqId = useTenantUniqueId();
	const { isDrillInReport, drillInParams } = getIsDrillInReport(
		UserId,
		tenantUniqId,
		id
	);
	const accessLevel = useAccessLevel();

	const location = useLocation();

	useEffect(() => {
		const unblockNavigation = history.block((location, action) => {
			if (action === 'POP') {
				//Reset selected report and metadata to avoid showing stale data if user comes back to this report after going back
				setSelectedReport({});
				setReportMetadata({});
				history.goBack(); 
				unblockNavigation();
			}
		});
		return () => {
			unblockNavigation();
		};
	}, [history]);

	useEffect(() => {
		const currentUrl: string = location.pathname;
		let previousUrl: string | null = null;
		try {
			const raw = localStorage.getItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				previousUrl =
					typeof parsed?.previous_drillIn_url === 'string'
						? (parsed.previous_drillIn_url as string)
						: null;
			}
		} catch (e) {
			previousUrl = null;
		}

		if (previousUrl !== null && previousUrl !== currentUrl) {
			removeDrillInParamsForPreviousReport(UserId, tenantUniqId);
		}
	}, [location.pathname]);

  useEffect(() => {
    if (fetchedReportMetadata?.reportType?.toLowerCase() === 'system') {
      setIsEditStandardReport(true);
    }
    if (fetchedReportMetadata?.id) {
      const action: IAuraPanelAction = {
        type: AuraPanelActionType.REPORT_PAGE,
        payload: {
          reportId: fetchedReportMetadata?.id || id,
        }
      };
      triggerAuraPanelAction(action);
    }
  }, [fetchedReportMetadata]);

	const setSelectedReportData = (reportMetaData) => {
		setSelectedReport({
			reportName: reportMetaData.reportName,
			id: id,
			reportType: reportMetaData.reportType,
			systemReportName: reportMetaData.systemReportName,
			description: reportMetaData?.description,
			ownerUserId: reportMetaData?.ownerUserId,
		});
		setReportMetadata(reportMetaData);
	};

	useEffect(() => {
		if ((hasParams && params) || isDrillInReport) {
			(async () => {
				ReportService.getReportMetaData(
					id,
					true,
					isDrillInReport ? drillInParams.isDrillIn : params.isDrillIn,
					isDrillInReport
						? drillInParams.sourceReportId
						: params.sourceReportId,
					isDrillInReport
						? drillInParams.sourceReportDrillInColumn
						: params.sourceReportDrillInColumn
				)
					.then((reportMetaData): Promise<any> => {
						// Call second API after first one succeeds
						const reportData = {
							id: reportMetaData?.id,
							reportType: reportMetaData?.reportType,
						};
						const isDeepLink = isDeepLinkForSystemReport(
							reportData,
							accessLevel
						);

						//if (isDeepLink) {
						// Create queryParams only if they are present in params
						const options: IQueryParamsTypes = {};

						if (isDrillInReport) {
							if (drillInParams.filters)
								options.filters = drillInParams.filters;
							if (drillInParams.isDrillIn)
								options.isDrillIn = drillInParams.isDrillIn;
							if (drillInParams.sourceReportId)
								options.sourceReportId = drillInParams.sourceReportId;
							if (drillInParams.sourceReportDrillInColumn)
								options.sourceReportDrillInColumn =
									drillInParams.sourceReportDrillInColumn;
						} else {
							if (params.fields) options.fields = params.fields;
							if (params.filters) options.filters = params.filters;
							if (params.orderBy) options.orderBy = params.orderBy;
							if (params.skip) options.skip = params.skip;
							if (params.take) options.take = params.take;
							if (params.orderField) options.orderField = params.orderField;
							if (params.teamsiteIds) options.teamsiteIds = params.teamsiteIds;
							if (params.isDrillIn !== undefined)
								options.isDrillIn = params.isDrillIn;
							if (params.sourceReportId)
								options.sourceReportId = params.sourceReportId;
							if (params.sourceReportDrillInColumn)
								options.sourceReportDrillInColumn =
									params.sourceReportDrillInColumn;
						}

						return ReportService.getReportDataWithDefaults(id, options);
						//}

						// If not a deep link, reject the promise to trigger the catch block
						//return Promise.reject({ status: 500 });
					})
					.then(({ data, pagination, report }) => {
						const reportMetaData = report;
						setFetchedReportMetadata({
							...reportMetaData,
							reportName: reportMetaData?.reportName,
						});
						setSelectedReportData(reportMetaData);
						setEnableSaveCopy(true);
						setReportData(data);
						setPagination(pagination);
						if (history.location.search) {
							history.push({ search: '' });
						}
					})
					.catch((error) => {
						console.error('Error while fetching report metadata', error);
						setIsError(error);
						setHideEditButtonOnError(true);
					})
					.finally(() => {
						setIsLoading(false);
					});
			})();
		}
	}, []);

	useEffect(() => {
		if (isError) {
			throw isError;
		}
	}, [isError]);

	const onClose = () => {
		if (lastScreen && lastScreen != Screens.VIEW_REPORT) {
			setSelectedReport({});
			setReportMetadata(undefined);
		}
		setIsCompileReportMode(false);
		history.push(`/selfservicereports`);
	};

	const resetFlashErrorMessage = () => {
		setFlashErrorMessage({
			triggerFlash: false,
			message: '',
		});
	};

	const updateSelectedReport = (reportMetaData) => {
		setSelectedReport({
			reportName: reportMetaData.reportName,
			id: reportMetaData.id,
			reportType: reportMetaData.reportType,
			systemReportName: reportMetaData.systemReportName,
			description: reportMetaData?.description,
			ownerUserId: reportMetaData?.ownerUserId,
		});
		setReportMetadata(reportMetaData);
	};

	useEffect(() => {
		setCurrentScreen(Screens.EDIT_REPORT);
		// Only execute this useEffect if hasParams is false or params is not present
		if ((!hasParams || !params) && !isDrillInReport) {
			if (
				(id && !selectedReport?.id) ||
				selectedReport?.id !== reportMetadata?.id
			) {
				if (id === reportMetadata?.id) {
					setSelectedReportData(reportMetadata);
					setIsLoading(false);
				} else {
					(async () => {
						let options = { addToRecent: true };
						ReportService.getReportDataWithDefaults(id, options)
							.then(({ data, pagination, report }) => {
								const reportMetaData = report;
								setFetchedReportMetadata({
									...reportMetaData,
									reportName: reportMetaData?.reportName,
								});
								setSelectedReportData(reportMetaData);
								setEnableSaveCopy(false);
								setReportData(data);
								setPagination(pagination);
							})
							.catch((error) => {
								console.error('Error while fetching report metadata', error);
								setIsError(error);
								setHideEditButtonOnError(true);
							})
							.finally(() => {
								setIsLoading(false);
							});
					})();
				}
			} else if (selectedReport?.id) {
				if (id === reportMetadata?.id) {
					setFetchedReportMetadata({
						...reportMetadata,
						reportName: reportMetadata?.reportName,
					});
				}
				setIsLoading(false);
			}
		}
	}, []);

  const createOrUpdateReport = async (
    updatedReport: UpdatedReportMetadata,
    closeAfterSave: boolean,
    isSaveCopyClicked: boolean
  ) => {
    setIsSaving(true);
    if (isEditStandardReport || isSaveCopyClicked) {
      const newReport = {
        ...updatedReport,
        systemReportId: isSaveCopyClicked
          ? updatedReport?.systemReportId
          : fetchedReportMetadata?.id,
        fromCustomReport: isEditStandardReport ? false : true,
        application: "WEB",
      };
      ReportService.createCustomReport(newReport)
        .then((response) => {
          setFetchedReportMetadata(response);
          updateSelectedReport(response);
          setIsSavedOnce(true);
          setIsEditStandardReport(false);
          setShowReportSavedToast(true);
          history.push(`/selfservicereports/report/${response.id}`);
        })
        .catch((error) => {
          console.error('Error creating report:', error);
          setFlashErrorMessage({ triggerFlash: true, message: error.title });
        })
        .finally(() => {
          setIsSaving(false);
        });
    } else {
      const newReport = { ...updatedReport, id: fetchedReportMetadata?.id, application: "WEB" };
      setIsSaving(true);
      ReportService.updateCustomReport(newReport, newReport?.id)
        .then((response) => {
          setFetchedReportMetadata(response);
          updateSelectedReport(response);
          setIsSaving(false);
          setIsSavedOnce(true);
          setShowReportSavedToast(true);
          if (closeAfterSave) {
            onClose();
          } else {
            history.push(`/selfservicereports/report/${response.id}`);
          }
        })
        .catch((error) => {
          console.error('Error updating report:', error);
          setFlashErrorMessage({ triggerFlash: true, message: error.title });
        })
        .finally(() => {
          setIsSaving(false);
        });
    }
  };

	return (
		<>
			{fetchedReportMetadata && !isLoading ? (
				<ErrorBoundary>
					<CompileReport
						reportMetadata={fetchedReportMetadata}
						isEditStandard={isEditStandardReport}
						onSave={createOrUpdateReport}
						isLoading={isLoading}
						isSaving={isSaving}
						flashErrorMessage={flashErrorMessage}
						resetFlashErrorMessage={resetFlashErrorMessage}
						mode={'create'}
						isSaved={isSavedOnce}
					/>
				</ErrorBoundary>
			) : (
				<div className='compile-report-container'>
					<Modal fullscreen inverted displayCloseButton={false}>
						{() => <FullScreenLoading loading={isLoading} />}
					</Modal>
				</div>
			)}
		</>
	);
};

export default  WithErrorBoundary(CreateReport);
