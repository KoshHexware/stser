import { HttpService, instance, ServiceAddressService } from 'seismic-common';
import {  IReportMetadata, ReportsSummary } from '../interfaces/IReport';
import {  IUserSettings } from '../interfaces/IAppData';
import { IQueryParamsTypes } from '../interfaces/IDeepLinkingTypes';
import { INewUpdatedUserAccessList, ISSRUser, IUserOrGroup, SearchPeopleParams } from '../interfaces/IShareReportsTypes';

class ReportService {
  private static isExecuting: boolean = false;
  private static queue: Array<() => void> = [];
  private static cache: Map<string, { response: any; timestamp: number }> =
    new Map();

  private static async getHost(): Promise<string> {
    return instance
      .getService(ServiceAddressService)
      .getServiceAddressByKey('ssrs');
  }

  public static async checkAccess(): Promise<string> {
    const checkAccessPath = 'api/v1/access';
    const url = `${await ReportService.getHost()}/${checkAccessPath}`;
    const response: any = await instance.getService(HttpService).get(url);
    return response;
  }

  public static async hasAccess(): Promise<boolean> {
    const checkAccessPath = 'api/v1/hasaccess';
    const url = `${await ReportService.getHost()}/${checkAccessPath}`;
    const response: any = await instance.getService(HttpService).get(url);
    return response;
  }

  public static async getReports(
    skip: number,
    take: number,
    reportType = 'all',
    searchTerm: string | '',
    orderField: string | null,
    orderBy: string | null
  ): Promise<[]> {
    const host = await ReportService.getHost();
    let parmsString = `reportType=${reportType}&skip=${skip}&take=${take}&orderField=${orderField}&orderBy=${orderBy}`;
    if (searchTerm) {
      parmsString += `&searchText=${searchTerm}`;
    }
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/reports/all?${parmsString}`);
    return response;
  }

  public static async getRecentReports(
    skip: number,
    take: number,
    searchTerm: string | '',
    orderField: string | null,
    orderBy: string | null
  ): Promise<[]> {
    const host = await ReportService.getHost();
    let parmsString = `skip=${skip}&take=${take}&orderField=${orderField}&orderBy=${orderBy}`;
    if (searchTerm) {
      parmsString += `&searchText=${searchTerm}`;
    }
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/reports/recent?${parmsString}`);
    return response;
  }

  public static async executeReportById(
    reportId: string,
    fields: [],
    filters: [],
    skip: number,
    take: number,
    orderField: string | null,
    orderBy: string | null,
    teamsiteIds: [],
    isSavedReport: boolean = true
  ): Promise<[]> {
    return new Promise((resolve, reject) => {
      const execute = async () => {
        if (ReportService.isExecuting) {
          ReportService.queue.push(execute);
          return;
        }

        ReportService.isExecuting = true;

        try {
          const host = await ReportService.getHost();
          let parmsString = `skip=${skip}&take=${take}`;
          parmsString += `&fields=${encodeURIComponent(
            JSON.stringify(
              fields.map((f: any) => {
                return {
                  name: f.name,
                  isProperty: f.isProperty,
                  propertyType: f.propertyType,
                  propertyId: f.propertyId,
                };
              })
            )
          )}`;
          parmsString += `&filters=${encodeURIComponent(
            JSON.stringify(filters)
          )}`;
          parmsString += `&teamsiteIds=${encodeURIComponent(
            JSON.stringify(teamsiteIds)
          )}`;
          if (!!orderField) {
            parmsString += `&orderField=${orderField}&orderBy=${orderBy}`;
          }
          parmsString += `&isSavedReport=${isSavedReport}`;
          const url = `${host}/api/v1/report/execute/${reportId}?${parmsString}`;

          // Check if the response is already in the cache and not expired
          const cached = ReportService.cache.get(url);
          const now = Date.now();
          if (cached && now - cached.timestamp < 30 * 60 * 1000) {
            // 30 minutes in milliseconds
            resolve(cached.response);
            return;
          }

          const response: any = await instance.getService(HttpService).get(url);

          // Store the response in the cache with the current timestamp
          ReportService.cache.set(url, { response, timestamp: now });

          // Limit the cache to the last 10 responses
          if (ReportService.cache.size > 10) {
            const keys = Array.from(ReportService.cache.keys());
            ReportService.cache.delete(keys[0]);
          }

          resolve(response);
        } catch (error) {
          reject(error);
        } finally {
          ReportService.isExecuting = false;
          if (ReportService.queue.length > 0) {
            const next = ReportService.queue.shift();
            if (next) next();
          }
        }
      };

      execute();
    });
  }

  public static async exportReport(
    reportId: string,
    fields: Array<any>,
    orderField: string | null,
    orderBy: string | null,
    filters: string[] = [],
    teamsiteIds: string[] = [],
    isSavedReport = true,
    isDrillIn: boolean,
    sourceReportId: string | null,
    sourceReportDrillInColumn: string | null
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const noDefaultFilters = filters.filter((f) => f?.values?.length > 0);
    let paramsString = `fields=${encodeURIComponent(
      JSON.stringify(
        fields.map((f: any) => {
          return {
            name: f.name,
            isProperty: f.isProperty,
            propertyType: f.propertyType,
            propertyId: f.propertyId,
          };
        })
      )
    )}`;
    paramsString += `&filters=${encodeURIComponent(
      JSON.stringify(noDefaultFilters)
    )}`;
    paramsString += `&teamsiteIds=${encodeURIComponent(
      JSON.stringify(teamsiteIds)
    )}`;

    if (!!orderField) {
      paramsString += `&orderField=${orderField}&orderBy=${orderBy}`;
    }
    paramsString += `&timezoneId=${Intl.DateTimeFormat().resolvedOptions().timeZone}`;
    paramsString += `&isSavedReport=${isSavedReport}`;
    paramsString += `&isDrillIn=${isDrillIn}`;
    paramsString += `&sourceReportId=${encodeURIComponent(sourceReportId || '')}`;
    paramsString += `&sourceReportDrillInColumn=${encodeURIComponent(sourceReportDrillInColumn || '')}`;
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/report/export/${reportId}?${paramsString}`, {
        responseContentType: 'text',
      });
    return response;
  }

  public static async createCustomReport(newReport: any): Promise<any> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .post(`${host}/api/v1/report`, newReport);
    return response;
  }

  public static async updateCustomReport(
    updatedReport: any,
    reportId: string
  ): Promise<any> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .put(`${host}/api/v1/report/${reportId}`, updatedReport);
    return response;
  }

  public static async getReportMetaData(
    reportId: string,
    addToRecent = false,
    isDrillIn: boolean = false,
    sourceReportId: string | null = null,
    sourceReportDrillInColumn: string | null = null
  ): Promise<IReportMetadata> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/report/${reportId}?addToRecent=${addToRecent}&isDrillIn=${isDrillIn}&sourceReportId=${encodeURIComponent(sourceReportId || '')}&sourceReportDrillInColumn=${encodeURIComponent(sourceReportDrillInColumn || '')}`);
    return response;
  }

  public static async deleteReportById(reportId: string): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .delete(`${host}/api/v1/report/${reportId}`);
    return response;
  }

  public static async getPickListFilters(
    filterName: string,
    systemReportId: string,
    teamsiteIds = []
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .get(
        `${host}/api/v1/filter/${filterName}/values?systemReportId=${systemReportId}&teamsiteIds=${encodeURIComponent(
          JSON.stringify(teamsiteIds)
        )}`
      );
    return response;
  }

  public static async getUserSettings(): Promise<IUserSettings> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/user/settings`);
    return response;
  }

  public static async updateReportFilterOption(
    filterOption: string
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .patch(`${host}/api/v1/user/filterOption/${filterOption}`);
    return response;
  }

  public static async updateUserSettingsGlobalTeamsites(
    teamsiteIds: any
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .patch(`${host}/api/v1/user/teamsites`, teamsiteIds);
    return response;
  }

  public static async getSSRUsersList(): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/share/users`);
    return response;
  }

  public static async getReportSharedUserList(reportId: string): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/share/report/${reportId}`);
    return response;
  }

  public static async updateSharedReportsUsersAccessList(
    accessList: INewUpdatedUserAccessList,
    reportId: string
  ): Promise<[]> {
    const payload = {
      NewSharedUserIds: accessList.newSharedUserIds ?? [],
      NewSharedGroupIds: accessList.newSharedGroupIds ?? [],
      RemovedUserIds: accessList.removedUserIds ?? [],
      RemovedGroupIds: accessList.removedGroupIds ?? [],
    };
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .post(`${host}/api/v1/share/report/${reportId}`, payload);
    return response;
  }

  public static async updateReportName(
    reportId: string,
    reportName: string
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .patch(`${host}/api/v1/report/${reportId}/name`, `"${reportName}"`);
    return response;
  }

  public static async updateReportDescription(
    reportId: string,
    reportDescription: string
  ): Promise<[]> {
    const host = await ReportService.getHost();
    const response: any = await instance
      .getService(HttpService)
      .patch(`${host}/api/v1/report/${reportId}/description`, {
        description: reportDescription,
      });
    return response;
  }

  /**
   * Fetches report data with default settings
   *
   * @param reportId - Unique identifier for the report
   * @param filters - Optional array of filter criteria to apply to the report
   * @param fields - Optional array of fields to include in the report output
   * @param skip - Optional number of records to skip (for pagination)
   * @param take - Optional number of records to take (for pagination)
   * @param orderField - Optional field name to sort results by
   * @param orderBy - Optional sort direction ('asc' or 'desc')
   * @param teamsiteIds - Optional array of teamsite IDs to filter the report data
   * @param addToRecent - Optional flag to indicate if the report should be added to recent reports
   * @returns Promise resolving to an array containing the report data
   */

  public static async getReportDataWithDefaults(
    reportId: string,
    options: IQueryParamsTypes = {}
  ): Promise<{ data: any[]; pagination: any; report: IReportMetadata }> {
    const host = await ReportService.getHost();
    let parmsArray: string[] = [];

    const {
      filters,
      fields,
      skip,
      take,
      orderBy,
      orderField,
      teamsiteIds,
      isSavedReport = true,
      addToRecent,
      isDrillIn = false,
      sourceReportId,
      sourceReportDrillInColumn,
    } = options;

    if (filters && filters.length > 0) {
      parmsArray.push(`filters=${encodeURIComponent(JSON.stringify(filters))}`);
    }
    if (fields && fields.length > 0) {
      parmsArray.push(`fields=${encodeURIComponent(JSON.stringify(
        fields.map((f: any) => {
          return {
            name: f.name,
            isProperty: f.isProperty,
            propertyType: f.propertyType,
            propertyId: f.propertyId,
          };
        })
      ))}`);
    }
    if (skip !== undefined) {
      parmsArray.push(`skip=${skip}`);
    }
    if (take !== undefined) {
      parmsArray.push(`take=${take}`);
    }
    if (orderField) {
      parmsArray.push(`orderField=${orderField}`);
    }
    if (orderBy) {
      parmsArray.push(`orderBy=${orderBy}`);
    }
    if (teamsiteIds && teamsiteIds.length > 0) {
      parmsArray.push(
        `teamsiteIds=${encodeURIComponent(JSON.stringify(teamsiteIds))}`
      );
    }
    if (addToRecent !== undefined) {
      parmsArray.push(`addToRecent=${addToRecent}`);
    }

    if (isDrillIn) {
      parmsArray.push(`isDrillIn=${isDrillIn}`);
      parmsArray.push(`sourceReportId=${encodeURIComponent(sourceReportId || '')}`);
      parmsArray.push(`sourceReportDrillInColumn=${encodeURIComponent(sourceReportDrillInColumn || '')}`);
    }

    parmsArray.push(`isSavedReport=${isSavedReport}`);

    let url = `${host}/api/v1/report/execute/${reportId}/withDefaults`;
    if (parmsArray.length > 0) {
      url += `?${parmsArray.join('&')}`;
    }

    const response: any = await instance.getService(HttpService).get(url);
    return response;
  }

  public static async getReportsSummary(): Promise<ReportsSummary[]> {
    const host = await ReportService.getHost();
    const response: ReportsSummary[] = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/reports/owned`);
    return response;
  }

  public static async searchPeoples(params: SearchPeopleParams, tenantId: string): Promise<IUserOrGroup[]> {
    const umsbffAddress = await instance
      .getService(ServiceAddressService)
      .getServiceAddressByKey('umsbff');
    const {
      keyword = '',
      objectType = 'All',
      includeHierarchyGroups = false,
      pageIndex = 0,
      pageSize = 200
    } = params;

    const response = await instance
      .getService(HttpService)
      .post<{ count: number; items: any[] }>(
        `${umsbffAddress}/api/v1/tenants/${tenantId}/peoples/search`,
        {
          filter: { keyword, objectType, includeHierarchyGroups },
          pageIndex,
          pageSize,
          orderBy: 'Name',
          orderAsc: true
        }
      );
      return response.items;
  }

  public static async getReportOwnerDetails(reportId: string): Promise<ISSRUser> {
    const host = await ReportService.getHost();
    const response: ISSRUser = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/share/report/${reportId}/owner`);
    return response;
  }

  public static async getShareRecipients(searchKeyword: string, pageIndex: number): Promise<{hasNextPage: boolean; items: ISSRUser[]}> {
    const host = await ReportService.getHost();
    let parmsArray: string[] = [];
    if (searchKeyword){
      parmsArray.push(`searchKeyword=${encodeURIComponent(searchKeyword)}`);
    }
    if(pageIndex !== undefined && pageIndex >=0){
      parmsArray.push(`pageIndex=${pageIndex}`);
    }
    const paramsString = parmsArray.join('&');
    const response: any = await instance
      .getService(HttpService)
      .get(`${host}/api/v1/share/recipients?${paramsString}`);
    return response;
  }
}

export default ReportService;
