export type ISSRUser = {
  id: string;
  legacyId: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  title: string;
  organization: string;
  thumbnailId: string;
  thumbnailUrl: string;
  type?: 'User' | 'Group';
  isGroup?: boolean;
  userGroupId?: string;
  userGroupName?: string;
};

export type IShareReportData = {
  ssrUsersList: ISSRUser[];
  sharedReportUsers: ISSRUser[];
};

export type INewUpdatedUserAccessList = {
  newSharedUserIds?: string[];
  newSharedGroupIds?: string[];
  removedUserIds?: string[];
  removedGroupIds?: string[];
};

export type IAccessUpdatedAPIStatus = 'loading' | 'success' | 'error';

export type IShareReportsState = {
  showAccessMenuButton: boolean;
  sharedReportUsers: ISSRUser[];
  ssrsAccessUsersList: ISSRUser[];
  usersHasAccess: ISSRUser[];
  usersNoAccess: ISSRUser[];
  updatedUsersAccessList: INewUpdatedUserAccessList;
  isAccessUpdated: boolean;
  searchUser: string;
  searchNoAccessUsersFound: boolean;
  accessUpdatedAPIStatus: IAccessUpdatedAPIStatus;
};

export type IShareReportsContext = IShareReportsState & {
  setShowAccessMenuButton: (showAccessMenuButton: boolean) => void;
  setSharedReportUsers: (sharedReportUsers: ISSRUser[]) => void;
  setSSRsAccessUsersList: (ssrsAccessUsersList: ISSRUser[]) => void;
  setUsersHasAccess: (usersHasAccess: ISSRUser[]) => void;
  setUsersHasNoAccess: (usersNoAccess: ISSRUser[]) => void;
  setUpdatedUsersAccessList: (
    updatedUsersAccessList: INewUpdatedUserAccessList
  ) => void;
  setIsAccessUpdated: (isAccessUpdated: boolean) => void;
  setSearchUser: (searchUser: string) => void;
  setSearchNoAccessUsersFound: (searchNoAccessUsersFound: boolean) => void;
  setAccessUpdatedAPIStatus: (accessUpdatedAPIStatus: IAccessUpdatedAPIStatus) => void;
};

export enum ViewType {
  AccessList = 'AccessList',
  GrantPermission = 'GrantPermission',
  RequestPermission = 'RequestPermission',
}

export enum ActionType {
  Edit = 'edit',
  View = 'view',
  Remove = 'remove',
  TransferOwner = 'transferOwner',
  Manage = 'manage',
  Add = 'add',
  UnknownAction = 'unknown',
}

export interface IUserOrGroup {
  id: string;
  name: string; 
  email: string;
  type: 'User' | 'Group';
  title?: string;
  groupType?: string,
  avatarBlobId?: string,
}

export type SearchPeopleParams = {
  keyword?: string;
  objectType: 'User' | 'Group' | 'All';
  orderBy?: string;
  orderAsc?: boolean;
  pageIndex?: number;
  pageSize?: number;
  includeHierarchyGroups: boolean;
};
