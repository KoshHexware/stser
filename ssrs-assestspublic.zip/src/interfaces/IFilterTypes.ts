export enum ITextOperations {
  CONTAINS = "Contains",
  DOES_NOT_CONTAIN = "DoesNotContain",
  BEGINS_WITH = "BeginsWith",
  ENDS_WITH = "EndsWith",
  STARTS_WITH = "StartsWith",
  EQUALS = "Equals",
  EQUAL = "Equal",
  NOT_EQUAL = "NotEqual",
  NOT_EQUALS = "NotEquals",
  CONTAINS_ANY = "ContainsAny",
  CONTAINS_ALL = "ContainsAll",
  IS_ONE_OF = "IsOneOf",
  IS_NOT_ONE_OF = "IsNotOneOf",
  NOT_CONTAINS = "NotContains",
  IS_CURRENT_USER = "IsCurrentUser",
  IS_MY_TEAM = "IsMyTeam",
}

export enum INumberOperations {
  EQUALS = "Equals",
  NOT_EQUALS = "NotEquals",
  EQUAL = "Equal",
  NOT_EQUAL = "NotEqual",
  GREATER_THAN = "GreaterThan",
  LESS_THAN = "LessThan",
  GREATER_THAN_OR_EQUAL = "GreaterThanOrEqual",
  LESS_THAN_OR_EQUAL = "LessThanOrEqual",
  BETWEEN = "Between",
  IN = "In",
}

export enum IDateOperations {
  EQUAL = "Equal",
  EQUALS = "Equals",
  NOT_EQUAL = "NotEqual",
  NOT_EQUALS = "NotEquals",
  DOES_NOT_EQUAL = "DoesNotEqual",
  BEFORE = "Before",
  AFTER = "After",
  BETWEEN = "Between",
  GREATER_THAN = "GreaterThan",
  LESS_THAN = "LessThan",
  GREATER_THAN_OR_EQUAL = "GreaterThanOrEqual",
  LESS_THAN_OR_EQUAL = "LessThanOrEqual",
  IN_THE_LAST = "InTheLast",
  IN_THE_NEXT = "InTheNext",
  NAMED_RANGE = "NamedRange",
}

export enum IBooleanOperations {
  EQUALS = "Equals",
  NOT_EQUALS = "NotEquals",
}

export enum INullishOperations {
  BLANK = "IsNull",
  NOT_BLANK = "IsNotNull",
}

export type IOperatorDetails = {
  name: ITextOperations | INumberOperations | IDateOperations | IBooleanOperations | INullishOperations;
  value: ITextOperations | INumberOperations | IDateOperations | IBooleanOperations | INullishOperations;
  uxLabel: string;
  label: string;
  /**
     * If `true`, the disabled styles will be applied to the option.
     * @default false
     */
  disabled?: boolean;
  reason?: string;
};

export enum IFilterDataType {
  TEXT = "Text",
  INTEGER = "Integer",
  DECIMAL = "Decimal",
  SDECIMAL = "decimal",
  FLOAT = "Float",
  SFLOAT = "float",
  DOUBLE = "Double",
  SDOUBLE = "double",
  DATE = "Date",
  DATE_TIME = "DateTime",
  BOOLEAN = "Boolean",
  CSV = "Csv",
}

export enum FILTER_TYPE {
  FREETEXT = "freetext",
  PICKLIST = "picklist",
  DOMAIN_OF_VALUES = "domainOfValues",
}

export type IFilter = {
  allowedOperators: IOperatorDetails[];
  category: string;
  dataType: IFilterDataType;
  filterName: string;
  filterPicklistQuery?: string;
  filterType: FILTER_TYPE;
  filterDefaultValues?: string[] | null;
  queryParam: string;
  uxDescription: string;
  uxLabel: string;
  operation: string;
  isDefault: boolean;
  values: string[] | number[];
  domainValues: string[];
  pickListValues: string[] | number[];
  isNewlyAdded: boolean;
  isNullable: boolean | null | undefined;
  filterValuesByTeamsite: boolean;
  enableRelativeUserFilterField: boolean;
};

export type IFilterError = {
  isError: boolean;
  errorMessage: string;
}

export type IFilterPickList = {
  filterName: string;
  values: string[] | number[];
}
