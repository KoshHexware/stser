import { IReportMetadata } from '../interfaces/IReport';

export type IFieldAndFilterState = {
  currentActiveTab: string;
  totalItems: number;
  totalItemsSelected: number;
  isDoneButtonClicked: boolean;
  isFieldsCancelClicked: boolean;
  isFiltersCancelClicked: boolean;
  currentCategorySelected: string;
  isToggled: boolean;
  finalUpdatedFields: [];
  isClearedClicked: boolean;
  initialFields: [];
  fields: [];
  updatedFields: [];
  finalUpdatedFilters: [],
  initialFilters: [],
  reportMetadata: IReportMetadata,
  isSidePanelExpanded: boolean;
};

export type IFieldAndFilterContext = IFieldAndFilterState & {
  setCurrentActiveTab: (currentActiveTab: string) => void;
  setTotalItems: (totalItems: number) => void;
  setTotalItemsSelected: (totalItemsSelected: number) => void;
  setCurrentCategorySelected: (currentCategorySelected: string) => void;
  setIsToggle: (isToggled: boolean) => void;
  setFinalUpdatedFields: (finalUpdatedFields: []) => void;
  setIsClearedClicked: (isClearedClicked: boolean) => void;
  resetFieldFilterStates: (data: any) => void;
  setIsDoneButtonClicked: (isDoneButtonClicked: boolean) => void;
  setFinalUpdatedFilters: (finalUpdatedFilters: []) => void,
  setIsSidePanelExpanded: (isSidePanelExpanded: boolean) => void;
};
