import { IFilter } from "./IFilterTypes";
import { IField } from "./IReport";

export type IQueryParamsTypes = {
  fields?: IField[];
  filters?: IFilter[];
  orderBy?: "asc" | "desc";
  skip?: number;
  take?: number;
  orderField?: string;
  teamsiteIds?: string[];
  isSavedReport?: boolean;
  addToRecent?: boolean;
  isDrillIn?: boolean;
  sourceReportId?: string;
  sourceReportDrillInColumn?: string;
}