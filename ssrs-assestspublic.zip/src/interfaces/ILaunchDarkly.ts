export interface ILaunchDarklyToggle {
  FeatureKey: string;
  FeatureState: "True" | "False";
}
