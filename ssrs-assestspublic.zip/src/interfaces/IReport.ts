import { IFilter } from "./IFilterTypes";
import { ITeamsites } from "../interfaces/IAppData";

export type IReport = {
  schemas: {
    IColumn: IReportColumn[];
    IData: IReportData[];
  };
};

export type IReportColumn = {
  key: string;
  label: string;
  isSortable: boolean;
  isDefault: boolean;
  cellRenderer?: string;
};

export type IReportData = {
  [key: string]: any;
};

export type ISystemReport = {
  id: string;
  reportName: string;
  description: string;
  domain: string;
  ownerUserName: string;
  ownerUserId: string;
  lastViewed: string;
  reportType: string;
};

export type ISelectedReport = {
  description: string;
  domain: string;
  id: string;
  lastUpdated: string;
  lastViewed: string;
  ownerThumbnailUrl: string;
  ownerUserId: string;
  ownerUserName: string;
  reportName: string;
  reportType: string;
  systemReportId: string;
  systemReportName: string;
  userId: string;
};

export enum IReportStatusType {
  UNSAVED_CHANGES = 'Unsaved changes',
  SAVED_CHANGES = 'Changes have been saved',
  NOT_MADE_CHANGES = "You haven't made any changes",
}

export type IReportMetadata = {
  id: string;
  reportName: string;
  description: string;
  domain: string;
  ownerUserName: string;
  ownerUserId: string;
  lastUpdated: string;
  reportType: string;
  orderField: string;
  orderBy: string;
  standardReportMetadata: StandardReportMetadata;
  showTeamsitePicker: boolean;
  teamsites: ITeamsites[];
  appliedFilters: IFilter[];
  requestedFields: IField[];
  systemReportId: string;
};

export type StandardReportMetadata = {
  name: string;
  description: string;
  orderField: string;
  orderBy: string;
  filters: IFilter[];
  fieldGroups: FieldGroup[];
  filterGroup: {
    id: string;
    uxLabel: string;
    filters: IFilter[];
  }[];
  charts: Chart[];
  filterCategoryOrder: string[];
};

export type Chart = {
  name: string;
};

export type FieldGroup = {
  uxLabel: string;
  fields: IField[];
};

export type IField = {
  propertyId: any;
  propertyType: any;
  isProperty: any;
  uxDescription: string;
  name: string;
  dataType: string;
  isDefault: boolean;
  uxLabel: string;
  definition: string;
};

export type ICompileReportMetadata = {
  id: string;
  reportName: string;
  description: string;
  domain: string;
  ownerUserName: string;
  ownerUserId: string;
  lastUpdated: string;
  reportType: string;
  orderField: string;
  orderBy: string;
  filters: IFilter[];
  fields: IField[];
  standardReportMetadata: IStandardReport;
};

export type IStandardReport = {
  id: string;
  name: string;
  description: string;
};

export type IReportSelectedColumns = {
  colId: string;
  hide: boolean | undefined | null;
}

export type ICompileReportState = {
  isChanged: boolean;
  isSaved: boolean;
  shouldFetchOwnedReports: boolean;
  id: string;
  ownerUserId: string;
  systemReportId: string;
  reportName: string;
  updatedReportName: string;
  description: string;
  updatedDescription: string;
  fields: IField[];
  updatedFields: IField[];
  filters: IFilter[];
  updatedFilters: IFilter[];
  isFilterCardClicked: boolean;
  currentSelectedFilter: IFilter;
  orderBy: string;
  updatedOrderBy: string;
  orderField: string;
  updatedOrderField: string;
  addColumnFields: IField[];
  isNewFilterAdding: boolean;
  filtersPickList: Map<string, string[]>;

  updatedTeamsites: ITeamsites[],
  originalTeamsites: ITeamsites[],
  isTeamsitesClicked: boolean,
  tempTeamsites: ITeamsites[],
  showTeamsitePicker: boolean,
  showLeaveWithoutSaveModal: boolean,
  gridHiddenColumns: string[],
  allReportsSummary: ReportsSummary[],
  shouldTriggerWithDefaultsAPI: boolean,
};

export type ICompileReportContext = ICompileReportState & {
  setIsChanged: (data: boolean) => void;
  setIsSaved: (data: boolean) => void;
  setShouldFetchOwnedReports: (data: boolean) => void;

  setUpdatedReportName: (name: string) => void;
  setUpdatedDescription: (description: string) => void;
  setUpdatedFields: (fields: IField[]) => void;
  setUpdatedFilters: (filters: IFilter[]) => void;
  setUpdatedOrderBy: (orderBy: string) => void;
  setUpdatedOrderField: (orderField: string) => void;

  setReportName: (name: string) => void;
  setDescription: (description: string) => void;
  setFields: (fields: IField[]) => void;
  setFilters: (filters: IFilter[]) => void;
  setOrderBy: (orderBy: string) => void;
  setOrderField: (orderField: string) => void;

  resetCompileReportState: () => void;
  resetCompileReportOriginalState: (data: ICompileReportState) => void;

  setIsFilterCardClicked: (data: boolean) => void;
  setCurrentSelectedFilter: (data: IFilter) => void;
  setIsNewFilterAdding: (data: boolean) => void;
  addToFiltersPicklist: (data: { key: string, values: string[] }) => void;

  setUpdatedTeamsites: (data: ITeamsites[]) => void;
  setOriginalTeamsites: (data: ITeamsites[]) => void;
  setIsTeamsitesClicked: (data: boolean) => void;
  setTempTeamsites: (data: ITeamsites[]) => void;
  setShowLeaveWithoutSaveModal: (data: boolean) => void;
  setGridHiddenColumns: (data: string[]) => void;
  setAllReportsSummary: (data: ReportsSummary[]) => void;
  setShouldTriggerWithDefaultsAPI: (data: boolean) => void;
};

export type IReportDataRequest = {
  reportId: string;
  systemReportId: string;
  skip: number;
  take: number;
  fields: IField[];
  filters: IFilter[];
  orderBy: string;
  orderField: string;
  reuestTime: Date;
  data: { rowData: IReportData[]; rowCount: number };
};

export type UpdatedReportMetadata = {
  id: string;
  systemReportId: string;
  reportName: string;
  description: string;
  fields: Array<any>;
  filters: any[];
  orderBy: string;
  orderField: string;
  teamsiteIds: string[];
}

export type ReportsSummary = {
  reportId: string;
  reportName: string;
  reportType: ReportType;
}

export enum ReportType {
  SYSTEM = "SYSTEM",
  CUSTOM = "CUSTOM",
}

export type IPagination = {
  skip: number;
  take: number;
  totalRecords: number;
}