import { Translations } from "@seismic/mantle/dist/locale/translations";
import { LanguageCode } from "seismic-common";

export interface IAppData {
  oAuthUrlForNullExternalCredential: string;
  application: IApplication;
  sdsAddresses: { Key: string; Value: string }[];
  featureToggles: IFeatureToggleSetting[];
  fmsFeatureToggles: IFMSToggleSetting[];
}

export interface IFeatureToggleSetting {
  Key: string;
  Value: { FeatureKey: string; FeatureState: "True" | "False" }[];
}

export interface IFMSToggleSetting {
  key: string;
  toggle: { status: string; value: boolean };
  options: IFMSToggleOption[];
}

export interface IFMSToggleOption {
  key: string;
  value: string;
}

export interface ITranslations {
  languageCode: LanguageCode,
  mantleTranslations: Translations
}

export interface IApplication {
  Client: IApplicationClient;
  /**
   * Type intentional as this is what is returned from Library Service
   */
  DefaultBrowserLanaguage: string;
  System: IApplicationSystem;
  User: IApplicationUser;
}

export interface IApplicationUser {
  Address: string;
  AllowOnBehalfToSendEmail: boolean;
  BelongTeamSites: string[];
  Biography: string;
  ContainerName: string;
  CurrentTeamSiteId: string;
  CurrentTimeZoneId: string;
  CustomPropertyText: string;
  DateCreated: string;
  DateLastChangedPwd: string;
  DefaultContentProfileId: string;
  DefaultTeamSiteId: string;
  Email: string;
  FirstName: string;
  IsLocked: boolean;
  IsSSOLogin: boolean;
  LandingPageBgImageBlobId: string;
  LandingPageBgImageUrl: string;
  LanguageCode: string;
  LastLoginTime: string;
  LastName: string;
  LinkedInId: string;
  OnBehalfUserId: string;
  Organization: string;
  PhoneNumber: string;
  PhotoThumbnailId: string;
  ReceiveSeismicNewsletter: boolean;
  ReceiveSystemStatusAlerts: boolean;
  ReceiveTrainingWebinarInvitations: boolean;
  RelativeImageUrl: string;
  SingleSignOnUsername: string;
  SpecialWorkspaceCollectionIds: IKeyValuePair<number, string>[];
  SystemLevelPermissions: IPermissionInfo[];
  ThumbnailRelativePathWithSignature: string;
  TimeZoneOffset: number;
  Title: string;
  Twitter: string;
  UserAllTeamSitePermissionInfoV2: IUserAllTeamSitePermissionInfoV2;
  UserGroupNames: string[];
  UserId: string;
  UserName: string;
  Usertype: number;
}

export interface IPermissionInfo {
  ActionList: string[];
  Actions: string;
  Description: string;
  Id: string;
  Name: string;
  PermissionCategory: string;
  PermissionType: string;
}

export interface IUserAllTeamSitePermissionInfoV2 {
  /**
   * Mispelling is on purpose since that is what is returned from API
   */
  TeamSitePermissionInfoDict: IKeyValuePair<
    string,
    { ContentUnqiuePermissions: string[]; TeamLevelPermissions: string[] }
  >[];
}

export interface IKeyValuePair<TKey, TValue> {
  Key: TKey;
  Value: TValue;
}

export interface IApplicationClient {
  Salesforce: ISalesforceClientInfo;
}

export interface ISalesforceClientInfo {
  ObjectId: string;
  ObjectName: string;
  EnableCreateContent: boolean;
  EnableCreateContentDelivery: boolean;
  EnableDownload: boolean;
  EnableSendEmail: boolean;
  EnableLogActivity: boolean;
  EnablePostToChatter: boolean;
  EnableSaveAttachment: boolean;
}

export interface IApplicationSystem {
  SystemOptions: ISystemOptions;
  DeliveryOptions: IDeliveryOption[];
  EmbeddedAppTabs: IEmbeddedAppTab[];
  EmbeddedApplicationDefaultTab: string;
  GeoEndpointInfos: Map<string, string>;
  EnableGeoEndpointCheck: boolean;
  UserProfileProperties: IUserProfilePropertyList;
}

export interface IUserProfilePropertyList {
  CustomProperties: IUserProfileProperty[];
}

export interface IUserProfileProperty {
  VisibleInUserPage: boolean;
  HasDomainOfValue: boolean;
  ListOrder: number;
  PropertyType: string;
  IsRequired: boolean;
  IndexedInSearch: boolean;
  Name: string;
  Id: string;
  IsEditableByUser: string;
  VisibleInUserSettings: boolean;
  DomainOfValues: { ListOrder: number; Value: string }[];
}

export interface IDeliveryOption {
  ChannelType: number;
  CurrentUserLiveSendNotificationSetting?: string | null;
  DeliveryOptionId: string;
  DisableOutmodeSendByEmail: boolean;
  FormCancelButtonText: string;
  FormDefinition: any;
  FormFinishButtonText: string;
  HasForm: boolean;
  IsHidden: boolean;
  Name: string;
  SMTPId: string | null;
  StorageType: number;
  StorageXml: string | null;
  Type: number;
}

export interface IEmbeddedAppTab {
  Title: string;
  TabTitle: string;
  ComponentType: number; // Enum
  ComponentVersion: number;
}

export interface ISystemOptions {
  FeatureSettings: IFeatureSetting[];
  [key: string]: any;
}
export interface IFeatureSetting {
  Description: string;
  FeatureId: string;
  FeatureName: string;
  State: string;
}

type ChartData = {
  chartType: string | undefined;
  chartTitle: string | undefined;
  infoText: string | undefined;
  isInModal: boolean | undefined;
}
export interface IMaximizeChart {
  isOpen: boolean;
  chartData: ChartData | null;
}

export interface IBreadcrumbUser {
  userName: string | undefined;
  userId: string | undefined;
  firstName: string | undefined;
  lastName: string | undefined;
  email: string | undefined;
  title: string | undefined;
  access: string | undefined;
}

export interface MetricsTypeProps {
  metricTypeTitle?: string,
  metrics: Array<ILabelValuePair>
}

export interface ILabelValuePair {
  label: string;
  value: string;
}

export interface UserPerformanceStatsResponse {
  data: UserStatsData;
}

export interface UserStatsData {
  entries: Array<UserStatsEntry>;
  totalCount: number;
}

export interface UserStatsEntry {
  id: string;
  email: string;
  managerUserId: string;
  managerEmail: string;
  managerName: string;
  organization: string;
  userName: string;
  displayName: string;
  title: string;
  thumbnailUrl: string;
  activeOpportunitiesValue: number;
  activeOpportunitiesCount: number;
  incompleteLessons: number;
  dsr: number;
  totalLinks: number;
  buyerEngagementDuration: number;
  contentViews: number;
  memberAvatarDetails: IMemeberAvatar[];
  emailsCount: number;
  meetings: number;
}

export interface IMemeberAvatar {
  name: string;
  thumbnailUrl: string;
}

export interface LocalStorageFilters {
  userId: string;
  fromDate: string;
  toDate: string;
}

export interface IDrawer {
  isOpen: boolean;
  rowData: object | null;
}

export interface IAverageDsrPerOpportunity {
  averageDsrPerOpportunity: number;
  peerTeamMaxAvgDSR: number;
}

export interface ILearningStats {
  completionRate: string;
  totalLessons: number;
}

export interface IRepPerformanceData {
  userId: string;
  managerUserId: string;
  userName: string;
  thumbnailUrl: string;
  activeOpportunities: number;
  amount: number;
}

export interface IActiveOpportunities {
  activeOpportunitiesCount: number;
  activeOpportunitiesTotalAmount: number;
}

export interface ISkills {
  skillsAverage: number;
  skillsAveragePeers: number;
}

export interface ReportData {
  category: string;
  value: number;
  imageUrl?: string;
}

export interface ReportSeriesData {
  name: string;
  data: ReportData[];
}

export interface IEngagementsSeriesData {
  category: string;
  value: number;
  imageUrl?: string;
  userId?: string;
}
export interface IUserEngagements {
  userId: string;
  userName: string;
  managerUserId: string | null;
  displayName: string;
  thumbnailUrl: string;
  title: string;
  dsr?: DsrEngagements[];
  email?: EmailEngagements[];
  links?: LinksEngagements[];
  meetings?: MeetingsEngagements[];
}
export interface DsrEngagements {
  title: string;
  temperature: string;
  opportunity: string;
  landingPageEngagementDuration: string;
  contentEngagementDuration: string;
  comments: number;
  reactions: number;
}

export interface EmailEngagements {
  title: string;
  opportunity: string;
  uniqueRecipients: number;
  linkViews: number;
  totalDownloads: number;
}

export interface LinksEngagements {
  title: string;
  opportunity: string;
  totalLiveSendContents: number;
  liveSendContentViewingSessions: number;
  totalAverageViewDuration: number;
}

export interface MeetingsEngagements {
  title: string;
  meetingsName: string;
  opportunity: number;
  talkingTime: number;
  topicsMentioned: number;
  keywordsMentioned: number;
  numberOfQuestionsAsked: number;
}

export interface IEngagementsData {
  name?: string;
  color?: string;
  data: Array<IEngagementsSeriesData>;
}
export interface ProspectDetailData {
  category: string;
  value: number;
  imageUrl: string;
}
export interface ProspectDetailsChartResponse {
  name: string;
  data: ProspectDetailData[];
}

export interface IProgramInfoCategory {
  category: string;
  value: number;
  programId: string;
}

export interface IPrograms {
  programId: string;
  programName: string;
}

export interface IResponse {
  totalContentViews: number;
  totalAssignedLearningCompletion: number;
  totalRequiredEventSessions: number;
  programInfoCategory: IProgramInfoCategory[];
  programs: IPrograms[];
}

export interface SkillsChartResponse {
  name: string;
  data: SkillsData[];
  color?: string;
  isBenchmarkSeries?: boolean;
}

export interface SkillsData {
  category: string;
  value: number;
}

//skills summary response
interface Skill {
  skillName: string;
  rating?: number;
}

export interface User {
  skills: Skill[];
  userId: string;
  userName: string;
  displayName?: string;
  managerUserId?: string;
  thumbnailUrl?: string;
}

export interface IskillsSummaryResponse {
  profileId: string;
  profileName: string;
  users: User[];
}

export interface dataSources {
  isLearningEnabled: boolean,
  isMeetingsEnabled: boolean,
  isSkillsEnabled: boolean,
  isProgramsEnabled: boolean,
  isCrmEnabled: boolean,
  isSeismicEnabled: boolean
}

export interface IUserPermissions {
  dataSources: [];
  userId: string;
  tenantId: string;
  accessLevel: string;
}

//skills user details response
export interface SkillsUserDetailsResponse {
  skillProfileName: string;
  skillProfileId: number;
  skills: UserSkillDetail[];
  userId: string;
  managerUserId: string;
  userName: string;
  displayName: string;
  thumbnailUrl: string;
}

interface UserSkillDetail {
  skillsId: number;
  skillName: string;
  rating: number;
  completedAt: string;
}

export interface ITeamsites {
  description: string;
  id: string;
  isSelected: boolean;
  name: string;
}

export interface ITenantSettings {
  isOrgHierarchyEnabled: boolean;
  hasOrgHierarchy: boolean;
}

export interface IUserSettings {
  teamsites: ITeamsites[];
  reportsFilterOption: string;
  tenantSettings: ITenantSettings;
  orderBy?: string;
  orderField?: string;
}