export enum Screens {
  REPORTS_LIST = 'REPORTS_LIST',
  VIEW_EDIT_REPORT = 'EDIT_VIEW_REPORT',
}

export type IReport = {
  description: string;
  domain: string;
  id: string;
  lastUpdated: string;
  lastViewed: string;
  ownerThumbnailUrl: string;
  ownerUserId: string;
  ownerUserName: string;
  reportName: string;
  reportType: string;
  systemReportId: string;
  systemReportName: string;
  userId: string;
};

// Interface for the localStorage __self_service_reports object
export interface SelfServiceReportsUserDataStorage {
  [userTenantKey: string]: {
    reports: Array<{
      reportId: string;
      hiddenColumnNames: string[];
      columnOrder: string;
    }>;
  };
}

export interface SelfServiceReportsLandingPageStorage {
  columnSortBy: string;
  columnSortOrder: string;
  columnOrder: string;
  columnReportSearch: string;
}

export interface ColumnSort {
  sort: 'asc' | 'desc';
  colId: string;
}
