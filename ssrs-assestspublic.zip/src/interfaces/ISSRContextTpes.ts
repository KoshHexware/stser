// import { Screens } from './SSRTypes';
import { Screens } from '../contexts/types';
import { IPagination, IReport } from './IReport';

export type ContextAction = {
    type: string;
    payload: any;
};

export type IAllReportsLandingPageState = {
    lastScreen: Screens;
    currentScreen: Screens;
    updatedReportsFilterOption: string;
    isCompileReportMode: boolean;
    hideEditButtOnError: boolean;
    orderBy: string;
    orderField: string;
    filterSearchText: string;
    enableSaveCopy: boolean;
    reportData: any;
    pagination: IPagination;
    areSystemReportsEnabled: boolean;
};

export type IAllReportsLandingPage = IAllReportsLandingPageState & {
    setShowNewReportModal: (data: boolean) => void;
    setLastScreen: (data: Screens) => void;
    setIsCompileReportMode: (data: boolean) => void;
    setCurrentScreen: (data: Screens) => void;
    setUpdatedReportsFilterOption: (data: string) => void;
    setHideEditButtonOnError: (data: boolean) => void;
    setOrderBy: (data: string) => void;
    setOrderField: (data: string) => void;
    setFilterSearchText: (data: string) => void;
    setEnableSaveCopy: (data: boolean) => void;
    setReportData: (data: any) => void;
    setPagination: (data: IPagination) => void;
    setAreSystemReportsEnabled: (data: boolean) => void;
};

export interface IReportDataState {
    selectedReport: IReport;
    reportMetadata: any;
    isReportShared: boolean;
    showReportSavedToast: false,
    isReportDrillIn?: boolean;
    drillInReportExportPayload?: any;
}

export type IReportData = IReportDataState & {
    setSelectedReport: (data: IReport) => void;
    setReportMetadata: (data: any) => void;
    setIsReportShared: (data: boolean) => void;
    setShowReportSavedToast: (data: boolean) => void;
    setIsReportDrillIn: (data: boolean) => void;
    setDrillInReportExportPayload: (data: any) => void;
};