if (typeof window.__scriptNonce__ !== 'undefined') {
    // this fix is in the official documentation for webpack
    // https://webpack.js.org/loaders/style-loader/#nonce
    // additional info in the PR: https://github.com/seismic/web-uplayer-assets/pull/891
    // eslint-disable-next-line
    __webpack_nonce__ = window.__scriptNonce__;
  }