import { triggerAuraPanelActionForLandingPage, triggerAuraPanelActionForReportPage } from "./utils";
import { IAuraPanelAction, AuraPanelActionType } from './types/AuraPanelActionTypes';

const FEATURE_FLAG: boolean = true; // Set to false to disable the feature: page context passing to Aura chat Panel

export const triggerAuraPanelAction = (action: IAuraPanelAction) => {
    if (!FEATURE_FLAG) {
        return;
    }

    const { type, payload } = action;
    switch (type) {
        case AuraPanelActionType.LANDING_PAGE:
            triggerAuraPanelActionForLandingPage();
            break;
        case AuraPanelActionType.REPORT_PAGE:
            if (payload && payload.reportId) {
                triggerAuraPanelActionForReportPage(payload.reportId);
            }
            break;
        default:
            break;
    }
}