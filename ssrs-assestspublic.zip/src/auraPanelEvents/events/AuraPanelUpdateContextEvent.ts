import { instance, EventService } from 'seismic-common';
import { AURA_CHAT_EVENTS } from '../types/AuraChatEventTypes';
import { ISSRContext } from '../types/SSRContextTypes';

const eventService = instance.getService(EventService);

export const dispatchAuraPanelUpdateContextEvent = (ssrContext: ISSRContext) => {
    eventService?.dispatch(AURA_CHAT_EVENTS.EVT_SEARCH_OMNI_AURA_CHAT_UPDATE_CONTEXT, ssrContext);
};