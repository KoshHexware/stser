export enum AuraPanelActionType {
    LANDING_PAGE = 'LandingPage',
    REPORT_PAGE = 'ReportPage',
}

export type IAuraPanelAction = {
    type: AuraPanelActionType;
    payload?: {
        reportId: string;
    };
}