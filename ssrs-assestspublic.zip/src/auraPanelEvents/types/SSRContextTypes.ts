export enum ClientContextType {
    INSIGHTS = 'Insights',
}

export enum ClientContextSubType {
    SSR_LANDING_PAGE = 'Self-service reports landing page',
    SSR_REPORT_PAGE = 'Self-service reports report page',
}

export enum ClientContextTriggerType {
    PAGE_LOAD = 'PageLoad',
    DIALOG_OPEN = 'DialogOpen',
}

export enum ChatContextPrimaryIdType {
    PRIMARY_ID_TYPE = 'ReportId',
}

export type IClientContext = {
    contextId?: string; // Optional: Unique event identifier (e.g., a Snowflake ID) used by the application team for event tracking or future reference.
    contextType: string;
    contextSubType: string;
    contextTriggerType?: 'PageLoad' | 'DialogOpen';
}

export type IChatContext = {
    primaryIdType: string;
    primaryId: string;
    additionalMetaData?: {
        format: string;
        contentType: number;
        contentId: string;
    };
}

export type ISSRContext = {
    clientContext: IClientContext;
    chatContext?: IChatContext;
}