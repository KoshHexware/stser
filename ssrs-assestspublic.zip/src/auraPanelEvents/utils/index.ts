import {dispatchAuraPanelUpdateContextEvent} from '../events/AuraPanelUpdateContextEvent';
import {ChatContextPrimaryIdType, ClientContextType, ISSRContext, ClientContextSubType } from '../types/SSRContextTypes';

export const triggerAuraPanelActionForLandingPage = () => {
    const ssrContext: ISSRContext = {
        clientContext: {
            contextType: ClientContextType.INSIGHTS,
            contextSubType: ClientContextSubType.SSR_LANDING_PAGE,
            contextTriggerType: 'PageLoad',
        },
    };
    dispatchAuraPanelUpdateContextEvent(ssrContext);
};

export const triggerAuraPanelActionForReportPage = (reportId: string) => {
    const ssrContext: ISSRContext = {
        clientContext: {
            contextType: ClientContextType.INSIGHTS,
            contextSubType: ClientContextSubType.SSR_REPORT_PAGE,
            contextTriggerType: 'PageLoad',
        },
        chatContext: {
            primaryIdType: ChatContextPrimaryIdType.PRIMARY_ID_TYPE,
            primaryId: reportId,
        },
    };
    dispatchAuraPanelUpdateContextEvent(ssrContext);
};
