import EN_US from './en-US.json';
const i18nLocales: any = {
    'en-US': EN_US,
};
export default i18nLocales;
