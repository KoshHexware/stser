import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import i18nLocales from './locales';
import { LanguageService, instance } from 'seismic-common';

const i18nInstance = i18n.createInstance();
i18nInstance.use(initReactI18next).init({
    resources: {
        ['en-US']: {
            translation: i18nLocales['en-US'] || {},
        },
    },
    load: 'currentOnly',
    fallbackLng: 'en-US',
    lng: 'en-US',
    react: {
        useSuspense: true,
    },
});

class Translate {
    lang: string;
    constructor() {
        this.lang = 'en-US';
    }

    async setLang() {
        const languageService = instance.getService(LanguageService);
        this.lang = languageService.getLanguage();
        if (this.lang != 'en-US') {
            try {
                const resource = await languageService.getTranslations(this.lang, 'SelfServiceReports', 'Default');
                i18nInstance.addResourceBundle(this.lang, 'translation', resource, true, true);
                return i18nInstance.changeLanguage(this.lang);
            } catch (ex) {
                return i18nInstance.changeLanguage('en-US');
            }
        }
        return i18nInstance.changeLanguage(this.lang);
    }

    format(key: string, defaultValue?: string, value = {}) {
        if (i18nInstance.exists(key)) {
            return i18nInstance.t(key, value);
        }
        return defaultValue;
    }
}

export default new Translate();
