export const FIXEDPAGESIZE = 1000;
export const FIXEDREPORTLISTPAGESIZE = 1000;
export const COMPILE_FIELD_FILTERS_ACTIONS = {
  COMPILE_FIELD_FILTERS_ACTIONS_CATEGORY_ALL: 'All',
  COMPILE_FIELD_FILTERS_ACTIONS_TABS_TABLE: 'Table',
  COMPILE_FIELD_FILTERS_ACTIONS_TABS_FILTERS: 'Filters',
};
export const COLOMNSELECTIONLIMIT = 200;

export const ACCESS_UPDATE_DISPLAY_TIME = 3000;
export const SEARCH_DEBOUNCE_DELAY = 300;

export const FIELD_FILTERS_MODAL_ERROR_BOUNDARY_COMPONENTS = {
  GetContentType: 'GetContentType',
  AddFilter: 'AddFilter',
  FieldAndFilterActions: 'FieldAndFilterActions',
  FieldAndFilterCategories: 'FieldAndFilterCategories',
  RenderColumns: 'RenderColumns',
  RenderFilters: 'RenderFilters',
  SearchItems: 'SearchItems',
  NewReportModel: 'NewReportModel',
  TableColumns: 'TableColumns',
  ReportFilters: 'ReportFilters',
};

export const REPORT_NAME_REGEX = /^(?!.*[\n\t])[a-zA-Z0-9_\-\s()]+$/;

export const INT_MAX = 2147483647;
export const INT_MIN = -2147483648;
export const FLOAT_MAX = parseFloat((3.4 * Math.pow(10, 38)).toString());
export const FLOAT_MIN = parseFloat((-3.4 * Math.pow(10, 38)).toString());

export type ContextualButtonStatus =
  | 'default'
  | 'loading'
  | 'success'
  | 'error';

export const CONTENT_CUSTOM_PROPERTY = 'ContentCustomProperty';
export const REPORT_MODE_VIEW = 'view';
export const REPORT_MODE_EDIT = 'edit';
export const REPORT_MODE_NEW = 'new';

export const ENABLE_SSR_USE_ENTITLEMENTS = 'ssr-use-entitlements';
export const ENABLE_SSR_WINTER_FY26_RELEASE = 'ssr-winter-fy26-release';
export const ENABLE_SSR_ENABLE_NEXT_GEN = 'ssr-enable-next-gen';

export const PERMISSION_KEYS = {
  VIEW_REPORT: "seismic.self-service-reports.view.report",
  MANAGE_ALL_REPORTS: "seismic.self-service-reports.manage.all.reports",
  CREATE_NEW_REPORTS: "seismic.self-service-reports.create.new.reports",
};

export const EDITOR_ACCESS_LEVEL =  'editor';
export const VIEWER_ACCESS_LEVEL = 'viewer';
export const CUSTOM_REPORT_EDITOR_ACCESS_LEVEL = 'customreporteditor'

export const LANDING_PAGE_REPORT_TYPE = {
  all: 'all',
  system: 'system',
  shared: 'shared',
  owned: 'owned',
};

export const SSRS_REPORT_TYPE = {
  SYSTEM: 'System',
  CUSTOM: 'Custom',
};

/**
 * Type for the string key used in localStorage
 */
export const SELF_SERVICE_REPORTS_STORAGE_KEY = '__self_service_reports';

export const SELF_SERVICE_REPORTS_LANDING_PAGE_STORAGE_KEY =
  '__self_service_reports_landing_page';

export const EMPTY_FILTER_VALUE = 'N/A';
