import { ColDef } from '@seismic/shared-datagrid';
import cellFormatRenderer from './cellFormatRenderer';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from './constants';
import { SelfServiceReportsUserDataStorage } from '../interfaces/SSRTypes';

export const getReportsTablColumnDefs = (
  fields: any,
  orderField = '',
  orderBy = '',
  selectedReport?: { id: string },
  userId?: string,
  tenantUniqId?: string,
  isSSRWinterFY26FeatureFlagEnabled?: boolean
): ColDef[] | [] => {
	const getUserTenantKey = (userId: string, tenantId: string): string => {
		return `${userId}_${tenantId}`;
	};

	if (!fields || fields?.length === 0) {
		return [];
	}

	let storedColumnOrder = '';
	if (userId && tenantUniqId && selectedReport?.id) {
		try {
			const userColumnPreferences = localStorage.getItem(
				SELF_SERVICE_REPORTS_STORAGE_KEY
			);
			if (userColumnPreferences) {
				const userData: SelfServiceReportsUserDataStorage = JSON.parse(
					userColumnPreferences
				);
				const userTenantKey = getUserTenantKey(userId, tenantUniqId);
				const userReports = userData[userTenantKey]?.reports || [];
				const reportData = userReports.find(
					(report) => report.reportId === selectedReport?.id
				);

				if (reportData) {
					storedColumnOrder = reportData.columnOrder;
				}
			}
		} catch (error) {
			console.error(
				'Error loading column visibility from localStorage:',
				error
			);
		}
	}

  const createColumnDefs = () => {
    return fields.map((field: any) => {
      let headerClass = `trk_button_ssrs-reports_view-sortable-column-header`;
      var cellFormatters = ['url-formatter', 'email-formatter'];
      if (isSSRWinterFY26FeatureFlagEnabled) {
        cellFormatters.push('number-formatter', 'rate-formatter');
      }
      let hasSort = cellFormatters?.includes(field.formatter)
        ? isSSRWinterFY26FeatureFlagEnabled && (field.formatter === 'number-formatter' || field.formatter === 'rate-formatter')
        : true;
      return {
        ...field,
        headerName: field.uxLabel || field.name,
        headerTooltip: field.uxDescription || field.uxLabel || field.name,
        autoHeight: true,
        field: field.name.toUpperCase(),
        sortable: hasSort,
        initialHide: !field.isDefault,
        minWidth: 150,
        headerClass: headerClass,
        type: field?.dataType,
		reportId: selectedReport?.id,
        ...(field.formatter && cellFormatRenderer(field.formatter, isSSRWinterFY26FeatureFlagEnabled)),
      };
    });
  };

	const applySortingAndCellRenderers = (defs: ColDef[]) => {
		return defs.map((col) => {
			let updatedCol = col;

			// Apply sorting if orderField and orderBy are provided
			if (orderField && orderBy && col.field === orderField.toUpperCase()) {
				updatedCol = {
					...updatedCol,
					initialSort: orderBy?.toLowerCase() as any,
				};
			}
			// Apply cellRenderer based on dataType first
			const colWithExtras = col as any; // Type assertion since we spread the field object

			switch (colWithExtras.dataType) {
				case 'DateTime':
					updatedCol = { ...updatedCol, cellRenderer: 'ReportDateTimeCell' };
					break;
				case 'Date':
					updatedCol = { ...updatedCol, cellRenderer: 'ReportDateCell' };
					break;
				case 'Owner':
					updatedCol = { ...updatedCol, cellRenderer: 'ReportOwnerCell' };
					break;
				default:
					if (!colWithExtras.formatter) {
						updatedCol = { ...updatedCol, cellRenderer: 'ReportCustomCell' };
					}
					break;
			}

			// Override with ReportLinkCell if drillIn is true (this should have priority)
			if (colWithExtras.drillIn) {
				updatedCol = { ...updatedCol, cellRenderer: 'ReportLinkCell' };
			}

			return updatedCol;
		});
	};

	// Create column definitions and apply sorting/cell renderers
	const unorderedColDefs = applySortingAndCellRenderers(createColumnDefs());

	// Fall back to default ordering if local storage order is unavailable
	return unorderedColDefs;
};
