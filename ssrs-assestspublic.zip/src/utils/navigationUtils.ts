import { instance, SeismicNavigator } from 'seismic-common';

export const navigateToUrl = (url: string, isSSRNextGenEnabled: boolean) => {
    const isNextGen = process.env.NEXT_GEN === 'true';

    if (isSSRNextGenEnabled && isNextGen) {
        try {
            const SeismicNavigatorService = instance.getService(SeismicNavigator);
            SeismicNavigatorService.navigateToUrl(url);
            return true;
        } catch (error) {
            console.error('Failed to use SeismicNavigator', error);
            return false;
        }
    } else {
        return false;
    }
};