import React from "react";
import { IconHost } from "@seismic/mantle";

const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Integer':
      case 'Decimal':
        return <IconHost category="variables-icons" params={{ type: 'number' }} size={16} />;
      case 'Text':
      case 'Csv':
        return <IconHost category="variables-icons" params={{ type: 'string' }} size={16} />;
      case 'Boolean':
        return <IconHost category="variables-icons" params={{ type: 'boolean' }} size={16} />;
      case 'Date':
      case 'DateTime':
        return <IconHost category="variables-icons" params={{ type: 'date' }} size={16} />;
      default:
        return <></>;
    }
  };

  export default getTypeIcon;