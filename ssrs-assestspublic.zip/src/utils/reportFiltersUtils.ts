import { parse } from 'date-fns';
import { FILTER_TYPE, IDateOperations, IFilter, IFilterDataType, INullishOperations, IOperatorDetails, ITextOperations } from '../interfaces/IFilterTypes';
import { FIELD_FILTERS_MODAL_ERROR_BOUNDARY_COMPONENTS } from './constants';
import { ITeamsites } from '../interfaces/IAppData';
import { USER_SCOPE_TEXT_OPERATORS } from './userScopeOperatorsConstants';
import { TFunction } from 'i18next';
import { useUserSettings } from '../contexts/CommonServicesContext';

/**
 * Extracts all filter objects from nested filterGroups into a flat array
 * @param {Object[]} filterGroup - Array of filter group objects
 * @returns {Object[]} - Flat array of all filter objects
 */
function extractAllFilters(filterGroup: { filters: IFilter[] }[]): IFilter[] {
  if (!Array.isArray(filterGroup)) {
    console.error('Input must be an array of filter groups');
    return [];
  }

  // Use flatMap to extract and flatten the filters arrays from each group
  return filterGroup.flatMap((group) => {
    // Check if the group has a filters property that is an array
    if (group && Array.isArray(group.filters)) {
      return group.filters;
    }
    return []; // Return empty array for invalid groups
  });
}

const getExtraAddedFiltersProps = (refinedFilters, filterGroup) => {
  // Extract filters once outside the map function
  const flattenFilters = extractAllFilters(filterGroup);

  // Create a lookup map for faster searches (optional optimization)
  const filterMap = {};
  flattenFilters?.forEach((f) => {
    filterMap[f.filterName.toLowerCase()] = f;
  });

  return refinedFilters?.map((filter) => {
    // Use the map for lookup instead of find
    const found = filterMap[filter.filterName.toLowerCase()];
    if (!found) {
      console.warn(
        `No matching filter definition found for: ${filter.filterName}`
      );
      return null; // Skip this filter if no matching definition exists
    }
    return {
      ...found,
      ...filter,
      values: filter.values || [],
      label: found?.uxLabel,
      allowedOperators:
        found?.allowedOperators?.map((operator) => ({
          ...operator,
          label: operator.uxLabel,
          value: operator.name,
        })) || [],
    };
  });
};

export const getRefinedFilters = (filters, filterGroup) => {
  if (filters && filters.length > 0) {
    const res = getExtraAddedFiltersProps(filters, filterGroup);
    return res;
  }
  return [];
};

export const areTeamsitesChanged = (
  teamsites: ITeamsites[],
  localTeamsites: ITeamsites[]
): boolean => {
  const teamSiteObj = teamsites.filter((teamsite) => teamsite?.isSelected);
  const localTeamSiteObj = localTeamsites.filter(
    (teamsite) => teamsite?.isSelected
  );

  // Compare IDs of selected teamsites
  const selectedIds = teamSiteObj.map((t) => t.id).sort();
  const selectedLocalIds = localTeamSiteObj.map((t) => t.id).sort();
  if (selectedIds?.length != selectedLocalIds.length) {
    return true;
  }
  return !selectedIds.every((id, index) => id === selectedLocalIds[index]);
};

export const getRefinedDomainOfValuesAndPickList = (domainValues, t) => {
  if (domainValues === undefined || domainValues?.length === 0) return [];
  return domainValues?.map((value) => {
    if (value === null) {
      const BlankLabel = t(
        'self_service_reports_picklist_blank_label',
        '(Blanks)'
      );
      return { label: BlankLabel, value: '(Blanks)' };
    } else {
      return { label: value, value: value };
    }
  });
};

export const getRefinedAllowedOperators = (
  allowedOperators: IOperatorDetails[],
  t: TFunction<"translation", undefined>,
  dataType: IFilterDataType,
  isNullable: boolean | null | undefined,
  filterType: FILTER_TYPE | undefined,
  enableRelativeUserFilterField: boolean | null | undefined
) => {
  const { tenantSettings } = useUserSettings();
  const { isOrgHierarchyEnabled, hasOrgHierarchy } = tenantSettings;

  let operators = allowedOperators.map((operator) => ({
    ...operator,
    label: t(
      `self_service_reports_filters_operations_${operator.name}`,
      operator.uxLabel
    ),
    value: operator.name,
    disabled: operator.name === ITextOperations.IS_MY_TEAM && (!isOrgHierarchyEnabled || !hasOrgHierarchy), // Disable user scope operators by default
    reason: (
      operator.name === ITextOperations.IS_MY_TEAM &&
      (!isOrgHierarchyEnabled)
    ) ?
      t('self_service_reports_my_team_disabled', '[My team] is disabled because Organization Structure in System Settings is not enabled yet.')
      : operator.name === ITextOperations.IS_MY_TEAM &&
        (!hasOrgHierarchy)
        ? t('self_service_reports_my_team_not_built', '[My team] is disabled because Organization Structure is not set up in System Settings.')
        : undefined
  }));

  if (dataType === IFilterDataType.BOOLEAN) {
    if (isNullable) {
      return operators.filter((operator) => operator.name !== 'NotEquals');
    } else {
      return operators.filter((operator) => operator.name === 'Equals');
    }
  }

  //chnage operator label to before and after for greter than and less than operators if dataType is date or datetime
  if (
    dataType === IFilterDataType.DATE ||
    dataType === IFilterDataType.DATE_TIME
  ) {
    operators = operators.map((operator) => {
      switch (operator.name) {
        case IDateOperations.GREATER_THAN:
          return {
            ...operator, label: t(
              'self_service_reports_filters_operations_After',
              'After'
            )
          };
        case IDateOperations.LESS_THAN:
          return {
            ...operator, label: t(
              'self_service_reports_filters_operations_Before',
              'Before'
            )
          };
      }
      return operator;
    });
  }
  return operators;
};

export const areFiltersChanged = (
  filters: IFilter[],
  updatedFilters: IFilter[],
  shouldShowRefeshIfBlankFilterRemoved: boolean
): boolean => {
  let flag = false;
  if (filters.length === updatedFilters.length) {
    filters.forEach((filterObj) => {
      const updatedFilterObj = updatedFilters.find(
        (f) => f.filterName.toLowerCase() === filterObj.filterName.toLowerCase()
      );
      if (updatedFilterObj) {
        if (
          !arrayValuesEqual(filterObj.values, updatedFilterObj.values) ||
          filterObj?.operation?.toLowerCase() !==
          updatedFilterObj?.operation?.toLowerCase()
        ) {
          flag = true;
        }
      } else {
        flag = true;
      }
    });
  } else if (
    updatedFilters.length > filters.length &&
    shouldShowRefeshIfBlankFilterRemoved
  ) {
    updatedFilters.forEach((filterObj) => {
      const updatedFilterObj = filters.find(
        (f) => f.filterName.toLowerCase() === filterObj.filterName.toLowerCase()
      );
      if (updatedFilterObj) {
        if (
          !arrayValuesEqual(filterObj.values, updatedFilterObj.values) ||
          filterObj?.operation?.toLowerCase() !==
          updatedFilterObj?.operation?.toLowerCase()
        ) {
          flag = true;
        }
      } else if (
        filterObj.values.length > 0 &&
        filterObj?.operation?.toLowerCase() !== 'none'
      ) {
        flag = true;
      }
    });
  } else if (filters.length !== updatedFilters.length) {
    return true;
  }
  return flag;
};

export const getUpdatedFiltersToApply = (updatedFilters) => {
  const fieldsToExtract = [
    'filterName',
    'operation',
    'values',
    'isProperty',
    'propertyType',
    'propertyId',
  ];
  return updatedFilters.map((filter) => {
    const newFilter = {};
    fieldsToExtract.forEach((field) => {
      if (filter.hasOwnProperty(field)) newFilter[field] = filter[field];
    });
    return newFilter;
  });
};

export const convertDateToString = (inputDate, getLocalize = false) => {
  if (!inputDate) return '';
  const date = new Date(inputDate);
  if (getLocalize) {
    const options = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      timeZone: 'UTC',
    };
    return date.toLocaleDateString('en-US', options);
  }

  return formatDate(date);
};

export const convertStringToDate = (dateString: string): Date => {
  // Adjust the format string to match the expected format of dateString
  let date;
  try {
    date = parse(dateString, 'MMM d, yyyy', new Date());
    if (isNaN(date.getTime())) {
      throw new Error('Invalid Date');
    }
  } catch (e) {
    date = parse(dateString, 'yyyy-MM-dd', new Date());
  }
  return date;
};

export const arrayValuesEqual = (arr1, arr2) => {
  if (arr1?.length !== arr2?.length) return false;
  for (let i = arr1?.length; i--;) {
    if (arr1[i] !== arr2[i]) return false;
  }
  return true;
};

export const getFilterDetails = (filters: IFilter[], filterName: string) => {
  const filter = filters.find(
    (f) => f.filterName.toLowerCase() === filterName.toLowerCase()
  );
  return filter || null;
};

export const getDomainOfValuesAndPickListUXLabel = (values, operation) => {
  if (values?.length === 1) {
    return `${operation} - ${values[0]}`;
  } else {
    return `${operation} - ${values?.length} items`;
  }
};

export const getOperationUXLabel = (operation) => {
  const allowedOperations = {
    Equals: 'Equals',
    NotEquals: 'Not Equals',
    IsOneOf: 'Is one of',
    IsNotOneOf: 'Is not one of',
  };
  return allowedOperations[operation];
};

export const getDisplayFilters = (groupFilters, updatedFilters) => {
  const exTractedUpdatedFilters = updatedFilters?.map((filter) => {
    return filter.filterName;
  });
  const filterAfterChanges = groupFilters?.map((groupFilter) => {
    groupFilter?.filters?.map((filter) => {
      filter.isDefault = !!exTractedUpdatedFilters?.find(
        (updatedFilterName) =>
          updatedFilterName.toLowerCase() === filter.filterName.toLowerCase()
      );
      return filter;
    });
    return groupFilter;
  });
  return filterAfterChanges;
};

export const sortItems = (items) => {
  return items?.sort((a, b) => {
    const aLower = a.uxLabel.toLowerCase();
    const bLower = b.uxLabel.toLowerCase();
    return aLower > bLower ? 1 : aLower < bLower ? -1 : 0;
  });
};

export const getSelectedSortItems = (items) => {
  const selectedItems = items.filter((item) => item.isDefault);
  return sortItems(selectedItems);
};

export const getFieldAndFiltersModelErrorBoundaryComponents = (
  errorComponentName: string
) => {
  return FIELD_FILTERS_MODAL_ERROR_BOUNDARY_COMPONENTS[errorComponentName];
};

export const getIllustrationSize = (errorComponentName: string) => {
  if (
    errorComponentName === 'GetContentType' ||
    errorComponentName === 'TableColumns' ||
    errorComponentName === 'ReportFilters'
  ) {
    return 'sm';
  } else {
    return 'lg';
  }
};

const formatDate = (date) => {
  const d = new Date(date);
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  const year = d.getFullYear();

  return `${year}-${month}-${day}`;
};
