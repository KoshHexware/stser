import { ReportsSummary } from "../interfaces/IReport";

/**
 * Generates an incremental report title for copies
 * @param originalReportName The base report name to use
 * @param existingReports Array of all existing reports to check against
 * @returns A new report name with incremental numbering
 */
export const generateIncrementalReportTitle = (
    originalReportName: string,
    existingReports: ReportsSummary[]
): string => {
    // Check if the original name already ends with a number in parentheses
    const lastNumberPattern = /^(.*?)(\s*\((\d+)\))$/;
    const matchLastNumber = originalReportName.match(lastNumberPattern);

    let baseName: string;
    let initialNum: number = 0;

    if (matchLastNumber) {
        // If original name already has a number at the end, use it as the base for incrementing
        baseName = matchLastNumber[1].trim();
        initialNum = parseInt(matchLastNumber[3], 10);
    } else {
        baseName = originalReportName;
    }

    // Escape special regex characters in the base name
    const escapedBaseName = baseName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // Create regex pattern to match "base name (n)"
    const namePattern = new RegExp(`^${escapedBaseName}\\s*\\((\\d+)\\)$`);

    // Find the highest number currently used
    let highestNumber = initialNum;

    existingReports.forEach(report => {
        // Check if this is the base name (without number)
        if (report.reportName === baseName) {
            highestNumber = Math.max(highestNumber, 0); // Ensure we'll start with at least (1)
        }

        // Check for numbered copies
        const match = report.reportName.match(namePattern);
        if (match && match[1]) {
            const num = parseInt(match[1], 10);
            highestNumber = Math.max(highestNumber, num);
        }
    });

    // Return the next incremental name
    return `${baseName} (${highestNumber + 1})`;
};