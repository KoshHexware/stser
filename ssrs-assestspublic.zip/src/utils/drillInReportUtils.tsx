import { SELF_SERVICE_REPORTS_STORAGE_KEY } from './constants';

export const getUserTenantKey = (userId: string, tenantId: string): string => {
	return `${userId}_${tenantId}`;
};

// Helper: remove drillInParams for the previous drill-in report id
export const removeDrillInParamsForPreviousReport = (
	userId: string,
	tenantId: string
) => {
	try {
		const raw = localStorage.getItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
		if (raw) {
			const data = JSON.parse(raw) || {};
			const prevReportId =
				typeof data.previous_drillIn_report_id === 'string'
					? (data.previous_drillIn_report_id as string)
					: null;

			if (prevReportId) {
				const stripDrillIn = (arr: any[]) => {
					arr.forEach((r) => {
						if (r && r.reportId === prevReportId) {
							delete r.drillInParams;
						}
					});
				};

				if (Array.isArray(data.reports)) {
					stripDrillIn(data.reports);
				}

				const userTenantKey = getUserTenantKey(userId, tenantId);
				if (data[userTenantKey] && Array.isArray(data[userTenantKey].reports)) {
					stripDrillIn(data[userTenantKey].reports);
				}

				// Also clear previous drill-in markers
				delete data.previous_drillIn_report_id;
				delete data.previous_drillIn_url;

				localStorage.setItem(
					SELF_SERVICE_REPORTS_STORAGE_KEY,
					JSON.stringify(data)
				);
			}
		}
	} catch (err) {
		console.error('Error removing drillInParams on URL change:', err);
	}
};

export const getIsDrillInReport = (
	userId: string,
	tenantId: string,
	targetReportId: string
): { isDrillInReport: boolean; drillInParams?: any } => {
	try {
		const existingUserData = localStorage.getItem(
			SELF_SERVICE_REPORTS_STORAGE_KEY
		);
		if (!existingUserData) return { isDrillInReport: false };
		const userData = JSON.parse(existingUserData);
		const userTenantKey = getUserTenantKey(userId, tenantId);
		const reports: any[] = userData?.[userTenantKey]?.reports || [];
		const existingReport = reports.find(
			(report: { reportId: string }) => report.reportId === targetReportId
		);
		return {
			isDrillInReport: !!existingReport?.drillInParams?.isDrillIn,
			drillInParams: existingReport?.drillInParams,
		};
	} catch (error) {
		console.error(
			'Error determining drill-in status from localStorage:',
			error
		);
		return { isDrillInReport: false };
	}
};

// Remove all drillInParams from localStorage. When on landing pages,
// also clear previous_drillIn_report_id and previous_drillIn_url.
export const removeAllDrillInParams = (
	userId: string,
	tenantId: string,
	pathname?: string
) => {
	try {
		const raw = localStorage.getItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
		if (!raw) return;
		const data = JSON.parse(raw) || {};

		const stripAllDrillIns = (arr: any[]) => {
			arr.forEach((r) => {
				if (r && r.drillInParams) {
					delete r.drillInParams;
				}
			});
		};

		if (Array.isArray(data.reports)) {
			stripAllDrillIns(data.reports);
		}

		const userTenantKey = getUserTenantKey(userId, tenantId);
		if (data[userTenantKey] && Array.isArray(data[userTenantKey].reports)) {
			stripAllDrillIns(data[userTenantKey].reports);
		}

		// If NOT on a specific report detail page (/selfservicereports/report/${id}),
		// treat it as a landing/general page and clear previous drill-in metadata.
		const isReportDetail =
			!!pathname && /^\/selfservicereports\/report\/[^/]+$/.test(pathname);
		const isLandingPage = !!pathname && !isReportDetail;
		if (isLandingPage) {
			delete data.previous_drillIn_report_id;
			delete data.previous_drillIn_url;
		}

		localStorage.setItem(
			SELF_SERVICE_REPORTS_STORAGE_KEY,
			JSON.stringify(data)
		);
	} catch (error) {
		console.error('Error clearing drill-in params from localStorage:', error);
	}
};
