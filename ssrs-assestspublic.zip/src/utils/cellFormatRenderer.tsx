const cellFormatRenderer = (formatter: string, isSSRWinterFY26FeatureFlagEnabled?: boolean) => {
  switch (formatter.toLowerCase()) {
    case 'url-formatter':
      return { cellRenderer: "ReportExternalIconCell" };
    case 'email-formatter':
      return { cellRenderer: "ReportEmailCell" };
    case 'number-formatter':
      return isSSRWinterFY26FeatureFlagEnabled ? { cellRenderer: "ReportNumberCell"} : undefined;
    case 'rate-formatter':
      return isSSRWinterFY26FeatureFlagEnabled ? { cellRenderer: "ReportRateCell"} : undefined;
    default:
      return undefined;
  }
};
export default cellFormatRenderer;