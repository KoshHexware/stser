import { ILaunchDarklyToggle } from "../interfaces/ILaunchDarkly";
import { ENABLE_SSR_ENABLE_NEXT_GEN } from "./constants";

export const checkSSRNextGenEnabled = (launchDarklyToggles: ILaunchDarklyToggle[] | undefined): boolean => {
    return launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_ENABLE_NEXT_GEN)?.FeatureState === "True" || false;
};


export const getInitAppData = async (): any => {
    const isNextGen = process.env.NEXT_GEN === 'true';
    try {
        if (
            isNextGen &&
            window.appDatas?.initApp &&
            window.appDatas.initApp['/selfservicereports']
        ) {
            return window.appDatas.initApp['/selfservicereports'] ?? null;
        }
    } catch (error) {
        console.error('Error retrieving initial app data', error);
    }
    return null;
};