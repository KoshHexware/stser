import { ReportsSummary, ReportType } from "../interfaces/IReport";
import { REPORT_NAME_REGEX } from "./constants";

export enum ReportNameError {
    NONE = "NONE",
    VIOLATES_CUSTOM_REPORTS_UNIQUENESS = "VIOLATES_CUSTOM_REPORTS_UNIQUENESS",
    VIOLATES_SYSTEM_REPORTS_UNIQUENESS = "VIOLATES_SYSTEM_REPORTS_UNIQUENESS",
    MAX_LENGTH_EXCEEDED = "MAX_LENGTH_EXCEEDED",
    CONTAINS_SPECIAL_CHARACTERS = "CONTAINS_SPECIAL_CHARACTERS",
    EMPTY_OR_WHITESPACE = "EMPTY_OR_WHITESPACE"
}

export const validateReportName = (
    reportName: string,
    allReportsSummary: ReportsSummary[]
): ReportNameError => {
    // Check if the report name is empty or only whitespace
    if (!reportName.length || !reportName.trim()) {
        return ReportNameError.EMPTY_OR_WHITESPACE;
    }

    // Check if the report name already exists in the summary list
    const reportExists = allReportsSummary.find(report => report.reportName?.trim().toLowerCase() === reportName.trim().toLowerCase());
    if (reportExists && reportExists.reportType.toLowerCase() === ReportType.CUSTOM.toLowerCase()) {
        return ReportNameError.VIOLATES_CUSTOM_REPORTS_UNIQUENESS;
    }

    // Check if the report name already exists as a system report
    // Assuming system reports are identified by a specific condition, e.g., reportType
    if (reportExists && reportExists.reportType.toLowerCase() === ReportType.SYSTEM.toLowerCase()) {
        return ReportNameError.VIOLATES_SYSTEM_REPORTS_UNIQUENESS;
    }

    // Check maximum length
    if (reportName.length > 100) {
        return ReportNameError.MAX_LENGTH_EXCEEDED;
    }

    // Check for special characters
    if (!REPORT_NAME_REGEX.test(reportName)) {
        return ReportNameError.CONTAINS_SPECIAL_CHARACTERS;
    }

    return ReportNameError.NONE;
}