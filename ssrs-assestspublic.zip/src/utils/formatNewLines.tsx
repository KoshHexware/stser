import React from "react";

export const formatNewLines = (str: string) =>
  str ?
    str.replace(/\n{3,}/g, '\n\n\n') // Replace any 3+ consecutive newlines with exactly 2 newlines
      .split('\n')
      .map((line: string, index: number, arr: string[]) => (
        <React.Fragment key={index}>
          {line}
          {index < arr.length - 1 && <br />}
        </React.Fragment>
      ))
    : '';