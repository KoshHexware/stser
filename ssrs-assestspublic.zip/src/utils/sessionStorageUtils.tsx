import { IQueryParamsTypes } from '../interfaces/IDeepLinkingTypes';
import { SELF_SERVICE_REPORTS_STORAGE_KEY } from './constants';


//sessionStorage function for storing query parameters
export const storeQueryParamsInSession = (params: IQueryParamsTypes): void => {
  try {
    sessionStorage.setItem(SELF_SERVICE_REPORTS_STORAGE_KEY, JSON.stringify(params));
  } catch (error) {
    console.error('Failed to store query parameters in sessionStorage:', error);
  }
};

// Function to retrieve query parameters from sessionStorage
export const getQueryParamsFromSession = (): IQueryParamsTypes | null => {
  try {
    const storedParams = sessionStorage.getItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
    return storedParams ? JSON.parse(storedParams) : null;
  } catch (error) {
    console.error('Failed to retrieve query parameters from sessionStorage:', error);
    return null;
  }
};

// Function to clear the stored parameters
export const clearQueryParamsFromSession = (): void => {
  try {
    sessionStorage.removeItem(SELF_SERVICE_REPORTS_STORAGE_KEY);
  } catch (error) {
    console.error('Failed to clear query parameters from sessionStorage:', error);
  }
};