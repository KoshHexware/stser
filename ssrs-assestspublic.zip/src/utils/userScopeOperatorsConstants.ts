
import { IOperatorDetails, ITextOperations } from '../interfaces/IFilterTypes';

export const USER_SCOPE_OPERATOR_CURRENT_USER_OPERATION_LABEL = 'Is [Current user]';
export const USER_SCOPE_OPERATOR_MY_TEAM_OPERATION_LABEL = 'Is [My team]';

export const USER_SCOPE_OPERATOR_CURRENT_USER: IOperatorDetails = {
    name: ITextOperations.IS_CURRENT_USER,
    value: ITextOperations.IS_CURRENT_USER,
    uxLabel: USER_SCOPE_OPERATOR_CURRENT_USER_OPERATION_LABEL,
    label: USER_SCOPE_OPERATOR_CURRENT_USER_OPERATION_LABEL,
};

export const USER_SCOPE_OPERATOR_MY_TEAM: IOperatorDetails = {
    name: ITextOperations.IS_MY_TEAM,
    value: ITextOperations.IS_MY_TEAM,
    uxLabel: USER_SCOPE_OPERATOR_MY_TEAM_OPERATION_LABEL,
    label: USER_SCOPE_OPERATOR_MY_TEAM_OPERATION_LABEL,
};

export const USER_SCOPE_TEXT_OPERATORS: IOperatorDetails[] = [
    USER_SCOPE_OPERATOR_CURRENT_USER,
    USER_SCOPE_OPERATOR_MY_TEAM,
];

export enum UserScopeTextMyTeamSubOperators {
    IncludeIndirectReportsValue = 'IncludeIndirectReports',
    IncludeIndirectReportsLabel = 'Include indirect reports',
    IncludeCurrentUserValue = 'IncludeCurrentUser',
    IncludeCurrentUserLabel = 'Include [Current user]',
    IncludeDirectReports = 'IncludeDirectReports'
}
