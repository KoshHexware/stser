
export const copyUrl = (reportId): boolean => {
    let result;
    const url = `https://${window.location.host}#/selfservicereports/report/view/${reportId}`;
    try {
        // @ts-ignore
        if (window.clipboardData) { // IE
            // @ts-ignore
            if (window.clipboardData.getData('Text')) { // allow access clipboard.
                result = !!accessClipboard(url);
            } else {
                result = false;
            }
        } else {
            result = !!accessClipboard(url);
            console.error('copy url error: access clip board denied.');
        } // moz, opera, webkit
    } catch (err) {
        result = false;
        console.error('copy url error:', err);
    }
    return result;
}
  
  function accessClipboard(link) {
    const linkElement = document.createElement('div');
    linkElement.innerText = link;
    linkElement.style.opacity = '0';
    linkElement.style.overflow = 'hidden';
    linkElement.style.height = '1px';
    linkElement.style.width = '1px';
    document.body.appendChild(linkElement);
    linkElement.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(linkElement);
    selection?.removeAllRanges();
    selection?.addRange(range);
    const result = document.execCommand('copy');
    document.body.removeChild(linkElement);
    return result;
}