import {
  ColumnSort,
  SelfServiceReportsLandingPageStorage,
} from '../interfaces/SSRTypes';
import { SELF_SERVICE_REPORTS_LANDING_PAGE_STORAGE_KEY } from './constants';

export const getReportLandingPageStorage =
  (): SelfServiceReportsLandingPageStorage => {
    const storageJson = localStorage.getItem(
      SELF_SERVICE_REPORTS_LANDING_PAGE_STORAGE_KEY
    );
    return storageJson
      ? JSON.parse(storageJson)
      : {
          columnSortBy: '',
          columnSortOrder: '',
          columnOrder: '',
          columnReportSearch: '',
        };
  };

export const updateReportLandingPageStorage = (
  updates: Partial<SelfServiceReportsLandingPageStorage>
) => {
  const currentStorage = getReportLandingPageStorage();
  const updatedStorage = { ...currentStorage, ...updates };
  localStorage.setItem(
    SELF_SERVICE_REPORTS_LANDING_PAGE_STORAGE_KEY,
    JSON.stringify(updatedStorage)
  );
  return updatedStorage;
};

export const handleColumnSortUpdate = (sortModel: ColumnSort[]) => {
  if (sortModel && sortModel.length > 0) {
    // Update the localStorage with the new sort model
    updateReportLandingPageStorage({
      columnSortBy: sortModel[0].colId,
      columnSortOrder: sortModel[0].sort,
    });
  }
};
