import ReportService from '../services/ReportService';
import { DateTime } from 'luxon';
import { ContextualButtonStatus } from './constants';

class ReportExporter {
  public static type 

  public static getFileName = name => {
    let formattedDate = DateTime.local().toFormat('yyyyMMddHHmmss');
    const sanitizedName = name.replace(/\s+/g, '_');
    return `${sanitizedName}_${formattedDate}.csv`;
  };

  public static exportReport = async (
    id: string,
    reportName: string,
    columnsToExport: string[],
    updatedOrderField: string,
    updatedOrderBy: string,
    updatedFilters: string[],
    teamsiteIds: string[],
    isSavedReport: boolean,
    isDrillIn: boolean,
    sourceReportId: string | null,
    sourceReportDrillInColumn: string | null
  ): Promise<ContextualButtonStatus> => {
    return new Promise((resolve) => {
      ReportService.exportReport(id, columnsToExport, updatedOrderField, updatedOrderBy, updatedFilters, teamsiteIds, isSavedReport, isDrillIn, sourceReportId, sourceReportDrillInColumn)
        .then((data: any) => {
          if (data) {
            let type = 'text/csv';
            const blob = new Blob([data], { type });
            let link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = ReportExporter.getFileName(reportName);
            link.click();
            resolve('success');
          } else {
            resolve('error');
          }
        })
        .catch(() => {
          resolve('error');
        });
    });
  };
}

export default ReportExporter;
