import { ILaunchDarklyToggle } from "../interfaces/ILaunchDarkly";
import {ENABLE_SSR_WINTER_FY26_RELEASE} from './constants';

export const checkSSRWinterFY26FeatureFlag = (launchDarklyToggles: ILaunchDarklyToggle[] | undefined): boolean  => {
    return launchDarklyToggles?.find(x => x.FeatureKey === ENABLE_SSR_WINTER_FY26_RELEASE)?.FeatureState === "True" || false;
};