import { useHistory } from 'react-router-dom';
import { IQueryParamsTypes } from '../interfaces/IDeepLinkingTypes';
import { EDITOR_ACCESS_LEVEL } from '../utils/constants';

export const caputureQueryParamsFromURl = (): {
  hasParams: boolean;
  params: IQueryParamsTypes;
} => {
  const history = useHistory();
  const queryParams = new URLSearchParams(history.location.search);
  const fieldsParam = queryParams.get('fields');
  const filtersParam = queryParams.get('filters');
  const orderByParam = queryParams.get('orderBy');
  const skipParam = queryParams.get('skip');
  const takeParam = queryParams.get('take');
  const orderFieldParam = queryParams.get('orderField');
  const teamsiteIdsParam = queryParams.get('teamsiteIds');
  const isDrillInParam = queryParams.get('isDrillIn');
  const sourceReportIdParam = queryParams.get('sourceReportId');
  const sourceReportDrillInColumnParam = queryParams.get('sourceReportDrillInColumn');

  const hasParams = queryParams.toString().length > 0;

  const params: IQueryParamsTypes = hasParams
    ? {
      fields: fieldsParam ? JSON.parse(decodeURIComponent(fieldsParam)) : [],
      filters: filtersParam
        ? JSON.parse(decodeURIComponent(filtersParam))
        : [],
      orderBy: orderByParam as 'asc' | 'desc' | undefined,
      skip: skipParam ? parseInt(skipParam) : undefined,
      take: takeParam ? parseInt(takeParam) : undefined,
      orderField: orderFieldParam || undefined,
      teamsiteIds: teamsiteIdsParam
        ? JSON.parse(decodeURIComponent(teamsiteIdsParam))
        : [],
      isDrillIn: isDrillInParam === 'true',
      sourceReportId: sourceReportIdParam || undefined,
      sourceReportDrillInColumn: sourceReportDrillInColumnParam || undefined,
    }
    : {};
  return { hasParams, params };
};

export const isDeepLinkForSystemReport = (reportInfo, accessLevel) => {
  const isEditor = accessLevel.toLowerCase() === EDITOR_ACCESS_LEVEL;
  return isEditor && reportInfo.reportType.toLowerCase() === 'system';
};
