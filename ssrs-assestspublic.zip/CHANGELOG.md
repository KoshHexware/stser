# seismic-self-service-reports-assets Changes By Release

All notable changes to this project will be documented in this file.

## [4.0.5] - 2026.02.02 ssrs web
### Fixed
- [NLTCS-2470] - Update Share modal search bar text
- [NLTCS-2494] - Drill in - After adding a column, it does not appear in the grid.
- [NLTCS-2479] - VQA feedback for drill-in

## [4.0.4] - 2026.01.19 ssrs web
### Added
- [NLTCS-2256] - SSR - Support for localization and accessibility
- [NLTCS-2258] - SSR - Next gen UI adoption - part 2
- [NLTCS-2259] - SSR - Support for hyperlinks in drill in columns
- [NLTCS-2316] - SSR - Integrate web-report-grid-ui in SSR
- [NLTCS-2319] - Update AG Grid license key in all Analytics apps reports
- [NLTCS-2337] - Pending work for drill down frontend component
- [NLTCS-2365] - SSR - Show all users and user groups in share modal
- [NLTCS-2369] - Support system report view for viewer only user in case of drillIn feature
- [NLTCS-2372] - URL Refresh should save state of the report when open in new tab in case of drill-in
- [NLTCS-2378] - URL Refresh should save state of the report when open in new tab in case of drill-in
### Fixed
- [NLTCS-2427] - Exporting Drill-In report data is not working as expected on the report view page
- [NLTCS-2338] - Readinesscoachingqa - ‘Done’ button is disabled after adding a custom property filter.
- [NLTCS-2360] - Drill-in, the exported report should include only the selected count, not all available columns.
- [NLTCS-2366] - In the Web Report Grid, the font does not match the UX guidelines. A different font family is being applied to the grid text
- [NLTCS-2367] - Shared report is not visible when shared with both User Group and individual user who belongs to that group
- [NLTCS-2370] - column shifting is not working in QA tenants
- [NLTCS-2371] - Sorting is not working in QA due to missing column separators

## [4.0.3] - 2025.12.05 ssrs web
### Added
- [NLTCS-2139] - Implement number formatting in UI for sorting and display
- [NLTCS-2248] - SSR - FE work to support sharing reports with user groups
- [NLTCS-2305] - Format all integer and decimal data type column using number-formatter by default
- [NLTCS-2329] - SSR – Number and rate formatter changes should be under the seasonal feature flag

## [4.0.2] - 2025.11.25 ssrs web
### Fixed
- [NLTCS-2265] - Improvement of the on-screen message for users on the report landing page when NO reports are visible.
- [NLTCS-2245] - SSR - Fix column order reset issue after sorting in reports

## [4.0.1] - 2025.10.29 ssrs web
### Fixed
- [NLTCS-2262] - ‘New Report’ button is disabled when the default option ‘All Reports’ is selected

## [3.0.11] - 2025.10.13 ssrs web
### Added
- [NLTCS-2203] - SSRS - FE - Adopt permission change in frontend
- [NLTCS-2095] - SSR - Handle api timeout in ssrs web, should show generic error message

## [3.0.10] - 2025.08.22 ssrs web
### Added
- [NLTCS-1157] - SSR - FE work for Relative filters - "my team"
- [NLTCS-1993] - SSR - Aura chat payload updates
### Fixed
- [NLTCS-1979] - 'Deselect All’ link shown even when there are no filter values to display
- [NLTCS-2065] - Info bar not displayed after selecting “Is [Current User]” (as per Figma design)
- [NLTCS-2067] - Users Report - 400 error after applying “Related User” filter
- [NLTCS-2068] - FE - The values set by my team operator are being persisted in the 'Current User' filter on the filter card.
- [NLTCS-2072] - Last Viewed column not showing latest data

## [3.0.9] - 2025.08.11 ssrs web
### Fixed
- [NLTCS-2044] - Paging is not working in report grid

## [3.0.8] - 2025.07.30 ssrs web
### Added
- [NLTCS-1772] - Support new operator  IsAllOf for field which can have multiple values.
- [NLTCS-1938] - SSR - Deep link support for system reports for editor role
### Fixed
- [NLTCS-1961] - Accessibility Test failling 
- [NLTCS-1967] - Adding column to report is missing values and not saving with new version of report
- [NLTCS-1971] - Filter count is not getting updated
- [NLTCS-1972] - Inconsistent Data Display in Program Report After Applying Audience Filter and Sorting
- [NLTCS-1973] - Data not loading correctly when a specific Team Site is selected.
- [NLTCS-1975] - Digital Sales Rooms - CORS Error Occurs After Removing "Activity Date" Filter
- [NLTCS-1987] - [FE] Execute API not triggered when saving report after changes without refresh
- [NLTCS-1983] - [FE] Deep link not honoring URL parameters 

## [3.0.7] - 2025.07.16 ssrs web
### Added
- [NLTCS-1095] - [UX] Filter - multi values display - should have info icon, which will show list of applied fields on hover.
- [NLTCS-1471] - SSR - Support to save empty and default filters without values in custom reports
- [NLTCS-1767] - Unique report names is user scoped & not tenant scoped. Change in same report error experience.
- [NLTCS-1781] - SSR - show tooltips for cells in report view if text is long
- [NLTCS-1782] - SSR - on landing page, if the right most column has no actions, hide the column.
- [NLTCS-1783] - SSR - Enhance generic filters to support contains/not contains for text fields 
- [NLTCS-1785] - SSR - Landing page - add hyphen in blank cells
- [NLTCS-1786] - SSR - UX - Add line below header on the Save copy modal
- [NLTCS-1791] - Relative date filters - add support for new/updated date operators
### Fixed
- [NLTCS-1806] - Incorrect sort order on landing page based on report type
- [NLTCS-1936] - Unsaved Report Name Shows Error
- [NLTCS-1937] - exported reports showing wrong date on report name
- [NLTCS-1956] - Description not cleared when switching from "Contains" to "Is one of"

## [3.0.6] - 2025.06.25 ssrs web
### Fixed
- [NLTCS-1775] - Long Column Name Gets Hidden After Clicking Eye or Info Icon
- [NLTCS-1780] - Landing page - on search, remove the whitespace that shows up in the highlighted text
- [NLTCS-1793] - Export for date fields appends timestamp of 12 AM.
- [NLTCS-1795] - training_event_sessions - Incorrect Filter Count Displayed on Initial Load.

## [3.0.5] - 2025.06.17 ssrs web
### Fixed
- [NLTCS-1769] - Filter count display when no criteria is applied.
- [NLTCS-1768] - Fix UI issue: truncated fields cannot be expanded.

## [3.0.3] - 2025.06.11 ssrs web
### Fixed
- [NLTCS-1765] - Description preview should truncate at 1 lines

## [3.0.2] - 2025.06.10 ssrs web
### Fixed
- [NLTCS-1759] - Add tooltip for report description and support 2 line break when consecutively added
- [NLTCS-1761] - New report modal report search by description is not working

## [3.0.1] - 2025.06.05 ssrs web
### Added
- [NLTCS-1676] - Update naming convention of exported .csv files in SSRS.
### Fixed
- [NLTCS-1750] - Validation for Report Name & Description
- [NLTCS-1752] - Training Event Session -an 'undefined' prefix
- [NLTCS-1753] - Missing scrollbar in report description
- [NLTCS-1754] - VQA - feedback items

## [3.0.0] - 2025.05.30 ssrs web
### Added
- [NLTCS-1153] - View and edit the report description
- [NLTCS-1503] - Popover to show field metadata.
- [NLTCS-1521] - Support for additional user group for editing custom reports
- [NLTCS-1523] - Unified view changes
- [NLTCS-1666] - Update Standard report description UI in the create new report flow.
- [NLTCS-1667] - Landing page - show description column and popover
- [NLTCS-1669] - Edit report name
- [NLTCS-1720] - Merge view and edit urls and support for old urls
- [NLTCS-1721] - Pendo tracking for report page
### Fixed
- [NLTCS-1500] - When I click on the standard report card in the New Report modal, a blank screen appears for a few seconds, which doesn't look good
- [NLTCS-1663] - Context changes for the self service report
- [NLTCS-1664] - Field popover - demo feedback items
- [NLTCS-1665] - Export button functionality in unified view
- [NLTCS-1723] - Deselecting all teamsites after reseting report and it does not update the count correctly.
- [NLTCS-1724] - The confirmation message shown after exporting a report is clickable
- [NLTCS-1726] - Reports with names containing only spaces or special characters are allowed to be saved.
- [NLTCS-1727] - Report description should have validation
- [NLTCS-1728] - Reports are being saved without renaming the default report name.
- [NLTCS-1729] - Two filters in the UI appear visually inconsistent.
- [NLTCS-1730] - Modal is also not as per figma
- [NLTCS-1731] - After clicking the Reset button, the custom report is getting saved
- [NLTCS-1732] - LeftPanel, Landing Page and Grid height issue
- [NLTCS-1733] - Support for hiding fields when viewing a report
- [NLTCS-1734] - New line support in column metadata popover .
- [NLTCS-1735] - Permission user group rename and remove support for newly added group ("Manage all reports" and "Report viewer")
- [NLTCS-1737] - An error occurs after saving a shared report.
- [NLTCS-1740] - After changing the report description, the updated description is not being reflected in the "Save a copy" modal.
- [NLTCS-1741] - Even when a report returns no results, the "Edit Table" and "Filters" buttons should still be visible on the grid.
- [NLTCS-1742] - Users with the "Report Viewer" role should not be able to save reports.
- [NLTCS-1743] - Unified view - UI Issues
- [NLTCS-1746] - The eye icon is not visible in standard reports
- [NLTCS-1747] - Exported reports should not include columns that are hidden using the eye icon
- [NLTCS-1748] - Error Displayed on SSR Homepage

## [2.0.7] - 2025.05.14 ssrs web
### Added
- [NLTCS-1324] - Teamsite Frontend - 1
- [NLTCS-1505] - Teamsites - Implement Pendo tracking
### Fixed
- [NLTCS-1308] - arrows in filters are not working
- [NLTCS-1501] - Share Modal search should work in order first name -> user name -> email
- [NLTCS-1504] - Sharing - Pendo related issues
- [NLTCS-1509] - The 'Save ' report option does not appear after creating a custom report.
- [NLTCS-1511] - 'Edit' button should not show if user does not have access to Teamsite
- [NLTCS-1513] - 'Reset' button functionality
- [NLTCS-1518] - User should not be able to deselect all the teamsite.
- [NLTCS-1519] - The selected Teamsite count is showing an incorrect number.
- [NLTCS-1661] - The Teamsite list does not display all entries when there are a large number of Teamsites
- [NLTCS-1662] - After performing a reset, the Teamsites option cannot be deselected.

## [2.0.6] - 2025.04.14 ssrs web
### Added
- [NLTCS-1276] - Support generic filters for all fields
- [NLTCS-1297] - Report sharing UX changes - 1
- [NLTCS-1307] - [Micron] Performance - Quicker explanation for each column in a report (There is a few seconds delay)
- [NLTCS-1318] - Report Sharing - landing page all filter should show users owned, shared and system reports.
- [NLTCS-1319] - User should not be able to edit shared report.
- [NLTCS-1322] - Report Sharing UI Changes - 2
- [NLTCS-1326] - Chainguard - Node update for ssrs
- [NLTCS-1344] - [Self service reports] Add tooltips for buttons without text/label
- [NLTCS-1357] - [Self service reports] Change user property labels in field and filter modals.
- [NLTCS-1363] - Web - Hide standard reports filter option from landing page for users with view access.
- [NLTCS-1369] - Unit tests for Sharing FE
- [NLTCS-1370] - Pendo tracking and accessibility for sharing
- [NLTCS-1488] - Hide the dropdown on landing page for report viewer users
### Fixed
- [NLTCS-1352] - Filter List Displays 'No Option' Before Loading Options
- [NLTCS-1353] - Filter Menu Display Issue – Options Not Fully visible

## [2.0.5] - 2025.03.18 Week 3 ssrs web
### Added
- [NLTCS-1262] - [SSRS] - Landing page UI changes
- [NLTCS-1292] - [SSRS] landing page - filter selection should be sticky across sessions
### Fixed
- [NLTCS-1250] - Complete Description is not visible on landing page 
- [NLTCS-1238] - Prod - Insufficient space to view filters option
- [NLTCS-1268] - No Error Message is displayed when no reports are found during search on New report Page
- [NLTCS-1269] - date filter displays different date value between selected and displayed date
- [NLTCS-1271] - Custom filters in view mode it getting appended with N/A
- [NLTCS-1274] - UI Issue : Filter Page break down on custom report
- [NLTCS-1278] - 'Invalid date' is appending at end if 'Is blank' filter applied

## [2.0.4] - 2025.02.06 Week 2
### Fixed
- [NLTCS-1247] - Investigate report refresh prompt when removing a filter with no criteria

## [2.0.3] - 2025.01.06 Week 5
### Added
- [NLTCS-1177] - Filter operator localization
- [NLTCS-1174] - Email and URL field UX Changes
- [NLTCS-1171] - Web - Show url in status for url/email fields.
- [NLTCS-1163] - Save copy using custom report
- [NLTCS-1162] - Support for url field type
- [NLTCS-1161] - Export feature UI improvements
- [NLTCS-1154] - Email columns - hyperlinks
- [NLTCS-1152] - Optimize edit filters and columns modal for re-renders
- [NLTCS-1142] - Support for null and non null value in filters
- [NLTCS-1139] - Export in Edit mode ( for the ad hoc analysis use-case )
- [NLTCS-1125] - Default filter fields in Self-service reports - support for Empty filter criteria in Standard and Custom reports
- [NLTCS-983] -  Support for filter category order
### Fixed
- [NLTCS-1071] - Multiple issue on standard report.
- [NLTCS-1136] - If column has blank data, then it should reflect in filter as well
- [NLTCS-1159] - Performance - Username filter not loading in 'Searches' report
- [NLTCS-1172] - For url field type on hover should display tooltip of url field value in edit mode
- [NLTCS-1180] - If error occurs on saving copy it persist state on ui but it does not reflect in api payload
- [NLTCS-1183] - Remove 'Is blank' and 'Is not blank' operators from filters where Null's are treated as Zero
- [NLTCS-1190] - Add only selected fields to execute request
- [NLTCS-1191] - Error in User group filter
- [NLTCS-1193] - URL tooltip copy button should reset once url copied
- [NLTCS-1199] - Inconsistent filter pop up label :'No Option' initially changes to 'No Selection'
- [NLTCS-1200] - Filter's are off screen & not visible in UI in view mode .
- [NLTCS-1207] - Custom property filter apply button does not enable when selecting on Not Contains operator
- [NLTCS-1213] - Export report missing custom column in view mode
- [NLTCS-1221] - Filter displays 'undefined' instead of 'Equals to'
- [NLTCS-1232] - State of filter is not changing after reset report

## [2.0.2] - 2024.12.06 Week 1
### Fixed
- [NLTCS-1113] - Fixed all scrollbar issues
- [NLTCS-1129] - Fixed issues with filters

### Improvments
- [NLTCS-1131] - Added support for decimal values with validation

## [2.0.1] - 2024.12.03 ssrs web
### Fixed
- [NLTCS-1073] - Report is getting saved with blank mandatory fields.
- [NLTCS-1106] - Export report should reflect only the filtered/visible columns
- [NLTCS-1097] - Filters is not getting applied in export
- [NLTCS-1103] - Fix error handling message in error boundary
- [NLTCS-1109] - Fix Localization in report grid and landing page
- [NLTCS-1110] - Issues in add column and add filter modal
- [NLTCS-1115] - Filters/Column selector - description text wrapping broken

### Added
- [NLTCS-1096] - Prefetch data for picklist - as soon as the filter edit popver opens.
 -[NLTCS-1114] - VQA- UX Observations

## [2.0.0] - 2024.11.27 Week 4
### Inital
 - [NLTCS-1053] - Report edit mode - new category based UI for filters
 - [NLTCS-982] - Report edit mode - new category based UI for columns
 - [NLTCS-1093] - CSP Manual:source file: seismic-self-service-reports-assets.main

### Improvments
 - [NLTCS-1043] - Performance improvements with ui state and unnecessary service calls
 - [NLTCS-1085] - Updated ui based on demo feedback items
 - [NLTCS-1087] - Removed the filters button in edit/analyze mode.
 - [NLTCS-1088] - Filter modal - disable pre-selected items.
 - [NLTCS-1090] - Filter and Columns modal - Search based on titles and description 

### Fixes
 - [NLTCS-1059] - Fix report loading issue for filters with special character values
 - [NLTCS-1062] - Default landing should be on All reports if user has not viewed any report
 - [NLTCS-1065] - Content Views Standard report not loading after username filter is applied.
 - [NLTCS-1072] - Fixed error on Date and Datetime filters.
 - [NLTCS-1074] - Report filters are failing for date with 'YYYY-MM-DD' format
 - [NLTCS-1075] - Email filter is not working
 - [NLTCS-1076] - User name filter is not working

## [1.0.5] - 2024.10 Week 5
### Inital
 - [NLTCS-996] - Filters UI implementation
 - [NLTCS-1026] - Sort filters and column in the edit page popover alphabetically
 - [NLTCS-998] - Added filters user input validation
 - [NLTCS-999] - Added tests for filters
 - [NLTCS-898] - Added Error boundry and empty state
 - [NLTCS-932] - Filters UI - Domain of values and picklist
### Improvments
 - [NLTCS-1025] - Landing page and shell improvments
 - [NLTCS-1027] - View mode changes from feedback
 - [NLTCS-1003] - Resolved feedback items
 - [RDPS-21086] - Accessibility changes

## [1.0.3] - 2024.10 Week 1
### Inital
 - [NLTCS-901] - View report implementation
 - [NLTCS-902] - Report list data grid implementation
 - [NLTCS-904] - New report button and new report modal implementation.
 - [NLTCS-907] - Added new report modal shell with routing
 - [NLTCS-924] - Integrate all and recent report api with sorting, searching and infinite scroll
 - [NLTCS-926] - Read fields from fieldGroups instead fields
 - [NLTCS-975] - Added standard report workflow, preview report, delete and fixed issues
 - [NLTCS-981] - Added export report feature
 - [NLTCS-987] - Show confirmation popup before deleting a report
 - [NLTCS-986] - Resolved demo feedback items
 - [NLTCS-997] - Added tooltip and remove icon for column chip
 - [NLTCS-919,NLTCS-935] - Added infinite scroll for report view and edit with initial skeleton
 - [NLTCS-1004] - Fixed issues with standard report analyze user workflow
 - [RDPS-21122] - Used updated api routes
 - [RDPS-21125] - Changes for mantle compliance

## [1.0.0] - 2024.06 Week 4
### Inital
 - [NLTCS-850] - Inital changes for self service reports