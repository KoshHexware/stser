const path = require("path");
const { deepAssign } = require('@seismic/toolchain/deepAssign');
const nextGenManifestConfig = require('@seismic/toolchain-scripts/webpack/seismic-importmap.app.v2.config');
//const nextGenManifestConfig = require('@seismic/toolchain-scripts/webpack/seismic-manifest.nextgen.config');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const webpack = require("webpack");

const packageName = require("../package.json").name;
const packageNameFileNameSafe = (
  packageName.startsWith("@") ? packageName.substring(1) : packageName
).replace(/\//g, "-");
const assetsPattern = `${packageNameFileNameSafe}.[name]`;

module.exports = (_, argv) => {
  const mode = argv.mode || 'production';
  const isProduction = mode === "production";

  const customizedConfig = {
    mode,
    devtool: isProduction ? "source-map" : "eval-source-map",
    entry: path.resolve(__dirname, '../src/app/SeismicEmbedWrapper/index.nextgenv2.tsx'),
    output: {
      path: path.join(__dirname, "../dist/assets/"),
      filename: `${assetsPattern}-nextgenv2.[chunkhash].js`,
      chunkFilename: `${assetsPattern}-nextgenv2.[chunkhash].js`,
    },
    resolve: {
      extensions: [".ts", ".tsx", ".js", ".jsx", ".json", ".css", ".scss"],
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx|ts|tsx)$/,
          use: "babel-loader",
          exclude: /node_modules/,
        },
        {
          test: /\.css$/,
          use: [
            isProduction ? MiniCssExtractPlugin.loader : 'style-loader',
            'css-loader',
            'postcss-loader'
          ],
          sideEffects: true
        },
        {
          test: /\.scss$/,
          use: [
            isProduction ? MiniCssExtractPlugin.loader : 'style-loader',
            'css-loader',
            'postcss-loader',
            'sass-loader'
          ],
          sideEffects: true
        },
      ],
    },
    plugins: [
      new webpack.DefinePlugin({
        "process.env.NEXT_GEN": JSON.stringify('true'),
        "process.env.basePath": JSON.stringify('window.parentRoute + "/selfservicereports"'),
        "process.env.NODE_ENV": JSON.stringify(isProduction ? "production" : "development"),
      }),
      new MiniCssExtractPlugin({
        filename: isProduction
          ? `${packageNameFileNameSafe}.nextgenv2.[name].[contenthash:8].css`
          : `${packageNameFileNameSafe}.nextgenv2.[name].css`,
        chunkFilename: isProduction
          ? `${packageNameFileNameSafe}.nextgenv2.[name].[contenthash:8].chunk.css`
          : `${packageNameFileNameSafe}.nextgenv2.[name].chunk.css`,
      }),
    ],
  };

  const ssrsConfig = deepAssign({}, nextGenManifestConfig, customizedConfig);
  return ssrsConfig;
}