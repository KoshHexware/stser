const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const webpack = require("webpack");

const packageName = require("../package.json").name;
const packageNameFileNameSafe = (
  packageName.startsWith("@") ? packageName.substring(1) : packageName
).replace(/\//g, "-");
const assetsPattern = `${packageNameFileNameSafe}.[name]`;

module.exports = (_, argv) => {
  const mode = argv.mode || "production";
  isProduction = mode === "production";
  return {
    mode: mode,
    devtool: isProduction ? "source-map" : "eval-source-map",
    entry: "./src/app/SeismicEmbedWrapper",
    output: {
      path: path.join(__dirname, "../dist/assets/"),
      filename: `${assetsPattern}.[chunkhash].js`,
      chunkFilename: `${assetsPattern}.[chunkhash].js`,
    },
    resolve: {
      extensions: [".ts", ".tsx", ".js", "jsx", ".json", ".css", ".scss"],
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx|ts|tsx)$/,
          use: "babel-loader",
          exclude: /node_modules/,
        },
        {
          test: /\.(scss|sass|css)/,
          use: ["style-loader", "css-loader", "sass-loader"],
          exclude: /node_modules/,
        },
      ],
    },
    devServer: {
      port: "3000",
      static: ["./dist/assets"],
    },
    plugins: [
      // https://webpack.js.org/plugins/define-plugin/
      new webpack.DefinePlugin({
        "process.env.NODE_ENV": JSON.stringify(
          isProduction ? "production" : "development"
        ),
        "process.env.NEXT_GEN": JSON.stringify("false"),
      }),
      new MiniCssExtractPlugin({
        filename: isProduction
          ? `${packageNameFileNameSafe}.[name].[contenthash:8].css`
          : `${packageNameFileNameSafe}.[name].css`,
        chunkFilename: isProduction
          ? `${packageNameFileNameSafe}.[name].[contenthash:8].chunk.css`
          : `${packageNameFileNameSafe}.[name].chunk.css`,
      }),
    ],
  };
};
