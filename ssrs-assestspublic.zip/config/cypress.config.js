const path = require("path");
const { browserList } = require("@seismic/toolchain/browserList");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const postCssFlexbugsFixes = require("postcss-flexbugs-fixes");
const postCssPresetEnv = require("postcss-preset-env");
const webpack = require("webpack");

const packageName = require("../package.json").name;
const packageNameFileNameSafe = (
  packageName.startsWith("@") ? packageName.substring(1) : packageName
).replace(/\//g, "-");
const assetsPattern = `${packageNameFileNameSafe}.[name]`;

function getStyleLoaders({ useSass, ...cssLoaderOptions } = {}) {
  cssLoaderOptions = {
    ...cssLoaderOptions,
    importLoaders: useSass ? 3 : 1,
    sourceMap: true,
  };

  const loaders = [
    { loader: MiniCssExtractPlugin.loader },
    {
      // "css-loader" resolves paths in CSS and adds assets as dependencies.
      loader: "css-loader",
      options: cssLoaderOptions,
    },
    {
      // "postcss-loader" applies autoprefixer to our CSS for IE 11 support.
      loader: "postcss-loader",
      options: {
        postcssOptions: {
          plugins: [
            postCssFlexbugsFixes,
            postCssPresetEnv({
              autoprefixer: {
                flexbox: "no-2009",
              },
              browsers: browserList,
              stage: 3,
            }),
          ],
        },
        sourceMap: true,
      },
    },
  ];

  if (useSass) {
    loaders.push(
      {
        loader: "resolve-url-loader",
        options: {
          sourceMap: true,
        },
      },
      {
        loader: "sass-loader",
        options: {
          sourceMap: true,
        },
      }
    );
  }

  return loaders;
}
module.exports = (_, argv) => {
  const mode = "test";
  return {
    mode,
    entry: "./src/app/SeismicEmbedWrapper",
    output: {
      path: path.join(__dirname, "../dist/assets/"),
      filename: `${assetsPattern}.[chunkhash].js`,
      chunkFilename: `${assetsPattern}.[chunkhash].js`,
    },
    resolve: {
      extensions: [".ts", ".tsx", ".js", ".jsx", ".json", ".scss", ".css"],
      alias: {
        _src: path.resolve(__dirname, "../src"),
        _widgets: path.resolve(__dirname, "../src/app/widgets"),
        _common: path.resolve(__dirname, "../src/app/components/common")
      }
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx|ts|tsx)$/,
          exclude: /node_modules/,
          use: "babel-loader",
        },
        // Support for SASS (using .scss or .sass extensions).
        {
          test: /\.(scss|sass|css)$/,
          use: getStyleLoaders({ modules: false, useSass: true }),
          sideEffects: true,
        },
        // Support for SASS modules with the extensions .module.scss or .module.sass
        {
          test: /\.module\.(scss|sass|css)$/,
          use: getStyleLoaders({ modules: true, useSass: true }),
        },
        {
          test: /\.(png|jpe?g|gif)$/i,
          use: [
            {
              loader: 'file-loader',
            },
          ],
        },
      ],
    },
    plugins: [
      // https://webpack.js.org/plugins/define-plugin/
      new webpack.DefinePlugin({
        "process.env.NODE_ENV": JSON.stringify("test"),
      }),
      new MiniCssExtractPlugin({
        filename:  `${packageNameFileNameSafe}.[name].css`,
        chunkFilename: `${packageNameFileNameSafe}.[name].chunk.css`,
      }),
    ],
    optimization: {
      splitChunks: {
        cacheGroups: {
          styles: {
            name: "styles",
            type: "css/mini-extract",
            chunks: "all",
            enforce: true,
          },
        },
      },
    },
  };
};