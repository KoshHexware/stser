import React from 'react';
import { I18nextProvider } from 'react-i18next';
import TeamsitesViewTag from '../../../../../src/app/components/Teamsites/TeamsitesViewTag/TeamsitesViewTag';
import testI18n from '../../../../support/i18n-setup';

describe('TeamsitesViewTag Component', () => {
    beforeEach(() => {
        window.React = React;
    });

    describe('Conditional Rendering', () => {
        it('should not render when teamsites is null or undefined', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={null} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag').should('not.exist');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={undefined} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag').should('not.exist');
        });

        it('should not render when teamsites array is empty', () => {
            const teamsites = [];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag').should('not.exist');
        });

        it('should not render when teamsites has only one item', () => {
            const teamsites = [
                { id: '1', name: 'Single Teamsite', isSelected: true }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag').should('not.exist');
        });

        it('should render when teamsites has more than one item', () => {
            const teamsites = [
                { id: '1', name: 'Teamsite One', isSelected: true },
                { id: '2', name: 'Teamsite Two', isSelected: false }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag').should('exist');
        });
    });

    describe('Tag Display and Content', () => {
        it('should display correct selected count when some teamsites are selected', () => {
            const teamsites = [
                { id: '1', name: 'Teamsite Alpha', isSelected: true },
                { id: '2', name: 'Teamsite Beta', isSelected: true },
                { id: '3', name: 'Teamsite Gamma', isSelected: false }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '2');
            
            cy.get('.ssrs-teamsites-view-tag').should('contain.text', 'Teamsites selected');
        });

        it('should display 0 when no teamsites are selected', () => {
            const teamsites = [
                { id: '1', name: 'Teamsite Alpha', isSelected: false },
                { id: '2', name: 'Teamsite Beta', isSelected: false },
                { id: '3', name: 'Teamsite Gamma', isSelected: false }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '0');
        });

        it('should display correct count when all teamsites are selected', () => {
            const teamsites = [
                { id: '1', name: 'Teamsite Alpha', isSelected: true },
                { id: '2', name: 'Teamsite Beta', isSelected: true },
                { id: '3', name: 'Teamsite Gamma', isSelected: true },
                { id: '4', name: 'Teamsite Delta', isSelected: true }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '4');
        });
    });

    describe('Edge Cases and Data Validation', () => {
        it('should handle teamsites with missing or undefined names', () => {
            const teamsites = [
                { id: '1', name: 'Valid Team', isSelected: true },
                { id: '2', name: null, isSelected: true },
                { id: '3', name: undefined, isSelected: true },
                { id: '4', name: '', isSelected: true },
                { id: '5', name: 'Another Valid Team', isSelected: false }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '4');

        });

        it('should handle teamsites with missing isSelected property', () => {
            const teamsites = [
                { id: '1', name: 'Team A', isSelected: true },
                { id: '2', name: 'Team B' }, // missing isSelected
                { id: '3', name: 'Team C', isSelected: false },
                { id: '4', name: 'Team D', isSelected: null } // null isSelected
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={teamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '1');
        });

    });

    describe('Performance and Memory', () => {
        it('should handle rapid prop changes without errors', () => {
            const initialTeamsites = [
                { id: '1', name: 'Team A', isSelected: true },
                { id: '2', name: 'Team B', isSelected: false }
            ];

            const updatedTeamsites = [
                { id: '1', name: 'Team A', isSelected: false },
                { id: '2', name: 'Team B', isSelected: true },
                { id: '3', name: 'Team C', isSelected: true }
            ];

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={initialTeamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '1');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <TeamsitesViewTag teamsites={updatedTeamsites} />
                </I18nextProvider>
            );

            cy.get('.ssrs-teamsites-view-tag-selected-count-text').should('contain.text', '2');
        });
    });
});