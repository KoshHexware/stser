import React from 'react';
import { I18nextProvider } from 'react-i18next';
import TeamsitesConfirmModal from '../../../../../src/app/components/Teamsites/TeamsitesConfirmModal/TeamsitesConfirmModal';
import { CompileReportContext } from '../../../../../src/contexts';
import testI18n from '../../../../support/i18n-setup';
import ReportService from '../../../../../src/services/ReportService';
import UpdatedFields from '../../../../fixtures/UpdatedFields.json';
import UpdatedFilters from '../../../../fixtures/updatedFilters.json';

describe('TeamsitesConfirmModal Component', () => {
    beforeEach(() => {
        window.React = React;

        cy.stub(ReportService, 'updateUserSettingsGlobalTeamsites').resolves([
            { id: 'teamsite-1', name: 'Teamsite 1', isSelected: true },
            { id: 'teamsite-3', name: 'Teamsite 3', isSelected: true }
        ]).as('updateUserSettingsGlobalTeamsites');
    });

    const mockTeamsites = [
        { id: 'teamsite-1', name: 'Teamsite 1', isSelected: true },
        { id: 'teamsite-2', name: 'Teamsite 2', isSelected: false },
        { id: 'teamsite-3', name: 'Teamsite 3', isSelected: true }
    ];

    const mountComponent = (contextOverrides = {}) => {
        const setIsTeamsitesChangesLoadingStub = cy.stub().as('setIsTeamsitesChangesLoadingHandler');

        const compileReportContextValue = {
            updatedFields: UpdatedFields,
            setUpdatedFields: cy.stub().as('setUpdatedFieldsHandler'),
            updatedFilters: UpdatedFilters,
            setUpdatedFilters: cy.stub().as('setUpdatedFiltersHandler'),
            setIsChanged: cy.stub().as('setIsChangedHandler'),
            isTeamsitesClicked: true,
            setIsTeamsitesClicked: cy.stub().as('setIsTeamsitesClickedHandler'),
            updatedTeamsites: mockTeamsites,
            setUpdatedTeamsites: cy.stub().as('setUpdatedTeamsitesHandler'),
            tempTeamsites: mockTeamsites,
            setTempTeamsites: cy.stub().as('setTempTeamsitesHandler'),
            ...contextOverrides
        };

        return cy.mount(
            <I18nextProvider i18n={testI18n}>
                <CompileReportContext.Provider value={compileReportContextValue}>
                    <TeamsitesConfirmModal 
                        setIsTeamsitesChangesLoading={setIsTeamsitesChangesLoadingStub}
                    />
                </CompileReportContext.Provider>
            </I18nextProvider>
        );
    };

    describe('Basic Rendering', () => {
        it('should render the modal when isTeamsitesClicked is true', () => {
            mountComponent();

            cy.get('.ssrs-teamsites-confirm-modal').should('exist');
            cy.get('[role="dialog"]').should('be.visible');
        });

        it('should not render the modal when isTeamsitesClicked is false', () => {
            mountComponent({ isTeamsitesClicked: false });

            cy.get('.ssrs-teamsites-confirm-modal').should('not.exist');
        });

        it('should render the correct header text', () => {
            mountComponent();

            cy.contains('You are changing teamsites').should('be.visible');
        });

        it('should render the correct message content', () => {
            mountComponent();

            cy.contains("This may change your report's applied filters and selected columns to match your new teamsite selection(s). Do you wish to proceed?")
                .should('be.visible');
        });

        it('should render Cancel and Confirm buttons', () => {
            mountComponent();

            cy.contains('button', 'Cancel').should('be.visible');
            cy.contains('button', 'Confirm').should('be.visible');
        });
    });

    describe('Cancel Button Functionality', () => {
        it('should call handleTeamsitesOnCancel when Cancel button is clicked', () => {
            mountComponent();

            cy.contains('button', 'Cancel').click();

            cy.get('@setTempTeamsitesHandler').should('have.been.calledWith', []);
            cy.get('@setIsTeamsitesClickedHandler').should('have.been.calledWith', false);
        });
    });

    describe('Confirm Button Functionality', () => {
        it('should call setIsTeamsitesChangesLoading(true) when Confirm is clicked', () => {
            mountComponent();

            cy.contains('button', 'Confirm').click();

            cy.get('@setIsTeamsitesChangesLoadingHandler').should('have.been.calledWith', true);
        });

        it('should call ReportService.updateUserSettingsGlobalTeamsites with selected teamsite IDs', () => {
            mountComponent();

            cy.contains('button', 'Confirm').click();

            cy.get('@updateUserSettingsGlobalTeamsites')
                .should('have.been.calledWith', ['teamsite-1', 'teamsite-3']);
        });

        it('should update context state after successful API call', () => {
            mountComponent();

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setUpdatedTeamsitesHandler').should('have.been.called');
                cy.get('@setTempTeamsitesHandler').should('have.been.calledWith', []);
                cy.get('@setIsTeamsitesClickedHandler').should('have.been.calledWith', false);
                cy.get('@setIsTeamsitesChangesLoadingHandler').should('have.been.calledWith', false);
            });
        });

        it('should handle API error gracefully', () => {
            cy.get('@updateUserSettingsGlobalTeamsites').then((stub) => {
                stub.rejects(new Error('API Error'));
            });

            mountComponent();

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setIsTeamsitesClickedHandler').should('have.been.calledWith', false);
                cy.get('@setIsTeamsitesChangesLoadingHandler').should('have.been.calledWith', false);
            });
        });
    });

    describe('Fields Filtering Logic', () => {
        it('should filter fields based on selected teamsites', () => {
            const fieldsWithTeamsites = [
                {
                    id: 'field-1',
                    name: 'Field 1',
                    isProperty: true,
                    propertyType: 'contentCustomProperty',
                    teamsiteIds: ['teamsite-1']
                },
                {
                    id: 'field-2',
                    name: 'Field 2',
                    isProperty: true,
                    propertyType: 'contentCustomProperty',
                    teamsiteIds: ['teamsite-999'] // Not in selected teamsites
                },
                {
                    id: 'field-3',
                    name: 'Field 3',
                    isProperty: false
                }
            ];

            mountComponent({
                updatedFields: fieldsWithTeamsites
            });

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setUpdatedFieldsHandler').should('have.been.called');
            });
        });

        it('should handle empty updatedFields', () => {
            mountComponent({
                updatedFields: []
            });

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setUpdatedFieldsHandler').should('have.been.calledWith', []);
            });
        });
    });

    describe('Filters Filtering Logic', () => {
        it('should filter filters based on selected teamsites and clear values for filterValuesByTeamsite', () => {
            const filtersWithTeamsites = [
                {
                    id: 'filter-1',
                    name: 'Filter 1',
                    isProperty: true,
                    propertyType: 'contentCustomProperty',
                    teamsiteIds: ['teamsite-1'],
                    values: ['value1', 'value2'],
                    filterValuesByTeamsite: true
                },
                {
                    id: 'filter-2',
                    name: 'Filter 2',
                    isProperty: true,
                    propertyType: 'contentCustomProperty',
                    teamsiteIds: ['teamsite-999'] // Not in selected teamsites
                },
                {
                    id: 'filter-3',
                    name: 'Filter 3',
                    isProperty: false,
                    values: ['value3']
                }
            ];

            mountComponent({
                updatedFilters: filtersWithTeamsites
            });

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setUpdatedFiltersHandler').should('have.been.called');
            });
        });

        it('should handle empty updatedFilters', () => {
            mountComponent({
                updatedFilters: []
            });

            cy.contains('button', 'Confirm').click();

            cy.wait(100).then(() => {
                cy.get('@setUpdatedFiltersHandler').should('have.been.calledWith', []);
            });
        });
    });

    describe('Teamsite Selection Logic', () => {
        it('should correctly identify selected teamsites', () => {
            const customTeamsites = [
                { id: 'ts-1', isSelected: true },
                { id: 'ts-2', isSelected: false },
                { id: 'ts-3', isSelected: true }
            ];

            mountComponent({
                tempTeamsites: customTeamsites
            });

            cy.contains('button', 'Confirm').click();

            cy.get('@updateUserSettingsGlobalTeamsites')
                .should('have.been.calledWith', ['ts-1', 'ts-3']);
        });

        it('should handle empty tempTeamsites array', () => {
            mountComponent({
                tempTeamsites: []
            });

            cy.contains('button', 'Confirm').click();

            cy.get('@updateUserSettingsGlobalTeamsites')
                .should('have.been.calledWith', []);
        });

        it('should handle tempTeamsites with no selected items', () => {
            const unselectedTeamsites = [
                { id: 'ts-1', isSelected: false },
                { id: 'ts-2', isSelected: false }
            ];

            mountComponent({
                tempTeamsites: unselectedTeamsites
            });

            cy.contains('button', 'Confirm').click();

            cy.get('@updateUserSettingsGlobalTeamsites')
                .should('have.been.calledWith', []);
        });
    });

    describe('Modal Close Functionality', () => {
        it('should call setIsTeamsitesClicked(false) when modal is closed via onClose', () => {
            mountComponent();

            // Simulate modal close (ESC key)
            cy.get('[role="dialog"]').type('{esc}');

            cy.get('@setIsTeamsitesClickedHandler').should('have.been.calledWith', false);
        });
    });
});
