import React from 'react';
import Teamsites from '../../../../src/app/components/Teamsites';
import { CompileReportContextWrapper } from '../../../support/CompileReportContextWrapper';

describe('Teamsites Component', () => {
    const mockTeamsites = [
        { id: 1, name: 'Teamsite Alpha', isSelected: true },
        { id: 2, name: 'Teamsite Beta', isSelected: false },
        { id: 3, name: 'Teamsite Gamma', isSelected: true },
        { id: 4, name: 'Teamsite Delta', isSelected: false },
        { id: 5, name: 'Teamsite Epsilon', isSelected: false }
    ];

    beforeEach(() => {
        window.React = React;
        const mockCompileReportContext = {
                updatedTeamsites: mockTeamsites,
                setIsTeamsitesClicked: cy.stub().as('setIsTeamsitesClickedStub'),
                setTempTeamsites: cy.stub().as('setTempTeamsitesStub'),
                tempTeamsites: []
            };

            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                >
                    <Teamsites />
                </CompileReportContextWrapper>
            );
    });

    describe('Basic Rendering', () => {

        it('should render the multi-select component', () => {
            cy.get('.ssrs-teamsites-select')
                .should('exist')
                .and('have.class', 'trk_select_ssrs_teamsites_edit_report');
        });

        it('should display correct selected count in label', () => {
            cy.get('.ssrs-teamsites-selected-count-text')
                .should('contain.text', '2');// 2 selected teamsites in mock data
        });

        it('should display "Teamsites selected" text', () => {
            cy.get('.ssrs-teamsites-label')
                .should('contain.text', 'Teamsites selected');
        });

        it('should be searchable and multi-select', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('ul[aria-labelledby="Select teamsites"]')
                .should('have.attr', 'aria-multiselectable', 'true');
        });
    });

    describe('Dropdown Interaction', () => {

        it('should open dropdown when clicked', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="listbox"]').should('be.visible');
        });

        it('should display all teamsite options', () => {
            cy.get('.ssrs-teamsites-select').click();

            mockTeamsites.forEach(teamsite => {
                cy.get('[role="listbox"]')
                    .should('contain.text', teamsite.name);
            });
        });

        it('should show selected teamsites as checked', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"][aria-checked="true"]')
                .should('have.length', 2);

            cy.get('[role="checkbox"]')
                .contains('Teamsite Alpha')
                .should('have.attr', 'aria-checked', 'true');

            cy.get('[role="checkbox"]')
                .contains('Teamsite Gamma')
                .should('have.attr', 'aria-checked', 'true');
        });

        it('should show unselected teamsites as unchecked', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Beta')
                .should('have.attr', 'aria-checked', 'false');

            cy.get('[role="checkbox"]')
                .contains('Teamsite Delta')
                .should('have.attr', 'aria-checked', 'false');
        });
    });

    describe('Selection Management', () => {

        it('should update selection when teamsite is clicked', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Beta')
                .click();

            cy.get('.ssrs-teamsites-selected-count-text')
                .should('contain.text', '3');
        });

        it('should deselect when selected teamsite is clicked', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Alpha')
                .click();

            cy.get('.ssrs-teamsites-selected-count-text')
                .should('contain.text', '1');
        });

        it('should update aria-checked state when selection changes', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Beta')
                .click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Beta')
                .should('have.attr', 'aria-checked', 'true');
        });
    });

    describe('Search Functionality', () => {

        it('should filter options when searching', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="listbox"]').should('be.visible');
            cy.get('.ssrs-teamsites-select').within(() => {
                cy.get('input[type="text"]').type('Alpha');
            });

            cy.get('[role="listbox"]')
                .should('contain.text', 'Teamsite Alpha')
                .and('not.contain.text', 'Teamsite Beta');
        });

        it('should show no results when search doesn\'t match', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="listbox"]').should('be.visible');

            cy.get('.ssrs-teamsites-select').within(() => {
                cy.get('input[type="text"]').type('NonexistentTeamsite');
            });

            cy.get('[role="listbox"]')
               .find('li')
               .should('have.length', 0);
        });

        it('should clear search and show all options when search is cleared', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="listbox"]').should('be.visible');

            cy.get('.ssrs-teamsites-select').within(() => {
                cy.get('input[type="text"]').type('Alpha');
            });
            cy.get('[role="listbox"]').should('contain.text', 'Teamsite Alpha');

            cy.get('.ssrs-teamsites-select').within(() => {
                cy.get('input[type="text"]').clear();
            });

            mockTeamsites.forEach(teamsite => {
                cy.get('[role="listbox"]')
                    .should('contain.text', teamsite.name);
            });
        });

        it('should handle keyboard navigation in search', () => {
            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="listbox"]').should('be.visible');

            cy.get('.ssrs-teamsites-select').within(() => {
                cy.get('input[type="text"]')
                    .type('Team')
                    .should('have.value', 'Team');
            });

            cy.get('[role="listbox"]').should('contain.text', 'Teamsite');
        });
    });

    describe('Save Functionality', () => {

        it('should trigger save when dropdown is closed after changes', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]')
                .contains('Teamsite Beta')
                .click();

            cy.get('body').click({ force: true });

            cy.get('@setIsTeamsitesClickedStub').should('have.been.calledWith', true);
            cy.get('@setTempTeamsitesStub').should('have.been.called');
        });

        it('should not trigger save when no changes are made', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('body').click({ force: true });

            cy.get('@setIsTeamsitesClickedStub').should('not.have.been.called');
            cy.get('@setTempTeamsitesStub').should('not.have.been.called');
        });

        it('should save updated teamsites with correct selection state', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]').contains('Teamsite Beta').click();
            cy.get('[role="checkbox"]').contains('Teamsite Alpha').click();

            cy.get('body').click({ force: true });

            cy.get('@setTempTeamsitesStub').should('have.been.called');
            cy.get('@setTempTeamsitesStub').then((stub) => {
                const savedTeamsites = stub.getCall(0).args[0];

                const alpha = savedTeamsites.find(t => t.name === 'Teamsite Alpha');
                const beta = savedTeamsites.find(t => t.name === 'Teamsite Beta');

                expect(alpha.isSelected).to.be.false;
                expect(beta.isSelected).to.be.true;
            });
        });
    });

    describe('Disabled State Management', () => {
        it('should enable all options when multiple teamsites are selected', () => {
            cy.get('.ssrs-teamsites-select').click();

            cy.get('[role="checkbox"]').each(($checkbox) => {
                cy.wrap($checkbox).should('not.have.attr', 'aria-disabled');
            });
        });
    });

    describe('Performance', () => {
        it('should not cause unnecessary re-renders on selection change', () => {
            const renderSpy = cy.spy().as('renderSpy');

            const mockCompileReportContext = {
                updatedTeamsites: mockTeamsites,
                setIsTeamsitesClicked: cy.stub().as('setIsTeamsitesClickedStub'),
                setTempTeamsites: cy.stub().as('setTempTeamsitesStub'),
                tempTeamsites: []
            };

            const TestWrapper = () => {
                renderSpy();
                return (
                    <CompileReportContextWrapper
                        compileReportContextValue={mockCompileReportContext}
                    >
                        <Teamsites />
                    </CompileReportContextWrapper>
                );
            };

            cy.mount(<TestWrapper />);

            cy.get('@renderSpy').should('have.been.calledOnce');

            cy.get('.ssrs-teamsites-select').click();
            cy.get('[role="checkbox"]').contains('Teamsite Beta').click();

            cy.get('@renderSpy').its('callCount').should('be.lessThan', 5);
        });
    });

});