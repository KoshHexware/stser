import React from 'react';
import { I18nextProvider } from 'react-i18next';
import NoAccess from '../../../../src/app/components/NoAccess/NoAccess';
import testI18n from '../../../support/i18n-setup';

describe('NoAccess Component', () => {
    beforeEach(() => {
        window.React = React;
    });

    describe('Basic Rendering', () => {
        it('should render the no access component with correct structure', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view').should('exist');
            cy.get('.no-access').should('exist');

            cy.get('.no-access-state-view-icon').should('exist');

            cy.get('.no-access-state-view-message').should('exist');
        });

        it('should be visible when rendered', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view').should('be.visible');
            cy.get('.no-access-state-view-icon').should('be.visible');
            cy.get('.no-access-state-view-message').should('be.visible');
        });
    });

    describe('Message Content', () => {
        it('should display the correct default message', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view-message')
                .should('contain.text', 'To view this page you need access from your administrator.');
        });

        it('should use translation key for message content', () => {
            const i18n = require('i18next');
            const { initReactI18next } = require('react-i18next');

            const customI18n = i18n.createInstance();
            customI18n
                .use(initReactI18next)
                .init({
                    lng: 'en',
                    fallbackLng: 'en',
                    resources: {
                        en: {
                            translation: {
                                'self_service_reports_no_access': 'Custom no access message for testing'
                            }
                        }
                    },
                    interpolation: {
                        escapeValue: false
                    }
                });

            cy.mount(
                <I18nextProvider i18n={customI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view-message')
                .should('contain.text', 'Custom no access message for testing');
        });

        it('should fall back to default text when translation is missing', () => {
            const emptyI18n = testI18n.cloneInstance({ resources: {} });

            cy.mount(
                <I18nextProvider i18n={emptyI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view-message')
                .should('contain.text', 'To view this page you need access from your administrator.');
        });

        it('should handle different languages', () => {
            const i18n = require('i18next');
            const { initReactI18next } = require('react-i18next');

            const spanishI18n = i18n.createInstance();
            spanishI18n
                .use(initReactI18next)
                .init({
                    lng: 'es',
                    fallbackLng: 'en',
                    resources: {
                        es: {
                            translation: {
                                'self_service_reports_no_access': 'Para ver esta página necesitas acceso de tu administrador.'
                            }
                        }
                    },
                    interpolation: {
                        escapeValue: false
                    }
                });

            cy.mount(
                <I18nextProvider i18n={spanishI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view-message')
                .should('contain.text', 'Para ver esta página necesitas acceso de tu administrador.');
        });
    });

    describe('Accessibility', () => {
        it('should be accessible to screen readers', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view-message')
                .should('be.visible')
                .and('not.have.attr', 'aria-hidden', 'true');

            cy.get('.no-access-state-view')
                .should('not.have.attr', 'aria-hidden', 'true');
        });

    });


    describe('Error Handling', () => {
        it('should handle missing i18n provider', () => {
            cy.mount(<NoAccess />);

            cy.get('.no-access-state-view').should('exist');
            cy.get('.no-access-state-view-message').should('exist');
        });
    });

    describe('Performance', () => {
        it('should render quickly without delays', () => {
            const startTime = Date.now();

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(1000); // Should render within 1 second
            });
        });

        it('should not cause memory leaks on unmount', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <NoAccess />
                </I18nextProvider>
            );

            cy.get('.no-access-state-view').should('exist');

            cy.mount(<div>Replacement content</div>);

            cy.get('.no-access-state-view').should('not.exist');
        });
    });
});