import React from "react";
import { FullScreenLoading } from "../../../../src/app/components/common/FullScreenLoading";

describe("Testing FullScreenLoading", () => {
  it("renders with loading true", () => {
    cy.mount(<FullScreenLoading loading={true} />);
    cy.get(".ssrs-scorecard-loader").should("exist");
  });
  it("renders with loading false", () => {
    cy.mount(<FullScreenLoading loading={false} />);
    cy.get(".ssrs-scorecard-loader").should("not.exist");
  });
});
