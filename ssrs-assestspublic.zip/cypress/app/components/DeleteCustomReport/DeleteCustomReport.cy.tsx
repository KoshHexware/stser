import React from 'react';
import { Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import { I18nextProvider } from 'react-i18next';
import { DeleteCustomReport } from '../../../../src/app/components/DeleteCustomReport';
import ReportService from '../../../../src/services/ReportService';
import { CompileReportContextWrapper } from '../../../support/CompileReportContextWrapper';
import testI18n from '../../../support/i18n-setup';

describe('DeleteCustomReport Component', () => {
    let history;

    beforeEach(() => {
        window.React = React;
        history = createMemoryHistory();
    });

    afterEach(() => {
        if (ReportService.deleteReportById?.restore) {
            ReportService.deleteReportById.restore();
        }
    });

    describe('Modal Display and Behavior', () => {
        it('should render modal when deleteCustomReport is true', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-modal').should('exist');
            cy.get('[role="dialog"]').should('be.visible');

            cy.get('h4').should('contain.text', 'Delete');
            cy.get('h4').should('contain.text', 'Test Custom Report');
            cy.get('h4').should('contain.text', '?');

            cy.get('[role="dialog"]').should('have.attr', 'aria-label', 'Custom report delete modal');

            cy.get('section').should('contain.text', 'Deleting will permenently remove this custom report');

            cy.get('.delete-custom-report-go-back').should('contain.text', 'Go back');
            cy.get('.delete-custom-report-delete').should('contain.text', 'Delete');
        });

        it('should not render modal when deleteCustomReport is false', () => {
            const mockProps = {
                deleteCustomReport: false,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('[data-testid="modal"]').should('not.exist');
            cy.get('[role="dialog"]').should('not.exist');
        });
    });

    describe('Go Back Functionality', () => {
        it('should call setDeleteCustomReport(false) when Go Back button is clicked', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-go-back').click();
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
        });

        it('should call setDeleteCustomReport(false) when modal is closed via onClose', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('button[aria-label="Close"]').click();
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
        });
    });

    describe('Delete Functionality - Using reportId prop', () => {
        it('should successfully delete report using provided reportId', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.stub(ReportService, 'deleteReportById')
                .resolves({ success: true })
                .as('deleteReportByIdStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'test-report-123');

            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
            cy.get('@onDeletedStub').should('have.been.called');
        });

        it('should handle deletion errors when using reportId', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            const deleteError = new Error('Failed to delete report');
            deleteError.status = 500;

            cy.stub(ReportService, 'deleteReportById')
                .rejects(deleteError)
                .as('deleteReportByIdStub');

            cy.stub(console, 'error').as('consoleErrorStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'test-report-123');

        });
    });

    describe('Delete Functionality - Using selectedReport', () => {
        it('should successfully delete report using selectedReport.id when reportId is not provided', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Selected Custom Report',
                reportId: undefined, // No reportId provided
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.stub(ReportService, 'deleteReportById')
                .resolves({ success: true })
                .as('deleteReportByIdStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'selected-report-456');

            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
            cy.get('@onDeletedStub').should('have.been.called');
        });

        it('should prioritize reportId prop over selectedReport.id', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'priority-report-789', // This should be used
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.stub(ReportService, 'deleteReportById')
                .resolves({ success: true })
                .as('deleteReportByIdStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'priority-report-789');
            cy.get('@deleteReportByIdStub').should('not.have.been.calledWith', 'selected-report-456');
        });
    });

    describe('Accessibility', () => {
        it('should have proper ARIA attributes', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Accessibility Test Report',
                reportId: 'a11y-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('[role="dialog"]').should('have.attr', 'aria-label', 'Custom report delete modal');

            cy.get('.delete-custom-report-go-back').should('be.visible').and('not.be.disabled');
            cy.get('.delete-custom-report-delete').should('be.visible').and('not.be.disabled');

            cy.get('h4').should('be.visible');
        });
    });

    describe('Delete Functionality - Navigation Logic', () => {
        it('should navigate to /selfservicereports when isViewReportMode is true', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'VIEW_REPORT',
                isViewReportMode: true // This enables the navigation logic
            };

            cy.stub(ReportService, 'deleteReportById')
                .resolves({ success: true })
                .as('deleteReportByIdStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );
            const initialPath = history.location.pathname;
            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'test-report-123');
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);

            // history.push('/selfservicereports');
            // cy.then(() => {
            //     expect(history.location.pathname).to.equal('/selfservicereports');
            // });

            cy.then(() => {
                expect(history.location.pathname).to.equal('/selfservicereports');
            });

            // onDeleted should not be called when navigating
            cy.get('@onDeletedStub').should('not.have.been.called');
        });

        it('should call onDeleted callback when isViewReportMode is false', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST',
                isViewReportMode: false // This disables navigation, uses callback instead
            };

            cy.stub(ReportService, 'deleteReportById')
                .resolves({ success: true })
                .as('deleteReportByIdStub');

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            const initialPath = history.location.pathname;

            cy.get('.delete-custom-report-delete').click();

            cy.get('@deleteReportByIdStub').should('have.been.calledWith', 'test-report-123');
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
            cy.get('@onDeletedStub').should('have.been.called');

            // Verify no navigation occurred
            cy.then(() => {
                expect(history.location.pathname).to.equal(initialPath);
            });
        });


    });

    describe('Go Back Functionality', () => {
        it('should call setDeleteCustomReport(false) when Go Back button is clicked', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('.delete-custom-report-go-back').click();
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
            cy.get('@setDeleteCustomReportStub').should('have.been.calledOnce');
        });

        it('should call setDeleteCustomReport(false) when modal is closed via onClose', () => {
            const mockProps = {
                deleteCustomReport: true,
                setDeleteCustomReport: cy.stub().as('setDeleteCustomReportStub'),
                customReportTitle: 'Test Custom Report',
                reportId: 'test-report-123',
                onDeleted: cy.stub().as('onDeletedStub')
            };

            const mockReportDataContext = {
                selectedReport: { id: 'selected-report-456', name: 'Selected Report' }
            };

            const mockAllReportsContext = {
                lastScreen: 'REPORTS_LIST'
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <Router history={history}>
                        <CompileReportContextWrapper
                            allReportsLandingPageContextValue={mockAllReportsContext}
                            reportDataContextValue={mockReportDataContext}
                        >
                            <DeleteCustomReport {...mockProps} />
                        </CompileReportContextWrapper>
                    </Router>
                </I18nextProvider>
            );

            cy.get('button[aria-label="Close"]').click();
            cy.get('@setDeleteCustomReportStub').should('have.been.calledWith', false);
            cy.get('@setDeleteCustomReportStub').should('have.been.calledOnce');
        });
    });
});