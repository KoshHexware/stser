import React from 'react';
import { Route, Router } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import CreateReport from '../../../../src/app/components/CreateReport';
import ReportService from '../../../../src/services/ReportService';
import { CompileReportContextWrapper } from '../../../support/CompileReportContextWrapper';
import testI18n from '../../../support/i18n-setup';
import { I18nextProvider } from 'react-i18next';
import { Screens } from '../../../../src/contexts/types';
import * as CommonServicesContext from '../../../../src/contexts/CommonServicesContext';
import * as auraPanelEvents from '../../../../src/auraPanelEvents';

describe('CreateReport Component', () => {
  let history;
  let mockAllReportsContext;
  let mockReportDataContext;
  let mockCompileReportContext;

  const createMockContexts = (
    overrides: {
      reportDataOverrides?: any;
      allReportsOverrides?: any;
      compileReportOverrides?: any;
    } = {}
  ) => {
    const {
      reportDataOverrides = {},
      allReportsOverrides = {},
      compileReportOverrides = {},
    } = overrides;

    return {
      allReports: {
        setHideEditButtonOnError: cy.stub().as('setHideEditButtonOnError'),
        setIsCompileReportMode: cy.stub().as('setIsCompileReportMode'),
        setCurrentScreen: cy.stub().as('setCurrentScreen'),
        setEnableSaveCopy: cy.stub().as('setEnableSaveCopy'),
        setReportData: cy.stub().as('setReportData'),
        setPagination: cy.stub().as('setPagination'),
        ...allReportsOverrides,
      },
      reportData: {
        setSelectedReport: cy.stub().as('setSelectedReport'),
        lastScreen: null,
        setReportMetadata: cy.stub().as('setReportMetadata'),
        reportMetadata: null,
        selectedReport: null,
        setShowReportSavedToast: cy.stub().as('setShowReportSavedToast'),
        ...reportDataOverrides,
      },
      compileReport: {
        updatedFields: [],
        updatedFilters: [],
        updatedTeamsites: [],
        setIsCompileReportMode: cy.stub(),
        ...compileReportOverrides,
      },
    };
  };

  const mountComponent = (reportId, contexts = null) => {
    const { allReports, reportData, compileReport } = contexts || {
      allReports: mockAllReportsContext,
      reportData: mockReportDataContext,
      compileReport: mockCompileReportContext,
    };

    if (reportId) {
      history.push(
        `/selfservicereports/report/${reportId}`
      );
    }

    return cy.mount(
      <Router history={history}>
        <I18nextProvider i18n={testI18n}>
          <CompileReportContextWrapper
            allReportsLandingPageContextValue={allReports}
            reportDataContextValue={reportData}
            compileReportContextValue={compileReport}
          >
            <Route path='/selfservicereports/report/:id'>
              <CreateReport />
            </Route>
          </CompileReportContextWrapper>
        </I18nextProvider>
      </Router>
    );
  };

  const createReportMetadata = (overrides = {}) => ({
    id: 'test-report-123',
    reportName: 'Test Report',
    reportType: 'custom',
    ...overrides,
  });

  const setupServiceStubs = (
    getMetadataResponse,
    createResponse = null,
    updateResponse = null
  ) => {
    if (getMetadataResponse instanceof Error) {
      cy.stub(ReportService, 'getReportMetaData')
        .rejects(getMetadataResponse)
        .as('getReportMetaData');
      
      cy.stub(ReportService, 'getReportDataWithDefaults')
        .rejects(getMetadataResponse)
        .as('getReportDataWithDefaults');
    } else if (getMetadataResponse === 'never-resolves') {
      cy.stub(ReportService, 'getReportMetaData')
        .callsFake(() => new Promise(() => {}))
        .as('getReportMetaData');
      
      cy.stub(ReportService, 'getReportDataWithDefaults')
        .callsFake(() => new Promise(() => {}))
        .as('getReportDataWithDefaults');
    } else {
      cy.stub(ReportService, 'getReportMetaData')
        .resolves(getMetadataResponse)
        .as('getReportMetaData');
      
      cy.stub(ReportService, 'getReportDataWithDefaults')
        .resolves({ data: [], pagination: {}, report: getMetadataResponse })
        .as('getReportDataWithDefaults');
    }

    if (createResponse) {
      if (createResponse instanceof Error) {
        cy.stub(ReportService, 'createCustomReport')
          .rejects(createResponse)
          .as('createCustomReport');
      } else {
        cy.stub(ReportService, 'createCustomReport')
          .resolves(createResponse)
          .as('createCustomReport');
      }
    }

    if (updateResponse) {
      if (updateResponse instanceof Error) {
        cy.stub(ReportService, 'updateCustomReport')
          .rejects(updateResponse)
          .as('updateCustomReport');
      } else {
        cy.stub(ReportService, 'updateCustomReport')
          .resolves(updateResponse)
          .as('updateCustomReport');
      }
    }
  };

  beforeEach(() => {
    // Mock useAccessLevel hook
    cy.stub(CommonServicesContext, 'useAccessLevel').returns({
      canEditReport: true,
      canCreateReport: true,
      canViewReport: true
    });

    // Mock triggerAuraPanelAction function
    cy.stub(auraPanelEvents, 'triggerAuraPanelAction').as('triggerAuraPanelAction');
    
    window.React = React;
    history = createMemoryHistory();

    const contexts = createMockContexts();
    mockAllReportsContext = contexts.allReports;
    mockReportDataContext = contexts.reportData;
    mockCompileReportContext = contexts.compileReport;
  });

  describe('Permission Error Handling (403)', () => {
    it('should handle 403 error and display ErrorBoundary', () => {
      const error403 = new Error('Forbidden');
      error403.httpRequestInfo = { statusCode: 403 };

      setupServiceStubs(error403);
      mountComponent('forbidden-report-123');
      
      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@getReportDataWithDefaults').should(
          'have.been.calledWith',
          'forbidden-report-123'
        );
        cy.get('@setHideEditButtonOnError').should(
          'have.been.calledWith',
          true
        );
      });
    });
  });

  describe('Loading States', () => {
    it('should display loading modal when fetching report metadata', () => {
      setupServiceStubs('never-resolves');
      mountComponent('test-report-123');

      cy.wait(100).then(() => {
        cy.get('.compile-report-container').should('exist');
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
      });
    });
  });

  describe('System Report Detection Logic', () => {
    const systemReportMetadata = createReportMetadata({
      id: 'system-report-123',
      reportName: 'System Report',
      reportType: 'system',
      systemReportName: 'System Report Name',
    });

    it('should NOT set isEditStandardReport when selectedReport ID matches and system report', () => {
      const systemReportMetadata = createReportMetadata({
        id: 'system-report-123',
        reportName: 'System Report',
        reportType: 'system',
        systemReportName: 'System Report Name',
        // Add fields needed by the component to prevent TypeError
        filterGroup: {
          filters: []
        },
        fields: []
      });

      const contexts = createMockContexts({
        reportDataOverrides: {
          reportMetadata: systemReportMetadata,
          selectedReport: { id: 'system-report-123' },
        },
      });

      cy.stub(ReportService, 'getReportDataWithDefaults').as('getReportDataWithDefaults');
      mountComponent('system-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Change the assertion - when IDs match, the method should NOT be called
        cy.get('@getReportDataWithDefaults').should('not.have.been.called');
      });
    });

    it('should set isEditStandardReport to true for system report when conditions allow', () => {
      setupServiceStubs(systemReportMetadata);
      mountComponent('system-report-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@setSelectedReport').should('have.been.called');
        cy.get('@setReportMetadata').should('have.been.called');
      });
    });

    ['SYSTEM', 'System'].forEach((reportType) => {
      it(`should handle system report type case insensitively (${reportType})`, () => {
        const metadata = createReportMetadata({
          id: 'system-report-123',
          reportType,
          systemReportName: 'System Report Name',
        });

        setupServiceStubs(metadata);
        mountComponent('system-report-123');

        cy.wait(100).then(() => {
          cy.get('@setCurrentScreen').should(
            'have.been.calledWith',
            Screens.EDIT_REPORT
          );
          // Update this to check for getReportDataWithDefaults
          cy.get('@getReportDataWithDefaults').should('have.been.called');
        });
      });
    });
  });

  describe('Context Path Branch Coverage', () => {
    it('should use existing metadata when ID matches but selectedReport is null', () => {
      const existingMetadata = createReportMetadata();
      const contexts = createMockContexts({
        reportDataOverrides: {
          reportMetadata: existingMetadata,
          selectedReport: null,
        },
      });

      cy.stub(ReportService, 'getReportDataWithDefaults').as('getReportDataWithDefaults');
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@getReportDataWithDefaults').should('not.have.been.called');
        cy.get('@setSelectedReport').should('have.been.called');
      });
    });

    it('should handle selectedReport exists but metadata ID mismatch', () => {
      const contexts = createMockContexts({
        reportDataOverrides: {
          reportMetadata: createReportMetadata({ id: 'different-report-456' }),
          selectedReport: { id: 'selected-report-789' },
        },
      });

      setupServiceStubs(createReportMetadata());
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should(
          'have.been.calledWith',
          'test-report-123'
        );
      });
    });

    it('should handle else-if branch when selectedReport exists and metadata matches', () => {
      const metadata = createReportMetadata();
      const contexts = createMockContexts({
        reportDataOverrides: {
          reportMetadata: metadata,
          selectedReport: { id: 'test-report-123' },
        },
      });

      cy.stub(ReportService, 'getReportDataWithDefaults').as('getReportDataWithDefaults');
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@getReportDataWithDefaults').should('not.have.been.called');
      });
    });
  });

  describe('Error Handling Coverage', () => {
    const testCases = [
      {
        name: 'createCustomReport error with title',
        setupStubs: () => {
          const error = new Error('Failed to create report');
          error.title = 'Creation Failed';
          setupServiceStubs(
            createReportMetadata({ reportType: 'system' }),
            error
          );
        },
      },
      {
        name: 'updateCustomReport error with title',
        setupStubs: () => {
          const error = new Error('Failed to update report');
          error.title = 'Update Failed';
          setupServiceStubs(createReportMetadata(), null, error);
        },
      },
      {
        name: 'error without title property',
        setupStubs: () => {
          setupServiceStubs(new Error('Error without title'));
        },
      },
    ];

    testCases.forEach(({ name, setupStubs }) => {
      it(`should handle ${name}`, () => {
        setupStubs();
        mountComponent('test-report-123');

        cy.wait(100).then(() => {
          cy.get('@setCurrentScreen').should(
            'have.been.calledWith',
            Screens.EDIT_REPORT
          );
          if (name.includes('error without title')) {
            cy.get('@setHideEditButtonOnError').should(
              'have.been.calledWith',
              true
            );
          } else {
            // Update this to check for getReportDataWithDefaults
            cy.get('@getReportDataWithDefaults').should('have.been.called');
          }
        });
      });
    });
  });

  describe('onClose Function Coverage', () => {
    it('should clear context when lastScreen is not VIEW_REPORT', () => {
      const contexts = createMockContexts({
        reportDataOverrides: { lastScreen: Screens.ALL_REPORTS },
      });

      setupServiceStubs(createReportMetadata());
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });

    it('should NOT clear context when lastScreen is VIEW_REPORT', () => {
      const contexts = createMockContexts({
        reportDataOverrides: { lastScreen: Screens.VIEW_REPORT },
      });

      setupServiceStubs(createReportMetadata());
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });

    it('should handle null lastScreen', () => {
      const contexts = createMockContexts({
        reportDataOverrides: { lastScreen: null },
      });

      setupServiceStubs(createReportMetadata());
      mountComponent('test-report-123', contexts);

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });
  });

  describe('Edge Cases and Additional Coverage', () => {
    it('should handle null fetchedReportMetadata gracefully', () => {
      setupServiceStubs(null);
      mountComponent('null-report-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
        cy.get('.compile-report-container').should('not.exist');
      });
    });

    it('should handle component with all properties in updateSelectedReport', () => {
      const completeMetadata = createReportMetadata({
        id: 'complete-report-123',
        systemReportName: 'System Name',
        description: 'Report description',
        ownerUserId: 'user123',
      });

      setupServiceStubs(completeMetadata);
      mountComponent('complete-report-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@setSelectedReport').should('have.been.calledWith', {
          reportName: completeMetadata.reportName,
          id: 'complete-report-123',
          reportType: completeMetadata.reportType,
          systemReportName: completeMetadata.systemReportName,
          description: completeMetadata.description,
          ownerUserId: completeMetadata.ownerUserId,
        });
      });
    });
  });

  describe('Error Throwing useEffect Coverage', () => {
    it('should throw error when isError state is set', () => {
      setupServiceStubs(new Error('Test error for throwing'));
      mountComponent('error-report-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@setHideEditButtonOnError').should(
          'have.been.calledWith',
          true
        );
      });
    });
  });

  describe('Complete Workflow Coverage', () => {
    const workflowTestCases = [
      {
        name: 'system report editing workflow',
        metadata: createReportMetadata({
          id: 'system-report-123',
          reportType: 'system',
          systemReportName: 'System Report Name',
          description: 'System report description',
          ownerUserId: null,
        }),
        reportId: 'system-report-123',
      },
      {
        name: 'custom report editing workflow',
        metadata: createReportMetadata({
          id: 'custom-report-123',
          reportType: 'custom',
          systemReportName: null,
          description: 'Custom report description',
          ownerUserId: 'user123',
        }),
        reportId: 'custom-report-123',
      },
    ];

    workflowTestCases.forEach(({ name, metadata, reportId }) => {
      it(`should handle complete ${name}`, () => {
        setupServiceStubs(metadata);
        mountComponent(reportId);

        cy.wait(100).then(() => {
          cy.get('@setCurrentScreen').should(
            'have.been.calledWith',
            Screens.EDIT_REPORT
          );
          // Update this to check for getReportDataWithDefaults
          cy.get('@getReportDataWithDefaults').should(
            'have.been.calledWith',
            reportId
          );
          cy.get('@setSelectedReport').should('have.been.called');
          cy.get('@setReportMetadata').should('have.been.called');
        });
      });
    });
  });

  describe('Component Integration Tests', () => {
    it('should test createOrUpdateReport function for creating new report', () => {
      const systemMetadata = createReportMetadata({
        id: 'system-123',
        reportType: 'system',
      });

      setupServiceStubs(systemMetadata, {
        id: 'new-report-456',
        reportName: 'New Report',
      });
      mountComponent('system-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });

    it('should test createOrUpdateReport function for updating existing report', () => {
      const customMetadata = createReportMetadata({
        id: 'custom-123',
        reportType: 'custom',
      });

      setupServiceStubs(customMetadata, null, {
        id: 'custom-123',
        reportName: 'Updated Report',
      });
      mountComponent('custom-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });
  });

  describe('Function Coverage Tests', () => {
    it('should test resetFlashErrorMessage function', () => {
      const metadata = createReportMetadata();
      setupServiceStubs(metadata);

      // Mount component and trigger error first
      mountComponent('test-report-123');

      cy.wait(100).then(() => {
        // The component should have mounted successfully
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
      });
    });
  });

  describe('Async Operations Coverage', () => {
    it('should test promise rejection handling', () => {
      const promiseError = new Error('Promise rejection');
      promiseError.title = 'Promise Error';

      setupServiceStubs(promiseError);
      mountComponent('promise-test-123');

      cy.wait(100).then(() => {
        cy.get('@setHideEditButtonOnError').should(
          'have.been.calledWith',
          true
        );
      });
    });

    it('should test finally block execution', () => {
      setupServiceStubs(createReportMetadata());
      mountComponent('finally-test-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should(
          'have.been.calledWith',
          Screens.EDIT_REPORT
        );
        cy.get('@setSelectedReport').should('have.been.called');
      });
    });
  });

  describe('Component Lifecycle Coverage', () => {
    it('should test multiple useEffect dependencies', () => {
      const metadata = createReportMetadata({
        id: 'effect-test-123',
        reportType: 'system',
      });

      setupServiceStubs(metadata);
      mountComponent('effect-test-123');

      cy.wait(100).then(() => {
        cy.get('@setCurrentScreen').should('have.been.called');
        // Update this to check for getReportDataWithDefaults
        cy.get('@getReportDataWithDefaults').should('have.been.called');
      });
    });
  });
});
