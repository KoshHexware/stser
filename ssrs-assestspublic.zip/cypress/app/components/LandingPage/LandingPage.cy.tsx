import React from 'react';
import LandingPage from '../../../../src/app/components/App/LandingPage';
import ReportService from '../../../../src/services/ReportService';
import MyReports from '../../../fixtures/MyReports.json';
import { AURA_CHAT_EVENTS } from '../../../../src/auraPanelEvents/types/AuraChatEventTypes';
import { instance, EventService } from 'seismic-common';
import { ClientContextSubType, ClientContextTriggerType, ClientContextType } from '../../../../src/auraPanelEvents/types/SSRContextTypes';

describe('Testing LandingPage', () => {
  beforeEach(() => {
    // Stub the service method once before all tests
    // Ensure `process` exists in the browser test environment
    if (typeof (window as any).process === 'undefined') {
      (window as any).process = { env: {} };
    }
    cy.stub(ReportService, 'getReports')
      .callsFake((page, pageSize, reportType, searchTerm) => {
        if (searchTerm === 'empty') {
          return Promise.resolve({ data: [], totalRecords: 0 });
        } else {
          return Promise.resolve(MyReports);
        }
      })
      .as('getReports');

    // Mount component once in beforeEach to avoid repetition
    cy.mount(<LandingPage />);
  });

  it('Should render the ReportsList with correct data', () => {
    // Check column headers
    ['Name', 'Owner', 'Last viewed'].forEach((header) => {
      cy.contains(header).should('exist');
    });

    // Check report data
    cy.contains('Learning report').should('exist');
    cy.contains('System').should('exist');
  });

  it('Report type filter dropdown works correctly', () => {
    cy.contains('All reports').click();

    // Verify dropdown appears with all options
    const options = ['My reports', 'Standard reports', 'All reports'];
    options.forEach((option) => {
      cy.contains(option).should('exist');
    });

    // Test selection changes filter
    cy.contains('My reports').click();
    cy.contains('My reports').should('be.visible');
    cy.get('@getReports').should('have.been.called');
  });

  it('Search functionality works correctly', () => {
    const searchInput = 'input[placeholder="Search for reports"]';
    cy.get(searchInput).should('exist');

    // Test scenarios
    const searchScenarios = [
      {
        term: 'empty',
        resetHistory: true,
        expectations: [
          { element: 'No search results', shouldExist: true },
          { element: 'Learning report', shouldExist: false },
        ],
      },
      {
        term: 'Learning',
        resetHistory: true,
        expectations: [{ element: 'Learning report', shouldExist: true }],
      },
    ];

    // Run through scenarios
    searchScenarios.forEach((scenario) => {
      if (scenario.resetHistory) {
        cy.get('@getReports').invoke('resetHistory');
      }

      cy.get(searchInput).clear();
      if (scenario.term) {
        cy.get(searchInput).type(scenario.term);
      }

      // For non-empty terms, verify API call
      if (scenario.term) {
        cy.get('@getReports').should(
          'be.calledWith',
          Cypress.sinon.match.any,
          Cypress.sinon.match.any,
          Cypress.sinon.match.any,
          scenario.term
        );
      } else {
        cy.get('@getReports').should('be.called');
      }

      // Check expected UI results
      scenario.expectations.forEach((exp) => {
        cy.contains(exp.element).should(
          exp.shouldExist ? 'be.visible' : 'not.exist'
        );
      });
    });

    // Test edge cases: minimum character threshold and special characters
    cy.get('@getReports').invoke('resetHistory');
    cy.get(searchInput).clear().type('a');
    cy.get('@getReports').should('not.be.called');

    cy.get('@getReports').invoke('resetHistory');
    cy.get(searchInput).clear().type('test@123');
    cy.get('@getReports').should(
      'be.calledWith',
      Cypress.sinon.match.any,
      Cypress.sinon.match.any,
      Cypress.sinon.match.any,
      'test@123'
    );
  });

  it('Report items are clickable and navigate to detail view', () => {
    cy.contains('Learning report').click();
    cy.url().should('match', /\/selfservicereports\/report\/\d+/);
  });

  it('New report button opens modal with correct content', () => {
    cy.contains('button', 'New report').should('exist').click();

    cy.contains('Choose a standard report to start with').should('be.visible');
  });
});

describe('aura panel events', () => {
  beforeEach(() => {
    cy.stub(ReportService, 'getReports')
      .callsFake((page, pageSize, reportType, searchTerm) => {
        if (searchTerm === 'empty') {
          return Promise.resolve({ data: [], totalRecords: 0 });
        } else {
          return Promise.resolve(MyReports);
        }
      })
      .as('getReports');
  });

  it('should dispatch aura panel event on component mount with correct SSR context for landing page', () => {
    cy.window().then((win) => {
      const eventService = instance.getService(EventService);
      cy.stub(eventService, 'dispatch').callsFake((eventName, ssrContext) => {
        if (eventName === AURA_CHAT_EVENTS.EVT_SEARCH_OMNI_AURA_CHAT_UPDATE_CONTEXT) {
          (win as any).ssrContext = ssrContext;
        }
      });
    });

    cy.mount(<LandingPage />);

    cy.window().its('ssrContext').should('exist');
    cy.window().its('ssrContext').should('have.property', 'clientContext').and('include', {
      contextTriggerType: ClientContextTriggerType.PAGE_LOAD,
      contextType: ClientContextType.INSIGHTS,
      contextSubType: ClientContextSubType.SSR_LANDING_PAGE,
    });
  });
});
