import React from 'react';
import ExportReport from '../../../../src/app/components/Export';
import { CompileReportContextWrapper } from '../../../support/CompileReportContextWrapper';
import reportMetadata from '../../../fixtures/reportMetadata.json';
import UpdatedFields from '../../../fixtures/updatedFields.json';
import updatedFilters from '../../../fixtures/updatedFilters.json';
import SystemReports from '../../../fixtures/SystemReports.json';
import CustomReports from '../../../fixtures/CustomReports.json';
import ReportExporter from '../../../../src/utils/ReportExporter';

describe('ExportReport Component', () => {
    const mockCompileReportContext = {
        updatedFields: UpdatedFields,
        updatedFilters: updatedFilters,
        updatedOrderField: 'contentProfileName',
        updatedOrderBy: 'ASC_NULLS_LAST',
        updatedTeamsites: [
            { id: 1, name: 'Teamsite 1', isSelected: true },
            { id: 2, name: 'Teamsite 2', isSelected: false },
            { id: 3, name: 'Teamsite 3', isSelected: true }
        ],
        gridHiddenColumns: [],
    };

    const mockReportDataContext = {
        selectedReport: SystemReports[0],
        reportMetadata: reportMetadata,
    };

    beforeEach(() => {
        window.React = React;
    });

    describe('Basic Rendering', () => {
        beforeEach(() => {
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });

        it('should render export button with correct attributes', () => {
            cy.get('[data-testid="export-button"]')
                .should('be.visible')
                .and('have.class', 'ssrs-view-report-export')
                .and('have.class', 'trk_button_ssrs-report_view-export_report');
        });

        it('should display export icon', () => {
            cy.get('[data-testid="export-button"]')
                .find('svg')
                .should('exist');
        });

        it('should show export label by default', () => {
            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Export');
        });
    });

    describe('Export Functionality', () => {
        beforeEach(() => {
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });

        it('should trigger export when button is clicked', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.calledOnce');
        });

        it('should call export with correct parameters', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.calledOnce');

            cy.get('@exportReportStub').then((stub) => {
                const call = stub.getCall(0);
                const args = call.args;

                expect(args[0]).to.equal(SystemReports[0].id); // reportId
                expect(args[1]).to.equal(SystemReports[0].reportName); // reportName
                expect(args[2]).to.be.an('array'); // fields
                expect(args[3]).to.equal('contentProfileName'); // orderField
                expect(args[4]).to.equal('ASC_NULLS_LAST'); // orderBy
                expect(args[5]).to.be.an('array'); // filters
                expect(args[6]).to.deep.equal([1, 3]); // teamsite IDs
            });
        });

        it('should show success state after successful export', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.wait(100);

            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Report export successful');
        });

        it('should revert to default state after 3 seconds', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.wait(100);
            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Report export successful');

            cy.wait(3100);
            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Export');
        });
    });

    describe('Export Functionality - Loading State', () => {
        beforeEach(() => {
            cy.stub(ReportExporter, 'exportReport')
                .callsFake(() => new Promise(resolve => setTimeout(() => resolve('success'), 500)))
                .as('loadingExportStub');

            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });
        it('should show loading state during export', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Exporting...')
                .and('be.disabled');
        });
    });

    describe('Error Handling', () => {
        beforeEach(() => {
            cy.stub(ReportExporter, 'exportReport').resolves('error').as('errorExportStub');

            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });

        it('should show error state when export fails', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.wait(100);

            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Report export failed');
        });

        it('should revert to default state after error timeout', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.wait(100);
            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Report export failed');

            cy.wait(3100);
            cy.get('[data-testid="export-button"]')
                .should('contain.text', 'Export');
        });
    });

    describe('Hidden Columns Filtering', () => {
        beforeEach(() => {
             const contextWithHiddenColumns = {
                ...mockCompileReportContext,
                gridHiddenColumns: ['contentProfileName', 'lastModified']
            };
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');

            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={contextWithHiddenColumns}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });
        it('should filter out hidden columns from export', () => {

            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.called');
            cy.get('@exportReportStub').then((stub) => {
                const fieldsArg = stub.getCall(0).args[2];
                const fieldNames = fieldsArg.map(f => f.name);
                expect(fieldNames).to.not.include('contentProfileName');
                expect(fieldNames).to.not.include('lastModified');
            });
        });
    });

    describe('Disabled States', () => {
        it('should be disabled when no report schema exists', () => {
            const contextWithNoFields = {
                ...mockCompileReportContext,
                updatedFields: []
            };
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={contextWithNoFields}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );

            cy.get('[data-testid="export-button"]').should('be.disabled');
        });

        it('should be disabled during loading state', () => {
            cy.stub(ReportExporter, 'exportReport')
                .callsFake(() => new Promise(resolve => setTimeout(() => resolve('success'), 500)))
                .as('loadingExportStub');

            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );

            cy.get('[data-testid="export-button"]').click();
            cy.get('[data-testid="export-button"]').should('be.disabled');
        });
    });

    describe('Custom Report Export', () => {
        it('should export custom reports correctly', () => {
            const customReportContext = {
                ...mockReportDataContext,
                selectedReport: CustomReports[0]
            };

            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={customReportContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );

            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.calledWith',
                CustomReports[0].id,
                CustomReports[0].reportName,
                Cypress.sinon.match.array,
                'contentProfileName',
                'ASC_NULLS_LAST',
                updatedFilters,
                [1, 3]
            );
        });
    });

    describe('Teamsite Filtering', () => {
        it('should only export selected teamsites', () => {
            const contextWithMixedTeamsites = {
                ...mockCompileReportContext,
                updatedTeamsites: [
                    { id: 1, name: 'Teamsite 1', isSelected: true },
                    { id: 2, name: 'Teamsite 2', isSelected: false },
                    { id: 3, name: 'Teamsite 3', isSelected: true },
                    { id: 4, name: 'Teamsite 4', isSelected: false }
                ]
            };
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={contextWithMixedTeamsites}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );

            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.called');
            cy.get('@exportReportStub').then((stub) => {
                const teamsiteIds = stub.getCall(0).args[6];
                expect(teamsiteIds).to.deep.equal([1, 3]);
            });
        });

        it('should handle no selected teamsites', () => {
            const contextWithNoSelectedTeamsites = {
                ...mockCompileReportContext,
                updatedTeamsites: [
                    { id: 1, name: 'Teamsite 1', isSelected: false },
                    { id: 2, name: 'Teamsite 2', isSelected: false }
                ]
            };
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={contextWithNoSelectedTeamsites}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );

            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.called');
            cy.get('@exportReportStub').then((stub) => {
                const teamsiteIds = stub.getCall(0).args[6];
                expect(teamsiteIds).to.deep.equal([]);
            });
        });
    });

    describe('Field Mapping', () => {
        beforeEach(() => {
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');
            cy.mount(
                <CompileReportContextWrapper
                    compileReportContextValue={mockCompileReportContext}
                    reportDataContextValue={mockReportDataContext}
                >
                    <ExportReport />
                </CompileReportContextWrapper>
            );
        });
        it('should correctly map field properties for export', () => {
            cy.get('[data-testid="export-button"]').click();

            cy.get('@exportReportStub').should('have.been.called');
            cy.get('@exportReportStub').then((stub) => {
                const fields = stub.getCall(0).args[2];

                fields.forEach(field => {
                    expect(field).to.have.property('name');
                    expect(field).to.have.property('isProperty');
                    expect(field).to.have.property('propertyType');
                    expect(field).to.have.property('propertyId');
                });
            });
        });
    });

    describe('Performance', () => {
        it('should not trigger unnecessary re-renders', () => {
            const renderSpy = cy.spy().as('renderSpy');
            cy.stub(ReportExporter, 'exportReport').resolves('success').as('exportReportStub');

            const TestWrapper = () => {
                renderSpy();
                return (
                    <CompileReportContextWrapper
                        compileReportContextValue={mockCompileReportContext}
                        reportDataContextValue={mockReportDataContext}
                    >
                        <ExportReport />
                    </CompileReportContextWrapper>
                );
            };

            cy.mount(<TestWrapper />);

            // Initial render
            cy.get('@renderSpy').should('have.been.calledOnce');

            // Click should not trigger additional renders
            cy.get('[data-testid="export-button"]').click();
            cy.get('@renderSpy').should('have.been.calledOnce');
        });
    });
});