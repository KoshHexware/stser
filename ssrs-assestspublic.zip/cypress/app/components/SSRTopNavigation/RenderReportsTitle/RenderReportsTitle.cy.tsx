import React from 'react';
import { RenderReportsTitle } from '../../../../../src/app/components/SSRTopNavigation/RenderReportsTitle';
import * as i18n from 'react-i18next';
import ReportService from '../../../../../src/services/ReportService';
import { CompileReportContextWrapper } from '../../../../support/CompileReportContextWrapper';

describe('RenderReportsTitle', () => {
    // Common test data
    const mockReport = {
        id: 'report-1',
        reportName: 'Test Report',
        description: 'Test Description',
        ownerUserId: 'System',
        reportType: 'Custom',
        systemReportName: 'System Report',
    };

    // Setup function to reduce duplication
    const setupTest = () => {
        // Context values
        const reportDataContextValue = { selectedReport: mockReport };
        const setUpdatedReportNameStub = cy.stub().as('setUpdatedReportName');
        const setUpdatedDescriptionStub = cy.stub().as('setUpdatedDescription');

        const testCompileReportContextValue = {
            ownerUserId: 'System',
            updatedReportName: 'Test Report',
            updatedDescription: 'Test Description',
            setUpdatedReportName: setUpdatedReportNameStub,
            setUpdatedDescription: setUpdatedDescriptionStub,
            allReportsSummary: [
                { reportName: 'Test Report 1', id: 'report-1' },
            ],
        };

        cy.stub(i18n, 'useTranslation').returns({
            t: (key, fallback) => fallback || key,
            i18n: { changeLanguage: () => new Promise(() => { }) }
        });

        // Mock report service methods
        cy.stub(ReportService, 'updateReportName').resolves();
        cy.stub(ReportService, 'updateReportDescription').resolves();

        return { reportDataContextValue, testCompileReportContextValue };
    };

    beforeEach(() => {
        window.React = React;
    });

    it('renders report name and description correctly', () => {
        const { reportDataContextValue, testCompileReportContextValue } = setupTest();

        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={reportDataContextValue}
                compileReportContextValue={testCompileReportContextValue}>
                <RenderReportsTitle />
            </CompileReportContextWrapper>
        );

        cy.get('.ssr-top-navigation-title h3').should('contain', 'Test Report');
        cy.get('.render-reports-title-description').should('contain', 'Test Description');
    });

    it('allows editing report name for owner', () => {
        const { reportDataContextValue, testCompileReportContextValue } = setupTest();

        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={reportDataContextValue}
                compileReportContextValue={testCompileReportContextValue}>
                <RenderReportsTitle />
            </CompileReportContextWrapper>
        );

        // Interaction steps
        cy.get('.ssr-top-navigation-title').click();
        cy.get('[data-testid="report-name-input"]').should('exist')
            .clear()
            .type('New Report Name');
        cy.get('._mntl-primary').click();

        // Assertions
        cy.wrap(ReportService.updateReportName).should('have.been.called');
        cy.get('body').contains('Report name updated successfully.').should('exist');
    });

    it('allows editing report description for owner', () => {
        const { reportDataContextValue, testCompileReportContextValue } = setupTest();

        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={reportDataContextValue}
                compileReportContextValue={testCompileReportContextValue}>
                <RenderReportsTitle />
            </CompileReportContextWrapper>
        );

        // Interaction steps
        cy.get('.render-reports-title-description').click();
        cy.get('[data-testid="report-description-input"]').should('exist')
            .clear()
            .type('New Description');
        cy.get('._mntl-primary').click();

        // Assertions
        cy.wrap(ReportService.updateReportDescription).should('have.been.called');
        cy.get('body').contains('Report description updated successfully.').should('exist');
    });

    it('shows validation error for empty report name', () => {
        const { reportDataContextValue, testCompileReportContextValue } = setupTest();
        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={reportDataContextValue}
                compileReportContextValue={testCompileReportContextValue}>
                <RenderReportsTitle />
            </CompileReportContextWrapper>
        );
        cy.get('.ssr-top-navigation-title').click();
        cy.get('[data-testid="report-name-input"]').should('exist')
            .clear();
        cy.get('._mntl-primary').click();
        cy.contains('Name can not be empty').should('exist');
    });

    it('shows validation error for empty description', () => {
        const { reportDataContextValue, testCompileReportContextValue } = setupTest();
        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={reportDataContextValue}
                compileReportContextValue={testCompileReportContextValue}>
                <RenderReportsTitle />
            </CompileReportContextWrapper>
        );
        cy.get('.render-reports-title-description').click();
        cy.get('[data-testid="report-description-input"]').should('exist')
            .clear();
        cy.get('._mntl-primary').click();
        cy.contains('Description can not be empty').should('exist');
    });
});