import React from 'react';
import BreadcrumbNavigation from '../../../../src/app/components/SSRTopNavigation/BreadcrumbNavigation';
import { ReportDataContext, AllReportsLandingPageContext, CompileReportContext } from '../../../../src/contexts';
import * as router from 'react-router-dom';
import * as i18n from 'react-i18next';
import * as CommonServicesContext from '../../../../src/contexts/CommonServicesContext';
import { EDITOR_ACCESS_LEVEL, CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, VIEWER_ACCESS_LEVEL } from '../../../../src/utils/constants';

describe('BreadcrumbNavigation', () => {
    // Use regular variables for initial declarations
    let onSave;
    let onSaveCopy;
    let historyPush;
    let setSelectedReport;
    let setReportMetadata;
    let setHideEditButtonOnError;
    let setShowLeaveWithoutSaveModal;

    beforeEach(() => {
        // Create the stubs inside the beforeEach hook
        onSave = cy.stub().as('onSave');
        onSaveCopy = cy.stub().as('onSaveCopy');
        historyPush = cy.stub().as('historyPush');
        setSelectedReport = cy.stub().as('setSelectedReport');
        setReportMetadata = cy.stub().as('setReportMetadata');
        setHideEditButtonOnError = cy.stub().as('setHideEditButtonOnError');
        setShowLeaveWithoutSaveModal = cy.stub().as('setShowLeaveWithoutSaveModal');

        // Stub hooks
        cy.stub(router, 'useHistory').returns({ push: historyPush });
        cy.stub(i18n, 'useTranslation').returns({ t: (key) => key });
        //cy.stub(CommonServicesContext, 'useAccessLevel').returns(EDITOR_ACCESS_LEVEL);
    });

    const mountWithContexts = (options = {}) => {
        const {
            accessLevel = VIEWER_ACCESS_LEVEL,
            currentScreen = 'EDIT_REPORT',
            isChanged = false,
            showLeaveWithoutSaveModal = false
        } = options;

        cy.stub(CommonServicesContext, 'useAccessLevel').returns(accessLevel);

        cy.mount(
            <ReportDataContext.Provider value={{
                setSelectedReport,
                setReportMetadata
            }}>
                <AllReportsLandingPageContext.Provider value={{
                    setHideEditButtonOnError,
                    currentScreen
                }}>
                    <CompileReportContext.Provider value={{
                        showLeaveWithoutSaveModal,
                        setShowLeaveWithoutSaveModal,
                        isChanged
                    }}>
                        <BreadcrumbNavigation onSave={onSave} onSaveCopy={onSaveCopy} />
                    </CompileReportContext.Provider>
                </AllReportsLandingPageContext.Provider>
            </ReportDataContext.Provider>
        );
    };

    it('renders back button and breadcrumb navigation', () => {
        mountWithContexts();
        cy.get('.ssrs-navigation-left').should('exist');
        cy.get('button').should('exist');
        cy.get('[data-atmt-id="seismic.self-service-reports.breadcum.go-to-insights"]').should('exist');
        cy.get('[data-atmt-id="seismic.self-service-reports.breadcum.go-to-reports-list"]').should('exist');
    });

    // it('navigates to reports list when back button is clicked with no unsaved changes', () => {
    //     mountWithContexts();
    //     cy.get('button').click();
    //     cy.get('@setSelectedReport').should('be.calledWith', {});
    //     cy.get('@setReportMetadata').should('be.calledWith', {});
    //     cy.get('@setHideEditButtonOnError').should('be.calledWith', false);
    //     cy.get('@historyPush').should('be.calledWith', '/selfservicereports');
    // });

    it('shows leave without save modal when back button is clicked with unsaved changes', () => {
        mountWithContexts({ isChanged: true });
        cy.get('button').click();
        cy.get('@setShowLeaveWithoutSaveModal').should('be.calledWith', true);
    });

    // it('navigates to insights when back button is clicked and currentScreen is not EDIT_REPORT', () => {
    //     mountWithContexts({ currentScreen: 'OTHER_SCREEN' });
    //     cy.get('button').click();
    //     cy.get('@historyPush').should('be.calledWith', '/insights');
    // });

    it('shows leave without save modal when breadcrumb item is clicked with unsaved changes', () => {
        mountWithContexts({ isChanged: true });
        cy.get('[data-atmt-id="seismic.self-service-reports.breadcum.go-to-reports-list"]').click();
        cy.get('@setShowLeaveWithoutSaveModal').should('be.calledWith', true);
    });

    // it('navigates to insights when first breadcrumb item is clicked and currentScreen is not EDIT_REPORT', () => {
    //     mountWithContexts({ currentScreen: 'OTHER_SCREEN' });
    //     cy.get('[data-atmt-id="seismic.self-service-reports.breadcum.go-to-insights"]').click();
    //     cy.get('@historyPush').should('be.calledWith', '/insights');
    // });

    // it('renders LeaveWithoutSaveModal when showLeaveWithoutSaveModal and isChanged are true', () => {
    //     mountWithContexts({ showLeaveWithoutSaveModal: true, isChanged: true });
    //     cy.get('LeaveWithoutSaveModal').should('exist');
    // });

    it('does not render LeaveWithoutSaveModal when showLeaveWithoutSaveModal is false', () => {
        mountWithContexts({ isChanged: true });
        cy.get('LeaveWithoutSaveModal').should('not.exist');
    });

    // it('handles non-editor access level', () => {
    //     cy.stub(CommonServicesContext, 'useAccessLevel').returns(VIEWER_ACCESS_LEVEL);

    //     mountWithContexts({ accessLevel: VIEWER_ACCESS_LEVEL, isChanged: false });

    //     cy.get('button').click();
    //     //cy.get('@setShowLeaveWithoutSaveModal').should('not.be.called');
    //     cy.get('@historyPush').should('be.calledWith', '/selfservicereports');
    // });

    it('handles custom report editor access level', () => {
        mountWithContexts({ accessLevel: CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, isChanged: true });
        cy.get('button').click();
        cy.get('@setShowLeaveWithoutSaveModal').should('be.calledWith', true);
    });
});