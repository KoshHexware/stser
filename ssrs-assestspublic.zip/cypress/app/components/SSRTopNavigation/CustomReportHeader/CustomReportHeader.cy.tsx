import React from 'react';
import { I18nextProvider } from 'react-i18next';
import CustomReportHeader from '../../../../../src/app/components/SSRTopNavigation/CustomReportHeader';
import { CompileReportContext, ReportDataContext } from '../../../../../src/contexts';
import { CommonServicesContextProvider } from '../../../../../src/contexts/CommonServicesContext';
import testI18n from '../../../../support/i18n-setup';
import UserSettings from '../../../../fixtures/UserSettings.json';
import { EDITOR_ACCESS_LEVEL } from '../../../../../src/utils/constants';

describe('CustomReportHeader Component', () => {
    let mockOnSave;
    let mockOnReset;
    let mockSetIsSidePanelVisible;
    let mockApplicationInfo;

    beforeEach(() => {
        window.React = React;
        mockOnSave = cy.stub().as('onSaveStub');
        mockOnReset = cy.stub().as('onResetStub');
        mockSetIsSidePanelVisible = cy.stub().as('setIsSidePanelVisibleStub');

        mockApplicationInfo = {
            User: {
                FirstName: "Test",
                LastName: "User",
                UserName: "testuser",
                UserId: "test-user-123",
                Title: "title",
            }
        };
    });

    const mountComponent = (
        compileReportContextOverrides = {},
        reportDataContextOverrides = {},
        componentProps = {}
    ) => {
        const defaultCompileReportContext = {
            ownerUserId: 'test-user-123',
            isChanged: false,
            isSaved: false,
            updatedFields: [],
            updatedFilters: [],
            updatedTeamsites: [],
            teamsites: [],
            fields: [],
            currentSelectedFilter: {},
            isCompileReportMode: false,
            isFilterCardClicked: false,
            isNewFilterAdding: false,
            updatedReportName: 'Test Report',
            updatedDescription: 'Test Description',
            updatedOrderBy: 'ASC_NULLS_LAST',
            updatedOrderField: 'contentProfileName',
            id: 'test-report-123',
            systemReportId: null,
            setUpdatedFields: cy.stub().as('setUpdatedFieldsStub'),
            setUpdatedFilters: cy.stub().as('setUpdatedFiltersStub'),
            setUpdatedTeamsites: cy.stub().as('setUpdatedTeamsitesStub'),
            setCurrentSelectedFilter: cy.stub().as('setCurrentSelectedFilterStub'),
            setIsCompileReportMode: cy.stub().as('setIsCompileReportModeStub'),
            setIsFilterCardClicked: cy.stub().as('setIsFilterCardClickedStub'),
            setIsNewFilterAdding: cy.stub().as('setIsNewFilterAddingStub'),
            setUpdatedReportName: cy.stub().as('setUpdatedReportNameStub'),
            setUpdatedDescription: cy.stub().as('setUpdatedDescriptionStub'),
            setUpdatedOrderBy: cy.stub().as('setUpdatedOrderByStub'),
            setUpdatedOrderField: cy.stub().as('setUpdatedOrderFieldStub'),
            resetCompileReportState: cy.stub().as('resetCompileReportStateStub'),
            resetCompileReportOriginalState: cy.stub().as('resetCompileReportOriginalStateStub'),
            setOriginalTeamsites: cy.stub().as('setOriginalTeamsitesStub'),
            setTempTeamsites: cy.stub().as('setTempTeamsitesStub'),
            ...compileReportContextOverrides
        };

        const defaultReportDataContext = {
            selectedReport: {
                id: 'test-report-123',
                reportName: 'Test Custom Report',
                ownerUserId: 'test-user-123'
            },
            reportMetadata: {
                ownerUserId: 'test-user-123'
            },
            showReportSavedToast: false,
            isReportShared: false,
            setSelectedReport: cy.stub().as('setSelectedReportStub'),
            setReportMetadata: cy.stub().as('setReportMetadataStub'),
            setShowReportSavedToast: cy.stub().as('setShowReportSavedToastStub'),
            setIsReportShared: cy.stub().as('setIsReportSharedStub'),
            ...reportDataContextOverrides
        };

        const defaultProps = {
            onSave: mockOnSave,
            onReset: mockOnReset,
            hideLabel: false,
            setIsSidePanelVisible: mockSetIsSidePanelVisible,
            ...componentProps
        };

        return cy.mount(
            <I18nextProvider i18n={testI18n}>
                <CommonServicesContextProvider
                    applicationInfo={mockApplicationInfo}
                    accessLevel={EDITOR_ACCESS_LEVEL}
                    userSettings={{ teamsites: UserSettings.teamsites as [], reportsFilterOption: 'all' }}
                >
                    <CompileReportContext.Provider value={defaultCompileReportContext}>
                        <ReportDataContext.Provider value={defaultReportDataContext}>
                            <CustomReportHeader {...defaultProps} />
                        </ReportDataContext.Provider>
                    </CompileReportContext.Provider>
                </CommonServicesContextProvider>
            </I18nextProvider>
        );
    };

    describe('Basic Rendering', () => {
        it('should render the component with default state', () => {
            mountComponent();
            cy.get('.ssrs-custom-report-header').should('exist');
        });

        it('should render in a container div', () => {
            mountComponent();
            cy.get('.ssrs-custom-report-header > div').should('exist');
        });
    });

    describe('Report Status: NOT_MADE_CHANGES', () => {
        beforeEach(() => {
            mountComponent({
                isChanged: false,
                isSaved: false
            });
        });

        it('should show disabled Save button for owner when no changes made', () => {
            cy.get('.srs-view-report-save-copy').should('be.visible');
            cy.get('.srs-view-report-save-copy').should('be.disabled');
            cy.get('.srs-view-report-save-copy').should('contain.text', 'Save');
        });

        it('should not show Reset button when no changes made', () => {
            cy.get('.ssrs-custom-report-header-reset-button').should('not.exist');
        });

        it('should have correct data attribute for disabled save button', () => {
            cy.get('.srs-view-report-save-copy')
                .should('have.attr', 'data-atmt-id', 'seismic.self-service-reports.edit-report.save-report-changes-disabled');
        });
    });

    describe('Report Status: UNSAVED_CHANGES', () => {
        beforeEach(() => {
            mountComponent({
                isChanged: true,
                isSaved: false
            });
        });

        it('should show enabled Save button when changes are made', () => {
            cy.get('.srs-view-report-save-copy').should('be.visible');
            cy.get('.srs-view-report-save-copy').should('not.be.disabled');
            cy.get('.srs-view-report-save-copy').should('contain.text', 'Save');
        });

        it('should show Reset Changes button when changes are made', () => {
            cy.get('.ssrs-custom-report-header-reset-button').should('be.visible');
            cy.get('.ssrs-custom-report-header-reset-button').should('contain.text', 'Reset changes');
        });

        it('should call onSave when Save button is clicked', () => {
            cy.get('.srs-view-report-save-copy').click();
            cy.get('@onSaveStub').should('have.been.calledWith', false, false);
        });

        it('should call onReset when Reset Changes button is clicked', () => {
            cy.get('.ssrs-custom-report-header-reset-button').click();
            cy.get('@onResetStub').should('have.been.calledOnce');
        });

        it('should have correct data attributes for enabled buttons', () => {
            cy.get('.srs-view-report-save-copy')
                .should('have.attr', 'data-atmt-id', 'seismic.self-service-reports.edit-report.reset-report-changes');
            
            cy.get('.ssrs-custom-report-header-reset-button')
                .should('have.attr', 'data-atmt-id', 'seismic.self-service-reports.edit-report.reset-report-changes');
        });
    });

    describe('Report Status: SAVED_CHANGES', () => {
        beforeEach(() => {
            mountComponent({
                isChanged: false,
                isSaved: true
            });
        });

        it('should show disabled Save button when changes are saved', () => {
            cy.get('.srs-view-report-save-copy').should('be.visible');
            cy.get('.srs-view-report-save-copy').should('be.disabled');
        });

        it('should not show Reset button when changes are saved', () => {
            cy.get('.ssrs-custom-report-header-reset-button').should('not.exist');
        });
    });

    describe('Owner vs Non-Owner Permissions', () => {
        it('should show Save button for report owner', () => {
            mountComponent({
                ownerUserId: 'test-user-123',
                isChanged: true
            }, {
                selectedReport: {
                    id: 'test-report-123',
                    ownerUserId: 'test-user-123'
                }
            });

            cy.get('.srs-view-report-save-copy').should('be.visible');
        });

        it('should show Save button when user matches ownerUserId from context', () => {
            mountComponent({
                ownerUserId: 'test-user-123',
                isChanged: true
            }, {
                selectedReport: {
                    id: 'test-report-123',
                    ownerUserId: 'different-user'
                }
            });

            cy.get('.srs-view-report-save-copy').should('be.visible');
        });

        it('should not show Save button for non-owner', () => {
            const nonOwnerApplicationInfo = {
                User: {
                    FirstName: "Different",
                    LastName: "User",
                    UserName: "differentuser",
                    UserId: "different-user-456",
                    Title: "title",
                }
            };

            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <CommonServicesContextProvider
                        applicationInfo={nonOwnerApplicationInfo}
                        accessLevel={EDITOR_ACCESS_LEVEL}
                        userSettings={{ teamsites: UserSettings.teamsites as [], reportsFilterOption: 'all' }}
                    >
                        <CompileReportContext.Provider value={{
                            ownerUserId: 'test-user-123',
                            isChanged: true,
                            isSaved: false
                        }}>
                            <ReportDataContext.Provider value={{
                                selectedReport: {
                                    id: 'test-report-123',
                                    ownerUserId: 'test-user-123'
                                },
                                showReportSavedToast: false,
                                setShowReportSavedToast: cy.stub()
                            }}>
                                <CustomReportHeader
                                    onSave={mockOnSave}
                                    onReset={mockOnReset}
                                />
                            </ReportDataContext.Provider>
                        </CompileReportContext.Provider>
                    </CommonServicesContextProvider>
                </I18nextProvider>
            );

            cy.get('.srs-view-report-save-copy').should('not.exist');
        });

        it('should show Reset button regardless of ownership when changes exist', () => {
            mountComponent({
                ownerUserId: 'different-user',
                isChanged: true
            }, {
                selectedReport: {
                    id: 'test-report-123',
                    ownerUserId: 'different-user'
                }
            });

            cy.get('.ssrs-custom-report-header-reset-button').should('be.visible');
        });
    });

    describe('Toast Functionality', () => {
        it('should trigger side panel when report is saved', () => {
            mountComponent({}, {
                showReportSavedToast: true
            });

            cy.wait(100);
            cy.get('@setIsSidePanelVisibleStub').should('have.been.calledWith', true);
        });

        it('should call setShowReportSavedToast(false) after timeout', () => {
            mountComponent({}, {
                showReportSavedToast: true
            });

            cy.wait(2100);
            cy.get('@setShowReportSavedToastStub').should('have.been.calledWith', false);
        });

        it('should not trigger side panel when showReportSavedToast is false', () => {
            mountComponent({}, {
                showReportSavedToast: false
            });

            cy.wait(100);
            cy.get('@setIsSidePanelVisibleStub').should('not.have.been.called');
        });

        it('should handle missing setIsSidePanelVisible prop gracefully', () => {
            mountComponent({}, {
                showReportSavedToast: true
            }, {
                setIsSidePanelVisible: undefined
            });

            cy.get('.ssrs-custom-report-header').should('exist');
        });
    });

    describe('Button Interactions', () => {
        it('should handle multiple rapid clicks on Save button', () => {
            mountComponent({
                isChanged: true
            });

            cy.get('.srs-view-report-save-copy').click();
            cy.get('.srs-view-report-save-copy').click();
            cy.get('.srs-view-report-save-copy').click();

            cy.get('@onSaveStub').should('have.callCount', 3);
            cy.get('@onSaveStub').should('always.have.been.calledWith', false, false);
        });

        it('should handle multiple rapid clicks on Reset button', () => {
            mountComponent({
                isChanged: true
            });

            cy.get('.ssrs-custom-report-header-reset-button').click();
            cy.get('.ssrs-custom-report-header-reset-button').click();

            cy.get('@onResetStub').should('have.callCount', 2);
        });

        it('should not call onSave when button is disabled', () => {
            mountComponent({
                isChanged: false,
                isSaved: false
            });

            cy.get('.srs-view-report-save-copy').click({ force: true });
            cy.get('@onSaveStub').should('not.have.been.called');
        });
    });

    describe('State Transitions', () => {
        it('should transition from no changes to unsaved changes', () => {
            mountComponent({
                isChanged: false,
                isSaved: false
            });

            cy.get('.ssrs-custom-report-header-reset-button').should('not.exist');
            cy.get('.srs-view-report-save-copy').should('be.disabled');

            mountComponent({
                isChanged: true,
                isSaved: false
            });

            cy.get('.ssrs-custom-report-header-reset-button').should('be.visible');
            cy.get('.srs-view-report-save-copy').should('not.be.disabled');
        });

        it('should transition from unsaved changes to saved', () => {
            mountComponent({
                isChanged: true,
                isSaved: false
            });

            cy.get('.ssrs-custom-report-header-reset-button').should('be.visible');
            cy.get('.srs-view-report-save-copy').should('not.be.disabled');

            mountComponent({
                isChanged: false,
                isSaved: true
            });

            cy.get('.ssrs-custom-report-header-reset-button').should('not.exist');
            cy.get('.srs-view-report-save-copy').should('be.disabled');
        });
    });

    describe('Accessibility', () => {
        it('should have proper button elements', () => {
            mountComponent({
                isChanged: true
            });

            cy.get('.srs-view-report-save-copy').should('have.prop', 'tagName', 'BUTTON');
            cy.get('.ssrs-custom-report-header-reset-button').should('have.prop', 'tagName', 'BUTTON');
        });

        it('should have accessible button text', () => {
            mountComponent({
                isChanged: true
            });

            cy.get('.srs-view-report-save-copy').should('contain.text', 'Save');
            cy.get('.ssrs-custom-report-header-reset-button').should('contain.text', 'Reset changes');
        });

        it('should indicate disabled state appropriately', () => {
            mountComponent({
                isChanged: false,
                isSaved: false
            });

            cy.get('.srs-view-report-save-copy').should('be.disabled');
            cy.get('.srs-view-report-save-copy').should('have.attr', 'disabled');
        });
    });

    describe('Performance', () => {
        it('should render quickly without delays', () => {
            const startTime = Date.now();

            mountComponent();

            cy.get('.ssrs-custom-report-header').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(500);
            });
        });

        it('should handle context updates efficiently', () => {
            mountComponent({
                isChanged: false
            });

            cy.get('.srs-view-report-save-copy').should('be.disabled');

            mountComponent({
                isChanged: true
            });

            cy.get('.srs-view-report-save-copy').should('not.be.disabled');
            cy.get('.ssrs-custom-report-header-reset-button').should('be.visible');
        });
    });
});