import React from 'react';
import { I18nextProvider } from 'react-i18next';
import SystemReportHeader from '../../../../../src/app/components/SSRTopNavigation/SystemReportHeader';
import { CompileReportContext } from '../../../../../src/contexts';
import testI18n from '../../../../support/i18n-setup';

describe('SystemReportHeader Component', () => {
    let mockOnSaveCopy;
    let mockOnReset;

    beforeEach(() => {
        mockOnSaveCopy = cy.stub().as('onSaveCopyStub');
        mockOnReset = cy.stub().as('onResetStub');
    });

    const mountComponent = (
        contextOverrides = {},
        componentProps = {}
    ) => {
        const defaultContext = {
            isChanged: false,
            updatedFields: [],
            ...contextOverrides
        };

        const defaultProps = {
            onSaveCopy: mockOnSaveCopy,
            onReset: mockOnReset,
            hideLabel: false,
            ...componentProps
        };

        return cy.mount(
            <I18nextProvider i18n={testI18n}>
                <CompileReportContext.Provider value={defaultContext}>
                    <SystemReportHeader {...defaultProps} />
                </CompileReportContext.Provider>
            </I18nextProvider>
        );
    };

    describe('Basic Rendering', () => {
        it('should render the component with default state', () => {
            mountComponent();

            cy.get('.ssrs-system-report-header').should('exist');
            cy.get('.ssrs-system-report-header-container').should('exist');
        });

        it('should render ExportReport component', () => {
            mountComponent();

            cy.get('.ssrs-system-report-header').should('exist');
        });
    });

    describe('No Changes State (NOT_MADE_CHANGES)', () => {
        beforeEach(() => {
            mountComponent({
                isChanged: false,
                updatedFields: []
            });
        });

        it('should show disabled Save Copy button when no changes made', () => {
            cy.get('.ssrs-view-report-save-copy').should('be.visible');
            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });

        it('should not show Reset Changes button when no changes made', () => {
            cy.get('.ssrs-system-report-header-container-reset-button').should('not.exist');
        });

        it('should have correct button styling when disabled', () => {
            cy.get('.ssrs-view-report-save-copy').should('have.class', 'ssrs-view-report-save-copy');
            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });
    });

    describe('Unsaved Changes State (UNSAVED_CHANGES)', () => {
        beforeEach(() => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });
        });

        it('should show enabled Save Copy button when changes are made', () => {
            cy.get('.ssrs-view-report-save-copy').should('be.visible');
            cy.get('.ssrs-view-report-save-copy').should('not.be.disabled');
        });

        it('should show Reset Changes button when changes are made', () => {
            cy.get('.ssrs-system-report-header-container-reset-button').should('be.visible');
            cy.get('.ssrs-system-report-header-container-reset-button').should('contain.text', 'Reset changes');
        });

        it('should call onSaveCopy when Save Copy button is clicked', () => {
            cy.get('.ssrs-view-report-save-copy').click();
            cy.get('@onSaveCopyStub').should('have.been.calledOnce');
        });

        it('should call onReset when Reset Changes button is clicked', () => {
            cy.get('.ssrs-system-report-header-container-reset-button').click();
            cy.get('@onResetStub').should('have.been.calledOnce');
        });

        it('should have correct data attributes for tracking', () => {
            cy.get('.ssrs-system-report-header-container-reset-button')
                .should('have.attr', 'data-atmt-id', 'seismic.self-service-reports.edit-report.reset-changes');
        });

        it('should have correct CSS classes for tracking', () => {
            cy.get('.ssrs-view-report-save-copy')
                .should('have.class', 'trk_button_ssrs-report_analyze_standard_open_save_as_copy_modal');
            
            cy.get('.ssrs-system-report-header-container-reset-button')
                .should('have.class', 'trk_button_ssrs-report_analyze_standard_open_reset_changes_modal');
        });
    });

    describe('Save Copy Button Disabled State', () => {
        it('should disable Save Copy button when updatedFields is empty', () => {
            mountComponent({
                isChanged: true,
                updatedFields: []
            });

            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });

        it('should disable Save Copy button when updatedFields is null', () => {
            mountComponent({
                isChanged: true,
                updatedFields: null
            });

            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });

        it('should disable Save Copy button when updatedFields is undefined', () => {
            mountComponent({
                isChanged: true,
                updatedFields: undefined
            });

            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });

        it('should enable Save Copy button when updatedFields has items', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field'  }]
            });

            cy.get('.ssrs-view-report-save-copy').should('not.be.disabled');
        });
    });

    describe('hideLabel Prop', () => {
        it('should use primary variant when hideLabel is false', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field'  }]
            }, {
                hideLabel: false
            });

            cy.get('.ssrs-view-report-save-copy').should('be.visible');
        });

        it('should pass hideLabel prop correctly to ExportReport', () => {
            mountComponent({}, { hideLabel: true });

            cy.get('.ssrs-system-report-header').should('exist');
        });
    });

    describe('State Transitions', () => {
        it('should transition from no changes to unsaved changes', () => {
            mountComponent({
                isChanged: false,
                updatedFields: []
            });

            cy.get('.ssrs-system-report-header-container-reset-button').should('not.exist');
            cy.get('.ssrs-view-report-save-copy').should('be.disabled');

            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-system-report-header-container-reset-button').should('be.visible');
            cy.get('.ssrs-view-report-save-copy').should('not.be.disabled');
        });

        it('should transition from unsaved changes back to no changes', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-system-report-header-container-reset-button').should('be.visible');

            mountComponent({
                isChanged: false,
                updatedFields: []
            });

            cy.get('.ssrs-system-report-header-container-reset-button').should('not.exist');
            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });
    });

    describe('Button Interactions', () => {
        it('should handle multiple rapid clicks on Save Copy button', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').click();
            cy.get('.ssrs-view-report-save-copy').click();
            cy.get('.ssrs-view-report-save-copy').click();

            cy.get('@onSaveCopyStub').should('have.callCount', 3);
        });

        it('should handle multiple rapid clicks on Reset Changes button', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-system-report-header-container-reset-button').click();
            cy.get('.ssrs-system-report-header-container-reset-button').click();

            cy.get('@onResetStub').should('have.callCount', 2);
        });

        it('should not call onSaveCopy when button is disabled', () => {
            mountComponent({
                isChanged: false,
                updatedFields: []
            });

            cy.get('.ssrs-view-report-save-copy').click({ force: true });
            cy.get('@onSaveCopyStub').should('not.have.been.called');
        });
    });

    describe('Tooltip Functionality', () => {
        it('should show tooltip on Save Copy button hover', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').trigger('mouseover');
            cy.wait(100);
            cy.get('body').should('contain.text', 'Save copy');
        });

        it('should hide tooltip when mouse leaves', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').trigger('mouseover');
            cy.wait(100);
            cy.get('body').should('contain.text', 'Save copy');

            cy.get('.ssrs-view-report-save-copy').trigger('mouseout');
            cy.wait(100);
            // Tooltip should disappear (specific assertion depends on tooltip implementation)
        });
    });

    describe('Edge Cases and Error Handling', () => {
        it('should handle missing context gracefully', () => {
            cy.mount(
                <I18nextProvider i18n={testI18n}>
                    <SystemReportHeader 
                        onSaveCopy={mockOnSaveCopy}
                        onReset={mockOnReset}
                    />
                </I18nextProvider>
            );

            cy.get('.ssrs-system-report-header').should('exist');
        });

        it('should handle null/undefined props gracefully', () => {
            mountComponent({
                isChanged: null,
                updatedFields: undefined
            });

            cy.get('.ssrs-system-report-header').should('exist');
            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
        });

        it('should handle missing onSaveCopy prop', () => {
            mountComponent({}, { onSaveCopy: undefined });

            cy.get('.ssrs-view-report-save-copy').should('be.visible');
        });

        it('should handle missing onReset prop', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            }, { 
                onReset: undefined 
            });

            cy.get('.ssrs-system-report-header-container-reset-button').should('be.visible');
        });
    });

    describe('Accessibility', () => {
        it('should have proper button elements', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').should('have.prop', 'tagName', 'BUTTON');
            cy.get('.ssrs-system-report-header-container-reset-button').should('have.prop', 'tagName', 'BUTTON');
        });

        it('should have accessible button text', () => {
            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').should('contain.text', 'Save copy');
            cy.get('.ssrs-system-report-header-container-reset-button').should('contain.text', 'Reset changes');
        });

        it('should indicate disabled state appropriately', () => {
            mountComponent({
                isChanged: false,
                updatedFields: []
            });

            cy.get('.ssrs-view-report-save-copy').should('be.disabled');
            cy.get('.ssrs-view-report-save-copy').should('have.attr', 'disabled');
        });
    });

    describe('Performance', () => {
        it('should render quickly without delays', () => {
            const startTime = Date.now();

            mountComponent();

            cy.get('.ssrs-system-report-header').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(500);
            });
        });

        it('should handle context updates efficiently', () => {
            mountComponent({
                isChanged: false,
                updatedFields: []
            });

            cy.get('.ssrs-view-report-save-copy').should('be.disabled');

            mountComponent({
                isChanged: true,
                updatedFields: [{ id: 'field1', name: 'Test Field' }]
            });

            cy.get('.ssrs-view-report-save-copy').should('not.be.disabled');
            cy.get('.ssrs-system-report-header-container-reset-button').should('be.visible');
        });
    });
});