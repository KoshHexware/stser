
import React from 'react';
import LandingPageTopNavigation from "../../../../../src/app/components/SSRTopNavigation/LandingPageTopNavigation";
import { ContextWrapper } from "../../../../support/ContextWrapper";
import ReportMetaData from '../../../../fixtures/ReportMetaData.json';

describe('Testing LandingPageTopNavigation', () => {
    it('Should show BreadcrumbNavigation and New report button', () => {
        const allReportsLandingPageContextValue = {
            updatedReportsFilterOption: '',
            isCompileReportMode: false,
            hideEditButtOnError: false,
            orderBy: '',
            orderField: '',
            setHideEditButtonOnError: () => { },
        };
        const reportDataContextValue = {
            selectedReport: {
                reportName: 'My user test add column',
                id: 'b4f5bbef-4c07-46f7-81c3-7d35c3cccf67',
                reportType: 'Custom',
                ownerUserId: 'System',
                userId: 'System',
                systemReportName: 'user',
                description: 'This is a test report',
            },
            reportMetadata: ReportMetaData,
            isReportShared: false,
            showReportSavedToast: false,
            setSelectedReport: () => { },
            setReportMetadata: () => { },
        };
        cy.mount(
            <ContextWrapper
                allReportsLandingPageContextValue={allReportsLandingPageContextValue}
                reportDataContextValue={reportDataContextValue}
            >
                <LandingPageTopNavigation />
            </ContextWrapper>
        )
        cy.get('.ssrs-top-panel').should('exist');
        cy.get('.ssrs-navigation').should('exist');
        cy.get('.ssrs-navigation-left').should('exist')
        cy.get('.ssrs-navigation-right').should('exist');
        cy.get('.ssrs-new-report-button').contains('New report').should('exist');
    });

});

