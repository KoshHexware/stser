import React from 'react';
import SystemReportNameLabel from '../../../../../src/app/components/SSRTopNavigation/SystemReportNameLabel';
import { ReportDataContext } from '../../../../../src/contexts';

describe('SystemReportNameLabel Component', () => {
    const mountComponent = (contextOverrides = {}) => {
        const defaultContext = {
            selectedReport: null,
            setSelectedReport: cy.stub().as('setSelectedReportStub'),
            reportMetadata: null,
            setReportMetadata: cy.stub().as('setReportMetadataStub'),
            showReportSavedToast: false,
            setShowReportSavedToast: cy.stub().as('setShowReportSavedToastStub'),
            isReportShared: false,
            setIsReportShared: cy.stub().as('setIsReportSharedStub'),
            ...contextOverrides
        };

        return cy.mount(
            <ReportDataContext.Provider value={defaultContext}>
                <SystemReportNameLabel />
            </ReportDataContext.Provider>
        );
    };

    describe('Basic Rendering', () => {
        it('should render without crashing when selectedReport is null', () => {
            mountComponent();
            
            cy.get('body').should('exist');
        });

        it('should render without crashing when selectedReport is undefined', () => {
            mountComponent({
                selectedReport: undefined
            });
            
            cy.get('body').should('exist');
        });
    });

    describe('Custom Report Type Rendering', () => {
        it('should render the component when reportType is Custom', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Test System Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
            cy.get('.ssr-top-navigation-report-title').should('be.visible');
        });

        it('should display the system report name', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'My Custom System Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('contain.text', 'My Custom System Report');
        });

        it('should render IconHost component with correct props', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('exist');
            cy.get('.ssr-top-navigation-report-title').find('img').should('exist');
        });


        it('should handle empty system report name', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: ''
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
            cy.get('.ssr-top-navigation-report-title').should('be.visible');
        });

        it('should handle null system report name', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: null
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
            cy.get('.ssr-top-navigation-report-title').should('be.visible');
        });

        it('should handle undefined system report name', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: undefined
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
            cy.get('.ssr-top-navigation-report-title').should('be.visible');
        });

        it('should handle long system report names', () => {
            const longName = 'This is a very long system report name that might cause layout issues if not handled properly';
            
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: longName
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('contain.text', longName);
            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
        });

        it('should handle special characters in system report name', () => {
            const specialName = 'Report_Analysis - Q4 2023 (Final)';
            
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: specialName
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('contain.text', specialName);
        });
    });

    describe('Non-Custom Report Types', () => {
        it('should not render when reportType is not Custom', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'System',
                    systemReportName: 'Test System Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
            cy.get('.ssr-top-navigation-report-title').should('not.exist');
        });

        it('should not render when reportType is Standard', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Standard',
                    systemReportName: 'Test Standard Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should not render when reportType is null', () => {
            mountComponent({
                selectedReport: {
                    reportType: null,
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should not render when reportType is undefined', () => {
            mountComponent({
                selectedReport: {
                    reportType: undefined,
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should not render when reportType is empty string', () => {
            mountComponent({
                selectedReport: {
                    reportType: '',
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });
    });

    describe('Case Sensitivity', () => {
        it('should be case sensitive for reportType', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'custom',
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should be case sensitive for reportType - CUSTOM', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'CUSTOM',
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should only render for exact "Custom" match', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom', 
                    systemReportName: 'Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
        });
    });


    describe('Edge Cases and Error Handling', () => {
        it('should handle selectedReport with missing properties', () => {
            mountComponent({
                selectedReport: {
                    id: 'test-id'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should handle selectedReport as empty object', () => {
            mountComponent({
                selectedReport: {}
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });

        it('should handle selectedReport with only reportType', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom'
                    // Missing systemReportName
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('be.visible');
            cy.get('.ssr-top-navigation-report-title').should('be.visible');
        });

        it('should handle selectedReport with only systemReportName', () => {
            mountComponent({
                selectedReport: {
                    systemReportName: 'Test Report'
                    // Missing reportType
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('not.exist');
        });
    });

    describe('Accessibility', () => {
        it('should have proper semantic structure', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Accessibility Test Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('exist');
            cy.get('.ssr-top-navigation-report-title').should('exist');
            cy.get('.ssr-top-navigation-report-title span').should('exist');
        });

        it('should have readable text content', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'User Friendly Report Name'
                }
            });

            cy.get('.ssr-top-navigation-report-title span')
                .should('be.visible')
                .should('contain.text', 'User Friendly Report Name');
        });
    });

    describe('Performance', () => {
        it('should render quickly', () => {
            const startTime = Date.now();

            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Performance Test'
                }
            });

            cy.get('.ssr-top-navigation-report-title-div').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(100);
            });
        });

        it('should handle rapid context changes efficiently', () => {
            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Initial Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('contain.text', 'Initial Report');

            mountComponent({
                selectedReport: {
                    reportType: 'Custom',
                    systemReportName: 'Updated Report'
                }
            });

            cy.get('.ssr-top-navigation-report-title').should('contain.text', 'Updated Report');
        });
    });
});