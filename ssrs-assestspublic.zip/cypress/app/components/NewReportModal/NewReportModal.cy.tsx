import React from 'react';
import { NewReportModal } from '../../../../src/app/components/NewReportModal';
import ReportService from '../../../../src/services/ReportService';
import SystemReports from '../../../fixtures/SystemReports.json';
import { ContextWrapper } from '../../../support/ContextWrapper';
import ReportMetaData from '../../../fixtures/ReportMetaData.json';

describe('NewReportModal Component', () => {
  const allReportsLandingPageContextValue = {
    updatedReportsFilterOption: '',
    isCompileReportMode: false,
    hideEditButtOnError: false,
    orderBy: '',
    orderField: '',
    setHideEditButtonOnError: () => { },
    setIsCompileReportMode: () => { },
  };

  const reportDataContextValue = {
    selectedReport: {
      reportName: 'My user test add column',
      id: 'b4f5bbef-4c07-46f7-81c3-7d35c3cccf67',
      reportType: 'Custom',
      ownerUserId: 'System',
      userId: 'System',
      systemReportName: 'user',
      description: 'This is a test report',
    },
    reportMetadata: ReportMetaData,
    isReportShared: false,
    showReportSavedToast: false,
    setSelectedReport: () => { },
    setReportMetadata: () => { },
  };

  beforeEach(() => {
    window.React = React;
    const mockSetModalVisibility = cy.stub().as('setModalVisibilityHandler');
    const setSelectedReportStub = cy.stub().as('setSelectedReportHandler');
    const setReportMetadataStub = cy.stub().as('setReportMetadataHandler');
    const setIsCompileReportModeStub = cy.stub().as('setIsCompileReportModeHandler');

    const modifiedAllReportsContext = {
      ...allReportsLandingPageContextValue,
      setIsCompileReportMode: setIsCompileReportModeStub,
    };
    const modifiedReportDataContext = {
      ...reportDataContextValue,
      setSelectedReport: setSelectedReportStub,
      setReportMetadata: setReportMetadataStub,
    };

    cy.stub(ReportService, 'getReports').resolves({ data: SystemReports });

    const historyPushStub = cy.stub().as('historyPushHandler');
    cy.stub(window, 'history').value({ push: historyPushStub });

    cy.mount(
      <ContextWrapper
        allReportsLandingPageContextValue={modifiedAllReportsContext}
        reportDataContextValue={modifiedReportDataContext}
      >
        <NewReportModal
          showModal={true}
          setModalVisibility={mockSetModalVisibility}
        />
      </ContextWrapper>
    );

    cy.get('.fullScreenLoading', { timeout: 5000 }).should('not.exist');
  });

  afterEach(() => {
    // Restore all stubs after each test
    if (ReportService.getReports?.restore) {
      ReportService.getReports.restore();
    }
    if (window.history?.restore) {
      window.history.restore();
    }
  });

  describe('Basic modal functionality', () => {

    it('Should display the NewReportModel when showModel is true', () => {
      cy.get('.NewReportModel').should('exist');
    });

    it('renders modal with correct title', () => {
      cy.get('.NewReportModel-modal').should('exist');
      cy.get('.NewReportModel-modal').should(
        'contain.text',
        'Choose a standard report to start with'
      );
    });

    it('closes modal when close button is clicked', () => {
      cy.get('.NewReportModel-modal').should('be.visible');
      cy.get('button[aria-label="Close"]').should('be.visible').click({ force: true });
      cy.get('@setModalVisibilityHandler').should('have.been.calledWith', false);
    });
  });

  describe('Search functionality', () => {
    it('renders search input with correct placeholder', () => {
      cy.get('input[placeholder="Search for a standard report"]').should('be.visible');
    });

    it('filters reports when searching', () => {
      let initialCount;
      cy.get('.report-card').then($cards => {
        initialCount = $cards.length;
        cy.log(`Initial card count: ${initialCount}`);
      });

      cy.get('input[placeholder="Search for a standard report"]')
        .should('be.visible')
        .type('user', { delay: 50 });

      cy.get('.report-card').should('have.length.at.least', 1);
    });

    it('should matches description in search results', () => {
      cy.wait(100); // Wait for data to load
      
      // Test name-based search
      cy.get('input[placeholder="Search for a standard report"]')
        .clear()
        .type('sales', { delay: 50 });
      
      cy.get('.report-card').should('have.length', 2);
      cy.get('.report-card').eq(0).should('contain.text', 'Sales Report');
      cy.get('.report-card').eq(1).should('contain.text', 'User Activity');
      
      // Test description-only search
      cy.get('input[placeholder="Search for a standard report"]')
        .clear()
        .type('engagement', { delay: 50 });
      
      cy.get('.report-card').should('have.length', 1);
      cy.get('.report-card').eq(0).should('contain.text', 'Marketing Data');
      
      // Test with a term that appears in both name and description
      cy.get('input[placeholder="Search for a standard report"]')
        .clear()
        .type('user', { delay: 50 });
      
      cy.get('.report-card').should('have.length', 5);
      cy.get('.report-card').eq(0).should('contain.text', 'user');
      cy.get('.report-card').eq(1).should('contain.text', 'User Activity');
    });

    it('shows no results message when search has no matches', () => {
      cy.get('input[placeholder="Search for a standard report"]')
        .should('be.visible')
        .clear()
        .type('NonExistentReport12345', { delay: 50 });

      cy.wait(100);

      cy.get('.NewReportModel-no-search-items').should('be.visible');
      cy.get('.no-search-items').should('be.visible');
    });

    it('clears no results state when search text is cleared', () => {
      cy.get('input[placeholder="Search for a standard report"]')
        .should('be.visible')
        .type('NonExistentReport12345', { delay: 50 });

      cy.get('.NewReportModel-no-search-items').should('be.visible');

      cy.get('input[placeholder="Search for a standard report"]').clear();

      cy.get('.NewReportModel-no-search-items').should('not.exist');
      cy.get('.report-card').should('be.visible');
    });
  });

  describe('Split view and report selection', () => {
    it('starts with collapsed split view', () => {
      cy.get('.NewReportModel-modal-expanded').should('not.exist');
      cy.get('.NewReportModel-modal').should('be.visible');
    });

    it('expands panel when report card is clicked', () => {
      cy.get('.report-card').first().should('be.visible').click();

      cy.get('.NewReportModel-modal-expanded').should('exist');
      cy.get('.NewReportModel-panel-container').should('be.visible');
      cy.get('.NewReportModel-panel-container-report-title').should('be.visible');
    });

    it('shows report details including title, description and action button', () => {
      let cardTitle;
      cy.get('.report-card').first().then($card => {
        cardTitle = $card.find('.report-title').text().trim();
        cy.log(`Card title: ${cardTitle}`);
      });

      cy.get('.report-card').first().click();

      cy.get('.NewReportModel-panel-container-report-title')
        .should('be.visible')
        .invoke('text')
        .then(text => {
          expect(text.trim()).to.not.be.empty;
          cy.log(`Panel title: ${text.trim()}`);
        });

      cy.get('.NewReportModel-panel-container-btn button')
        .should('be.visible')
        .should('contain.text', 'Use this report');
    });

    it('collapses panel when same card is clicked again', () => {
      cy.get('.report-card').first().click();
      cy.get('.NewReportModel-modal-expanded').should('exist');
      cy.get('.report-card').first().click();
      cy.get('.NewReportModel-modal-expanded').should('not.exist');
    });

    it('switches selected report when different card is clicked', () => {
      cy.get('.report-card').then($cards => {
        if ($cards.length >= 2) {
          cy.get('.report-card').first().click();

          let firstTitle;
          cy.get('.NewReportModel-panel-container-report-title')
            .invoke('text')
            .then(text => {
              firstTitle = text.trim();

              cy.get('.report-card').eq(1).click();

              cy.get('.NewReportModel-panel-container-report-title')
                .invoke('text')
                .should(secondTitle => {
                  expect(secondTitle.trim()).to.not.equal(firstTitle);
                });
            });
        } else {
          cy.log('Not enough cards to test switching between reports');
        }
      });
    });

    it('collapses panel when searching', () => {
      cy.get('.report-card').first().click();
      cy.get('.NewReportModel-modal-expanded').should('exist');

      cy.get('input[placeholder="Search for a standard report"]')
        .type('test', { delay: 50 });

      cy.get('.NewReportModel-modal-expanded').should('not.exist');
    });

    it('displays formatted report description with line breaks', () => {
      cy.get('.report-card').first().click();

      cy.get('.NewReportModel-panel-container > div').should('exist');
    });
  });

});
