import React from 'react';
import { StandardReportCard } from  '../../../../../src/app/components/NewReportModal/StandardReportCard';

describe('StandardReportCard Component', () => {
    let mockReport;
    let mockSetModalVisibility;
    let mockOnClick;

    beforeEach(() => {
        window.React = React;
        
        mockReport = {
            id: 'test-report-123',
            reportName: 'Test Standard Report',
            description: 'This is a test report description',
            systemReportName: 'test_report',
            reportType: 'Standard'
        };

        mockSetModalVisibility = cy.stub().as('setModalVisibilityStub');
        mockOnClick = cy.stub().as('onClickStub');
    });

    describe('Basic Rendering', () => {
        it('should render the card with correct structure', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper').should('exist');
            cy.get('.report-card').should('exist');

            cy.get('.report-card-title-icon').should('exist');
            cy.get('.report-card-description-title').should('exist');
            cy.get('.report-card-title').should('exist');
        });

        it('should display the report name', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-title')
                .should('contain.text', 'Test Standard Report');
        });

        it('should render the IconHost with correct props', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-title-icon').should('exist');
            
            cy.get('.report-card-title-icon').should('not.be.empty');
        });

        it('should have proper CSS classes', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper')
                .should('have.class', 'trk_link_ssrs-reports_list_new_report_modal-create_report_from');
        });
    });

    describe('Selection State', () => {
        it('should not have selected class when not selected', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper')
                .should('not.have.class', 'report-card-selected');
        });

        it('should not have selected class when different report is selected', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId="different-report-456"
                />
            );

            cy.get('.report-card-wrapper')
                .should('not.have.class', 'report-card-selected');
        });

        it('should have selected class when this report is selected', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId="test-report-123"
                />
            );

            cy.get('.report-card-wrapper')
                .should('have.class', 'report-card-selected');
        });

        it('should toggle selected state correctly', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper')
                .should('not.have.class', 'report-card-selected');

            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId="test-report-123"
                />
            );

            cy.get('.report-card-wrapper')
                .should('have.class', 'report-card-selected');
        });
    });

    describe('Click Interaction', () => {
        it('should call onClick with report when card is clicked', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper').click();

            cy.get('@onClickStub').should('have.been.calledOnce');
            cy.get('@onClickStub').should('have.been.calledWith', mockReport);
        });

        it('should handle multiple clicks correctly', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper').click();
            cy.get('.report-card-wrapper').click();
            cy.get('.report-card-wrapper').click();

            cy.get('@onClickStub').should('have.been.calledThrice');
        });

        it('should work when clicking on nested elements', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-title').click();

            cy.get('@onClickStub').should('have.been.calledOnce');
            cy.get('@onClickStub').should('have.been.calledWith', mockReport);
        });
    });

    describe('Component Integration', () => {
        it('should maintain selection state during re-renders', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId="test-report-123"
                />
            );

            cy.get('.report-card-wrapper')
                .should('have.class', 'report-card-selected');

            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId="test-report-123"
                />
            );

            cy.get('.report-card-wrapper')
                .should('have.class', 'report-card-selected');
        });
    });

    describe('Accessibility', () => {
        it('should have meaningful content for screen readers', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper')
                .should('contain.text', 'Test Standard Report');

            cy.get('.report-card-wrapper')
                .should('not.have.attr', 'aria-hidden', 'true');
        });
    });

    describe('Performance', () => {
        it('should render quickly with large datasets', () => {
            const startTime = Date.now();

            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(1000);
            });
        });

        it('should not cause memory leaks on unmount', () => {
            cy.mount(
                <StandardReportCard
                    report={mockReport}
                    setModalVisibility={mockSetModalVisibility}
                    key="test-key"
                    onClick={mockOnClick}
                    modalSelectedReportId={null}
                />
            );

            cy.get('.report-card-wrapper').should('exist');

            cy.mount(<div>Replacement content</div>);

            cy.get('.report-card-wrapper').should('not.exist');
        });
    });
});