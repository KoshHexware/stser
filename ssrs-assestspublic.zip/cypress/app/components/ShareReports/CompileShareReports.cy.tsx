import React from 'react';
import CompileShareReports from '../../../../src/app/components/ShareReports/CompileShareReports';
import { ReportDataContext } from '../../../../src/contexts';
import * as useFetchShareReportDataModule from '../../../../src/app/components/ShareReports/useFetchShareReportData';
import ShareReportsState from '../../../../src/contexts/ShareReportsContext';
import ShareReports from '../../../../src/app/components/ShareReports';
import { Modal, Spinner } from '@seismic/mantle';

describe('CompileShareReports Component', () => {
    const mockSelectedReport = { id: 'report-123', name: 'Test Report' };
    const mockReportMetadata = { ownerUserId: 'user-1', title: 'Test Report' };
    const mockUsers = [
        { legacyId: 'user-1', fullName: 'Owner User' },
        { legacyId: 'user-2', fullName: 'Test User 2' },
        { legacyId: 'user-3', fullName: 'Test User 3' },
    ];
    const mockSharedUsers = [{ legacyId: 'user-2' }];

    beforeEach(() => {
        cy.stub(React, 'useContext').returns({
            selectedReport: mockSelectedReport,
            isReportShared: true,
            reportMetadata: mockReportMetadata,
        });
    });

    it('renders ShareReports with ShareReportsState when data is loaded', () => {
        cy.stub(useFetchShareReportDataModule, 'default').returns({
            data: {
                ssrUsersList: mockUsers,
                sharedReportUsers: mockSharedUsers,
            },
            isLoading: false,
        });

        cy.mount(
            <ReportDataContext.Provider
                value={{
                    selectedReport: mockSelectedReport,
                    isReportShared: true,
                    reportMetadata: mockReportMetadata,
                }}
            >
                <CompileShareReports />
            </ReportDataContext.Provider>
        );

        cy.get(ShareReportsState).should('exist');
        cy.get(ShareReports).should('exist');
        cy.get(Modal).should('exist');
    });

    it('renders Modal with Spinner when isReportShared is true and data is loading', () => {
        cy.stub(useFetchShareReportDataModule, 'default').returns({
            data: { ssrUsersList: null, sharedReportUsers: null },
            isLoading: true,
        });

        cy.mount(
            <ReportDataContext.Provider
                value={{
                    selectedReport: mockSelectedReport,
                    isReportShared: true,
                    reportMetadata: mockReportMetadata,
                }}
            >
                <CompileShareReports />
            </ReportDataContext.Provider>
        );

        cy.get(Modal).should('exist');
        cy.get(Spinner).should('exist');
    });

    it('renders Modal with ShareReports when isReportShared is true and data is loaded', () => {
        cy.stub(useFetchShareReportDataModule, 'default').returns({
            data: {
                ssrUsersList: mockUsers,
                sharedReportUsers: mockSharedUsers,
            },
            isLoading: false,
        });

        // Mock the conditions to render Modal branch
        const contextValue = {
            selectedReport: mockSelectedReport,
            isReportShared: true,
            reportMetadata: mockReportMetadata,
        };

        cy.mount(
            <ReportDataContext.Provider value={contextValue}>
                <CompileShareReports />
            </ReportDataContext.Provider>
        );

        // Either ShareReportsState or Modal should exist based on the implementation
        cy.get('body').then($body => {
            if ($body.find('.ui-theme-root.ecsc-permission-modal').length > 0) {
                cy.get(Modal).should('exist');
                cy.get(ShareReports).should('exist');
                cy.get(Spinner).should('not.exist');
            } else {
                cy.get(ShareReportsState).should('exist');
                cy.get(ShareReports).should('exist');
            }
        });
    });

    it('renders nothing when isReportShared is false', () => {
        cy.stub(useFetchShareReportDataModule, 'default').returns({
            data: { ssrUsersList: null, sharedReportUsers: null },
            isLoading: false,
        });

        cy.mount(
            <ReportDataContext.Provider
                value={{
                    selectedReport: mockSelectedReport,
                    isReportShared: false,
                    reportMetadata: mockReportMetadata,
                }}
            >
                <CompileShareReports />
            </ReportDataContext.Provider>
        );

        cy.get(Modal).should('exist');
        cy.get(ShareReportsState).should('exist');
        cy.get(ShareReports).should('exist');
    });

    it('computes correct context values for ShareReportsState', () => {
        const useFetchSpy = cy.stub(useFetchShareReportDataModule, 'default').returns({
            data: {
                ssrUsersList: mockUsers,
                sharedReportUsers: mockSharedUsers,
            },
            isLoading: false,
        });
        
        const shareReportsStateStub = cy.stub();
        cy.stub(React, 'useMemo').callsFake((fn) => {
            const result = fn();
            shareReportsStateStub(result);
            return result;
        });

        cy.mount(
            <ReportDataContext.Provider
                value={{
                    selectedReport: mockSelectedReport,
                    isReportShared: true,
                    reportMetadata: mockReportMetadata,
                }}
            >
                <CompileShareReports />
            </ReportDataContext.Provider>
        );

        cy.wrap(shareReportsStateStub).should('be.calledWithMatch', {
            showAccessMenuButton: false,
            usersHasAccess: Cypress.sinon.match.array,
            usersNoAccess: Cypress.sinon.match.array,
            isAccessUpdated: false,
        });
    });
});