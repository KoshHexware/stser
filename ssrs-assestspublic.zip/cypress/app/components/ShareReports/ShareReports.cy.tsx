import React from 'react';
import { CompileReportContextWrapper } from '../../../support/CompileReportContextWrapper';
import ShareReports from '../../../../src/app/components/ShareReports';
import usersHasAccessToReport from '../../../fixtures/usersHasAccessToReport.json';
import usersWithNoAccessToReport from '../../../fixtures/usersWithNoAccessToReport.json';
import ReportService from '../../../../src/services/ReportService';
import ssrUsersList from '../../../fixtures/ssrUsersList.json';
import sharedReportUsers from '../../../fixtures/sharedReportUsers.json';

describe('ShareReports Modal Component', () => {
    let mockReportData;
    let mockShareReportsData;

    beforeEach(() => {
        mockReportData = {
            setIsReportShared: cy.stub().as('setIsReportSharedHandler'),
            selectedReport: {
                reportName: 'My Users - test',
                id: 'c3ff65b8-b4ac-4ce6-b04a-7ba7e5d11594',
                reportType: 'Custom',
                systemReportName: 'Users',
                description: 'Test report description',
            },
            reportMetadata: {
                id: 'c3ff65b8-b4ac-4ce6-b04a-7ba7e5d11594',
                reportName: 'My Content Profiles',
                systemReportId: 'c3ff65b8-b4ac-4ce6-b04a-7ba7e5d11594',
                systemReportName: 'Content Profiles',
                description: 'Test report metadata description',
                ownerUserName: 'asinha',
                ownerUserId: 'ea2ae9d6-674d-49ae-b294-24d4c088df81',
                reportType: 'System',
                orderField: 'contentProfileName',
                orderBy: 'ASC_NULLS_LAST',
            },
            setSelectedReport: cy.stub(),
            setReportMetadata: cy.stub(),
            isReportShared: true,
        };

        mockShareReportsData = {
            isAccessUpdated: false,
            searchUser: '',
            searchNoAccessUsersFound: false,
            usersNoAccess: usersWithNoAccessToReport,
            usersHasAccess: usersHasAccessToReport,
            setIsAccessUpdated: cy.stub().as('setIsAccessUpdatedHandler'),
            setSearchUser: cy.stub().as('setSearchUserHandler'),
            setSearchNoAccessUsersFound: cy.stub().as('setSearchNoAccessUsersFoundHandler'),
            setUsersHasAccess: cy.stub().as('setUsersHasAccessHandler'),
            setUsersHasNoAccess: cy.stub().as('setUsersHasNoAccessHandler'),
            updatedUsersAccessList: [],
            setUpdatedUsersAccessList: cy.stub().as('setUpdatedUsersAccessListHandler'),
            setUsersNoAccess: cy.stub().as('setUsersNoAccessHandler'),
            setAccessUpdatedAPIStatus: cy.stub().as('setAccessUpdatedAPIStatusHandler'),
            accessUpdatedAPIStatus: 'idle',
        };

        cy.stub(ReportService, 'getSSRUsersList').resolves(ssrUsersList);
        cy.stub(ReportService, 'getReportSharedUserList').resolves(sharedReportUsers);
        cy.stub(ReportService, 'updateSharedReportsUsersAccessList').resolves(usersHasAccessToReport)
            .as('updateSharedReportsUsersAccessList');
        cy.stub(ReportService, 'getShareRecipients').callsFake((keyword, pageIndex) => {
            const allUsers = [...usersHasAccessToReport, ...usersWithNoAccessToReport];
            const filteredUsers = allUsers.filter(user =>
                user.firstName?.toLowerCase().includes(keyword.toLowerCase()) ||
                user.fullName?.toLowerCase().includes(keyword.toLowerCase()) ||
                user.email?.toLowerCase().includes(keyword.toLowerCase())
            );
            return Promise.resolve({
                items: filteredUsers,
                hasNextPage: false
            });
        }).as('getShareRecipients');

        // Stub clipboard API for copy link functionality
        cy.window().then((win) => {
            cy.stub(win.navigator.clipboard, 'writeText').resolves();
        });

        cy.mount(
            <CompileReportContextWrapper
                reportDataContextValue={mockReportData}
                shareReportsContextValue={mockShareReportsData}
            >
                <ShareReports />
            </CompileReportContextWrapper>
        );
    });

    describe('Modal Structure and Basic Rendering', () => {
        it('should render the ShareReports modal with correct structure', () => {
            cy.get('.ui-theme-root.ecsc-permission-modal').should('be.visible');
            cy.get('.ssrs-analytics-panel-wrapper').should('be.visible');
        });

        it('should render the header with correct title', () => {
            cy.get('.ssrs-analytics-header-wrapper').should('be.visible');
            cy.get('.ssrs-analytics-header-text').should('contain', 'Share report with others');
        });

        it('should have proper modal attributes', () => {
            cy.get('[role="dialog"]').should('exist');
            cy.get('[aria-label*="Share report with others"]').should('exist');
        });

        it('should close modal when close button is clicked', () => {
            cy.get('button[aria-label="Close"]').click();
            cy.get('@setIsReportSharedHandler').should('have.been.calledWith', false);
        });
    });

    describe('Access List Panel', () => {
        it('should render the access list panel with correct structure', () => {
            cy.get('.ssrs-analytics-access-group-list-wrapper').should('exist');
            cy.get('.ssrs-analytics-access-group-title-wrapper')
                .contains('People with access')
                .should('exist');
            cy.get('.ssrs-analytics-access-group-list-inner-wrapper').should('exist');
        });

        it('should render the correct number of access items', () => {
            cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                .find('[data-testid="access-item"], .access-item, div[id]')
                .should('have.length', usersHasAccessToReport.length);
        });

        it('should display user information correctly', () => {
            // Check if user names from fixture are displayed
            if (usersHasAccessToReport.length > 0) {
                const firstUser = usersHasAccessToReport[0];
                cy.contains(firstUser.firstName).should('exist');
            }

            cy.get('._mntl-avatar-user').should('have.length.at.least', usersHasAccessToReport.length);

            // Check if owner tag is displayed
            cy.contains('Owner').should('exist');

        });

    });

    describe('Footer and Action Buttons', () => {
        it('should render footer with correct structure', () => {
            cy.get('.ssrs-access-panel-footer').should('exist');
        });

        it('should render copy link button', () => {
            cy.get('.trk_input_ssrs_share_report_copy_link, button')
                .contains('Copy link')
                .should('be.visible');
        });

        it('should render done button', () => {
            cy.get('button')
                .contains('Done')
                .should('be.visible');
        });

        it('should close modal when done button is clicked', () => {
            cy.get('button')
                .contains('Done')
                .click();

            cy.get('@setIsReportSharedHandler').should('have.been.calledWith', false);
        });
    });

    describe('Loading States', () => {
        it('should show loading spinner during API calls', () => {
            const loadingMockShareReportsData = {
                ...mockShareReportsData,
                accessUpdatedAPIStatus: 'loading'
            };
            cy.mount(
                <CompileReportContextWrapper
                    reportDataContextValue={mockReportData}
                    shareReportsContextValue={loadingMockShareReportsData}
                >
                    <ShareReports />
                </CompileReportContextWrapper>
            );

            cy.get('.ssrs-access-panel-spinner-wrapper')
                .should('be.visible');
        });

        it('should show success message after access update', () => {
            const enhancedShareReportsData = {
                ...mockShareReportsData,
                isAccessUpdated: true,
                accessUpdatedAPIStatus: 'success'
            };
            cy.mount(
                <CompileReportContextWrapper
                    reportDataContextValue={mockReportData}
                    shareReportsContextValue={enhancedShareReportsData}
                >
                    <ShareReports />
                </CompileReportContextWrapper>
            );

            cy.contains('Access updated').should('be.visible');
        });
    });

    describe('Accessibility', () => {
        it('should have proper ARIA labels', () => {
            cy.get('[role="dialog"]').should('exist');
            cy.get('input[placeholder*="Search"]').should('exist');
        });

        it('should have proper heading structure', () => {
            cy.get('h3').should('contain', 'Share report with others');
        });
    });

    describe('Search Functionality', () => {
        beforeEach(() => {
            const SearchTestWrapper = () => {
                const [searchUser, setSearchUser] = React.useState('');
                const [usersHasAccess, setUsersHasAccess] = React.useState(usersHasAccessToReport);
                const [usersNoAccess, setUsersNoAccess] = React.useState([]);
                const [searchNoAccessUsersFound, setSearchNoAccessUsersFound] = React.useState(false);

                const enhancedShareReportsData = {
                    ...mockShareReportsData,
                    searchUser,
                    setSearchUser,
                    usersHasAccess,
                    setUsersHasAccess,
                    usersNoAccess,
                    setUsersNoAccess,
                    setUsersHasNoAccess: setUsersNoAccess,
                    searchNoAccessUsersFound,
                    setSearchNoAccessUsersFound,
                };

                return (
                    <CompileReportContextWrapper
                        reportDataContextValue={mockReportData}
                        shareReportsContextValue={enhancedShareReportsData}
                    >
                        <ShareReports />
                    </CompileReportContextWrapper>
                );
            };

            cy.mount(<SearchTestWrapper />);
        });
        it('should render search input with correct placeholder', () => {
            cy.get('.trk_input_ssrs_share_report_user_search')
                .should('be.visible')
                .find('input')
                .should('have.attr', 'placeholder')
                .and('contain', 'Search and add people or groups');
        });

        it('should have search icon in the input', () => {
            cy.get('.trk_input_ssrs_share_report_user_search')
                .parent()
                .find('svg')
                .should('exist');
        });

        it('should update search value when typing and call setSearchUser', () => {
            const searchTerm = 'Some text';

            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .clear()
                .type(searchTerm, { delay: 50 })
                .should('have.value', searchTerm);

            cy.wait(100);

            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .should('have.value', searchTerm);
        });

        it('should filter users with access based on search term', () => {
            const existingUser = usersHasAccessToReport[0];
            const searchTerm = existingUser.firstName || existingUser.fullName;

            if (searchTerm) {
                cy.get('.trk_input_ssrs_share_report_user_search')
                    .find('input')
                    .clear()
                    .type(searchTerm);

                cy.wait(100);

                cy.get('.ssrs-analytics-access-group-list-wrapper')
                    .should('be.visible');

                cy.get('.ssrs-analytics-access-group-title-wrapper')
                    .contains('People with access')
                    .should('exist');
            }
        });

        it('should show no access users when searching for users without access', () => {
            // Test with a user that exists in no access list
            const noAccessUser = usersWithNoAccessToReport[0];
            const searchTerm = noAccessUser.firstName;

            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .clear()
                .type(searchTerm);

            cy.wait(1000);
            cy.get('@getShareRecipients').should('have.been.called');
            cy.get('.ssrs-analytics-no-access-title-wrapper')
                .contains('People without access')
                .should('exist');
            cy.contains('button', 'Add')
                .should('exist');
        });

        it('should show NoSearchItems when no results found', () => {
            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .clear()
                .type('NonExistentUser12345XYZ');

            cy.wait(200);

            cy.get('.ssrs-access-panel-access-list-panel-content-wrapper')
                .should('be.visible');

            cy.get('.ssrs-access-panel-access-list-panel-content-wrapper')
                .find('.no-search-items')
                .should('exist');
        });

        it('should clear search and show all users when input is cleared', () => {
            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .type('test');

            cy.wait(100);

            cy.get('.trk_input_ssrs_share_report_user_search')
                .find('input')
                .clear();

            cy.wait(100);

            cy.get('.ssrs-analytics-access-group-list-wrapper')
                .should('be.visible');

            cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                .find('div[id]')
                .should('have.length', usersHasAccessToReport.length);
        });
    });

    describe('Access Control Actions', () => {

        beforeEach(() => {
            const SearchTestWrapper = () => {
                const [searchUser, setSearchUser] = React.useState('');
                const [usersHasAccess, setUsersHasAccess] = React.useState(usersHasAccessToReport);
                const [usersNoAccess, setUsersNoAccess] = React.useState([]);
                const [searchNoAccessUsersFound, setSearchNoAccessUsersFound] = React.useState(false);

                const enhancedShareReportsData = {
                    ...mockShareReportsData,
                    searchUser,
                    setSearchUser,
                    usersHasAccess,
                    setUsersHasAccess,
                    usersNoAccess,
                    setUsersNoAccess,
                    setUsersHasNoAccess: setUsersNoAccess,
                    searchNoAccessUsersFound,
                    setSearchNoAccessUsersFound,
                };

                return (
                    <CompileReportContextWrapper
                        reportDataContextValue={mockReportData}
                        shareReportsContextValue={enhancedShareReportsData}
                    >
                        <ShareReports />
                    </CompileReportContextWrapper>
                );
            };

            cy.mount(<SearchTestWrapper />);
        });

        describe('Remove Access Functionality', () => {
            it('should show remove access button for non-owner users', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if (!$item.text().includes('Owner')) {
                            cy.wrap($item)
                                .find('button[data-atmt-id="mntl-button"]')
                                .should('exist');
                        }
                    });
            });

            it('should open menu when clicking on access menu button', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if (!$item.text().includes('Owner')) {
                            cy.wrap($item)
                                .find('button[data-atmt-id="mntl-button"]')
                                .first()
                                .click();

                            cy.get('.ssrs-analytics-dropdown-option-wrapper ,.trk_button_ssrs_share_report_remove_user')
                                .should('be.visible');

                            return false; // Exit the each loop
                        }
                    });
            });

            it('should remove user access when remove button is clicked', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .its('length')
                    .then((initialCount) => {
                        cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                            .find('div[id]')
                            .each(($item) => {
                                if (!$item.text().includes('Owner')) {
                                    cy.wrap($item)
                                        .find('button[data-atmt-id="mntl-button"]')
                                        .first()
                                        .click();

                                    cy.get('.trk_button_ssrs_share_report_remove_user')
                                        .contains('Remove access')
                                        .click();

                                    cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                                        .find('div[id]')
                                        .should('have.length', initialCount - 1);

                                    return false; // Exit the each loop
                                }
                            });
                    });
            });

            it('should not show remove access for owner', () => {

                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .contains('Owner')
                    .parent()
                    .within(() => {
                        cy.get('button[data-atmt-id="mntl-button"]')
                            .should('not.exist');
                    });
            });
        });

        describe('Permission Level - Can View', () => {
            it('should show "Can view" permission level for regular users', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if (!$item.text().includes('Owner')) {
                            cy.wrap($item)
                                .should('contain', 'Can view');
                            return false;
                        }
                    });
            });

            it('should show "Can manage" permission level for owner', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if ($item.text().includes('Owner')) {
                            cy.wrap($item).within(() => {
                                cy.contains('Owner').should('exist');
                                cy.get('.ssrs-analytics-disabled-relation')
                                    .should('contain', 'Can manage');
                            });
                            return false; // Exit the loop once owner is found
                        }
                    });
            });

            it('should allow changing permission level via dropdown', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if (!$item.text().includes('Owner')) {
                            cy.wrap($item)
                                .find('button[data-atmt-id="mntl-button"]')
                                .contains('Can view')
                                .click();

                            cy.get('.ssrs-analytics-dropdown-option-wrapper ,.trk_button_ssrs_share_report_remove_user')
                                .should('be.visible')
                                .and('contain', 'Can view')
                                .and('contain', 'Remove access');

                            return false;
                        }
                    });
            });

            it('should update permission when different level is selected', () => {
                cy.get('.ssrs-analytics-access-group-list-inner-wrapper')
                    .find('div[id]')
                    .each(($item) => {
                        if (!$item.text().includes('Owner')) {
                            cy.wrap($item)
                                .find('button[data-atmt-id="mntl-button"]')
                                .contains('Can view')
                                .click();

                            cy.get('.ssrs-analytics-dropdown-option-wrapper')
                                .contains('Can view')
                                .click();

                            cy.wait(100);
                            
                            cy.wrap($item)
                                .should('contain', 'Can view');

                            return false;
                        }
                    });
            });
        });

        describe('Add User Functionality', () => {
            it('should show add button for users without access when searching', () => {
                const noAccessUser = usersWithNoAccessToReport[0];
                const searchTerm = noAccessUser.firstName;

                if (searchTerm) {
                    cy.get('.trk_input_ssrs_share_report_user_search')
                        .find('input')
                        .clear()
                        .type(searchTerm);

                    cy.wait(1000);

                    cy.get('@getShareRecipients').should('have.been.called');
                    cy.contains('People without access', { timeout: 5000 })
                        .should('exist');
                    cy.get('.trk_link_button_ssrs_share_report_add_user')
                        .contains('Add', { timeout: 5000 })
                        .should('exist');
                }
            });

            it('should add user to access list when add button is clicked', () => {
                const noAccessUser = usersWithNoAccessToReport[0];
                const searchTerm = noAccessUser.firstName || noAccessUser.fullName || noAccessUser.email;

                cy.get('.trk_input_ssrs_share_report_user_search')
                    .find('input')
                    .clear()
                    .type(searchTerm);

                cy.wait(1000);

                cy.get('@getShareRecipients').should('have.been.called');

                cy.contains('People without access', { timeout: 5000 })
                    .should('exist');

                cy.get('.trk_link_button_ssrs_share_report_add_user')
                    .contains('Add')
                    .first()
                    .click({ force: true });

                cy.get('@updateSharedReportsUsersAccessList').should('have.been.called');
            });
        });

    });

});
