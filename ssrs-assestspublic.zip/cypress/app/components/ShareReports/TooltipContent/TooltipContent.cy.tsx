import React from 'react';
import TooltipContent from '../../../../../src/app/components/ShareReports/TooltipContent/TooltipContent';

describe('TooltipContent Component', () => {
    const mountComponent = (props = {}) => {
        return cy.mount(<TooltipContent {...props} />);
    };

    describe('Basic Rendering', () => {
        it('should render the wrapper div with correct class', () => {
            mountComponent();

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist');
        });

        it('should render without crashing when no props are provided', () => {
            mountComponent();

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist');
        });

        it('should render empty content when no message is provided', () => {
            mountComponent();

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('be.empty');
        });
    });

    describe('Message Display', () => {
        it('should display the message when provided', () => {
            const message = 'This is a test tooltip message';
            mountComponent({ message });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', message);
        });

        it('should display empty string message', () => {
            mountComponent({ message: '' });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', '');
        });

        it('should handle long messages', () => {
            const longMessage = 'This is a very long tooltip message that might wrap to multiple lines and should be displayed correctly without breaking the layout or functionality of the component';
            mountComponent({ message: longMessage });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', longMessage);
        });

        it('should handle special characters in message', () => {
            const specialMessage = 'Message with special chars: !@#$%^&*()_+-={}[]|\\:";\'<>?,./';
            mountComponent({ message: specialMessage });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', specialMessage);
        });

        it('should handle HTML entities in message', () => {
            const htmlMessage = 'Message with HTML: <div>Test</div> & "quotes"';
            mountComponent({ message: htmlMessage });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', htmlMessage);
        });

        it('should handle numeric message', () => {
            const numericMessage = 12345;
            mountComponent({ message: numericMessage });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', '12345');
        });

        it('should handle null message', () => {
            mountComponent({ message: null });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('exist');
        });

        it('should handle undefined message', () => {
            mountComponent({ message: undefined });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('exist');
        });
    });

    describe('Lock Icon Display', () => {
        it('should not show lock icon by default', () => {
            const message = 'Test message';
            mountComponent({ message });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').within(() => {
                cy.get('svg').should('not.exist');
            });
        });

        it('should not show lock icon when showLockIcon is false', () => {
            const message = 'Test message';
            mountComponent({ message, showLockIcon: false });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').within(() => {
                cy.get('svg').should('not.exist');
            });
        });

        it('should show lock icon when showLockIcon is true', () => {
            const message = 'Test message';
            mountComponent({ message, showLockIcon: true });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').within(() => {
                cy.get('svg').should('exist');
            });
        });


        it('should show lock icon without message', () => {
            mountComponent({ showLockIcon: true });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').within(() => {
                cy.get('svg').should('exist');
            });
        });
    });

    describe('Combined Props', () => {
        it('should display both lock icon and message when both props are provided', () => {
            const message = 'Secure tooltip message';
            mountComponent({ message, showLockIcon: true });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').within(() => {
                cy.get('svg').should('exist');
                cy.contains(message).should('exist');
            });
        });
    });


    describe('Accessibility', () => {
        it('should render semantic content', () => {
            const message = 'Accessible tooltip message';
            mountComponent({ message, showLockIcon: true });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', message)
                .within(() => {
                    cy.get('svg').should('exist');
                });
        });

        it('should have proper text content for screen readers', () => {
            const message = 'Screen reader friendly message';
            mountComponent({ message });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('contain.text', message);
        });

        it('should handle empty content for accessibility', () => {
            mountComponent();

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist');
        });
    });

    describe('Edge Cases', () => {
        it('should handle null props gracefully', () => {
            mountComponent({ message: null, showLockIcon: null });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist');
        });

        it('should handle undefined props gracefully', () => {
            mountComponent({ message: undefined, showLockIcon: undefined });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist');
        });

        it('should handle mixed valid and invalid props', () => {
            mountComponent({ message: 'Valid message', showLockIcon: null });

            cy.get('.ssrs-analytics-tooltip-content-wrapper')
                .should('exist')
                .should('contain.text', 'Valid message');
        });
    });

    describe('Performance', () => {
        it('should render quickly without delays', () => {
            const startTime = Date.now();
            
            mountComponent({ message: 'Performance test', showLockIcon: true });

            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('exist').then(() => {
                const renderTime = Date.now() - startTime;
                expect(renderTime).to.be.lessThan(100);
            });
        });

        it('should handle rapid prop changes efficiently', () => {
            mountComponent({ message: 'Initial message', showLockIcon: false });
            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('contain.text', 'Initial message');

            mountComponent({ message: 'Updated message', showLockIcon: true });
            cy.get('.ssrs-analytics-tooltip-content-wrapper').should('contain.text', 'Updated message');
            cy.get('.ssrs-analytics-tooltip-content-wrapper svg').should('exist');
        });
    });
});