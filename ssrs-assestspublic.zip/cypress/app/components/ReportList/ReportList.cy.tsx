import React from 'react';
import { ReportsList } from '../../../../src/app/components/ReportsList';
import { ReportDataContext, AllReportsLandingPageContext } from '../../../../src/contexts';
import ReportService from '../../../../src/services/ReportService';
import { MemoryRouter } from 'react-router-dom';
import { Screens } from '../../../../src/contexts/types';
import * as CommonServicesContext from '../../../../src/contexts/CommonServicesContext';
import * as UserSettingsHooks from '../../../../src/contexts/CommonServicesContext';
import * as AccessLevelHooks from '../../../../src/contexts/CommonServicesContext';
import { EDITOR_ACCESS_LEVEL, VIEWER_ACCESS_LEVEL } from '../../../../src/utils/constants';

describe('ReportsList Component', () => {
    let mockReportDataContext;
    let mockAllReportsLandingPageContext;

    const mockReportsData = {
        data: [
            {
                id: '1',
                reportName: 'Test Report 1',
                description: 'Test Description 1',
                systemReportName: 'System Report 1',
                reportType: 'custom',
                ownerUserId: 'test-user-id',
                ownerUserName: 'Test User',
                lastViewed: '2023-06-01T12:00:00Z',
                lastUpdated: '2023-06-01T12:00:00Z',
                sharedOn: '2023-05-01T12:00:00Z',
            },
            {
                id: '2',
                reportName: 'Test Report 2',
                description: 'Test Description 2',
                systemReportName: '',
                reportType: 'system',
                ownerUserId: 'other-user-id',
                ownerUserName: 'Other User',
                lastViewed: '2023-06-02T12:00:00Z',
                lastUpdated: '2023-06-02T12:00:00Z',
                sharedOn: null,
            },
        ],
        totalRecords: 2,
    };

    beforeEach(() => {
        if (typeof (window as any).process === 'undefined') {
            (window as any).process = { env: {} };
        }       
        mockReportDataContext = {
            setSelectedReport: cy.stub().as('setSelectedReport'),
            selectedReport: {},
        };

        mockAllReportsLandingPageContext = {
            setLastScreen: cy.stub().as('setLastScreen'),
            setCurrentScreen: cy.stub().as('setCurrentScreen'),
            setUpdatedReportsFilterOption: cy.stub().as('setUpdatedReportsFilterOption'),
            updatedReportsFilterOption: 'all',
        };

        // Stub ReportService methods
        cy.stub(ReportService, 'getReports').as('getReports').resolves(mockReportsData);
        cy.stub(ReportService, 'getRecentReports').as('getRecentReports').resolves(mockReportsData);
        cy.stub(ReportService, 'updateReportFilterOption').as('updateReportFilterOption').resolves({});

        // Stub the imported hooks with proper module paths
        cy.stub(CommonServicesContext, 'useApplicationInfo').returns({
            User: { UserId: 'test-user-id' }
        });

        cy.stub(CommonServicesContext, 'useMantleTranslations').returns({
            languageCode: 'en',
            mantleTranslations: {}
        });

        // If these are separate hook files, stub them individually
        cy.stub(UserSettingsHooks, 'useUserSettings').returns({
            reportsFilterOption: 'all'
        });

        cy.stub(AccessLevelHooks, 'useAccessLevel').returns(EDITOR_ACCESS_LEVEL);

        // Stub useHistory from react-router-dom
        const mockHistory = {
            push: cy.stub().as('historyPush'),
            goBack: cy.stub(),
            listen: cy.stub(),
            location: { pathname: '/selfservicereports' },
            replace: cy.stub()
        };
        cy.stub(require('react-router-dom'), 'useHistory').returns(mockHistory);

        cy.viewport(1200, 800);
    });

    function mountComponent(accessLevel = EDITOR_ACCESS_LEVEL, selectedReportType = 'all') {
        // Override the access level stub if needed
        cy.stub(AccessLevelHooks, 'useAccessLevel').returns(accessLevel);
        mockAllReportsLandingPageContext = {
            ...mockAllReportsLandingPageContext,
            updatedReportsFilterOption: selectedReportType
        };

        cy.mount(
            <MemoryRouter>
                <ReportDataContext.Provider value={mockReportDataContext}>
                    <AllReportsLandingPageContext.Provider value={mockAllReportsLandingPageContext}>
                        <ReportsList />
                    </AllReportsLandingPageContext.Provider>
                </ReportDataContext.Provider>
            </MemoryRouter>
        );
    }

    it('should render the reports list', () => {
        mountComponent();
        cy.get('.report-list-container').should('exist');
        cy.get('.report-list-filters-container').should('exist');
    });

    it('should set initial context values on load', () => {
        mountComponent();
        cy.get('@setCurrentScreen').should('have.been.calledWith', Screens.REPORTS_LIST);
        cy.get('@setLastScreen').should('have.been.calledWith', Screens.REPORTS_LIST);
        cy.get('@setSelectedReport').should('have.been.calledWith', {});
    });

    it('should fetch reports on initial load', () => {
        mountComponent();
        cy.get('@getReports').should('have.been.called');
    });

    it('should display the correct number of reports', () => {
        mountComponent();
        cy.contains('2 Items').should('exist');
    });

    it('should update report filter when selection changes', () => {
        mountComponent();

        // Wait for component to load
        cy.get('.report-list-filters-container').should('exist');

        // Look for the filter dropdown
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('My reports').click();

        cy.get('@updateReportFilterOption').should('have.been.calledWith', 'owned');
        cy.get('@setUpdatedReportsFilterOption').should('have.been.calledWith', 'owned');
    });

    it('should handle shared reports data source getRows method', () => {
        const mockSharedReportsData = {
            data: [
                {
                    id: '3',
                    reportName: 'Shared Report 1',
                    description: 'Shared Description 1',
                    reportType: 'shared',
                    ownerUserId: 'other-user-id',
                    ownerUserName: 'Other User',
                    lastViewed: '2023-06-01T12:00:00Z',
                    lastUpdated: '2023-06-01T12:00:00Z',
                    sharedOn: '2023-05-01T12:00:00Z',
                }
            ],
            totalRecords: 1,
        };

        // Reset the stub to return the shared reports data
        cy.get('@getReports').then((stub) => {
            stub.resetBehavior();
            stub.resolves(mockSharedReportsData);
        });

        mountComponent(EDITOR_ACCESS_LEVEL, 'shared');

        // Switch to shared reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Shared with me').click();

        cy.get('@getReports').should('have.been.calledWith',
            Cypress.sinon.match.number,
            Cypress.sinon.match.number,
            'shared',
            Cypress.sinon.match.any,
            Cypress.sinon.match.any,
            Cypress.sinon.match.any
        );
    });

    it('should handle shared reports data source with search term', () => {
        const mockSharedReportsData = {
            data: [],
            totalRecords: 0,
        };

        // Reset the stub to return the shared reports data
        cy.get('@getReports').then((stub) => {
            stub.resetBehavior();
            stub.resolves(mockSharedReportsData);
        });

        mountComponent();

        // Switch to shared reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Shared with me').click();

        // Add search term
        cy.get('input[placeholder*="Search"]').type('Test Search');

        // Wait for debounced search
        cy.wait(500);

        cy.get('@getReports').should('have.been.calledWith',
            Cypress.sinon.match.number,
            Cypress.sinon.match.number,
            'shared',
            Cypress.sinon.match.any,
            Cypress.sinon.match.any,
            Cypress.sinon.match.any
        );
    });

    it('should handle shared reports data source with sorting', () => {
        const mockSharedReportsData = {
            data: [],
            totalRecords: 0,
        };

        cy.get('@getReports').then((stub) => {
            stub.resetBehavior();
            stub.resolves(mockSharedReportsData);
        });

        mountComponent();

        // Switch to shared reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Shared with me').click();

        // Click on a column header to sort (assuming reportName column exists)
        cy.get('[col-id="reportName"]').click();

        cy.get('@getReports').should('have.been.calledWith',
            Cypress.sinon.match.number,
            Cypress.sinon.match.number,
            'shared',
            Cypress.sinon.match.any,
            Cypress.sinon.match.any,
            Cypress.sinon.match.any
        );
    });

    it('should configure column definitions for owned reports filter', () => {
        mountComponent();

        // Switch to owned reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('My reports').click();

        // Verify that the grid shows columns appropriate for owned reports
        // Should have lastViewed column with desc sort but not sharedOn column
        cy.get('.ag-header-cell[col-id="lastViewed"]').should('exist');
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('exist');

        // Verify initial sort is applied to lastViewed column
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-viewed > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label > .ag-sort-indicator-container > .ag-sort-descending-icon').should('exist');
    });

    it('should configure column definitions for system reports filter', () => {
        mountComponent();

        // Switch to system reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Standard reports').click();

        // Verify that the grid shows columns appropriate for system reports
        // Should have lastUpdated column with desc sort but not ownerUserName or sharedOn columns
        cy.get('.ag-header-cell[col-id="lastUpdated"]').should('exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');

        // Verify initial sort is applied to lastUpdated column
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-updated').should('exist');
    });

    it('should configure column definitions for all reports filter', () => {
        mountComponent();

        // Default filter should be 'all reports'
        cy.get('.report-list-filters-container').should('exist');

        // Verify that the grid shows columns appropriate for all reports
        // Should have lastUpdated column with desc sort but not sharedOn column
        cy.get('.ag-header-cell[col-id="lastUpdated"]').should('exist');
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('exist');

        // Verify initial sort is applied to lastUpdated column
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-updated').should('exist');
    });

    it('should configure column definitions for shared reports filter', () => {
        const mockSharedReportsData = {
            data: [
                {
                    id: '3',
                    reportName: 'Shared Report 1',
                    description: 'Shared Description 1',
                    reportType: 'shared',
                    ownerUserId: 'other-user-id',
                    ownerUserName: 'Other User',
                    lastViewed: '2023-06-01T12:00:00Z',
                    lastUpdated: '2023-06-01T12:00:00Z',
                    sharedOn: '2023-05-01T12:00:00Z',
                }
            ],
            totalRecords: 1,
        };

        cy.get('@getReports').then((stub) => {
            stub.resetBehavior();
            stub.resolves(mockSharedReportsData);
        });

        mountComponent();

        // Switch to shared reports filter
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Shared with me').click();

        // Verify that the grid shows columns appropriate for shared reports
        // Should include all columns including sharedOn
        cy.get('.ag-header-cell[col-id="lastUpdated"]').should('exist');
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('exist');

        // Verify initial sort is applied to lastUpdated column
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-updated').should('exist');
    });

    it('should handle column visibility changes when switching between filter types', () => {
        mountComponent();

        // Start with all reports (default) - should not show sharedOn
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('exist');

        // Switch to owned reports - should not show sharedOn
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('My reports').click();
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('exist');

        // Switch to system reports - should not show sharedOn or ownerUserName
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Standard reports').click();
        cy.get('.ag-header-cell[col-id="sharedOn"]').should('not.exist');
        cy.get('.ag-header-cell[col-id="ownerUserName"]').should('not.exist');
    });

    it('should apply correct initial sort for different report types', () => {
        mountComponent();

        // Test owned reports - should sort by lastViewed desc
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('My reports').click();
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-viewed > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label > .ag-sort-indicator-container > .ag-sort-descending-icon').should('exist');
        cy.get('.ag-header-cell[col-id="lastUpdated"] .ag-sort-indicator').should('not.exist');

        // Test system reports - should sort by lastUpdated desc
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('Standard reports').click();
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-viewed > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label > .ag-sort-indicator-container > .ag-sort-descending-icon').should('exist');
        cy.get('.ag-header-cell[col-id="lastViewed"] .ag-sort-indicator').should('not.exist');

        // Test all reports - should sort by lastUpdated desc
        cy.get('[data-testid="filter-dropdown"]').click();
        cy.contains('All reports').click();
        cy.get('.trk_button_ssrs-reports_list-sortable-column-header-last-viewed > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label > .ag-sort-indicator-container > .ag-sort-descending-icon').should('exist');
    });

    it('should maintain column definitions consistency across filter switches', () => {
        mountComponent();

        // Verify basic columns exist initially
        cy.get('.ag-header-cell[col-id="reportName"]').should('exist');
        cy.get('.ag-header-cell[col-id="description"]').should('exist');

        // Switch between filters and verify core columns remain
        const filters = ['My reports', 'Standard reports', 'All reports'];

        filters.forEach(filter => {
            cy.get('[data-testid="filter-dropdown"]').click();
            cy.contains(filter).click();

            // Core columns should always be present
            cy.get('.ag-header-cell[col-id="reportName"]').should('exist');
            cy.get('.ag-header-cell[col-id="description"]').should('exist');
        });
    });

});