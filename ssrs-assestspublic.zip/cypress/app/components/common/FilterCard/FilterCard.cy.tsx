import React from 'react';
import FilterCard from '../../../../../src/app/components/common/FilterCard/FilterCard';
import { CompileReportContext, AllReportsLandingPageContext } from '../../../../../src/contexts';
import { Screens } from '../../../../../src/contexts/types';
import { FILTER_TYPE, IFilterDataType, IBooleanOperations, INullishOperations, ITextOperations } from '../../../../../src/interfaces/IFilterTypes';
import { VIEWER_ACCESS_LEVEL } from '../../../../../src/utils/constants';
import * as CommonServicesContext from '../../../../../src/contexts/CommonServicesContext';

describe('FilterCard Component', () => {

    let mockRemoveFilter;
    let mockSetIsFilterCardClicked;
    let mockSetCurrentSelectedFilter;

    const defaultFilter = {
        id: '1',
        filterName: 'testFilter',
        uxLabel: 'Test Filter',
        dataType: IFilterDataType.TEXT,
        filterType: FILTER_TYPE.FREETEXT,
        values: ['Test Value'],
        operation: ITextOperations.EQUALS,
        allowedOperators: [{ name: 'Equals', uxLabel: 'is' }],
        isNewlyAdded: false
    };

    beforeEach(() => {
        const mockRemoveFilter = cy.stub().as('removeFilterStub');
        const mockSetIsFilterCardClicked = cy.stub().as('setIsFilterCardClickedStub');
        const mockSetCurrentSelectedFilter = cy.stub().as('setCurrentSelectedFilterStub');

        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext)
            .returns({
                setIsFilterCardClicked: mockSetIsFilterCardClicked,
                isFilterCardClicked: false,
                setCurrentSelectedFilter: mockSetCurrentSelectedFilter,
                currentSelectedFilter: { filterName: '' },
                id: '123',
                reportName: 'Test Report'
            })
            .withArgs(AllReportsLandingPageContext)
            .returns({
                currentScreen: Screens.EDIT_REPORT
            });

        cy.stub(CommonServicesContext, 'useAccessLevel').returns('editor');
    });

    it('renders filter card with correct label and value', () => {
        cy.mount(
            <FilterCard filter={defaultFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item-title').should('contain', 'Test Filter');
        cy.get('.filter-card-content-item-value').should('contain', 'is Test Value');
    });

    it('selects filter on click', () => {
        cy.mount(
            <FilterCard filter={defaultFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item').click();

        cy.get('@setIsFilterCardClickedStub').should('have.been.calledWith', true);
        cy.get('@setCurrentSelectedFilterStub').should('have.been.calledWith', defaultFilter);
    });

    it('selects filter on Enter key press', () => {
        cy.mount(
            <FilterCard filter={defaultFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item').trigger('keydown', { key: 'Enter' });

        cy.get('@setIsFilterCardClickedStub').should('have.been.calledWith', true);
        cy.get('@setCurrentSelectedFilterStub').should('have.been.calledWith', defaultFilter);
    });

    it('displays boolean filter value correctly', () => {
        const booleanFilter = {
            ...defaultFilter,
            dataType: IFilterDataType.BOOLEAN,
            operation: IBooleanOperations.EQUALS,
            values: ['True']
        };

        cy.mount(
            <FilterCard filter={booleanFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item-value').should('contain', 'is True');
    });

    it('displays date filter value correctly', () => {
        const dateFilter = {
            ...defaultFilter,
            dataType: IFilterDataType.DATE,
            values: ['2023-05-15T00:00:00.000Z']
        };

        cy.mount(
            <FilterCard filter={dateFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item-value').should('contain', 'is');
        cy.get('.bold-text').should('exist');
    });

    it('displays blank/not blank operation with no value correctly', () => {
        const blankFilter = {
            ...defaultFilter,
            operation: INullishOperations.BLANK,
            values: [],
            allowedOperators: [{ name: INullishOperations.BLANK, uxLabel: '-' }]
        };

        cy.mount(
            <FilterCard filter={blankFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item-value').should('contain', '-');
    });

    it('displays multiple values correctly', () => {
        const multiValueFilter = {
            ...defaultFilter,
            values: ['Value 1', 'Value 2'],
            filterType: FILTER_TYPE.DOMAIN_OF_VALUES
        };

        cy.mount(
            <FilterCard filter={multiValueFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item-value').should('contain', 'Value 1');
        cy.get('.filter-value-count').should('contain', '+1');
    });

    it('truncates long single value and shows tooltip', () => {
        const longValueFilter = {
            ...defaultFilter,
            values: ['This is a very long value that exceeds twenty five characters and should be truncated'],
            filterType: FILTER_TYPE.PICKLIST
        };

        cy.mount(
            <FilterCard filter={longValueFilter} onRemoveFilter={mockRemoveFilter} />
        );

        // Check that the value is truncated (should show first 25 characters + ...)
        cy.get('.filter-card-content-item-value').should('exist').then(($el) => {
            const el = $el[0] as HTMLElement;
            const style = window.getComputedStyle(el);
            const indicatesEllipsis =
                (style.textOverflow && style.textOverflow.includes('ellipsis')) ||
                style.whiteSpace === 'nowrap' ||
                style.overflow === 'hidden';
            expect(indicatesEllipsis, 'element should be styled to truncate with ellipsis').to.be.true;
        });
        cy.get('.bold-text').trigger('mouseover');
        cy.get('[data-tippy-root]').should('not.exist');
    });

    it('does not truncate short single value and no tooltip', () => {
        const shortValueFilter = {
            ...defaultFilter,
            values: ['Short value'],
            filterType: FILTER_TYPE.DOMAIN_OF_VALUES
        };

        cy.mount(
            <FilterCard filter={shortValueFilter} onRemoveFilter={mockRemoveFilter} />
        );

        // Check that the value is not truncated
        cy.get('.bold-text').should('contain', 'Short value');
        cy.get('.bold-text').should('not.contain', '...');

        // Check that no tooltip appears on hover since value is short
        cy.get('.bold-text').trigger('mouseover');
        cy.get('[data-tippy-root]').should('not.exist');
    });

    it('cannot show remove button in view report mode', () => {
        cy.stub(CommonServicesContext, 'useAccessLevel').returns(VIEWER_ACCESS_LEVEL);
        cy.mount(
            <FilterCard filter={defaultFilter} onRemoveFilter={mockRemoveFilter} />
        );

        cy.get('.filter-card-content-item').trigger('mouseenter');
        cy.get('.filter-card-remove').should('not.exist');
    });

    it('scrolls into view when filter is newly added', () => {
        const scrollIntoViewSpy = cy.spy().as('scrollIntoViewSpy');
        cy.stub(Element.prototype, 'scrollIntoView').callsFake(scrollIntoViewSpy);

        cy.mount(
            <FilterCard
                filter={{ ...defaultFilter, isNewlyAdded: true }}
                onRemoveFilter={mockRemoveFilter}
            />
        );

        cy.get('@scrollIntoViewSpy').should('have.been.calledOnce');
    });

    it('should set operation to EQUALS for Boolean filter with default values and no operation', () => {
        const filter = {
            dataType: IFilterDataType.BOOLEAN,
            filterDefaultValues: [true],
            operation: undefined, // No operation specified
            filterName: 'isActive',
            uxLabel: 'Is Active',
            values: [true],
            allowedOperators: [{ name: IBooleanOperations.EQUALS, uxLabel: 'Equals' }]
        };

        // Render component with this filter
        cy.mount(<FilterCard filter={filter} />);

        // Verify the operation was automatically set to EQUALS
        cy.get('.filter-card-content-item-value').should('contain', 'Equals');
    });

    it('should set operation to EQUALS for Boolean filter with default values and "none" operation', () => {
        const filter = {
            dataType: IFilterDataType.BOOLEAN,
            filterDefaultValues: [false],
            operation: 'none', // lowercase "none"
            filterName: 'isActive',
            uxLabel: 'Is Active',
            values: [false],
            allowedOperators: [{ name: IBooleanOperations.EQUALS, uxLabel: 'Equals' }]
        };

        cy.mount(<FilterCard filter={filter} />);
        cy.get('.filter-card-content-item-value').should('contain', 'Equals');
    });

    it('should not set operation when filterDefaultValues array is empty', () => {
        const filter = {
            dataType: IFilterDataType.BOOLEAN,
            filterDefaultValues: [], // Empty array
            operation: undefined,
            filterName: 'isActive',
            uxLabel: 'Is Active',
            values: [true],
            allowedOperators: [{ name: IBooleanOperations.EQUALS, uxLabel: 'Equals' }]
        };

        const originalOperation = filter.operation;

        cy.mount(<FilterCard filter={filter} />);

        // Operation should not be changed
        cy.wrap(filter).then(f => {
            expect(f.operation).to.equal(originalOperation);
        });
    });

    it('should not set operation when filterDefaultValues is undefined', () => {
        const filter = {
            dataType: IFilterDataType.BOOLEAN,
            filterDefaultValues: undefined, // undefined, not using optional chaining
            operation: undefined,
            filterName: 'isActive',
            uxLabel: 'Is Active',
            values: [true],
            allowedOperators: [{ name: IBooleanOperations.EQUALS, uxLabel: 'Equals' }]
        };

        const originalOperation = filter.operation;

        cy.mount(<FilterCard filter={filter} />);

        // Operation should not be changed
        cy.wrap(filter).then(f => {
            expect(f.operation).to.equal(originalOperation);
        });
    });

    it('should not set operation for non-Boolean filters', () => {
        const filter = {
            dataType: IFilterDataType.TEXT, // Not BOOLEAN
            filterDefaultValues: [true],
            operation: undefined,
            filterName: 'status',
            uxLabel: 'Status',
            values: ['Active'],
            allowedOperators: [{ name: 'contains', uxLabel: 'Contains' }]
        };

        const originalOperation = filter.operation;

        cy.mount(<FilterCard filter={filter} />);

        // Operation should not be changed
        cy.wrap(filter).then(f => {
            expect(f.operation).to.equal(originalOperation);
        });
    });

    it('should not override an already specified valid operation', () => {
        const filter = {
            dataType: IFilterDataType.BOOLEAN,
            filterDefaultValues: [true],
            operation: IBooleanOperations.NOT_EQUALS, // Already has a valid operation
            filterName: 'isActive',
            uxLabel: 'Is Active',
            values: [true],
            allowedOperators: [
                { name: IBooleanOperations.EQUALS, uxLabel: 'Equals' },
                { name: IBooleanOperations.NOT_EQUALS, uxLabel: 'Not Equals' }
            ]
        };

        cy.mount(<FilterCard filter={filter} />);

        // Operation should remain NOT_EQUALS, not changed to EQUALS
        cy.get('.filter-card-content-item-value').should('contain', 'Not Equals');
        cy.wrap(filter).then(f => {
            expect(f.operation).to.equal(IBooleanOperations.NOT_EQUALS);
        });
    });
});