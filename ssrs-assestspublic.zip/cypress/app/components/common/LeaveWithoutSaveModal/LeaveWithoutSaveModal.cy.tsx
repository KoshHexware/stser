import React from 'react';
import LeaveWithoutSaveModal from '../../../../../src/app/components/common/LeaveWithoutSaveModal/LeaveWithoutSaveModal';
import { CompileReportContext, ReportDataContext } from '../../../../../src/contexts';
import * as i18n from 'react-i18next';
import { CUSTOM_REPORT_EDITOR_ACCESS_LEVEL, EDITOR_ACCESS_LEVEL } from '../../../../../src/utils/constants';
import * as CommonServicesContext from '../../../../../src/contexts/CommonServicesContext';

describe('LeaveWithoutSaveModal Component', () => {
    // Test case 1: Basic rendering
    it('renders the modal when showLeaveWithoutSaveModal is true', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        // Setup context stubs
        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: '123' }
            });

        // Mount component
        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Assertions for rendered content
        cy.get('.leave-without-save-modal-main-mntl-component').should('exist');
        cy.get('.leave-without-save-modal-header-text').should('contain', 'Leave without saving?');
        cy.get('.leave-without-save-modal-description-text-div').should('exist');
        cy.get('.leave-without-save-modal-description-text-div')
            .should('have.text', 'You have unsaved changes. Are you sure you’d like to navigate away without saving?');
        cy.get('button').contains('Discard changes').should('exist');
        cy.get('button').contains('Save and leave').should('exist');
    });

    // Test case 2: Save and leave for owner of custom report
    it('calls onSave when "Save and leave" is clicked by report owner', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        // Stub hooks
        cy.stub(i18n, 'useTranslation').returns({
            t: (key, defaultValue) => defaultValue || key
        });

        // Mock the access level functions
        //cy.stub(CommonServicesContext, 'useAccessLevel').returns(EDITOR_ACCESS_LEVEL);
        cy.stub(CommonServicesContext, 'useApplicationInfo').returns({ User: { UserId: 'System' } });

        // Setup context stubs
        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: 'System' }
            });

        // Mount component
        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Click save and leave
        cy.get('button').contains('Save and leave').click();

        // Verify onSave was called with correct parameters
        cy.get('@onSaveMock').should('be.calledWith', true, false);
        cy.get('@setShowLeaveWithoutSaveModalMock').should('be.calledWith', false);
        cy.get('@onSaveCopyMock').should('not.be.called');
    });

    // Test case 3: Save and leave for system reports
    it('calls onSaveCopy when "Save and leave" is clicked for system reports', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        // Setup context stubs
        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: '123' }
            });

        // Mount component
        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Click save and leave
        cy.get('button').contains('Save and leave').click();

        // Verify onSaveCopy was called
        cy.get('@onSaveCopyMock').should('be.called');
        cy.get('@setShowLeaveWithoutSaveModalMock').should('be.calledWith', false);
        cy.get('@onSaveMock').should('not.be.called');
    });

    // Test case 4: Save copy for non-owners with editor access
    it('calls onSaveCopy when "Save and leave" is clicked by non-owner with editor access', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        // Setup as non-owner with editor access
        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: '123' }
            });

        cy.stub(i18n, 'useTranslation').returns({
            t: (key, defaultValue) => defaultValue || key
        });

        cy.stub(CommonServicesContext, 'useAccessLevel').returns(EDITOR_ACCESS_LEVEL);
        cy.stub(CommonServicesContext, 'useApplicationInfo').returns({
            User: { UserId: '123' } // Different from owner
        });

        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Click save and leave
        cy.get('button').contains('Save and leave').click();

        // Verify onSaveCopy was called
        cy.get('@onSaveCopyMock').should('be.called');
        cy.get('@setShowLeaveWithoutSaveModalMock').should('be.calledWith', false);
        cy.get('@onSaveMock').should('not.be.called');
    });

    // Test case 5: Save copy for custom report editor
    it('calls onSaveCopy when "Save and leave" is clicked by user with CUSTOM_REPORT_EDITOR_ACCESS_LEVEL', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: '123' }
            });

        cy.stub(i18n, 'useTranslation').returns({
            t: (key, defaultValue) => defaultValue || key
        });

        cy.stub(CommonServicesContext, 'useAccessLevel').returns(CUSTOM_REPORT_EDITOR_ACCESS_LEVEL);
        cy.stub(CommonServicesContext, 'useApplicationInfo').returns({
            User: { UserId: '123' } // Different from owner
        });

        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Click save and leave
        cy.get('button').contains('Save and leave').click();

        // Verify onSaveCopy was called
        cy.get('@onSaveCopyMock').should('be.called');
        cy.get('@setShowLeaveWithoutSaveModalMock').should('be.calledWith', false);
    });

    // Test case 6: Discard changes button
    it('discards changes and navigates to reports list when "Discard changes" is clicked', () => {
        const onSaveMock = cy.stub().as('onSaveMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');
        const goToReportsListMock = cy.stub().as('goToReportsListMock');
        const setShowLeaveWithoutSaveModalMock = cy.stub().as('setShowLeaveWithoutSaveModalMock');

        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                showLeaveWithoutSaveModal: true,
                setShowLeaveWithoutSaveModal: setShowLeaveWithoutSaveModalMock
            })
            .withArgs(ReportDataContext).returns({
                selectedReport: { reportType: 'custom' },
                reportMetadata: { ownerUserId: '123' }
            });

        cy.stub(i18n, 'useTranslation').returns({
            t: (key, defaultValue) => defaultValue || key
        });

        cy.stub(CommonServicesContext, 'useAccessLevel').returns(EDITOR_ACCESS_LEVEL);
        cy.stub(CommonServicesContext, 'useApplicationInfo').returns({
            User: { UserId: '123' }
        });

        cy.mount(
            <LeaveWithoutSaveModal
                onSave={onSaveMock}
                onSaveCopy={onSaveCopyMock}
                goToReportsList={goToReportsListMock}
            />
        );

        // Click discard changes
        cy.get('button').contains('Discard changes').click();

        // Verify modal is closed and navigation occurs
        cy.get('@setShowLeaveWithoutSaveModalMock').should('be.calledWith', false);
        cy.get('@goToReportsListMock').should('be.called');
        cy.get('@onSaveMock').should('not.be.called');
        cy.get('@onSaveCopyMock').should('not.be.called');
    });
});