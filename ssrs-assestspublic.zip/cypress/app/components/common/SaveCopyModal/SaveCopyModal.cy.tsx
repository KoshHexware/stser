import SaveCopyModal from '../../../../../src/app/components/common/SaveCopyModal/SaveCopyModal';
import React from 'react';
import { CompileReportContext, ReportDataContext } from '../../../../../src/contexts';

describe('SaveCopyModal', () => {
    // Use regular variables for non-Cypress values
    const defaultCompileContext = {
        updatedReportName: 'Test Report',
        updatedDescription: 'Test Description',
        setUpdatedReportName: () => { },  // Plain function instead of cy.stub()
        setUpdatedDescription: () => { },  // Plain function instead of cy.stub()
        id: '123',
        reportName: 'Test Report',
        description: 'Test Description',
        allReportsSummary: [
            { reportName: 'Test Report 1', id: 'report-1' },
            { reportName: 'Test Report 2', id: 'report-2' }
        ]
    };

    const defaultReportContext = {
        selectedReport: {
            reportName: 'Selected Report',
            description: 'Selected Description'
        }
    };

    // Setup stub functions inside each test
    beforeEach(() => {
        // Setup common mocks inside the beforeEach hook
        cy.stub(React, 'useContext')
            .callThrough()
            .withArgs(CompileReportContext).returns({
                ...defaultCompileContext,
                setUpdatedReportName: cy.stub().as('setUpdatedReportName'),
                setUpdatedDescription: cy.stub().as('setUpdatedDescription')
            })
            .withArgs(ReportDataContext).returns(defaultReportContext);
    });

    it('should render the modal', () => {
        // Create stubs inside the test
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );
    });

    it('should render the modal with correct title and call onClose when cancel button is clicked', () => {
        // Create stubs inside the test
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );
        cy.get('._mntl-modal-header-content').should('exist');
        cy.contains('Save copy').should('exist');
        cy.contains('button', 'Cancel').click();
        cy.get('@onCloseMock').should('have.been.calledWith', false);
    });

    it('should disable save button when report name is invalid', () => {
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );

        // Enter invalid name (too long)
        cy.get('.custom-report-name').clear().type('Test@');
        cy.contains('button', 'Save copy').should('be.disabled');
    });

    it('should disable save button when description is empty', () => {
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );

        cy.get('.custom-report-description').clear();
        cy.contains('button', 'Save copy').should('be.disabled');
    });

    it('should show character count for description', () => {
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );

        cy.get('.custom-report-description').clear().type('New description');
        cy.get('.desc-count').should('contain', (500 - 'New description'.length).toString());
    });

    it('should call onSaveCopy with trimmed values when save button is clicked', () => {
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );

        cy.get('.custom-report-name').clear().type('  New Report Name  ');
        cy.get('.custom-report-description').clear().type('  New Description  ');
        cy.get('#btnSaveCopy').click();
        cy.get('@onSaveCopyMock').should('have.been.calledWith', 'New Report Name', 'New Description');
    });

    it('should display error message when report name is empty', () => {
        const onCloseMock = cy.stub().as('onCloseMock');
        const onSaveCopyMock = cy.stub().as('onSaveCopyMock');

        cy.mount(
            <SaveCopyModal
                onClose={onCloseMock}
                onSaveCopy={onSaveCopyMock}
            />
        );

        cy.get('.custom-report-name').clear();
        cy.contains('This field is required.').should('exist');
    });
});