import React from 'react';
import { ErrorBoundary } from '../../../../../src/app/components/common/ErrorBoundary';

describe('Testing ErrorBoundary', () => {
  it('Should not display a fallback UI if there is no error', () => {
    cy.mount(<ErrorBoundary> <h1>Hello, World</h1> </ErrorBoundary>)
    cy.contains('Unable to connect').should('not.exist');
  });

  const Foo = () => {
    throw new Error('Oh no');
  };

  it('Should display a fallback UI if there is an error', () => {
    cy.mount(<ErrorBoundary> <Foo /> </ErrorBoundary>)
    cy.get(".mntl-state-view").should("exist");
    cy.get(".mntl-state-view-title").should("exist");
    cy.get(".mntl-state-view-description").should("exist");
  });
});