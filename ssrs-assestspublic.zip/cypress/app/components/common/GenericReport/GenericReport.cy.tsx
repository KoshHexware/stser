import React from 'react';
import { getReportsTablColumnDefs } from '../../../../../src/utils/getReportsTblColumnDefs';
import ReportService from '../../../../../src/services/ReportService';
import ReportMetaData from '../../../../fixtures/ReportMetaData.json';
import ReportData from '../../../../fixtures/ReportData.json';
import { ContextWrapper } from '../../../../support/ContextWrapper';
import { AsyncReportGrid } from '../../../../../src/app/components/common/GenericReport/AsyncReportGrid';
import ReportExporter from '../../../../../src/utils/ReportExporter';

describe('Testing AsyncReportGrid component', () => {
  const contextValue = {
    reportSchema: getReportsTablColumnDefs(ReportMetaData.fields),
    selectedReport: {
      id: '84a5c9a8-5ba2-4e06-8914-c24a18a8236c',
      name: 'user',
    },
    reportMetadata: ReportMetaData,
    setColumnsToExport: () => {},
  };
  beforeEach(() => {
    cy.stub(ReportService, 'getReportMetaData').resolves(ReportMetaData);
    cy.stub(ReportService, 'executeReportById').resolves(ReportData);
    cy.mount(
      <ContextWrapper value={contextValue}>
        <AsyncReportGrid
          initialSkip={5}
          pageSize={5}
          reportId={ReportMetaData.id}
          reportName='user'
          defaultSortField={ReportMetaData.orderField}
          fields={getReportsTablColumnDefs(ReportMetaData.fields)}
          filters={ReportMetaData.filters}
          teamsites={ReportMetaData.teamsites}
        />
      </ContextWrapper>
    );
  });

  describe('Testing external url link and Email fields', () => {
    it('Testing external url and Email', () => {
      cy.mount(
        <ContextWrapper value={contextValue}>
          <AsyncReportGrid
            initialSkip={5}
            pageSize={5}
            reportId={ReportMetaData.id}
            reportName='user'
            defaultSortField={ReportMetaData.orderField}
            fields={getReportsTablColumnDefs(ReportMetaData.fields)}
            filters={ReportMetaData.filters}
          />
        </ContextWrapper>
      ).then(() => {
        it('Should render external url link', () => {
          cy.get('.external-link-cell').should('exist');
          cy.get('.external-link-cell')
            .trigger('mouseover')
            .then(() => {
              cy.get('.copy-icon').should('exist');
            });
          cy.get('.copy-icon')
            .should('exist')
            .click()
            .then(() => {
              cy.contains('.check-filled').should('exist');
            });
        });
        it('Should render the Email field', () => {
          cy.get('.email-cell').should('exist');
          cy.get('.email-value').should('exist');
        });
      });
    });
  });
  describe('Testing default filters without values', () => {
    it('Should not render default filters without values in filters panel', () => {
      cy.mount(
        <ContextWrapper value={contextValue}>
          <AsyncReportGrid
            initialSkip={5}
            pageSize={5}
            reportId={ReportMetaData.id}
            reportName='user'
            defaultSortField={ReportMetaData.orderField}
            fields={getReportsTablColumnDefs(ReportMetaData.fields)}
            filters={ReportMetaData.filters}
          />
        </ContextWrapper>
      ).then(() => {
        it('Should not render default filters without values in filters panel', () => {
          cy.get(
            '.trk_button_ssrs-reports-view-data-grid-toolbar-expand-collapse-filters-section'
          )
            .click()
            .then(() => {
              cy.get('.filter-panel').should('exist');
              cy.get('.filter-panel').find('.filter').should('have.length', 1);
            });
        });
      });
    });
  });
 
});
