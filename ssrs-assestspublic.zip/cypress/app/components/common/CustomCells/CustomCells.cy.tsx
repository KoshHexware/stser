import React from "react";
import {
  NameCell,
  OwnerCell,
  DateCell,
  DateTimeCell,
  DescriptionCell,
  EmailCell,
  ExternalIconCell,
  ReportOwnerCell,
  ReportDateCell,
  ReportDateTimeCell,
  ReportExternalIconCell,
  ReportEmailCell,
  ReportCustomCell
} from "../../../../../src/app/components/common/CustomCells";

describe("Testing Custom cells components", () => {
  describe("NameCell", () => {
    it('should render the NameCell component with correct data', () => {
      const mockData = {
        reportType: 'Custom',
        reportName: 'Sample Report',
        description: 'This is a sample report description.',
      };
      cy.mount(<NameCell data={mockData} value={mockData.reportName} />);
      cy.get('.icon-host').should('exist');
      cy.get('.report-name').should('contain.text', mockData.reportName);
    });
    it("should render dash when NameCell value is empty", () => {
      cy.mount(<NameCell data={{ reportName: "" }} value="" />);
      cy.get('p').should("contain.text", "-");
    });
  });

  describe("DescriptionCell", () => {
    it("DescriptionCell tests", () => {
      const mockData = {
        description: "This is a sample description with multiple lines.\nSecond line of description."
      };
      cy.mount(<DescriptionCell data={mockData} value={mockData.description} />);
      cy.get('.description-text').should("contain.text", mockData.description);
    });
    it("should render dash when DescriptionCell value is empty", () => {
      cy.mount(<DescriptionCell data={{}} value="" />);
      cy.get('p').should("contain.text", "-");
    });
    it("should highlight search terms in DescriptionCell", () => {
      const mockData = {
        description: "This is a sample description"
      };
      cy.mount(<DescriptionCell data={mockData} value={mockData.description} context="sample" />);
      cy.get('.custom-highlighter-mark-tag').should('exist');
    });
  });

  describe("OwnerCell", () => {
    it("OwnerCell tests", () => {
      cy.mount(<OwnerCell data={{ thumbnailUrl: "" }} value={"Jhon roan"} />);
      cy.contains("Jhon roan").should("exist");
      cy.contains("Jr").should("exist");
    });
    it("should render dash when OwnerCell value is empty", () => {
      cy.mount(<OwnerCell data={{}} value="" />);
      cy.get('p').should("contain.text", "-");
    });
  });

  describe("DateCell", () => {
    it("DateCell tests", () => {
      cy.mount(<DateCell value="2026-01-01" />);
      cy.get('span').should("contain.text", "Jan 1, 2026");
    });

    it("should render dash when DateCell value is empty", () => {
      cy.mount(<DateCell value="" />);
      cy.get('p').should("contain.text", "-");
    });
  });

  describe("DateTimeCell", () => {
    it("DateTimeCell tests", () => {
      cy.mount(<DateTimeCell value="2026-01-01T10:30:00Z" />);
      cy.get('span').should("contain.text", "Jan 01, 2026 at 4:00 PM");
    });

    it("should render dash when DateTimeCell value is empty", () => {
      cy.mount(<DateTimeCell value="" />);
      cy.get('p').should("contain.text", "-");
    });
  });

  describe("ExternalIconCell", () => {
    it("ExternalIconCell tests", () => {
      cy.mount(<ExternalIconCell value="https://www.google.com" />);
      cy.get('.external-link-cell').should("exist");
    });
    it("should render nothing when ExternalIconCell value is empty", () => {
      cy.mount(<ExternalIconCell value="" />);
      cy.get('body').should('not.contain', 'external-link-cell');
    });
  });

  describe("EmailCell", () => {
    it("EmailCell tests", () => {
      cy.mount(<EmailCell value="xyz@example.com" />);
      cy.get('.email-cell').should("exist");
    });
    it("should render nothing when EmailCell value is empty", () => {
      cy.mount(<EmailCell value="" />);
      cy.get('body').should('not.contain', 'email-cell');
    });
  });

  describe("ReportOwnerCell", () => {
    it("ReportOwnerCell tests", () => {
      cy.mount(<ReportOwnerCell data={{ ownerThumbnailUrl: "" }} value="John Doe" />);
      cy.get('.report-owner-text').should("contain.text", "John Doe");
    });
    it("should render nothing when ReportOwnerCell value is empty", () => {
      cy.mount(<ReportOwnerCell data={{}} value="" />);
      cy.get('body').should('not.contain', 'owner-cell');
    });
  });

  describe("ReportDateCell", () => {
    it("ReportDateCell tests", () => {
      cy.mount(<ReportDateCell value="2026-01-01" />);
      cy.get('span').should("contain.text", "Jan 1, 2026");
    });

    it("should render nothing when ReportDateCell value is empty", () => {
      cy.mount(<ReportDateCell value="" />);
      cy.get('body').should('not.contain', 'span');
    });
  });

  describe("ReportDateTimeCell", () => {
    it("ReportDateTimeCell tests", () => {
      cy.mount(<ReportDateTimeCell value="2026-01-01T10:30:00Z" />);
      cy.get('span').should("contain.text", "Jan 01, 2026 at 4:00 PM");
    });

    it("should render nothing when ReportDateTimeCell value is empty", () => {
      cy.mount(<ReportDateTimeCell value="" />);
      cy.get('body').should('not.contain', 'span');
    });
  });

  describe("ReportExternalIconCell", () => {
    it("ReportExternalIconCell tests", () => {
      cy.mount(<ReportExternalIconCell value="https://www.google.com" />);
      cy.get('.external-link-cell').should("exist");
    });

    it("should render nothing when ReportExternalIconCell value is empty", () => {
      cy.mount(<ReportExternalIconCell value="" />);
      cy.get('body').should('not.contain', 'external-link-cell');
    });
  });

  describe("ReportEmailCell", () => {
    it("should render email address correctly", () => {
      const shortEmail = "test@example.com";
      cy.mount(<ReportEmailCell value={shortEmail} />);
      cy.get('.report-email-cell').should("exist");
      cy.get('.report-email-value').should('contain.text', shortEmail);
    });
    it("should render nothing when ReportEmailCell value is empty", () => {
      cy.mount(<ReportEmailCell value="" />);
      cy.get('body').should('not.contain', 'report-email-cell');
    });
  });

  describe("ReportCustomCell", () => {
    it("should render custom content in ReportCustomCell", () => {
      const customContent = "This is a custom cell content";
      cy.mount(<ReportCustomCell value={customContent} />);
      cy.get('.report-custom-cell-container').should("exist");
      cy.get('.report-custom-cell-text').should("contain.text", customContent);
    });
    it("should render nothing when ReportCustomCell value is empty", () => {
      cy.mount(<ReportCustomCell value="" />);
      cy.get('body').should('not.contain', 'report-custom-cell-container');
    });
  });
});

