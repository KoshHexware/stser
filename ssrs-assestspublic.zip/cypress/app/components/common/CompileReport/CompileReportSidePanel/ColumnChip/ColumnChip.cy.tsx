import React from 'react';
import ColumnChip from '../../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/ColumnChip/ColumnChip';

describe('ColumnChip Component', () => {
    const column = {
        title: 'Test Column',
        dataType: 'string',
        description: 'This is a test column',
        id: 'test-column-id',
        definition: 'Test Definition',
    };

    beforeEach(() => {
        const onRemoveMock = cy.stub();
        cy.mount(
            <ColumnChip
                column={column}
                onRemove={onRemoveMock}
                reportId="test-report-id"
                reportName="Test Report"
            />
        );
    });

    it('should render the column title', () => {
        cy.get('.ssrs-column-chip-info').should('contain.text', column.title);
    });
});