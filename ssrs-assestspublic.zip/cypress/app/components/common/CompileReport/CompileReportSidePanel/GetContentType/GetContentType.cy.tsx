import React from 'react';
import GetContentType from '../../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/GetContentType/index';
import * as reactI18next from 'react-i18next';
import {
  IFilterDataType,
  ITextOperations,
  INumberOperations,
  IDateOperations,
  FILTER_TYPE
} from '../../../../../../../src/interfaces/IFilterTypes';

describe('GetContentType Component', () => {
  let mockSetUpdatedValues;

  beforeEach(() => {
    cy.stub(reactI18next, 'useTranslation').returns({
      t: (key, defaultValue) => defaultValue || key,
      i18n: { changeLanguage: cy.stub() }
    });

    mockSetUpdatedValues = cy.stub().as('setUpdatedValues');
  });

  const createMockFilter = (dataType, filterType = FILTER_TYPE.FREETEXT, operation = 'Equals') => ({
    filterName: 'testFilter',
    queryParam: 'testFilter',
    uxLabel: 'Test Filter',
    uxDescription: 'Test filter description',
    category: 'Test',
    dataType,
    filterType,
    operation,
    isDefault: false,
    values: [],
    domainValues: ['Option 1', 'Option 2', 'Option 3'],
    pickListValues: ['Option 1', 'Option 2', 'Option 3'],
    isNewlyAdded: false,
    isNullable: false,
    filterValuesByTeamsite: false,
    allowedOperators: []
  });

  const mountComponent = (props = {}) => {
    const defaultProps = {
      filter: createMockFilter(IFilterDataType.TEXT),
      currentSelectedOperator: ITextOperations.CONTAINS,
      defaultValue: [],
      setUpdatedValues: mockSetUpdatedValues,
      isOpratorChanged: 0,
      filterPickList: ['Item 1', 'Item 2', 'Item 3'],
      clearFilter: false,
      ...props
    };

    // @ts-ignore - cy.mount is defined in cypress support files
    cy.mount(<GetContentType {...defaultProps} />);
  };

  describe('Text Data Type Filters', () => {
    it('should render text input for freetext filter with contains operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS
      });

      cy.get('.get-content-type-text').should('exist');
      cy.get('.get-content-type-text input').should('have.attr', 'placeholder', 'Enter [text field]');
    });

    it('should render text input for domain of values filter with contains operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.DOMAIN_OF_VALUES),
        currentSelectedOperator: ITextOperations.CONTAINS
      });

      cy.get('.get-content-type-text').should('exist');
      cy.get('.get-content-type-text input').should('have.attr', 'placeholder', 'Enter [text field]');
    });

    it('should render multiselect for domain of values filter with equals operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.DOMAIN_OF_VALUES),
        currentSelectedOperator: ITextOperations.EQUALS
      });

      cy.get('.ssrs-edit-filter-picklist-select').should('exist');
    });

    it('should render multiselect for picklist filter', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.PICKLIST),
        currentSelectedOperator: ITextOperations.EQUALS
      });

      cy.get('.ssrs-edit-filter-picklist-select').should('exist');
    });

    it('should show clear button when text input has value', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS,
        defaultValue: ['test value']
      });

      cy.get('.ssrs-edit-filter-text-remove-button').should('exist');
    });

    it('should clear text input when clear button is clicked', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS,
        defaultValue: ['test value']
      });

      cy.get('.ssrs-edit-filter-text-remove-button').click();
      cy.get('@setUpdatedValues').should('have.been.calledWith', []);
    });
  });

  describe('Numeric Data Type Filters', () => {
    it('should render number input for integer filter', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.INTEGER),
        currentSelectedOperator: INumberOperations.EQUALS
      });

      cy.get('input[type="number"]').should('exist');
      cy.get('input').should('have.attr', 'step', '1');
    });

    it('should render number input for decimal filter', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DECIMAL),
        currentSelectedOperator: INumberOperations.EQUALS
      });

      cy.get('input[type="number"]').should('exist');
      cy.get('input').should('have.attr', 'step', '0.1');
    });

    it('should render two number inputs for between operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.INTEGER),
        currentSelectedOperator: INumberOperations.BETWEEN
      });

      cy.get('.get-content-type-between').should('exist');
      cy.get('input[type="number"]').should('have.length', 2);
      cy.contains('and').should('exist');
    });

    it('should show clear button when number input has value', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.INTEGER),
        currentSelectedOperator: INumberOperations.EQUALS,
        defaultValue: [123]
      });

      cy.get('.ssrs-edit-filter-text-remove-button').should('exist');
    });
  });

  describe('Date Data Type Filters', () => {
    it('should render date input for standard date operations', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.EQUALS
      });

      cy.get('.get-content-type-date').should('exist');
    });

    it('should render number input and timeframe select for "in the last" operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.IN_THE_LAST
      });

      cy.get('.get-content-type-in-the-last-next').should('exist');
      cy.get('.get-content-type-in-the-last-next-input').should('exist');
      cy.get('.get-content-type-in-the-last-next-select').should('exist');
    });

    it('should render number input and timeframe select for "in the next" operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.IN_THE_NEXT
      });

      cy.get('.get-content-type-in-the-last-next').should('exist');
      cy.get('.get-content-type-in-the-last-next-input').should('exist');
      cy.get('.get-content-type-in-the-last-next-select').should('exist');
    });

    it('should render named range select for named range operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.NAMED_RANGE
      });

      cy.get('.get-content-type-named-range').should('exist');
      cy.get('.get-content-type-named-range-select').should('exist');
    });

    it('should render two date inputs for between operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.BETWEEN
      });

      cy.get('.get-content-type-between').should('exist');
    });
  });

  describe('Boolean Data Type Filters', () => {
    it('should render boolean select with True/False options', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.BOOLEAN),
        currentSelectedOperator: 'Equals'
      });

      cy.get('.add-filter-popover-content-field-ops').should('exist');
    });

    it('should handle boolean default values correctly', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.BOOLEAN),
        currentSelectedOperator: 'Equals',
        defaultValue: ['true']
      });

      cy.get('@setUpdatedValues').should('have.been.called');
    });
  });

  describe('Value Updates and State Management', () => {
    it('should call setUpdatedValues when text input changes', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS
      });

      cy.get('.get-content-type-text input').type('test input');
      cy.get('@setUpdatedValues').should('have.been.called');
    });

    it('should clear values when clearFilter prop is true', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS,
        defaultValue: ['test'],
        clearFilter: true
      });

      cy.get('@setUpdatedValues').should('have.been.calledWith', []);
    });

    it('should handle operator changes for text filters', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS,
        isOpratorChanged: 1
      });

      cy.get('@setUpdatedValues').should('have.been.called');
    });

    it('should handle default values for picklist filters', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.PICKLIST),
        currentSelectedOperator: ITextOperations.EQUALS,
        defaultValue: ['Item 1', 'Item 2']
      });

      cy.get('@setUpdatedValues').should('have.been.called');
      cy.get('.ssrs-edit-filter-picklist-select').should('exist');
      cy.get('.ssrs-edit-filter-picklist-select').contains('Item 1 and Item 2').should('exist');
    });
  });

  describe('User Experience Features', () => {
    it('should have proper placeholder text for text inputs', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS
      });

      cy.get('input').should('have.attr', 'placeholder', 'Enter [text field]');
    });

    it('should have proper placeholder for number inputs', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.INTEGER),
        currentSelectedOperator: INumberOperations.EQUALS
      });

      cy.get('input[type="number"]').should('have.attr', 'placeholder', 'Enter [number field]');
    });

    it('should have proper aria labels for date inputs', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.EQUALS
      });

      cy.get('[aria-label="Select a date"]').should('exist');
    });

    it('should handle numeric input validation properly', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.INTEGER),
        currentSelectedOperator: INumberOperations.EQUALS
      });

      cy.get('input[type="number"]').type('123');
      cy.get('input[type="number"]').should('have.value', '123');
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle empty default values gracefully', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.TEXT, FILTER_TYPE.FREETEXT),
        currentSelectedOperator: ITextOperations.CONTAINS,
        defaultValue: []
      });

      cy.get('.get-content-type-text').should('exist');
      cy.get('.get-content-type-text input').should('have.value', '');
    });

    it('should handle missing filter properties gracefully', () => {
      const incompleteFilter = {
        ...createMockFilter(IFilterDataType.TEXT),
        domainValues: undefined
      };

      mountComponent({
        filter: incompleteFilter,
        currentSelectedOperator: ITextOperations.CONTAINS
      });

      cy.get('.get-content-type-text input').should('exist');
    });

    it('should handle date type conversion for between operation', () => {
      mountComponent({
        filter: createMockFilter(IFilterDataType.DATE),
        currentSelectedOperator: IDateOperations.BETWEEN,
        defaultValue: ['2025-01-01', '2025-12-31']
      });

      cy.get('@setUpdatedValues').should('have.been.called');
    });
  });
});
