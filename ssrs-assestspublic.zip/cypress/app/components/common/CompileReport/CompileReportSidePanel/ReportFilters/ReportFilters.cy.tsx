import React from 'react';
import { CompileReportContextWrapper } from '../../../../../../support/CompileReportContextWrapper';
import ReportFilters from '../../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/ReportFilters';
import updatedFilters from '../../../../../../fixtures/updatedFilters.json';
import finalUpdatedFields from '../../../../../../fixtures/finalUpdatedFields.json';
import reportMetadata  from '../../../../../../fixtures/ReportMetaData.json';
import finalUpdatedFilters from "../../../../../../fixtures/finalUpdatedFilters.json"
import { CommonServicesContextProvider } from '../../../../../../../src/contexts/CommonServicesContext';
import UserSettings from '../../../../../../fixtures/UserSettings.json';

describe('Testing ReportFilters', () => {

  const allReportsLandingPageContextValue = {
    isLoading: false,
    isSaved: false,
    isSaving: false,
    isEditStandard: true,
    setIsEditStandard: () => {},
    setIsSaved: () => {},
    setIsSaving: () => {},
  };

  const reportDataContextValue = {
    reportMetadata: reportMetadata,
    setSelectedReport: () => {},
    setReportMetadata: () => {},
    isReportShared: false,
  };

  const fieldAndFilterContextValue = {
    totalItemsSelected: 7,
    setTotalItemsSelected: () => {},
    currentCategorySelected: 'KPI and metrics',
    finalUpdatedFields,
    setFinalUpdatedFields: () => {},
    isToggled: false,
    isClearedClicked: false,
    setIsToggle: () => {},
    resetFieldFilterStates: () => {},
    setIsDoneButtonClicked: () => {},
    currentActiveTab: 'filters',
    finalUpdatedFilters,
    setFinalUpdatedFilters: () => {},
    reportMetadata,
    setCurrentCategorySelected: () => {},
    setCurrentCategoryFields: () => {},
    setCurrentActiveTab: () => {},
    setIsClearedClicked: () => {},
    setIsToggled: () => {},
    setIsFilterCardClicked: () => {},
    setIsNewFilterAdding: () => {},
    setUpdatedFields: () => {},
    setUpdatedFilters: () => {},
    setUpdatedTeamsites: () => {},
  };

  it('Testing Report Side Panel content', () => {
    const  compileReportContextValue = {
      isFilterCardClicked: false,
      updatedFilters: updatedFilters,
      setUpdatedFilters: () => {},
      setIsFilterCardClicked: () => {},
      currentSelectedFilter: {
        filterName: 'isDeleted',
        queryParam: 'isDeleted',
        uxLabel: 'Is Deleted',
        uxDescription: 'Is the user deleted.',
        category: 'Users',
        dataType: 'Boolean',
        allowedOperators: [
          {
            name: 'Equals',
            uxLabel: 'Equals',
            label: 'Equals',
            value: 'Equals',
          },
        ],
        filterType: 'domainOfValues',
        filterPicklistQuery: '',
        domainValues: [],
        operation: 'Equals',
        values: ['false'],
        label: 'Is Deleted',
      },
    };

    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}>
        <CompileReportContextWrapper
          allReportsLandingPageContextValue={allReportsLandingPageContextValue}
          reportDataContextValue={reportDataContextValue}
          compileReportContextValue={compileReportContextValue}
          fieldFilterContextValue={fieldAndFilterContextValue}>
          <ReportFilters totalHeight={300} />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
    cy.contains('Filters').should('exist');
    cy.contains('Add filter').should('exist');
    cy.get('.edit-report-filters-container').children().should('have.length', 11);
  });

  it('Testing Edit Filter popup exists or not when clicks on filter card', () => {
    const compileReportContextValue = {
      isFilterCardClicked: true,
      updatedFilters: updatedFilters,
      setUpdatedFilters: () => {},
      setIsFilterCardClicked: () => {},
      currentSelectedFilter: {
        filterName: 'IsPublishedContentProfile',
        queryParam: 'IsPublishedContentProfile',
        uxLabel: 'Is content profile published?',
        uxDescription: 'A true/false value to determine if the content profile is published.',
        category: 'Content profile basics',
        dataType: 'Boolean',
        allowedOperators: [
          {
            name: 'Equals',
            uxLabel: 'Equals',
            label: 'Equals',
            value: 'Equals',
          },
          {
            name: 'NotEquals',
            uxLabel: 'Not Equals',
            label: 'Not Equals',
            value: 'NotEquals',
          },
        ],
        filterType: 'domainOfValues',
        filterPicklistQuery: 'SELECT distinct isPublished as IsPublishedContentProfile FROM contentProfiles',
        domainValues: ['true', 'false'],
        operation: 'Equals',
        values: ['true'],
        propertyType: 'None',
        label: 'Is content profile published?',
      },
    };
    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}>
        <CompileReportContextWrapper
          allReportsLandingPageContextValue={allReportsLandingPageContextValue}
          reportDataContextValue={reportDataContextValue}
          compileReportContextValue={compileReportContextValue}
          fieldFilterContextValue={fieldAndFilterContextValue}>
          <ReportFilters totalHeight={300} />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
    cy.contains('Edit filter').should('exist');
  });

  it('Testing Filter Card', () => {
    const  compileReportContextValue = {
      isFilterCardClicked: false,
      updatedFilters: [
        {
          filterName: "IsPublishedContentProfile",
          queryParam: "IsPublishedContentProfile",
          uxLabel: "Is content profile published?",
          uxDescription:
            "A true/false value to determine if the content profile is published.",
          category: "Content profile basics",
          dataType: "Boolean",
          allowedOperators: [
            {
              name: "Equals",
              uxLabel: "Equals",
              label: "Equals",
              value: "Equals",
            },
            {
              name: "NotEquals",
              uxLabel: "Not Equals",
              label: "Not Equals",
              value: "NotEquals",
            },
          ],
          filterType: "domainOfValues",
          filterPicklistQuery:
            "SELECT distinct isPublished as IsPublishedContentProfile FROM contentProfiles",
          domainValues: ["true", "false"],
          operation: "Equals",
          values: ["true"],
          propertyType: "None",
          label: "Is content profile published?",
        },
      ],
      setUpdatedFilters: () => {},
      setIsFilterCardClicked: () => {},
      currentSelectedFilter: {
        filterName: "IsPublishedContentProfile",
        queryParam: "IsPublishedContentProfile",
        uxLabel: "Is content profile published?",
        uxDescription:
          "A true/false value to determine if the content profile is published.",
        category: "Content profile basics",
        dataType: "Boolean",
        allowedOperators: [
          {
            name: "Equals",
            uxLabel: "Equals",
            label: "Equals",
            value: "Equals",
          },
          {
            name: "NotEquals",
            uxLabel: "Not Equals",
            label: "Not Equals",
            value: "NotEquals",
          },
        ],
        filterType: "domainOfValues",
        filterPicklistQuery:
          "SELECT distinct isPublished as IsPublishedContentProfile FROM contentProfiles",
        domainValues: ["true", "false"],
        operation: "Equals",
        values: ["true"],
        propertyType: "None",
        label: "Is content profile published?",
      },
    };
    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}>
        <CompileReportContextWrapper
          allReportsLandingPageContextValue={allReportsLandingPageContextValue}
          reportDataContextValue={reportDataContextValue}
          compileReportContextValue={compileReportContextValue}
          fieldFilterContextValue={fieldAndFilterContextValue}
        >
          <ReportFilters totalHeight={300} />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
    cy.get('.filter-card .filter-card-content-item div')
      .children('div')
      .contains('Is content profile published?')
      .should('exist');
    cy.get('.filter-card .filter-card-content-item div').children('div').contains('Equals true').should('exist');
    cy.get('.filter-card-content-item')
      .focus()
      .then(() => {
        cy.get('.filter-card-remove').click();
        cy.get('.edit-report-filters-container').children().should('have.length', 0);
      });
  });

  it('Testing Filter Card when values length is more than 1', () => {
    const testFilters = [
      {
        filterName: 'hireDate',
        queryParam: 'hireDate',
        uxLabel: 'Hire Date',
        uxDescription: "The user's hire date.",
        category: 'Users',
        dataType: 'DateTime',
        allowedOperators: [
          {
            name: 'Equals',
            uxLabel: 'Equals',
            label: 'Equals',
            value: 'Equals',
          },
          {
            name: 'NotEqual',
            uxLabel: 'Not Equal',
            label: 'Not Equal',
            value: 'NotEqual',
          },
          {
            name: 'GreaterThan',
            uxLabel: 'Greater Than',
            label: 'Greater Than',
            value: 'GreaterThan',
          },
          {
            name: 'LessThan',
            uxLabel: 'Less Than',
            label: 'Less Than',
            value: 'LessThan',
          },
          {
            name: 'Between',
            uxLabel: 'Between',
            label: 'Between',
            value: 'Between',
          },
        ],
        filterType: 'freetext',
        domainValues: [],
        operation: 'Between',
        values: ['Oct 2, 2024', 'Oct 21, 2024'],
        label: 'Hire Date',
      },
    ];
    const  compileReportContextValue = {
      isFilterCardClicked: true,
      updatedFilters: testFilters,
      setUpdatedFilters: () => {},
      setIsFilterCardClicked: () => {},
      currentSelectedFilter: testFilters[0],
    };
    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}>
        <CompileReportContextWrapper
          allReportsLandingPageContextValue={allReportsLandingPageContextValue}
          reportDataContextValue={reportDataContextValue}
          compileReportContextValue={compileReportContextValue}
          fieldFilterContextValue={fieldAndFilterContextValue}>
          <ReportFilters totalHeight={300} />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
    cy.get('.filter-card .filter-card-content-item div').children('div').contains('Hire Date').should('exist');
    cy.get('.filter-card .filter-card-content-item div')
      .children('div')
      .contains('Oct 2, 2024 - Oct 21, 2024')
      .should('exist');
  });

  it('Testing FilterCard when values length is 0', () => {
    const testFilters = [
      {
        filterName: 'hireDate',
        queryParam: 'hireDate',
        uxLabel: 'Hire Date',
        uxDescription: "The user's hire date.",
        category: 'Users',
        dataType: 'DateTime',
        allowedOperators: [
          {
            name: 'Equals',
            uxLabel: 'Equals',
            label: 'Equals',
            value: 'Equals',
          },
          {
            name: 'NotEqual',
            uxLabel: 'Not Equal',
            label: 'Not Equal',
            value: 'NotEqual',
          },
          {
            name: 'GreaterThan',
            uxLabel: 'Greater Than',
            label: 'Greater Than',
            value: 'GreaterThan',
          },
          {
            name: 'LessThan',
            uxLabel: 'Less Than',
            label: 'Less Than',
            value: 'LessThan',
          },
          {
            name: 'Between',
            uxLabel: 'Between',
            label: 'Between',
            value: 'Between',
          },
        ],
        filterType: 'freetext',
        domainValues: [],
        operation: 'Between',
        values: [],
        label: 'Hire Date',
      },
    ];
    const contextValue = {
      isFilterCardClicked: true,
      updatedFilters: testFilters,
      setUpdatedFilters: () => {},
      setIsFilterCardClicked: () => {},
      currentSelectedFilter: testFilters[0],
    };
    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}>
        <CompileReportContextWrapper
          allReportsLandingPageContextValue={allReportsLandingPageContextValue}
          reportDataContextValue={reportDataContextValue}
          compileReportContextValue={contextValue}
          fieldFilterContextValue={fieldAndFilterContextValue}>
          <ReportFilters totalHeight={300} />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
    cy.get('.filter-card .filter-card-content-item div').children('div').contains('-').should('exist');
  });
});
