import React from 'react';
import { CompileReportSidePanel } from '../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel';
import { FieldAndFilterContext } from '../../../../../../src/contexts/index';
import * as reactI18next from 'react-i18next';
import * as TableColumnsModule from '../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/TableColumns/TableColumns';
import * as ReportFiltersModule from '../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/ReportFilters';
import * as ErrorBoundaryModule from '../../../../../../src/app/components/common/ErrorBoundary/index';

describe('CompileReportSidePanel Component', () => {
    beforeEach(() => {
        cy.stub(reactI18next, 'useTranslation').returns({
            t: (key, defaultValue) => defaultValue || key,
            i18n: { changeLanguage: cy.stub() }
        });

        const MockTableColumns = () => <div data-testid="mock-table-columns">Mock Table Columns</div>;
        const MockReportFilters = () => <div data-testid="mock-report-filters">Mock Report Filters</div>;
        const MockErrorBoundary = ({ children }) => <>{children}</>;

        cy.stub(TableColumnsModule, 'default').callsFake(MockTableColumns);
        cy.stub(ReportFiltersModule, 'default').callsFake(MockReportFilters);
        cy.stub(ErrorBoundaryModule, 'ErrorBoundary').callsFake(MockErrorBoundary);
    });

    const mountComponent = (props = {}) => {
        const defaultProps = {
            currentVisibleTab: 0,
            setCurrentVisibleTab: cy.spy().as('setCurrentVisibleTabSpy'),
            isSidePanelVisible: true,
            setIsSidePanelVisible: cy.spy().as('setIsSidePanelVisibleSpy'),
            totalHeight: 100,
            columnVisibility: {},
            toggleColumnVisibility: cy.spy().as('toggleColumnVisibilitySpy'),
            setColumnVisibility: cy.spy().as('setColumnVisibilitySpy'),
            ...props
        };

        const setCurrentActiveTab = cy.spy().as('setCurrentActiveTabSpy');

        cy.mount(
            <FieldAndFilterContext.Provider value={{ setCurrentActiveTab }}>
                <CompileReportSidePanel {...defaultProps} />
            </FieldAndFilterContext.Provider>
        );
    };

    it('should render the component with default props', () => {
        mountComponent();

        // Check if the SidePanel renders
        cy.get('.edit-side-panel').should('exist');

        // Check if the tabs are rendered
        cy.contains('Table').should('exist');
        cy.contains('Filters').should('exist');

        // Check if the first tab is selected by default
        cy.get('.trk_tab_ssrs-table-view-selected-columns-tab').should('exist');
    });

    it('should render with the specified tab selected', () => {
        mountComponent({ currentVisibleTab: 1 });

        // Check if the Filters tab is selected
        cy.get('.trk_tab_ssrs-view-selected-filter-tab').contains('Filters').should('exist');
    });

    it('should switch tabs when Table tab is clicked', () => {
        mountComponent({ currentVisibleTab: 1 });

        // Click the Table tab
        cy.contains('Table').click();

        // Check if the callback was called with correct tab index
        cy.get('@setCurrentVisibleTabSpy').should('have.been.calledWith', 0);
        cy.get('@setCurrentActiveTabSpy').should('have.been.calledWith', 'Table');
    });

    it('should switch tabs when Filters tab is clicked', () => {
        mountComponent();

        // Click the Filters tab
        cy.contains('Filters').click();

        // Check if the callback was called with correct tab index
        cy.get('@setCurrentVisibleTabSpy').should('have.been.calledWith', 1);
        cy.get('@setCurrentActiveTabSpy').should('have.been.calledWith', 'Filters');
    });

    it('should toggle panel visibility when onToggle is triggered', () => {
        mountComponent();

        // Find the toggle button and click it
        cy.get('button[aria-label="Toggle"]').click();

        // Check if the setIsSidePanelVisible callback was called with false
        cy.get('@setIsSidePanelVisibleSpy').should('have.been.calledWith', false);
    });

    it('should render with the panel collapsed', () => {
        mountComponent({ isSidePanelVisible: false });

        // Check if the panel has the collapsed class
        cy.get('button[aria-label="Toggle"][aria-expanded="false"]').should('exist');
    });

    it('should navigate between tabs using arrow keys', () => {
        mountComponent({ currentVisibleTab: 1 });

        // Use left arrow key to navigate to Table tab
        cy.contains('Filters').type('{leftarrow}');

        // Click the now-focused element
        cy.focused().click();

        // Check if the callbacks were called correctly
        cy.get('@setCurrentVisibleTabSpy').should('have.been.calledWith', 0);
        cy.get('@setCurrentActiveTabSpy').should('have.been.calledWith', 'Table');
    });

    it('should handle keyboard navigation with Space key on Filters tab', () => {
        mountComponent();
        cy.contains('Table').type('{rightarrow}'); // Focus on Filters tab

        cy.focused().click();

        // Check if the callbacks were called correctly
        cy.get('@setCurrentVisibleTabSpy').should('have.been.calledWith', 1);
        cy.get('@setCurrentActiveTabSpy').should('have.been.calledWith', 'Filters');
    });

    it('should apply appropriate accessibility attributes', () => {
        mountComponent();
        cy.get('[aria-label="Edit the report navigation panel to add or remove columns and filters"]').should('exist');
    });

    it('should apply the correct CSS classes', () => {
        mountComponent();

        // Check for SidePanel class
        cy.get('.edit-side-panel').should('exist');

        // Check for container classes
        cy.get('.edit-side-panel-container').should('exist');
        cy.get('.tabs-container.mntl-scrollbar').should('exist');

        // Check for tab classes
        cy.get('.trk_tab_ssrs-table-view-selected-columns-tab').should('exist');
        cy.get('.trk_tab_ssrs-view-selected-filter-tab').should('exist');
    });
});