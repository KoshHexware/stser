import React from 'react';
import { CompileReportContextWrapper } from '../../../../../../support/CompileReportContextWrapper';
import updatedFields from '../../../../../../fixtures/UpdatedFields.json';
import fields from '../../../../../../fixtures/fields.json';
import updatedFilters from '../../../../../../fixtures/updatedFilters.json';
import finalUpdatedFields from '../../../../../../fixtures/finalUpdatedFields.json';
import reportMetadata from '../../../../../../fixtures/ReportMetaData.json';
import finalUpdatedFilters from '../../../../../../fixtures/finalUpdatedFilters.json';
import CompileFieldAndFilterActions from '../../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/CompileFieldAndFilterActions';

describe('Testing CompileFieldAndFilterActions', () => {

  const compileReportContextValue = {
    updatedFields,
    fields,
    updatedFilters,
    setIsFilterCardClicked: () => {},
    currentSelectedFilter: {},
    setUpdatedFilters: () => {},
    setIsNewFilterAdding: () => {},
  };

  const fieldFilterContextValue = {
    totalItemsSelected: 7,
    setTotalItemsSelected: () => {},
    currentCategorySelected: 'All',
    finalUpdatedFields,
    setFinalUpdatedFields: () => {},
    isToggled: false,
    isClearedClicked: false,
    setIsToggle: () => {},
    resetFieldFilterStates: () => {},
    setIsDoneButtonClicked: () => {},
    currentActiveTab: 'Filters',
    finalUpdatedFilters,
    setFinalUpdatedFilters: () => {},
    reportMetadata,
    setCurrentCategorySelected: () => {},
  };

  it('Testing columns check/uncheck changes in case of category All', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'All',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };

    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.get('input[aria-label="Content profile name"]').should('be.checked');
    cy.get('input[aria-label="Content views"]').should('be.checked');
    cy.get('input[aria-label="Is content profile deleted?"]').should('not.be.checked');
    cy.get('input[aria-label="Content profile name"]').uncheck();
    cy.get('input[aria-label="Is content profile deleted?"]').check();
  });

  it('Testing columns check/uncheck changes in case of category All', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'KPI and metrics',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };

    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.get('input[aria-label="Content views"]').should('be.checked');
    cy.get('input[aria-label="Livedoc generations"]').should('not.be.checked');
    cy.get('input[aria-label="Content views"]').uncheck();
    cy.get('input[aria-label="Livedoc generations"]').check();
  });

  it('Testing Filters Model', () => {
    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add filter').should('exist').click();
    cy.contains('Filter selection').should('exist');
    cy.contains('Cancel').should('exist');
    cy.contains('Done').should('exist');
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li').should('have.length', 4);
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li').eq(0).should('have.text', `All (12)`);
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li')
      .eq(1)
      .should('have.text', 'Content profile details');
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li')
      .eq(2)
      .should('have.text', 'Content profile basics');
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li')
      .eq(3)
      .should('have.text', 'KPI and metrics');
    cy.get('[aria-label="Content profile name"]').click();
    cy.contains('Cancel').should('exist').click();
    cy.contains('Filter selection').should('not.exist');
  });

  it('Testing Columns Model', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'All',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };

    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.contains('Column selection').should('exist');
    cy.contains('Cancel').should('exist');
    cy.contains('Done').should('exist');
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li').should('have.length', 4);
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li').eq(0).should('have.text', `All (16)`);
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li')
      .eq(1)
      .should('have.text', 'Content profile basics');
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li')
      .eq(2)
      .should('have.text', 'Content profile details');
    cy.get('.compile-field-filter-container').children('div').should('have.length', 16);
    cy.get('.compile-field-filter-modal-footer .compile-field-filter-total-selected').should(
      'have.text',
      'Total Selected  (7)'
    );
    cy.get('.field-actions .field-actions-toggle-div').should('have.text', 'Only show selected columns');
    cy.get('.field-actions-clear-all').should('have.text', 'Clear all');
  });

  it('Testing Columns actions', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'All',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };
    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.get('.field-actions .field-actions-toggle-div input').should('exist').click();
    cy.get('.field-actions-clear-all').should('exist').click();
    cy.get('.field-actions-clear-all').should('be.disabled');
    cy.contains('Cancel').should('exist').click();
    cy.contains('Add column').should('exist').click();
  });

  it('Testing Columns Model with Toggle OFF, search and other category', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'KPI and metrics',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };

    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.get('.field-filter-categories .field-filter-categories-navlist-nav ul li').should('have.length', 4);
    cy.get('.compile-field-filter-container').children('div').should('have.length', 9);
    cy.get('.add-column-search div input').should('exist').type('content views');
    cy.get('.compile-field-filter-container').children('div').should('have.length', 1);
    cy.get('.add-column-search div input').should('exist').clear().type('Hello');
    cy.contains('No search results');
    cy.contains('We couldn’t find anything matching your search query');
    cy.get('.field-actions .field-actions-toggle-div input').should('exist').click();
    cy.get('header').children('section').eq(1).should('exist').click();
    cy.contains('Add column').should('exist').click();
  });

  it('Testing Columns Model with Toggle is ON, search and other category', () => {
    const fieldFilterContextValue = {
      totalItemsSelected: 7,
      setTotalItemsSelected: () => {},
      currentCategorySelected: 'Content profile details',
      finalUpdatedFields,
      setFinalUpdatedFields: () => {},
      isToggled: true,
      isClearedClicked: false,
      setIsToggle: () => {},
      resetFieldFilterStates: () => {},
      setIsDoneButtonClicked: () => {},
      currentActiveTab: 'Table',
      finalUpdatedFilters,
      setFinalUpdatedFilters: () => {},
      reportMetadata,
      setCurrentCategorySelected: () => {},
    };

    cy.mount(
      <CompileReportContextWrapper
        compileReportContextValue={compileReportContextValue}
        fieldFilterContextValue={fieldFilterContextValue}>
        <CompileFieldAndFilterActions />
      </CompileReportContextWrapper>
    );
    cy.contains('Add column').should('exist').click();
    cy.contains('Nothing to view');
    cy.contains('There are no selected field items to view');
  });
});
