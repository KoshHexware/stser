import React from 'react';
import { CompileReportContextWrapper } from '../../../../../../support/CompileReportContextWrapper';
import AddFilter from '../../../../../../../src/app/components/common/CompileReport/CompileReportSidePanel/AddFilter';
import ReportService from '../../../../../../../src/services/ReportService';
import FilterPicklist from '../../../../../../fixtures/filterPicklist.json';
import compileContext from '../../../../../../fixtures/compileReportContext.json';
import reportMetadata from '../../../../../../fixtures/ReportMetaData.json';
import { CommonServicesContextProvider } from '../../../../../../../src/contexts/CommonServicesContext';
import UserSettings from '../../../../../../fixtures/UserSettings.json';

describe('AddFilter Component tests', () => {

  // Factory function for creating test filters
  const createFilter = (dataType, filterType = 'freetext', additionalProps = {}) => ({
    filterName: `${dataType.toLowerCase()}Filter`,
    queryParam: `${dataType.toLowerCase()}Field`,
    uxLabel: `${dataType} Field`,
    uxDescription: `A ${dataType.toLowerCase()} filter field.`,
    category: 'Test',
    dataType,
    filterType,
    domainValues: [],
    values: [],
    isNullable: false,
    ...additionalProps
  });

  // Common operator sets for different data types
  const operatorSets = {
    text: [
      { name: 'Equals', uxLabel: 'Equals' },
      { name: 'NotEquals', uxLabel: 'Not Equals' },
      { name: 'Contains', uxLabel: 'Contains' },
      { name: 'DoesNotContain', uxLabel: 'Does Not Contain' },
      { name: 'StartsWith', uxLabel: 'Starts with' },
      { name: 'EndsWith', uxLabel: 'Ends with' },
      { name: 'IsOneOf', uxLabel: 'Is one of' },
      { name: 'IsNotOneOf', uxLabel: 'Is not one of' },
      { name: 'IsNull', uxLabel: 'Blank' },
      { name: 'IsNotNull', uxLabel: 'Not Blank' }
    ],
    number: [
      { name: 'Equals', uxLabel: 'Equals' },
      { name: 'NotEquals', uxLabel: 'Not Equals' },
      { name: 'GreaterThan', uxLabel: 'Greater Than' },
      { name: 'LessThan', uxLabel: 'Less Than' },
      { name: 'GreaterThanOrEqual', uxLabel: 'Greater Than or Equal' },
      { name: 'LessThanOrEqual', uxLabel: 'Less Than or Equal' },
      { name: 'Between', uxLabel: 'Between' },
      { name: 'IsNull', uxLabel: 'Blank' },
      { name: 'IsNotNull', uxLabel: 'Not Blank' }
    ],
    date: [
      { name: 'Equals', uxLabel: 'Equals' },
      { name: 'NotEqual', uxLabel: 'Not Equal' },
      { name: 'GreaterThan', uxLabel: 'Greater Than' },
      { name: 'LessThan', uxLabel: 'Less Than' },
      { name: 'Between', uxLabel: 'Between' },
      { name: 'InTheLast', uxLabel: 'In The Last' },
      { name: 'InTheNext', uxLabel: 'In The Next' },
      { name: 'NamedRange', uxLabel: 'Named Range' },
      { name: 'IsNull', uxLabel: 'Is blank' },
      { name: 'IsNotNull', uxLabel: 'Is not blank' }
    ],
    boolean: [
      { name: 'Equals', uxLabel: 'Equals' }
    ]
  };

  // Context stubs - will be created in beforeEach
  let contextStubs;
  let baseContextConfig;

  // Helper function to create context stubs
  const createContextStubs = (overrides = {}) => {
    return {
      // All Reports Landing Page Context stubs
      setHideEditButtonOnError: cy.stub().as('setHideEditButtonOnError'),
      setShowLeaveWithoutSaveModal: cy.stub().as('setShowLeaveWithoutSaveModal'),

      // Field and Filter Context stubs
      setTotalItemsSelected: cy.stub().as('setTotalItemsSelected'),
      setFinalUpdatedFields: cy.stub().as('setFinalUpdatedFields'),
      setIsToggle: cy.stub().as('setIsToggle'),
      resetFieldFilterStates: cy.stub().as('resetFieldFilterStates'),
      setIsDoneButtonClicked: cy.stub().as('setIsDoneButtonClicked'),
      setFinalUpdatedFilters: cy.stub().as('setFinalUpdatedFilters'),
      setCurrentCategorySelected: cy.stub().as('setCurrentCategorySelected'),
      setCurrentCategoryFields: cy.stub().as('setCurrentCategoryFields'),
      setCurrentActiveTab: cy.stub().as('setCurrentActiveTab'),
      setIsClearedClicked: cy.stub().as('setIsClearedClicked'),
      setIsToggled: cy.stub().as('setIsToggled'),
      setIsFilterCardClicked: cy.stub().as('setIsFilterCardClicked'),
      setIsNewFilterAdding: cy.stub().as('setIsNewFilterAdding'),
      setUpdatedFields: cy.stub().as('setUpdatedFields'),
      setUpdatedFilters: cy.stub().as('setUpdatedFilters'),
      setUpdatedTeamsites: cy.stub().as('setUpdatedTeamsites'),

      // Report Data Context stubs
      setSelectedReport: cy.stub().as('setSelectedReport'),
      setReportMetadata: cy.stub().as('setReportMetadata'),

      // Compile Report Context stubs
      addToFiltersPicklist: cy.stub().as('addToFiltersPicklist'),

      // Override with any custom values
      ...overrides
    };
  };

  // Helper function to create base context configuration
  const createBaseContextConfig = (contextStubs) => ({
    allReportsLandingPageContextValue: {
      setHideEditButtonOnError: contextStubs.setHideEditButtonOnError,
      currentScreen: 'EDIT_REPORT',
      isChanged: false,
      showLeaveWithoutSaveModal: false,
      setShowLeaveWithoutSaveModal: contextStubs.setShowLeaveWithoutSaveModal
    },
    fieldAndFilterContextValue: {
      totalItemsSelected: 7,
      setTotalItemsSelected: contextStubs.setTotalItemsSelected,
      currentCategorySelected: 'KPI and metrics',
      finalUpdatedFields: [],
      setFinalUpdatedFields: contextStubs.setFinalUpdatedFields,
      isToggled: false,
      isClearedClicked: false,
      setIsToggle: contextStubs.setIsToggle,
      resetFieldFilterStates: contextStubs.resetFieldFilterStates,
      setIsDoneButtonClicked: contextStubs.setIsDoneButtonClicked,
      currentActiveTab: 'filters',
      finalUpdatedFilters: [],
      setFinalUpdatedFilters: contextStubs.setFinalUpdatedFilters,
      reportMetadata: reportMetadata,
      setCurrentCategorySelected: contextStubs.setCurrentCategorySelected,
      setCurrentCategoryFields: contextStubs.setCurrentCategoryFields,
      setCurrentActiveTab: contextStubs.setCurrentActiveTab,
      setIsClearedClicked: contextStubs.setIsClearedClicked,
      setIsToggled: contextStubs.setIsToggled,
      setIsFilterCardClicked: contextStubs.setIsFilterCardClicked,
      setIsNewFilterAdding: contextStubs.setIsNewFilterAdding,
      setUpdatedFields: contextStubs.setUpdatedFields,
      setUpdatedFilters: contextStubs.setUpdatedFilters,
      setUpdatedTeamsites: contextStubs.setUpdatedTeamsites,
    },
    reportDataContextValue: {
      reportMetadata: reportMetadata,
      setSelectedReport: contextStubs.setSelectedReport,
      setReportMetadata: contextStubs.setReportMetadata,
      isReportShared: false,
    }
  });

  // Helper function to create context stubs for compile report
  const createCompileReportContextStubs = (contextStubs, overrides = {}) => ({
    setIsFilterCardClicked: contextStubs.setIsFilterCardClicked,
    setIsNewFilterAdding: contextStubs.setIsNewFilterAdding,
    setUpdatedFilters: contextStubs.setUpdatedFilters,
    addToFiltersPicklist: contextStubs.addToFiltersPicklist,
    isFilterCardClicked: true,
    isNewFilterAdding: true,
    updatedFilters: [],
    filtersPickList: new Map(),
    systemReportId: 'test-system-report-id',
    showTeamsitePicker: false,
    updatedTeamsites: [],
    tempTeamsites: [],
    currentSelectedFilter: {
      ...compileContext.currentSelectedFilter,
      values: [],
      operation: undefined
    },
    ...overrides
  });

  // Helper function to mount component
  const mountAddFilter = (contextOverrides = {}) => {
    contextStubs = createContextStubs();
    baseContextConfig = createBaseContextConfig(contextStubs);
    const compileReportContextValue = createCompileReportContextStubs(contextStubs, contextOverrides);

    return cy.mount(
      <CommonServicesContextProvider
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}
      >
        <CompileReportContextWrapper
          {...baseContextConfig}
          compileReportContextValue={compileReportContextValue}
        >
          <AddFilter />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );
  };

  // UI interaction helpers
  const selectOperator = (operatorText: string) => {
    cy.get('[data-cy="add-filter-operator-dropdown"], .add-filter-popover-content-field-ops').click();
    cy.contains(operatorText).click();
  };

  const typeInInput = (value: string, selector = '.get-content-type-text') => {
    cy.get(selector).clear().type(value);
  };

  const clickApply = () => {
    cy.get('[data-cy="add-filter-apply-button"], .add-filter-apply-button')
      .not('.add-filter-apply-button-disabled')
      .click();
  };

  const clickCancel = () => {
    cy.contains('button', 'Cancel').click();
  };

  const clickDone = () => {
    cy.contains('button', 'Done').click();
  };

  const clickClearAll = () => {
    cy.get('[data-cy="add-filter-clear-all"], .add-filter-popover-content-field-clear-all').click();
  };

  // ========== TEST SETUP ==========
  beforeEach(() => {
    // Initialize context stubs
    contextStubs = createContextStubs();
    baseContextConfig = createBaseContextConfig(contextStubs);

    // Stub ReportService
    cy.stub(ReportService, 'getPickListFilters').resolves(FilterPicklist);
  });

  // ========== BASIC MODAL FUNCTIONALITY TESTS ==========
  describe('Modal Display and Basic Functionality', () => {
    it('should display Add filter modal with correct elements', () => {
      mountAddFilter();

      cy.get('.add-filter-popover').should('be.visible');
      cy.contains('Add filter').should('be.visible');
      cy.contains('button', 'Cancel').should('be.visible');
      cy.get('.add-filter-apply-button').should('be.visible');
    });

    it('should display Edit filter modal when editing existing filter', () => {
      mountAddFilter({ isNewFilterAdding: false });

      cy.contains('Edit filter').should('be.visible');
      cy.contains('Add filter').should('not.exist');
    });

    it('should handle modal dismiss correctly', () => {
      mountAddFilter();

      clickCancel();
      cy.get('@setIsFilterCardClicked').should('have.been.calledWith', false);
      cy.get('@setIsNewFilterAdding').should('have.been.calledWith', false);
    });
  });

  // ========== TEXT FILTER TESTS ==========
  describe('Text Filter Operations', () => {
    const textFilter = createFilter('Text', 'freetext', {
      allowedOperators: operatorSets.text
    });

    describe('Basic Text Operations', () => {
      const basicTextOperations = ['Equals', 'Not Equals', 'Contains', 'Does Not Contain', 'Starts with', 'Ends with'];

      basicTextOperations.forEach(operator => {
        it(`should handle ${operator} operation correctly`, () => {
          mountAddFilter({ currentSelectedFilter: textFilter });

          selectOperator(operator);
          typeInInput('test value');

          cy.get('.add-filter-apply-button')
            .should('not.have.class', 'add-filter-apply-button-disabled');
          clickApply();

          cy.get('@setUpdatedFilters').should('have.been.called');
        });
      });
    });

    describe('Text Input Validation', () => {
      it('should show error for whitespace-only input in Contains operation', () => {
        mountAddFilter({ currentSelectedFilter: textFilter });

        selectOperator('Contains');
        typeInInput('   ');

        cy.contains('Enter valid text').should('be.visible');
        cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('have.class', 'add-filter-apply-button-disabled');
      });

      it('should accept valid text input and enable apply button', () => {
        mountAddFilter({ currentSelectedFilter: textFilter });

        selectOperator('Contains');
        typeInInput('valid text');

        cy.contains('Enter valid text').should('not.exist');
        cy.get('.add-filter-apply-button')
          .should('not.have.class', 'add-filter-apply-button-disabled');
      });

      it('should handle empty input for freetext operations', () => {
        mountAddFilter({ currentSelectedFilter: textFilter });

        selectOperator('Equals');
        cy.get('.add-filter-apply-button').should('exist');

        // Empty input should still allow apply for some operations
        typeInInput('text');
        cy.get('.add-filter-apply-button')
          .should('not.have.class', 'add-filter-apply-button-disabled');
      });

      it('should trim whitespace for freetext filters on apply', () => {
        mountAddFilter({ currentSelectedFilter: textFilter });

        selectOperator('Equals');
        typeInInput('  spaced text  ');
        clickApply();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });
    });

    describe('List Operations (Is one of, Is not one of)', () => {
      ['Is one of', 'Is not one of'].forEach(operator => {
        it(`should handle ${operator} operation`, () => {
          mountAddFilter({ currentSelectedFilter: textFilter });

          selectOperator(operator);
          cy.get('.add-filter-popover-content-field-content').should('be.visible');
          cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
        });
      });
    });

    describe('Null Operations', () => {
      ['Blank', 'Not Blank'].forEach(operator => {
        it(`should handle ${operator} operation without showing input field`, () => {
          mountAddFilter({ currentSelectedFilter: textFilter });

          selectOperator(operator);

          // Should not show input field for null operations
          cy.get('.add-filter-popover-content-field-content').should('not.exist');
          cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');

          clickApply();
          cy.get('@setUpdatedFilters').should('have.been.called');
        });
      });
    });
  });

  // ========== NUMBER FILTER TESTS ==========
  describe('Number Filter Operations', () => {
    const numberDataTypes = ['Integer', 'Float', 'Double', 'Decimal'];

    numberDataTypes.forEach(dataType => {
      describe(`${dataType} Filter Tests`, () => {
        const numberFilter = createFilter(dataType, 'freetext', {
          allowedOperators: operatorSets.number
        });

        describe('Single Value Operations', () => {
          const singleValueOps = ['Equals', 'Not Equals', 'Greater Than', 'Less Than', 'Greater Than or Equal', 'Less Than or Equal'];

          singleValueOps.forEach(operator => {
            it(`should handle ${operator} operation for ${dataType}`, () => {
              mountAddFilter({ currentSelectedFilter: numberFilter });

              selectOperator(operator);

              const testValue = dataType === 'Integer' ? '123' : '123.45';
              typeInInput(testValue, '.get-content-type-text input');

              cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
              clickApply();

              cy.get('@setUpdatedFilters').should('have.been.called');
            });
          });
        });

        describe('Between Operation', () => {
          it(`should validate Between operation for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: numberFilter });

            selectOperator('Between');
            cy.get('.get-content-type-between').should('be.visible');

            // Test invalid range (first > second)
            cy.get('.get-content-type-between-number-1 input').type('10');
            cy.get('.get-content-type-between-number-2 input').type('5');

            cy.contains('Invalid number range').should('be.visible');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('have.class', 'add-filter-apply-button-disabled');

            // Test valid range
            cy.get('.get-content-type-between-number-2 input').clear().type('15');
            cy.contains('Invalid number range').should('not.exist');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal')
              .should('not.have.class', 'add-filter-apply-button-disabled');
          });

          it(`should require both values for Between operation for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: numberFilter });

            selectOperator('Between');

            // With only one value, should be disabled
            cy.get('.get-content-type-between-number-1 input').type('10');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('have.class', 'add-filter-apply-button-disabled');

            // With both values, should be enabled
            cy.get('.get-content-type-between-number-2 input').type('20');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal')
              .should('not.have.class', 'add-filter-apply-button-disabled');
          });
        });

        describe('Input Type Validation', () => {
          it(`should enforce ${dataType} input restrictions`, () => {
            mountAddFilter({ currentSelectedFilter: numberFilter });

            selectOperator('Equals');

            if (dataType === 'Integer') {
              // Integer should block decimal input
              cy.get('.get-content-type-text input').type('123.45');
              cy.get('.get-content-type-text input').should('have.value', '12345');
            } else {
              // Float types should allow decimal input
              cy.get('.get-content-type-text input').type('123.45');
              cy.get('.get-content-type-text input').should('have.value', '123.45');
            }
          });

          it(`should handle negative numbers for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: numberFilter });

            selectOperator('Equals');

            cy.get('.get-content-type-text input').type('-123');
            cy.get('.get-content-type-text input').should('have.value', '-123');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');
          });

          it(`should handle zero value for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: numberFilter });

            selectOperator('Equals');

            cy.get('.get-content-type-text input').type('0');
            cy.get('.get-content-type-text input').should('have.value', '0');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');
          });
        });

        describe('Null Operations', () => {
          ['Blank', 'Not Blank'].forEach(operator => {
            it(`should handle ${operator} operation for ${dataType}`, () => {
              mountAddFilter({ currentSelectedFilter: numberFilter });

              selectOperator(operator);

              cy.get('.add-filter-popover-content-field-content').should('not.exist');
              cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');

              clickApply();
              cy.get('@setUpdatedFilters').should('have.been.called');
            });
          });
        });
      });
    });
  });

  // ========== DATE AND DATETIME FILTER TESTS ==========
  describe('Date and DateTime Filter Operations', () => {
    const dateDataTypes = ['Date', 'DateTime'];

    dateDataTypes.forEach(dataType => {
      describe(`${dataType} Filter Tests`, () => {
        const dateFilter = createFilter(dataType, 'freetext', {
          allowedOperators: operatorSets.date
        });

        describe('Basic Date Operations', () => {
          ['Equals', 'Not Equal'].forEach(operator => {
            it(`should handle ${operator} operation for ${dataType}`, () => {
              mountAddFilter({ currentSelectedFilter: dateFilter });

              selectOperator(operator);
              cy.get('.add-filter-popover-content-field-content').should('be.visible');
              cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
            });
          });

          it(`should show Greater Than as "After" for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: dateFilter });

            cy.get('.add-filter-popover-content-field-ops').click();
            cy.contains('After').should('be.visible'); // Greater Than shows as "After" for dates
          });

          it(`should show Less Than as "Before" for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: dateFilter });

            cy.get('.add-filter-popover-content-field-ops').click();
            cy.contains('Before').should('be.visible'); // Less Than shows as "Before" for dates
          });
        });

        describe('Between Operation', () => {
          it(`should enable apply button with valid date range for ${dataType}`, () => {
            // Create a filter with pre-selected valid date range to test enabled state
            const filterWithValidDates = createFilter(dataType, 'freetext', {
              allowedOperators: operatorSets.date,
              values: ['2024-01-01', '2024-01-31'], // Valid date range
              operation: 'Between'
            });

            mountAddFilter({
              currentSelectedFilter: filterWithValidDates,
              updatedFilters: [filterWithValidDates]
            });

            selectOperator('Between');
            cy.get('.get-content-type-between').should('be.visible');

            // With valid pre-selected dates, apply button should be enabled
            cy.get('.trk-button-ssrs-apply-filter-edit-modal')
              .should('not.have.class', 'add-filter-apply-button-disabled');
          });

          it(`should disable apply button with invalid date range for ${dataType}`, () => {
            // Create a filter with invalid date range (end before start)
            const filterWithInvalidDates = createFilter(dataType, 'freetext', {
              allowedOperators: operatorSets.date,
              values: ['2024-01-31', '2024-01-01'], // Invalid date range (end before start)
              operation: 'Between'
            });

            mountAddFilter({
              currentSelectedFilter: filterWithInvalidDates,
              updatedFilters: [filterWithInvalidDates]
            });

            selectOperator('Between');
            cy.get('.get-content-type-between').should('be.visible');

            // With invalid date range, should show error and disable apply button
            cy.contains('Invalid date range').should('be.visible');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('have.class', 'add-filter-apply-button-disabled');
          });

          it(`should require both dates for Between operation for ${dataType}`, () => {
            // Test with only one date value (incomplete range)
            const filterWithOnlyStartDate = createFilter(dataType, 'freetext', {
              allowedOperators: operatorSets.date,
              values: ['2024-01-01'], // Only start date, missing end date
              operation: 'Between'
            });

            mountAddFilter({
              currentSelectedFilter: filterWithOnlyStartDate,
              updatedFilters: [filterWithOnlyStartDate]
            });

            selectOperator('Between');
            cy.get('.get-content-type-between').should('be.visible');

            // With incomplete date range, apply button should be disabled
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('have.class', 'add-filter-apply-button-disabled');
          });

        });

        describe('Relative Date Operations', () => {
          ['In The Last', 'In The Next'].forEach(operator => {
            it(`should handle ${operator} operation for ${dataType}`, () => {
              mountAddFilter({ currentSelectedFilter: dateFilter });

              selectOperator(operator);
              cy.get('.add-filter-popover-content-field-content').should('be.visible');
              cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');
            });
          });
        });

        describe('Named Range Operation', () => {
          it(`should handle Named Range operation for ${dataType}`, () => {
            mountAddFilter({ currentSelectedFilter: dateFilter });

            selectOperator('Named Range');
            cy.get('.add-filter-popover-content-field-content').should('be.visible');
            cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');
          });
        });

        describe('Null Operations', () => {
          ['Is blank', 'Is not blank'].forEach(operator => {
            it(`should handle ${operator} operation for ${dataType}`, () => {
              mountAddFilter({ currentSelectedFilter: dateFilter });

              selectOperator(operator);

              cy.get('.add-filter-popover-content-field-content').should('not.exist');
              cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');

              clickApply();
              cy.get('@setUpdatedFilters').should('have.been.called');
            });
          });
        });
      });
    });
  });

  // ========== BOOLEAN FILTER TESTS ==========
  describe('Boolean Filter Operations', () => {
    describe('Non-nullable Boolean Filter', () => {
      const booleanFilter = createFilter('Boolean', 'domainOfValues', {
        allowedOperators: operatorSets.boolean,
        isNullable: false
      });

      it('should show boolean value selector with True/False options', () => {
        mountAddFilter({ currentSelectedFilter: booleanFilter });

        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-popover-content-field-content').click();

        cy.contains('True').should('be.visible');
        cy.contains('False').should('be.visible');
      });

      it('should handle boolean value selection correctly', () => {
        mountAddFilter({ currentSelectedFilter: booleanFilter });

        // Test True selection
        cy.get('.add-filter-popover-content-field-content').click();
        cy.contains('True').click();
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');

        // Test False selection
        cy.get('.add-filter-popover-content-field-content').click();
        cy.contains('False').click();
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
      });

      it('should show Done button for new boolean filter without values', () => {
        mountAddFilter({
          currentSelectedFilter: booleanFilter,
          isNewFilterAdding: true
        });

        cy.contains('button', 'Done').should('be.visible');

        // After selecting value, should show Apply button instead
        cy.get('.add-filter-popover-content-field-content').click();
        cy.contains('True').click();

        cy.get('.add-filter-apply-button').should('be.visible');
        cy.contains('button', 'Done').should('not.exist');
      });
    });

    describe('Nullable Boolean Filter', () => {
      const nullableBooleanFilter = createFilter('Boolean', 'domainOfValues', {
        allowedOperators: [
          ...operatorSets.boolean,
          { name: 'IsNull', uxLabel: 'Blank' },
          { name: 'IsNotNull', uxLabel: 'Not Blank' }
        ],
        isNullable: true
      });

      it('should show operator dropdown for nullable boolean', () => {
        mountAddFilter({ currentSelectedFilter: nullableBooleanFilter });

        cy.get('.add-filter-popover-content-field-ops').should('be.visible');
        cy.get('.add-filter-popover-content-field-ops').click();

        cy.contains('Equals').should('be.visible');
        cy.contains('Blank').should('be.visible');
        cy.contains('Not Blank').should('be.visible');
      });

      it('should handle null operations for nullable boolean', () => {
        mountAddFilter({ currentSelectedFilter: nullableBooleanFilter });

        // Test Blank operation
        selectOperator('Blank');
        cy.get('.add-filter-popover-content-field-content').should('not.exist');
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');

        // Test Not Blank operation
        selectOperator('Not Blank');
        cy.get('.add-filter-popover-content-field-content').should('not.exist');
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
      });
    });
  });

  // ========== PICKLIST AND DOMAIN OF VALUES TESTS ==========
  describe('Picklist and Domain of Values Filters', () => {
    describe('Picklist Filters', () => {
      const picklistFilter = createFilter('Text', 'picklist', {
        allowedOperators: [
          { name: 'IsOneOf', uxLabel: 'Is one of' },
          { name: 'IsNotOneOf', uxLabel: 'Is not one of' },
          { name: 'Equals', uxLabel: 'Equals' },
          { name: 'NotEquals', uxLabel: 'Not Equals' }
        ]
      });

      ['Is one of', 'Is not one of'].forEach(operator => {
        it(`should handle ${operator} operation with multiple selection`, () => {
          mountAddFilter({ currentSelectedFilter: picklistFilter });

          selectOperator(operator);
          cy.get('.add-filter-popover-content-field-content').should('be.visible');
          cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
        });
      });

      it('should show deselect all button for picklist filters with selected values', () => {
        const picklistFilterWithValues = createFilter('Text', 'picklist', {
          allowedOperators: [
            { name: 'IsOneOf', uxLabel: 'Is one of' },
            { name: 'IsNotOneOf', uxLabel: 'Is not one of' }
          ],
          values: ['Value1', 'Value2'], // Pre-selected values
          operation: 'IsOneOf'
        });

        const filtersPickList = new Map();
        filtersPickList.set(picklistFilterWithValues.filterName, ['Value1', 'Value2']);

        mountAddFilter({
          currentSelectedFilter: picklistFilterWithValues,
          updatedFilters: [picklistFilterWithValues],
          filtersPickList
        });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-popover-content-field-content').click();

        // Deselect all button should be visible when values are selected
        cy.get('.trk_link_button_ssrs-edit-filter-picklist-deselect-all').should('be.visible');
      });

      it('should deselect all values when deselect all button is clicked for picklist', () => {
        const picklistFilterWithValues = createFilter('Text', 'picklist', {
          allowedOperators: [
            { name: 'IsOneOf', uxLabel: 'Is one of' },
            { name: 'IsNotOneOf', uxLabel: 'Is not one of' }
          ],
          values: ['Value1', 'Value2'], // Pre-selected values
          operation: 'IsOneOf'
        });

        const filtersPickList = new Map();
        filtersPickList.set(picklistFilterWithValues.filterName, ['Value1', 'Value2']);

        mountAddFilter({
          currentSelectedFilter: picklistFilterWithValues,
          updatedFilters: [picklistFilterWithValues],
          filtersPickList
        });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-popover-content-field-content').click();
        // Click deselect all button
        cy.get('.trk_link_button_ssrs-edit-filter-picklist-deselect-all').click();

        // Apply button should still be enabled (empty selection is valid for some operations)
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
      });

    });

    describe('Domain of Values Filters', () => {
      const domainFilter = createFilter('Text', 'domainOfValues', {
        allowedOperators: [
          { name: 'IsOneOf', uxLabel: 'Is one of' },
          { name: 'IsNotOneOf', uxLabel: 'Is not one of' }
        ],
        domainValues: ['Value1', 'Value2', 'Value3']
      });

      it('should show domain values for selection', () => {
        mountAddFilter({ currentSelectedFilter: domainFilter });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
      });

      it('should handle domain value selection correctly', () => {
        mountAddFilter({ currentSelectedFilter: domainFilter });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').click();
        cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
      });

      it('should show deselect all button for domain filters with selected values', () => {
        const domainFilterWithValues = createFilter('Text', 'domainOfValues', {
          allowedOperators: [
            { name: 'IsOneOf', uxLabel: 'Is one of' },
            { name: 'IsNotOneOf', uxLabel: 'Is not one of' }
          ],
          domainValues: ['Value1', 'Value2', 'Value3'],
          values: ['Value1', 'Value3'], // Pre-selected values
          operation: 'IsOneOf'
        });

        mountAddFilter({
          currentSelectedFilter: domainFilterWithValues,
          updatedFilters: [domainFilterWithValues]
        });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-popover-content-field-content').click();

        // Deselect all button should be visible when values are selected
        cy.get('.trk_link_button_ssrs-edit-filter-picklist-deselect-all').should('be.visible');
      });

      it('should deselect all values when deselect all button is clicked for domain values', () => {
        const domainFilterWithValues = createFilter('Text', 'domainOfValues', {
          allowedOperators: [
            { name: 'IsOneOf', uxLabel: 'Is one of' },
            { name: 'IsNotOneOf', uxLabel: 'Is not one of' }
          ],
          domainValues: ['Value1', 'Value2', 'Value3'],
          values: ['Value1', 'Value2'], // Pre-selected values
          operation: 'IsOneOf'
        });

        mountAddFilter({
          currentSelectedFilter: domainFilterWithValues,
          updatedFilters: [domainFilterWithValues]
        });

        selectOperator('Is one of');
        cy.get('.add-filter-popover-content-field-content').should('be.visible');
        cy.get('.add-filter-popover-content-field-content').click();

        // Click deselect all button
        cy.get('.trk_link_button_ssrs-edit-filter-picklist-deselect-all').click();

        // After deselecting all, the button should no longer be visible
        cy.get('.trk_link_button_ssrs-edit-filter-picklist-deselect-all').should('not.exist');

        // Apply button should still be enabled (empty selection is valid for some operations)
        cy.get('.trk-button-ssrs-apply-filter-edit-modal').should('not.have.class', 'add-filter-apply-button-disabled');
      });
    });
  });

  // ========== CLEAR ALL FUNCTIONALITY TESTS ==========
  describe('Clear All Functionality', () => {
    it('should show Clear All button when filter has values and operator', () => {
      const filterWithValues = createFilter('Text', 'freetext', {
        allowedOperators: operatorSets.text,
        values: ['existing value'],
        operation: 'Equals'
      });

      mountAddFilter({
        currentSelectedFilter: filterWithValues,
        isNewFilterAdding: false
      });

      selectOperator('Equals');
      cy.get('.add-filter-popover-content-field-clear-all').should('be.visible');
    });

    it('should clear filter values when Clear All is clicked', () => {
      const filterWithValues = createFilter('Text', 'freetext', {
        allowedOperators: operatorSets.text,
        values: ['existing value'],
        operation: 'Equals'
      });

      mountAddFilter({
        currentSelectedFilter: filterWithValues,
        isNewFilterAdding: false
      });

      selectOperator('Equals');
      clickClearAll();

      // Clear All button should no longer be visible after clearing
      cy.get('.add-filter-popover-content-field-clear-all').should('not.exist');
    });

    it('should reset operator to None and clear values when Clear All is clicked', () => {
      const filterWithValues = createFilter('Text', 'freetext', {
        allowedOperators: operatorSets.text,
        values: ['existing value'],
        operation: 'Equals'
      });

      mountAddFilter({
        currentSelectedFilter: filterWithValues,
        isNewFilterAdding: false
      });

      selectOperator('Equals');
      typeInInput('some text');
      clickClearAll();
      selectOperator('Equals');

      // Should clear the input
      cy.get('.get-content-type-text').should('have.value', '');
    });
  });


  // ========== FILTER ACTIONS AND STATE MANAGEMENT ==========
  describe('Filter Actions and State Management', () => {
    describe('Cancel Functionality', () => {
      it('should close modal and reset state on cancel', () => {
        mountAddFilter();

        clickCancel();

        cy.get('@setIsFilterCardClicked').should('have.been.calledWith', false);
        cy.get('@setIsNewFilterAdding').should('have.been.calledWith', false);
      });

      it('should remove new filter on cancel without values', () => {
        const testFilter = createFilter('Text', 'freetext', {
          allowedOperators: operatorSets.text
        });

        mountAddFilter({
          isNewFilterAdding: true,
          currentSelectedFilter: testFilter,
          updatedFilters: [testFilter]
        });

        clickCancel();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });
    });

    describe('Apply Functionality', () => {
      it('should update filter values on apply', () => {
        const testFilter = createFilter('Text', 'freetext', {
          allowedOperators: operatorSets.text
        });

        mountAddFilter({
          isNewFilterAdding: false,
          currentSelectedFilter: testFilter,
          updatedFilters: [testFilter]
        });

        selectOperator('Equals');
        typeInInput('test value');
        clickApply();

        cy.get('@setUpdatedFilters').should('have.been.called');
        cy.get('@setIsFilterCardClicked').should('have.been.calledWith', false);
        cy.get('@setIsNewFilterAdding').should('have.been.calledWith', false);
      });

      it('should handle freetext trimming on apply', () => {
        const testFilter = createFilter('Text', 'freetext', {
          allowedOperators: operatorSets.text
        });

        mountAddFilter({
          currentSelectedFilter: testFilter,
          updatedFilters: [testFilter]
        });

        selectOperator('Equals');
        typeInInput('  spaced text  ');
        clickApply();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });

      it('should handle relative date operations with empty values', () => {
        const dateFilter = createFilter('Date', 'freetext', {
          allowedOperators: operatorSets.date
        });

        mountAddFilter({
          currentSelectedFilter: dateFilter,
          updatedFilters: [dateFilter]
        });

        selectOperator('In The Last');
        clickApply();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });
    });

    describe('Done Functionality', () => {
      it('should handle empty filter creation with Done button', () => {
        const testFilter = createFilter('Boolean', 'domainOfValues', {
          allowedOperators: operatorSets.boolean,
          values: []
        });

        mountAddFilter({
          isNewFilterAdding: true,
          currentSelectedFilter: testFilter,
          updatedFilters: [testFilter]
        });

        clickDone();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });

      it('should set filter operation to None for empty filters', () => {
        const testFilter = createFilter('Text', 'freetext', {
          allowedOperators: operatorSets.text,
          values: []
        });

        mountAddFilter({
          isNewFilterAdding: true,
          currentSelectedFilter: testFilter,
          updatedFilters: [testFilter]
        });

        clickDone();

        cy.get('@setUpdatedFilters').should('have.been.called');
      });
    });
  });

  // ========== ACCESSIBILITY AND UX TESTS ==========
  describe('Accessibility and User Experience', () => {
    it('should have proper modal structure and be visible', () => {
      mountAddFilter();

      cy.get('.add-filter-popover').should('be.visible');
      cy.get('.add-filter-popover').should('contain', 'Add filter');
      cy.contains('Cancel').should('be.visible');
      cy.get('.add-filter-apply-button').should('be.visible');
    });

    it('should maintain proper tab order and focusable elements', () => {
      mountAddFilter();

      cy.get('.add-filter-popover').should('be.visible');
      cy.get('.add-filter-popover-content-field-ops').should('be.visible');
    });

    it('should show appropriate button text based on context', () => {
      // Test Add mode
      mountAddFilter({ isNewFilterAdding: true });
      cy.contains('Add filter').should('be.visible');

      // Test Edit mode  
      mountAddFilter({ isNewFilterAdding: false });
      cy.contains('Edit filter').should('be.visible');
    });

    it('should handle button state transitions correctly', () => {
      const textFilter = createFilter('Text', 'freetext', {
        allowedOperators: operatorSets.text
      });

      mountAddFilter({ currentSelectedFilter: textFilter });

      // Initially should show apply button
      cy.get('.add-filter-apply-button').should('exist');

      // After operator selection, should remain enabled for most operations
      selectOperator('Equals');
      cy.get('.add-filter-apply-button').should('not.have.class', 'add-filter-apply-button-disabled');
    });
  });

  it('Testing Date or DateTime with operations like InTheLast, InTheNext, NamedRange', () => {
    let currentSelectedFilter = {
      filterName: 'LastLogin',
      queryParam: 'lastLogin',
      uxLabel: 'Last Login',
      uxDescription: 'The last login date of the user.',
      category: 'Users',
      dataType: 'DateTime',
      allowedOperators: [
        {
          name: 'InTheLast',
          uxLabel: 'In the last',
        },
        {
          name: 'InTheNext',
          uxLabel: 'In the next',
        },
        {
          name: 'NamedRange',
          uxLabel: 'Named range',
        },
      ],
      filterType: 'freetext',
      domainValues: [],
      values: [],
    };
    cy.mount(
      <CommonServicesContextProvider
        accessLevel='editor'
        userSettings={{
          teamsites: UserSettings.teamsites as [],
          reportsFilterOption: 'all',
          tenantSettings: UserSettings.tenantSettings
        }}
      >
        <CompileReportContextWrapper
          fieldFilterContextValue={{}}
          compileReportContextValue={{ ...compileContext, currentSelectedFilter: currentSelectedFilter }}>
          <AddFilter />
        </CompileReportContextWrapper>
      </CommonServicesContextProvider>
    );

    //Case 1: Select In The Last operation
    cy.contains('Last Login').should('exist');
    cy.get('.add-filter-popover-content-field-ops').should('exist').click();
    cy.get('.add-filter-popover-content-field-ops div div').contains('In the last').click();
    cy.get('.get-content-type-in-the-last-next').should('exist');
    cy.get('.get-content-type-in-the-last-next > ._mntl-select').should('exist');
    cy.get('.get-content-type-in-the-last-next-input').should('exist').type('5');
    // cy.get('.get-content-type-in-the-last').should('exist');
    cy.get('.add-filter-apply-button').should('exist');

    //Case 2: Select In The Next operation
    cy.get('.add-filter-popover-content-field-ops').should('exist').click();
    cy.get('.add-filter-popover-content-field-ops div div').contains('In the next').click();
    cy.get('.get-content-type-in-the-last-next').should('exist');
    cy.get('.get-content-type-in-the-last-next > ._mntl-select').should('exist');
    cy.get('.get-content-type-in-the-last-next-input').should('exist').type('5');
    cy.get('.add-filter-apply-button').should('exist');

    //Case 3: Select Named Range operation
    cy.get('.add-filter-popover-content-field-ops').should('exist').click();
    cy.get('.add-filter-popover-content-field-ops div div').contains('Named range').click();
    cy.get('.get-content-type-named-range').should('exist');
    cy.get('.get-content-type-named-range > ._mntl-select').should('exist');
    //click it
    cy.get('.get-content-type-named-range > ._mntl-select').click();
    cy.contains('Today').should('exist');
    cy.contains('This week').should('exist');
    cy.contains('This month').should('exist');
    cy.contains('This year').should('exist');
    cy.contains('Last week').should('exist');
    cy.contains('Last month').should('exist');
    cy.contains('Last year').should('exist');
    cy.contains('Year to date').should('exist');
    cy.get('.add-filter-apply-button').should('exist');
  });
});
