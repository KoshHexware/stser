import ReportService from '../../src/services/ReportService';
import { HttpService, ServiceAddressService, instance } from 'seismic-common';
import Fields from '../fixtures/fields.json';

describe('Testing Report Service', () => {
  beforeEach(() => {
    cy.stub(ReportService, 'getHost').resolves('dummyHost');

    // Fix the intercept patterns to match the actual API calls
    cy.intercept('GET', '**/api/v1/reports/all*', {
      fixture: 'SystemReports.json',
    }).as('getReports');

    cy.intercept('GET', '**/api/v1/reports/recent*', {
      fixture: 'RecentReports.json',
    }).as('getRecentReports');

    cy.intercept('GET', '**/api/v1/report/execute/**', {
      fixture: 'executeReportById.json',
    }).as('executeReportById');

    cy.intercept('GET', '**/api/v1/report/**', {
      fixture: 'ReportMetaData.json',
    }).as('getReportMetaData');

    cy.intercept('GET', '**/api/v1/share/users', {
      fixture: 'ssrUsersList.json',
    }).as('getSSRUsersList');

    cy.intercept('GET', '**/api/v1/share/report/**', {
      fixture: 'sharedReportUsers.json',
    }).as('getReportSharedUserList');
  });

  it('Testing getReports', () => {
    ReportService.getReports().then((response) => {
      except(response).to.have.length(7);
    });
  });

  it('Testing getRecentReports', () => {
    ReportService.getRecentReports().then((response) => {
      except(response).to.have.length(3);
    });
  });

  it('Testing executeReportById', () => {
    ReportService.executeReportById(
      '84a5c9a8-5ba2-4e06-8914-c24a18a8236c',
      Fields,
      0,
      100
    ).then((response) => {
      expect(response).to.have.property('data');
    });
  });

  it('Testing getReportMetaData', () => {
    ReportService.getReportMetaData(
      '84a5c9a8-5ba2-4e06-8914-c24a18a8236c'
    ).then((response) => {
      expect(response).to.have.property('fields');
    });
  });

  it('should encode the values array strings in the filters', () => {
    const filters = [
      {
        filterName: 'meetingname',
        operation: 'IsOneOf',
        values: [
          '[Meeting Prep&Calendar Integration]Smoke test for 2024.07 Week 3 recurring meeting',
        ],
      },
    ];

    const expectedEncodedFilters = [
      {
        filterName: 'meetingname',
        operation: 'IsOneOf',
        values: [
          encodeURIComponent(
            '[Meeting Prep&Calendar Integration]Smoke test for 2024.07 Week 3 recurring meeting'
          ),
        ],
      },
    ];

    const encodedFilters = filters.map((filter: any) => ({
      ...filter,
      values: filter.values.map((value: string) => encodeURIComponent(value)),
    }));

    expect(encodedFilters).to.deep.equal(expectedEncodedFilters);
  });

  it('Testing getSSRUsersList', () => {
    ReportService.getSSRUsersList().then((response) => {
      expect(response).to.have.length(10);
    });
  });

  it('Testing getReportSharedUserList', () => {
    ReportService.getReportSharedUserList("").then((response) => {
      expect(response).to.have.length(3);
    });
  });
});

describe('ReportService Unit Tests', () => {
  let httpServiceStub;
  let serviceAddressServiceStub;
  let instanceStub;

  beforeEach(() => {
    // Create stubs for the dependencies
    httpServiceStub = {
      get: cy.stub().as('httpGet'),
      post: cy.stub().as('httpPost'),
      put: cy.stub().as('httpPut'),
      delete: cy.stub().as('httpDelete'),
      patch: cy.stub().as('httpPatch')
    };

    serviceAddressServiceStub = {
      getServiceAddressByKey: cy.stub().as('getServiceAddress')
    };

    instanceStub = {
      getService: cy.stub().as('getInstance')
    };

    // Setup the service address to return a mock URL
    serviceAddressServiceStub.getServiceAddressByKey.returns('https://mock-ssrs-host.com');

    // Setup instance.getService to return the appropriate service
    instanceStub.getService.callsFake((serviceType) => {
      if (serviceType === HttpService) return httpServiceStub;
      if (serviceType === ServiceAddressService) return serviceAddressServiceStub;
      return {};
    });

    // Mock the seismic-common instance
    cy.stub(instance, 'getService').callsFake((serviceType) => {
      if (serviceType === HttpService) return httpServiceStub;
      if (serviceType === ServiceAddressService) return serviceAddressServiceStub;
      return {};
    });
  });

  afterEach(() => {
    // Clear any cache between tests
    if (ReportService['cache']) {
      ReportService['cache'].clear();
    }
    ReportService['isExecuting'] = false;
    ReportService['queue'] = [];
  });

  describe('checkAccess', () => {
    it('should call the correct API endpoint for access check', () => {
      const mockResponse = 'EDITOR_ACCESS';
      httpServiceStub.get.resolves(mockResponse);

      cy.wrap(ReportService.checkAccess()).then((result) => {
        expect(httpServiceStub.get).to.have.been.calledWith('https://mock-ssrs-host.com/api/v1/access');
        expect(result).to.equal(mockResponse);
      });
    });

    it('should handle errors from access check API', () => {
      const mockError = new Error('Access denied');
      httpServiceStub.get.rejects(mockError);

      ReportService.checkAccess().then(
        () => {
          throw new Error('Should have failed');
        },
        (error) => {
          expect(error.message).to.equal('Access denied');
        }
      );
    });
  });

  describe('hasAccess', () => {
    it('should return boolean access status', () => {
      httpServiceStub.get.resolves(true);

      cy.wrap(ReportService.hasAccess()).then((result) => {
        expect(httpServiceStub.get).to.have.been.calledWith('https://mock-ssrs-host.com/api/v1/hasaccess');
        expect(result).to.be.true;
      });
    });
  });

  describe('getReports', () => {
    it('should fetch reports with correct parameters', () => {
      const mockReports = [{ id: '1', name: 'Test Report' }];
      httpServiceStub.get.resolves(mockReports);

      cy.wrap(ReportService.getReports(0, 10, 'all', 'test', 'name', 'asc')).then((result) => {
        const expectedUrl = 'https://mock-ssrs-host.com/api/v1/reports/all?reportType=all&skip=0&take=10&orderField=name&orderBy=asc&searchText=test';
        expect(httpServiceStub.get).to.have.been.calledWith(expectedUrl);
        expect(result).to.deep.equal(mockReports);
      });
    });

    it('should handle empty search term', () => {
      const mockReports = [];
      httpServiceStub.get.resolves(mockReports);

      cy.wrap(ReportService.getReports(0, 10, 'all', '', 'name', 'asc')).then(() => {
        const expectedUrl = 'https://mock-ssrs-host.com/api/v1/reports/all?reportType=all&skip=0&take=10&orderField=name&orderBy=asc';
        expect(httpServiceStub.get).to.have.been.calledWith(expectedUrl);
      });
    });
  });

  describe('getRecentReports', () => {
    it('should fetch recent reports with correct parameters', () => {
      const mockReports = [{ id: '1', name: 'Recent Report' }];
      httpServiceStub.get.resolves(mockReports);

      cy.wrap(ReportService.getRecentReports(0, 5, 'recent', 'date', 'desc')).then((result) => {
        const expectedUrl = 'https://mock-ssrs-host.com/api/v1/reports/recent?skip=0&take=5&orderField=date&orderBy=desc&searchText=recent';
        expect(httpServiceStub.get).to.have.been.calledWith(expectedUrl);
        expect(result).to.deep.equal(mockReports);
      });
    });
  });

  describe('executeReportById', () => {
    it('should execute report with correct parameters', () => {
      const mockResponse = { data: [], totalCount: 0 };
      httpServiceStub.get.resolves(mockResponse);

      const fields = [{ name: 'field1', isProperty: false }];
      const filters = [{ name: 'filter1', value: 'test' }];
      const teamsiteIds = ['ts1', 'ts2'];

      cy.wrap(ReportService.executeReportById('report-123', fields, filters, 0, 10, 'name', 'asc', teamsiteIds)).then((result) => {
        expect(httpServiceStub.get).to.have.been.called;
        expect(result).to.deep.equal(mockResponse);
      });
    });
  });

  describe('createCustomReport', () => {
    it('should create custom report', () => {
      const newReport = { name: 'New Report', description: 'Test report' };
      const mockResponse = { id: 'new-report-id', ...newReport };
      httpServiceStub.post.resolves(mockResponse);

      cy.wrap(ReportService.createCustomReport(newReport)).then((result) => {
        expect(httpServiceStub.post).to.have.been.calledWith('https://mock-ssrs-host.com/api/v1/report', newReport);
        expect(result).to.deep.equal(mockResponse);
      });
    });
  });

  describe('updateCustomReport', () => {
    it('should update custom report', () => {
      const updatedReport = { name: 'Updated Report', description: 'Updated description' };
      const reportId = 'report-123';
      const mockResponse = { id: reportId, ...updatedReport };
      httpServiceStub.put.resolves(mockResponse);

      cy.wrap(ReportService.updateCustomReport(updatedReport, reportId)).then((result) => {
        expect(httpServiceStub.put).to.have.been.calledWith(`https://mock-ssrs-host.com/api/v1/report/${reportId}`, updatedReport);
        expect(result).to.deep.equal(mockResponse);
      });
    });
  });

  describe('getReportMetaData', () => {
    it('should get report metadata with addToRecent flag', () => {
      const reportId = 'report-123';
      const mockMetadata = { id: reportId, name: 'Test Report', fields: [] };
      httpServiceStub.get.resolves(mockMetadata);

      cy.wrap(ReportService.getReportMetaData(reportId, true)).then((result) => {
        expect(httpServiceStub.get).to.have.been.calledWith(`https://mock-ssrs-host.com/api/v1/report/${reportId}?addToRecent=true&isDrillIn=false&sourceReportId=&sourceReportDrillInColumn=`);
        expect(result).to.deep.equal(mockMetadata);
      });
    });

    it('should get report metadata without adding to recent', () => {
      const reportId = 'report-123';
      const mockMetadata = { id: reportId, name: 'Test Report', fields: [] };
      httpServiceStub.get.resolves(mockMetadata);

      cy.wrap(ReportService.getReportMetaData(reportId)).then((result) => {
        expect(httpServiceStub.get).to.have.been.calledWith(`https://mock-ssrs-host.com/api/v1/report/${reportId}?addToRecent=false&isDrillIn=false&sourceReportId=&sourceReportDrillInColumn=`);
        expect(result).to.deep.equal(mockMetadata);
      });
    });
  });

  describe('deleteReportById', () => {
    it('should delete report by ID', () => {
      const reportId = 'report-123';
      const mockResponse = { success: true };
      httpServiceStub.delete.resolves(mockResponse);

      cy.wrap(ReportService.deleteReportById(reportId)).then((result) => {
        expect(httpServiceStub.delete).to.have.been.calledWith(`https://mock-ssrs-host.com/api/v1/report/${reportId}`);
        expect(result).to.deep.equal(mockResponse);
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle network errors gracefully', () => {
      const networkError = new Error('Network unavailable');
      httpServiceStub.get.rejects(networkError);

      ReportService.getReports().then(
        () => {
          throw new Error('Should have failed');
        },
        (error) => {
          expect(error.message).to.equal('Network unavailable');
        }
      );
    });

    it('should handle API errors gracefully', () => {
      const apiError = new Error('Invalid request');
      httpServiceStub.post.rejects(apiError);

      const newReport = { name: 'New Report', description: 'Test report' };
      const mockResponse = { id: 'new-report-id', ...newReport };
      httpServiceStub.post.resolves(mockResponse);

      ReportService.createCustomReport(newReport).then(
        () => {
          throw new Error('Should have failed');
        },
        (error) => {
          expect(error.message).to.equal('Invalid request');
        }
      );
    });
  });
});