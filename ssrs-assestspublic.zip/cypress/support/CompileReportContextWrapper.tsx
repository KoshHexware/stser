import React from 'react';
import { AllReportsLandingPageContext,CompileReportContext, FieldAndFilterContext, ReportDataContext, ShareReportsContext } from '../../src/contexts';

type CompileReportContextWrapperProps = {
  children: React.ReactNode;
  allReportsLandingPageContextValue?: any;
  compileReportContextValue?: any;
  fieldFilterContextValue?: any;
  shareReportsContextValue?: any;
  reportDataContextValue?: any;
};

export const CompileReportContextWrapper = (props: CompileReportContextWrapperProps) => {
  const { children, allReportsLandingPageContextValue, compileReportContextValue, fieldFilterContextValue, shareReportsContextValue, reportDataContextValue } = props;
  return (
    <> 
    <AllReportsLandingPageContext.Provider value={allReportsLandingPageContextValue}>
      <FieldAndFilterContext.Provider value={fieldFilterContextValue}>
        <CompileReportContext.Provider value={compileReportContextValue}>
          <ReportDataContext.Provider value={reportDataContextValue}>
            <ShareReportsContext.Provider value={shareReportsContextValue}>
              {children}
            </ShareReportsContext.Provider>
          </ReportDataContext.Provider>
        </CompileReportContext.Provider>
      </FieldAndFilterContext.Provider>
    </AllReportsLandingPageContext.Provider>
    </>
  );
};
