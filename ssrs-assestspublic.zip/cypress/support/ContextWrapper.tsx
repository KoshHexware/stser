import React from 'react';
import { AllReportsLandingPageContext } from '../../src/contexts';
import { ReportDataContext } from '../../src/contexts';

type ContextWrapper = {
  children: React.ReactNode;
  allReportsLandingPageContextValue?: any;
  reportDataContextValue?: any;
};
export const ContextWrapper = (props: ContextWrapper) => {
  const {
    children,
    allReportsLandingPageContextValue,
    reportDataContextValue,
  } = props;
  return (
    <>
      <AllReportsLandingPageContext.Provider
        value={allReportsLandingPageContextValue}
      >
        <ReportDataContext.Provider value={reportDataContextValue}>
          {children}
        </ReportDataContext.Provider>
      </AllReportsLandingPageContext.Provider>
    </>
  );
};
