import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
    en: {
        translation: {
            'self_service_reports_403_error_title': 'No access or no permissions',
            'self_service_reports_403_error_description': 'You do not have the access to this report.',
            'self_service_reports_teamsites_access_error_description': 'You do not have access to the applied Teamsites.',
            'self_service_reports_404_error_title': 'Page Not Found',
            'self_service_reports_404_error_description': 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.',
            'self_service_reports_500_error_title': 'Unable to connect',
            'self_service_reports_500_error_description': 'We could not connect your account due to some technical error on our end. Please try connecting again.',
            'self_service_reports_component_failure_description': 'Please select different operation to proceed.'
        }
    }
};

i18n
    .use(initReactI18next)
    .init({
        lng: 'en',
        fallbackLng: 'en',
        resources,
        interpolation: {
            escapeValue: false
        }
    });

export default i18n;