import { getReportsTablColumnDefs } from '../../src/utils/getReportsTblColumnDefs';

describe("getReportsTblColumnDefs Utility", () => {
    const fields = [
      {
        "name": "userName",
        "dataType": "Text",
        "isDefault": true,
        "uxLabel": "User name"
      },
      {
        "name": "isDeleted",
        "dataType": "Boolean",
        "isDefault": true,
        "uxLabel": "Is deleted"
      },
      {
        "name": "licenseType",
        "dataType": "Text",
        "isDefault": true,
        "uxLabel": "License type"
      }
    ];

    it("should generate column definitions for dynamic fields", () => {
        cy.wrap(getReportsTablColumnDefs(fields)).then(res => {
            expect(res).to.be.an('array');
            expect(res).to.have.length(3);
            expect(res[0].headerName).to.equal('User name');
            expect(res[1].headerName).to.equal('Is deleted');
            expect(res[2].headerName).to.equal('License type');
        });
    });
});