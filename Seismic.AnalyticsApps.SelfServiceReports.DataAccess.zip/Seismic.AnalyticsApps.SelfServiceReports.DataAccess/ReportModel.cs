﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess
{
    public class ReportModel
    {
        public Guid ReportId { get; set; }

        public Guid SystemReportId { get; set; }

        public required string SystemReportName { get; set; }

        public required string ReportName { get; set; }

        public required string Description { get; set; }

        public string? Domain { get; set; }

        public string? OwnerUserId { get; set; }

        public List<ReportField>? Fields { get; set; }

        public List<ReportFilter>? Filters { get; set; }

        public string? OrderByField { get; set; }

        public OrderType OrderBy { get; set; }

        public string? UserId { get; set; }

        public DateTime LastViewed { get; set; }

        public long Id { get; set; }

        public Guid TenantId { get; set; }

        public ReportType ReportType { get; set; }

        public DateTime LastUpdated { get; set; }

    }
}
