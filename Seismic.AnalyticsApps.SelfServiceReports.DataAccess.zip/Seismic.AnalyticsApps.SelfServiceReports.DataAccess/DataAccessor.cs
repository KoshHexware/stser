﻿using Microsoft.EntityFrameworkCore;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess
{
    public class DataAccessor(ISsrsContext _dbContext, Serilog.ILogger logger) : IDataAccessor
    {
        private readonly Serilog.ILogger _logger = logger.ForContext<DataAccessor>();

        public async Task<RecentReport?> GetRecentReportAsync(Guid reportId, string userId, Guid tenantId)
        {
            return await _dbContext.Set<RecentReport>()
                .Where(rr => rr.ReportId == reportId && rr.UserId == userId && rr.TenantId == tenantId)
                .SingleOrDefaultAsync();
        }

        public async Task<IEnumerable<RecentReportModel>> GetRecentReportsAsync(string userId, Guid tenantId)
        {
            var recentReports = from rr in _dbContext.Set<RecentReport>()
                                join r in _dbContext.Set<Report>() on rr.ReportId equals r.ReportId into rs
                                from r in rs.DefaultIfEmpty()
                                where rr.UserId == userId && rr.TenantId == tenantId
                                select new RecentReportModel
                                {
                                    ReportId = rr.ReportId,
                                    UserId = rr.UserId,
                                    TenantId = rr.TenantId,
                                    ReportName = r.ReportName,
                                    Description = r.Description ?? "",
                                    Domain = r.Domain ?? "",
                                    OwnerUserId = r.OwnerUserId,
                                    LastViewed = rr.OpenDate,
                                    LastUpdated = r != null ? r.ModifiedOnUtc : DateTime.MinValue,
                                    ReportType = r != null ? ReportType.Custom : ReportType.System,
                                    SystemReportId = r != null ? r.SystemReportId : Guid.Empty,
                                    SystemReportName = r != null ? r.ReportName : "",
                                };

            return await recentReports.ToListAsync();
        }

        public async Task<Report?> GetReportAsync(Guid reportId, Guid tenantId)
        {
            return await _dbContext.Set<Report>()
                .Where(rr => rr.ReportId == reportId && rr.TenantId == tenantId)
                .SingleOrDefaultAsync();
        }

        public async Task<Report?> GetReportByNameAsync(string reportName, Guid tenantId, string userId)
        {
            return await _dbContext.Set<Report>()
                .Where(rr => rr.ReportName.Trim().ToLower() == reportName.Trim().ToLower()
                && rr.TenantId == tenantId
                && rr.OwnerUserId == userId).SingleOrDefaultAsync();

        }

        public async Task<IEnumerable<ReportModel>> GetAllReportsAsync(Guid tenantId, string userId, string? searchText, bool ownedReportsOnly = false)
        {
            var reports = (from r in _dbContext.Set<Report>()
                           join rr in _dbContext.Set<RecentReport>() on r.ReportId equals rr.ReportId into rrs
                           from rr in rrs.DefaultIfEmpty()
                           where r.TenantId == tenantId
                           && (!ownedReportsOnly || r.OwnerUserId == userId)
                           && (string.IsNullOrWhiteSpace(searchText) || r.ReportName.ToLower().Contains(searchText.ToLower())
                           || r.Description.ToLower().Contains(searchText.ToLower()))
                           select new
                           {
                               Report = r,
                               RecentReport = rr
                           })
                           .GroupBy(x => x.Report.ReportId)
                           .Select(g => g.OrderByDescending(x => x.RecentReport != null && x.RecentReport.UserId == userId)
                           .ThenBy(x => x.RecentReport == null)
                             .Select(x => new ReportModel
                             {
                                 ReportId = x.Report.ReportId,
                                 ReportName = x.Report.ReportName,
                                 SystemReportName = string.Empty, //this is not available here. will be set in service.
                                 Description = x.Report.Description,
                                 Domain = x.Report.Domain,
                                 OwnerUserId = x.Report.OwnerUserId,
                                 SystemReportId = x.Report.SystemReportId,
                                 LastViewed = x.RecentReport != null && x.RecentReport.UserId == userId ? x.RecentReport.OpenDate : DateTime.MinValue,
                                 LastUpdated = x.Report.ModifiedOnUtc,
                                 ReportType = ReportType.Custom,
                             }).FirstOrDefault());

            return await reports.ToListAsync();
        }

        public async Task<RecentReport> AddRecentReportAsync(RecentReport report)
        {
            await _dbContext.Set<RecentReport>().AddAsync(report);
            await _dbContext.SaveChangesAsync();
            return report;
        }

        public async Task<Report> SaveReportAsync(Report report)
        {
            await _dbContext.Set<Report>().AddAsync(report);
            await _dbContext.SaveChangesAsync();
            return report;
        }

        public async Task<Report> UpdateReportAsync(Report reportEntity)
        {
            _dbContext.Set<Report>().Update(reportEntity);
            await _dbContext.SaveChangesAsync();
            return reportEntity;
        }

        public async Task<RecentReport> UpdateRecentReportAsync(RecentReport report)
        {
            _dbContext.Set<RecentReport>().Update(report);
            await _dbContext.SaveChangesAsync();
            return report;
        }

        public async Task<IEnumerable<RecentReport>> GetRecentReportsForUserByReportIdsAsync(string userId, Guid tenantId, List<Guid> reportIds)
        {
            return await _dbContext.Set<RecentReport>()
                .Where(rr => rr.UserId == userId && rr.TenantId == tenantId && reportIds.Contains(rr.ReportId))
                .ToListAsync();
        }

        public async Task<IEnumerable<DraftReport>> GetAllDraftReports(Guid tenantId, string? searchText)
        {
            var all = _dbContext.Set<DraftReport>()
                .Where(r => r.TenantId == tenantId);

            if (string.IsNullOrWhiteSpace(searchText))
            {
                return await all.ToListAsync();
            }

            return await all.Where(r => ((r.ReportName.ToLower().Contains(searchText.ToLower()))
            || (r.Description.ToLower().Contains(searchText.ToLower())))).ToListAsync();
        }

        public async Task<bool> IsDraftReportNameUniqueAsync(Guid tenantId, string reportName, Guid? reportId = null)
        {
            return !await _dbContext.Set<DraftReport>()
                .AnyAsync(r => r.TenantId == tenantId &&
                               r.ReportName.ToLower() == reportName.ToLower() &&
                               (!reportId.HasValue || r.ReportId != reportId.Value));
        }

        public async Task<DraftReport?> GetDraftReportById(Guid reportId, Guid tenantId)
        {
            return await _dbContext.Set<DraftReport>()
                .Where(dr => dr.ReportId == reportId && dr.TenantId == tenantId)
                .SingleOrDefaultAsync();
        }

        public async Task<DraftReport> SaveDraftReportAsync(DraftReport draftReport)
        {
            await _dbContext.Set<DraftReport>().AddAsync(draftReport);
            await _dbContext.SaveChangesAsync();
            return draftReport;
        }

        public async Task<DraftReport> UpdateDraftReportAsync(DraftReport draftReport)
        {
            _dbContext.Set<DraftReport>().Update(draftReport);
            await _dbContext.SaveChangesAsync();
            return draftReport;
        }

        public async Task<IEnumerable<Report>> GetAllReportsBySystemReportIdAsync(Guid systemReportId, Guid tenantId)
        {
            return await _dbContext.Set<Report>()
                .Where(r => r.SystemReportId == systemReportId && r.TenantId == tenantId)
                .ToListAsync();
        }

        public async Task<IEnumerable<RecentReport>> GetRecentReportsByReportIdsAsync(Guid tenantId, List<Guid> reportIds)
        {
            return await _dbContext.Set<RecentReport>()
                .Where(rr => rr.TenantId == tenantId && reportIds.Contains(rr.ReportId))
                .ToListAsync();
        }

        public async Task<IEnumerable<Report>> UpdateReportsAsync(IEnumerable<Report> reports)
        {
            _dbContext.Set<Report>().UpdateRange(reports);
            await _dbContext.SaveChangesAsync();
            return reports;
        }

        public async Task<IEnumerable<RecentReport>> UpdateRecentReportsAsync(IEnumerable<RecentReport> reports)
        {
            _dbContext.Set<RecentReport>().UpdateRange(reports);
            await _dbContext.SaveChangesAsync();
            return reports;
        }

        // draft report filters
        public async Task<IEnumerable<DraftReportFilter>> GetDraftReportFilters(Guid tenantId)
        {
            return await _dbContext.Set<DraftReportFilter>()
                .Where(drf => drf.TenantId == tenantId).ToListAsync();
        }

        public async Task<DraftReportFilter?> GetDraftReportFilterByName(Guid tenantId, string filterName)
        {
            return await _dbContext.Set<DraftReportFilter>()
                .Where(drf => drf.TenantId == tenantId)
                .SingleOrDefaultAsync(d => d.FilterName.ToLower() == filterName.ToLower());
        }

        public void UpdateDraftReportFilter(DraftReportFilter draftReportFilters)
        {
            _dbContext.Set<DraftReportFilter>().Update(draftReportFilters);
        }

        public void AddDraftReportFilter(DraftReportFilter draftReportFilters)
        {
            _dbContext.Set<DraftReportFilter>().Add(draftReportFilters);
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteRecentReportAsync(IEnumerable<RecentReport> recentReports)
        {
            _dbContext.Set<RecentReport>().RemoveRange(recentReports);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteDraftReportAsync(DraftReport draftReport)
        {
            _dbContext.Set<DraftReport>().Remove(draftReport);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteDraftReportFilterAsync(DraftReportFilter draftReportFilter)
        {
            _dbContext.Set<DraftReportFilter>().Remove(draftReportFilter);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<List<Guid>> GetAllTenants()
        {
            return await _dbContext.Set<TenantCacheInfo>().Select(t => t.TenantId).ToListAsync();
        }

        public async Task<List<string>> GetAllReportOwnerUsers(Guid tenantId)
        {
            return await _dbContext.Set<Report>().Where(r => r.TenantId == tenantId).Select(r => r.OwnerUserId).Distinct().ToListAsync();
        }

        public async Task<UserSettings?> GetUserSettingsAsync(Guid tenantId, string userId)
        {
            return await _dbContext.Set<UserSettings>().Where(t => t.TenantId == tenantId && t.UserId == userId).SingleOrDefaultAsync();
        }

        public async Task<UserSettings> AddUserSettingsAsync(UserSettings userTeamsites)
        {
            _dbContext.Set<UserSettings>().Add(userTeamsites);
            await _dbContext.SaveChangesAsync();
            return userTeamsites;
        }

        public async Task<UserSettings> UpdateUserSettingsAsync(UserSettings userTeamsites)
        {
            _dbContext.Set<UserSettings>().Update(userTeamsites);
            await _dbContext.SaveChangesAsync();
            return userTeamsites;
        }

        public async Task<SharedReportWithUser> SaveSharedReportWithUserAsync(SharedReportWithUser shareReport, bool saveChanges = false)
        {
            _dbContext.Set<SharedReportWithUser>().Add(shareReport);

            if (saveChanges)
                await _dbContext.SaveChangesAsync();

            return shareReport;
        }

        public async Task<List<string>> GetSharedReportUsersAsync(Guid reportId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>()
                .Where(sr => sr.ReportId == reportId && sr.TenantId == tenantId).Select(x => x.UserId)
                .ToListAsync();
        }

        public async Task<List<SharedReportWithUser>> GetSharedReportWithUsersAndGroupsAsync(Guid reportId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>()
                .Where(sr => sr.ReportId == reportId && sr.TenantId == tenantId)
                .ToListAsync();
        }

        public async Task<SharedReportWithUser?> GetSharedReportWithUserAsync(Guid reportId, string userId, Guid tenantId, List<string> userGroupIds)
        {
            return await _dbContext.Set<SharedReportWithUser>()
                .Where(sr => sr.ReportId == reportId && (sr.UserId == userId || (userGroupIds != null && userGroupIds.Contains(sr.UserGroupId))) && sr.TenantId == tenantId)
                .FirstOrDefaultAsync();
        }

        public async Task<SharedReportWithUser?> GetSharedReportWithUsersAsync(Guid reportId, string userId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>()
                .Where(sr => sr.ReportId == reportId &&
                !string.IsNullOrWhiteSpace(userId) && sr.UserId == userId && sr.TenantId == tenantId)
                .SingleOrDefaultAsync();
        }

        public async Task<SharedReportWithUser?> GetSharedReportWithUserGroupAsync(Guid reportId, string userGroupId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>()
                .Where(sr => sr.ReportId == reportId &&
                !string.IsNullOrWhiteSpace(userGroupId) && sr.UserGroupId == userGroupId && sr.TenantId == tenantId)
                .FirstOrDefaultAsync();
        }

        public async Task<SharedReportWithUser> UpdateSharedReportAsync(SharedReportWithUser sharedReport, bool saveChanges = false)
        {
            _dbContext.Set<SharedReportWithUser>().Update(sharedReport);

            if (saveChanges)
                await _dbContext.SaveChangesAsync();

            return sharedReport;
        }

        public async Task<bool> IsReportShared(Guid reportId, string userId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>().AnyAsync(x => x.ReportId == reportId && x.UserId == userId && x.TenantId == tenantId);
        }

        public async Task<bool> IsReportSharedWithUser(Guid reportId, string userId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>().AnyAsync(x => x.ReportId == reportId &&
             !string.IsNullOrWhiteSpace(userId) && x.UserId == userId && x.TenantId == tenantId);
        }

        public async Task<bool> IsReportSharedWithUserGroup(Guid reportId, string userGroupId, Guid tenantId)
        {
            return await _dbContext.Set<SharedReportWithUser>().AnyAsync(x => x.ReportId == reportId &&
             !string.IsNullOrWhiteSpace(userGroupId) && x.UserGroupId == userGroupId && x.TenantId == tenantId);
        }

        public async Task<List<SharedReport>> GetSharedReportsForUserAsync(string? searchText, string userId, Guid tenantId, List<string> userGroupIds)
        {
            searchText = searchText?.ToLower();
            var result = await (from sr in _dbContext.Set<SharedReportWithUser>()
                                join ar in _dbContext.Set<Report>() on sr.ReportId equals ar.ReportId
                                join rr in _dbContext.Set<RecentReport>().Where(rr => rr.UserId == userId && rr.TenantId == tenantId) on sr.ReportId equals rr.ReportId into rrs
                                from rr in rrs.DefaultIfEmpty()
                                where sr.TenantId == tenantId
                                      && (ar.TenantId == tenantId && ar.OwnerUserId != userId)
                                      && (sr.UserId == userId || userGroupIds.Contains(sr.UserGroupId))
                                      && (string.IsNullOrWhiteSpace(searchText) || ar.ReportName.ToLower().Contains(searchText)
                                          || ar.Description.ToLower().Contains(searchText))
                                select new SharedReport()
                                {
                                    ReportId = ar.ReportId,
                                    SystemReportId = ar.SystemReportId,
                                    ReportName = ar.ReportName,
                                    Description = ar.Description,
                                    CreatedOnUtc = ar.CreatedOnUtc,
                                    Domain = ar.Domain,
                                    Fields = ar.Fields,
                                    Filters = ar.Filters,
                                    Id = ar.Id,
                                    ModifiedOnUtc = ar.ModifiedOnUtc,
                                    OrderBy = ar.OrderBy,
                                    OrderByField = ar.OrderByField,
                                    OwnerUserId = ar.OwnerUserId,
                                    TenantId = ar.TenantId,
                                    OpenDate = rr != null ? rr.OpenDate : DateTime.MinValue,
                                    SharedAtUtc = sr.SharedAtUtc
                                }).ToListAsync();

            return result.DistinctBy(x => x.ReportId).OrderByDescending(r => r.OpenDate).ToList();
        }

        public async Task<List<Report>> GetAllCustomReportsForTheTenant(Guid tenantId)
        {
            return await _dbContext.Set<Report>()
                .Where(sr => sr.TenantId == tenantId)
                .ToListAsync();
        }


        public async Task<IEnumerable<DataAreaAccess>> GetAllDataAreasAccessAsync(Guid tenantId)
        {
            return await _dbContext.Set<DataAreaAccess>()
                    .Where(da => da.TenantId == tenantId)
                    .ToListAsync();
        }

        public async Task<IEnumerable<DataAreaAccess>> GetAllDataAreasAccessByIdsAsync(Guid tenantId, Guid[] dataAreaIds)
        {
            return await _dbContext.Set<DataAreaAccess>()
                .Where(da => da.TenantId == tenantId && dataAreaIds.Contains(da.DataAreaId))
                .ToListAsync();
        }

        public async Task<DataAreaAccess> UpdateDataAreaAccess(DataAreaAccess dataAreaAccessEntity)
        {
            _dbContext.Set<DataAreaAccess>().Update(dataAreaAccessEntity);
            await _dbContext.SaveChangesAsync();
            return dataAreaAccessEntity;
        }

        public async Task<IEnumerable<DataAreaAccess>> UpdateDataAreaAccessRange(IEnumerable<DataAreaAccess> dataAreaAccesses)
        {
            _dbContext.Set<DataAreaAccess>().UpdateRange(dataAreaAccesses);
            await _dbContext.SaveChangesAsync();
            return dataAreaAccesses;
        }

        public async Task<DataAreaAccess> AddDataAreaAccessAsync(DataAreaAccess dataAreaAccess)
        {
            await _dbContext.Set<DataAreaAccess>().AddAsync(dataAreaAccess);
            await _dbContext.SaveChangesAsync();
            return dataAreaAccess;
        }

        public async Task<IEnumerable<DataAreaAccess>> AddDataAreaAccessRangeAsync(IEnumerable<DataAreaAccess> dataAreaAccesses)
        {
            await _dbContext.Set<DataAreaAccess>().AddRangeAsync(dataAreaAccesses);
            await _dbContext.SaveChangesAsync();
            return dataAreaAccesses;
        }

        public async Task<IEnumerable<AccessControlMigration>> GetExistingAccessControlAsync(CancellationToken stoppingToken)
        {
            return await _dbContext.Set<AccessControlMigration>()
                     .Where(x => x.Status == AccessControlStatus.Needed)
                     .ToListAsync(stoppingToken);
        }

        public async Task<IEnumerable<AccessControlMigration>> GetExistingAccessControlWithLockAsync(CancellationToken stoppingToken)
        {
            // Use PostgreSQL-specific SELECT FOR UPDATE SKIP LOCKED
            var sql = @"
                SELECT * FROM ""AccessControlMigration"" 
                WHERE ""Status"" = {0}
                FOR UPDATE SKIP LOCKED";

            return await _dbContext.Set<AccessControlMigration>()
                .FromSqlRaw(sql, AccessControlStatus.Needed.ToDisplayString())
                .ToListAsync(stoppingToken);
        }

        public async Task<IEnumerable<AccessControlMigration>> UpdateAccessControlMigrationRange(IEnumerable<AccessControlMigration> accessControlMigrations, CancellationToken stoppingToken)
        {
            var strategy = ((DbContext)_dbContext).Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await ((DbContext)_dbContext).Database.BeginTransactionAsync(stoppingToken);
                try
                {
                    _dbContext.Set<AccessControlMigration>().UpdateRange(accessControlMigrations);
                    await _dbContext.SaveChangesAsync(stoppingToken);
                    await transaction.CommitAsync(stoppingToken);
                    return accessControlMigrations;
                }
                catch
                {
                    await transaction.RollbackAsync(stoppingToken);
                    throw;
                }
            });
            return accessControlMigrations;
        }

        public async Task<List<TenantCacheInfo>> GetAllObslateTenantCacheInfo()
        {
            return await _dbContext.Set<TenantCacheInfo>().Where(x=> x.IsRunning == true && x.ModifiedOnUtc <= DateTime.UtcNow.AddMinutes(-90)). ToListAsync();
        }

        public async Task<TenantCacheInfo> GetAndClaimTenantCacheInfoJobAsync(CancellationToken stoppingToken)
        {
            var strategy = ((DbContext)_dbContext).Database.CreateExecutionStrategy();

            #pragma warning disable CS8603 // Possible null reference return.
            return await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await ((DbContext)_dbContext).Database.BeginTransactionAsync(stoppingToken);

                try
                {
                    var sql = @"
                        SELECT * FROM ""TenantCacheInfo"" 
                        WHERE ""CacheRefreshedAt"" <= {0}
                        AND ""IsRunning"" = false
                        ORDER BY ""CacheRefreshedAt"" ASC
                        LIMIT 1
                        FOR UPDATE SKIP LOCKED";

                    var thresholdDate = DateTime.UtcNow.AddMinutes(-10);

                    var jobStatus = await _dbContext.Set<TenantCacheInfo>()
                        .FromSqlRaw(sql, thresholdDate)
                        .SingleOrDefaultAsync(stoppingToken);

                    if (jobStatus != null)
                    {
                        // Immediately update isRunning to claim the job
                        jobStatus.IsRunning =true;
                        jobStatus.ModifiedOnUtc = DateTime.UtcNow;
                        _dbContext.Set<TenantCacheInfo>().Update(jobStatus);
                        await _dbContext.SaveChangesAsync(stoppingToken);

                        // Commit and RELEASE the connection
                        await transaction.CommitAsync(stoppingToken);
                    }
                    else
                    {
                        await transaction.RollbackAsync(stoppingToken);
                    }

                    #pragma warning disable CS8603
                    return jobStatus;
                    #pragma warning restore CS8603
                }
                catch
                {
                    await transaction.RollbackAsync(stoppingToken);
                    return null;
                }
            });
            #pragma warning restore CS8603 // Possible null reference return.
        }

        public async Task<List<TenantOrgCacheInfo>> GetAllObslateTenantOrgCacheInfo()
        {
            return await _dbContext.Set<TenantOrgCacheInfo>().Where(x => x.IsRunning == true && x.ModifiedOnUtc <= DateTime.UtcNow.AddMinutes(-90)).ToListAsync();
        }

        public async Task<TenantOrgCacheInfo> GetAndClaimTenantOrgCacheInfoJobAsync(CancellationToken stoppingToken)
        {
            var strategy = ((DbContext)_dbContext).Database.CreateExecutionStrategy();

            #pragma warning disable CS8603 // Possible null reference return.
            return await strategy.ExecuteAsync(async () =>
            {
                using var transaction = await ((DbContext)_dbContext).Database.BeginTransactionAsync(stoppingToken);

                try
                {
                    var sql = @"
                        SELECT * FROM ""TenantOrgCacheInfo"" 
                        WHERE ""CacheRefreshedAt"" <= {0}
                        AND ""IsRunning"" = false
                        ORDER BY ""CacheRefreshedAt"" ASC
                        LIMIT 1
                        FOR UPDATE SKIP LOCKED";

                    var thresholdDate = DateTime.UtcNow.AddMinutes(-10);

                    var jobStatus = await _dbContext.Set<TenantOrgCacheInfo>()
                        .FromSqlRaw(sql, thresholdDate)
                        .SingleOrDefaultAsync(stoppingToken);

                    if (jobStatus != null)
                    {
                        // Immediately update isRunning to claim the job
                        jobStatus.IsRunning = true;
                        jobStatus.ModifiedOnUtc = DateTime.UtcNow;
                        _dbContext.Set<TenantOrgCacheInfo>().Update(jobStatus);
                        await _dbContext.SaveChangesAsync(stoppingToken);

                        // Commit and RELEASE the connection
                        await transaction.CommitAsync(stoppingToken);
                    }
                    else
                    {
                        await transaction.RollbackAsync(stoppingToken);
                    }

                    #pragma warning disable CS8603
                    return jobStatus;
                    #pragma warning restore CS8603
                }
                catch
                {
                    await transaction.RollbackAsync(stoppingToken);
                    return null;
                }
            });
            #pragma warning restore CS8603 // Possible null reference return.
        }
    }
}

