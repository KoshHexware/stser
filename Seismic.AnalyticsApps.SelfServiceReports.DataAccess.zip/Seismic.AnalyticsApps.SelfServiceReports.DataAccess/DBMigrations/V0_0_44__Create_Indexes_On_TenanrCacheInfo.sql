CREATE INDEX IF NOT EXISTS "IX_TenantCacheInfo_TenantId_CacheRefreshedAt" ON "public"."TenantCacheInfo"("TenantId", "CacheRefreshedAt");
