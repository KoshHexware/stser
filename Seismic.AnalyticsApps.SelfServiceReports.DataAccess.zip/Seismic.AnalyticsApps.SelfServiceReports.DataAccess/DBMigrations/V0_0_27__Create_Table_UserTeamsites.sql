﻿CREATE TABLE IF NOT EXISTS public."UserTeamsites" (
	"Id" serial PRIMARY KEY,
	"UserId" TEXT NOT NULL,
	"TenantId" uuid NOT NULL,
	"Teamsites" jsonb NOT NULL,
	"CreatedOnUtc" timestamp with time zone NOT NULL,
	"ModifiedOnUtc" timestamp with time zone NOT NULL,
	"IsDeleted" boolean NOT NULL DEFAULT false,
	"DeletedOnUtc" timestamp with time zone NULL,
	CONSTRAINT "UserTeamsites_UserId_TenantId_key" UNIQUE ("UserId", "TenantId")
)
WITH (
  OIDS=FALSE
);

CREATE INDEX idx_userteamsites_userid_tenantid ON public."UserTeamsites" ("UserId", "TenantId");