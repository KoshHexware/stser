CREATE INDEX IF NOT EXISTS "IX_DraftReports_TenantId"
    ON public."DraftReports" USING btree
    ("TenantId" ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE INDEX IF NOT EXISTS "IX_DraftReports_ReportId_TenantId"
    ON public."DraftReports" USING btree
    ("ReportId" ASC NULLS LAST, "TenantId" ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE INDEX IF NOT EXISTS "IX_TenantCacheInfo_TenantId"
    ON public."TenantCacheInfo" USING btree
    ("TenantId" ASC NULLS LAST)
    TABLESPACE pg_default;

CREATE INDEX IF NOT EXISTS "IX_TenantCacheInfo_TenantId_CacheRefreshedAt"
    ON public."TenantCacheInfo" USING btree
    ("TenantId" ASC NULLS LAST, "CacheRefreshedAt" ASC NULLS FIRST)
    TABLESPACE pg_default;