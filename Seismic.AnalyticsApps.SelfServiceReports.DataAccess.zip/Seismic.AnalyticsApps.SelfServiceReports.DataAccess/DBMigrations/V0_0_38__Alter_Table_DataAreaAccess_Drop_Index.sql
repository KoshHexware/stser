-- evolve-tx-off
-- Drop the existing index if it exists
DROP INDEX IF EXISTS DataAreaAccess_DataAreaId_TenantId_Idx;
