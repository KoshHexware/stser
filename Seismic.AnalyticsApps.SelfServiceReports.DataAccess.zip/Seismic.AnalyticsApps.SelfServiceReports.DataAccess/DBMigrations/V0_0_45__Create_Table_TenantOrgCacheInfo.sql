CREATE TABLE IF NOT EXISTS public."TenantOrgCacheInfo"
(
    "Id" serial PRIMARY KEY,
    "TenantId" uuid UNIQUE NOT NULL,
    "CreatedOnUtc" timestamp with time zone NOT NULL,
    "CacheRefreshedAt" timestamp with time zone NOT NULL,
    "ModifiedOnUtc" timestamp with time zone NOT NULL,
    "IsDeleted" boolean NOT NULL DEFAULT false,
    "DeletedOnUtc" timestamp with time zone,
    "IsRunning" boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS "IX_TenantOrgCacheInfo_TenantId_CacheRefreshedAt" ON "public"."TenantOrgCacheInfo"("TenantId", "CacheRefreshedAt");

CREATE INDEX IF NOT EXISTS "IX_TenantOrgCacheInfo_TenantId" ON "public"."TenantOrgCacheInfo"("TenantId");

