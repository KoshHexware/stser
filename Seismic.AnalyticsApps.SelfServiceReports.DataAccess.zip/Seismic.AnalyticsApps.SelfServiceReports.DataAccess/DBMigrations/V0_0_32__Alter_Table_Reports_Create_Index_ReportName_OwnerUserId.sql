-- evolve-tx-off
-- Create a new unique index including OwnerUserId
CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS "IX_Reports_ReportName_OwnerUserId"
    ON public."Reports" ("ReportName", "OwnerUserId");