﻿DROP TABLE IF EXISTS public."Reports";

DROP TABLE IF EXISTS public."RecentReports";