ALTER TABLE public."DraftReportFilters"
ADD COLUMN "DomainValues" jsonb not null default '[]'::jsonb;