ALTER TABLE public."DraftReportFilters"
ADD COLUMN "EnableRelativeUserFilterField" text;