﻿DROP TABLE IF EXISTS public."UserTeamsites";

CREATE TABLE IF NOT EXISTS public."UserSettings" (
	"Id" serial PRIMARY KEY,
	"UserId" TEXT NOT NULL,
	"TenantId" uuid NOT NULL,
	"Teamsites" jsonb NULL,
    "ReportsFilterOption" TEXT NULL,
	"CreatedOnUtc" timestamp with time zone NOT NULL,
	"ModifiedOnUtc" timestamp with time zone NOT NULL,
	"IsDeleted" boolean NOT NULL DEFAULT false,
	"DeletedOnUtc" timestamp with time zone NULL,
	CONSTRAINT "UserSettings_UserId_TenantId_key" UNIQUE ("UserId", "TenantId")
)
WITH (
  OIDS=FALSE
);

CREATE INDEX idx_usersettings_userid_tenantid ON public."UserSettings" ("UserId", "TenantId");