ALTER TABLE public."TenantCacheInfo"
ADD COLUMN "ModifiedOnUtc" timestamp with time zone NOT NULL,
ADD COLUMN "IsDeleted" boolean NOT NULL DEFAULT false,
ADD COLUMN "DeletedOnUtc" timestamp with time zone NULL;
