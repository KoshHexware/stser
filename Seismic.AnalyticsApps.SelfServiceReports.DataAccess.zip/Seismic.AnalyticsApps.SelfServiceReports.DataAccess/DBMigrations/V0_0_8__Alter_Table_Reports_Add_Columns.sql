﻿ALTER TABLE public."Reports"
ADD COLUMN "Fields" jsonb NOT NULL,
ADD COLUMN "Filters" jsonb NOT NULL,
ADD COLUMN "OrderByField" TEXT,
ADD COLUMN "OrderBy" TEXT NOT NULL CHECK ("OrderBy" IN ('ASC', 'DESC'));

ALTER TABLE public."Reports"
RENAME COLUMN "BaseReportId" TO "SystemReportId";