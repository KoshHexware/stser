CREATE TABLE IF NOT EXISTS public."SharedReportWithUser" (
	"Id" serial PRIMARY KEY,
	"ReportId" uuid NOT NULL,
	"UserId" TEXT NOT NULL,
	"SharedAtUtc" timestamp with time zone NOT NULL,
	"TenantId" uuid NOT NULL,
	"CreatedOnUtc" timestamp with time zone NOT NULL,
	"ModifiedOnUtc" timestamp with time zone NOT NULL,
	"IsDeleted" boolean NOT NULL DEFAULT false,
	"DeletedOnUtc" timestamp with time zone NULL
);

CREATE INDEX idx_sharedreportwithuser_reportid_userid_tenantid ON public."SharedReportWithUser" ("ReportId", "UserId", "TenantId");