-- Add unique composite index on report table for ReportName and TenantId columns
CREATE UNIQUE INDEX IF NOT EXISTS Reports_ReportName_TenantId_Idx ON public."Reports" ("ReportName", "TenantId");

-- Add unique composite index on recentreport table for ReportId and TenantId columns
CREATE UNIQUE INDEX IF NOT EXISTS RecentReports_ReportId_TenantId_Idx ON public."RecentReports" ("ReportId", "TenantId");
