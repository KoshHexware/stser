CREATE TABLE IF NOT EXISTS public."DraftReports" (
	"Id" bigserial PRIMARY KEY,
	"ReportId" uuid NOT NULL UNIQUE,
	"ReportName" text NOT NULL,
	"Description" text NOT NULL,
	"Template" text NOT NULL,
	"TenantId" uuid NOT NULL,
	"CreatedOnUtc" timestamp with time zone NOT NULL,
	"ModifiedOnUtc" timestamp with time zone NOT NULL,
	"IsDeleted" boolean NOT NULL DEFAULT false,
	"DeletedOnUtc" timestamp with time zone NULL
);