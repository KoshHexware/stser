-- evolve-tx-off
-- Create a new unique index including OwnerUserId, TenantId and ReportName
CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS "IX_Reports_ReportName_OwnerUserId_TenantId"
ON public."Reports" ("ReportName", "OwnerUserId", "TenantId")
WHERE "IsDeleted" = false;