CREATE TABLE IF NOT EXISTS public."DraftReportFilters" (
    "Id" BIGSERIAL PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "FilterName" TEXT NOT NULL,
    "QueryParam" TEXT NOT NULL,
    "UxLabel" TEXT NOT NULL,
    "UxDescription" TEXT NOT NULL,
    "Category" TEXT NOT NULL,
    "DataType" TEXT NOT NULL,
    "AllowedOperations" JSONB NOT NULL,
    "FilterType" TEXT NOT NULL,
    "FilterPicklistQuery" TEXT,
    "CreatedOnUtc" timestamp with time zone NOT NULL,
    "ModifiedOnUtc" timestamp with time zone NOT NULL,
    "IsDeleted" BOOLEAN NOT NULL,
    "DeletedOnUtc" timestamp with time zone
);
