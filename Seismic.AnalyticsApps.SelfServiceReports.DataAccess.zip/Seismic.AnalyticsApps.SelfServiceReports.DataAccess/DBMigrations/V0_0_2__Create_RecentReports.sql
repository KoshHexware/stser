﻿CREATE TABLE IF NOT EXISTS public."RecentReports" (
  "Id" bigserial PRIMARY KEY,
  "ReportId" uuid NOT NULL,
  "UserId"  VARCHAR(36) NOT NULL,
  "OpenDate" timestamp with time zone NOT NULL,
  UNIQUE ("ReportId", "UserId")
);