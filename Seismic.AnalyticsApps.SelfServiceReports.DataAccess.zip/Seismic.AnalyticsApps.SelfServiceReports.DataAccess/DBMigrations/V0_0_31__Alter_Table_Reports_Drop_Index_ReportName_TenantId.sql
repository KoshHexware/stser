-- Drop the existing index if it exists
DROP INDEX IF EXISTS "IX_Reports_ReportName_TenantId";
