﻿CREATE TABLE IF NOT EXISTS public."DataAreaAccess"
(
    "Id" bigserial PRIMARY KEY,    
    "TenantId" uuid NOT NULL,
    "DataAreaId" uuid NOT NULL,
    "UserIds" jsonb,
    "UserGroupIds" jsonb,
    "AccessType" text NOT NULL,
    "IsDeleted" boolean NOT NULL DEFAULT false,
    "CreatedOnUtc" timestamptz NOT NULL,
    "ModifiedOnUtc" timestamptz NOT NULL,
    "DeletedOnUtc" timestamptz,
    "CreatedBy" text NOT NULL,
    "ModifiedBy" text NOT NULL,
    "DeletedBy" text,
    CONSTRAINT "DataAreaAccess_AccessType_check" CHECK ("AccessType" = ANY (ARRAY['All', 'Included', 'Excluded', 'NoAccess']))
);
CREATE UNIQUE INDEX IF NOT EXISTS DataAreaAccess_DataAreaId_TenantId_Idx ON public."DataAreaAccess" ("DataAreaId", "TenantId");