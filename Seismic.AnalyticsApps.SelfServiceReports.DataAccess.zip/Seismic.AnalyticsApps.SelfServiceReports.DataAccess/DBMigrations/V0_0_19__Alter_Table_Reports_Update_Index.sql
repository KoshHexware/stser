-- Drop the existing index if it exists
DROP INDEX IF EXISTS Reports_ReportName_TenantId_Idx;

-- Create the new partial index
CREATE UNIQUE INDEX IF NOT EXISTS Reports_ReportName_TenantId_Idx
ON public."Reports" ("ReportName", "TenantId")
WHERE "IsDeleted" = false;