﻿CREATE TABLE IF NOT EXISTS public."AccessControlMigration"
(
    "Id" bigserial PRIMARY KEY, 
    "TenantId" uuid NOT NULL UNIQUE,   
    "Status" Text NOT NULL DEFAULT 'NotNeeded',
    "IsDeleted" boolean NOT NULL DEFAULT false,
    "CreatedOnUtc" timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ModifiedOnUtc" timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "DeletedBy" text,	
    "DeletedOnUtc" timestamptz DEFAULT NULL,
    CONSTRAINT "AccessControlMigration_Status_check" CHECK ("Status" = ANY (ARRAY['NotNeeded', 'Needed', 'Completed']))
);
    