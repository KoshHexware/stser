ALTER TABLE IF EXISTS public."DraftReports"
    ADD CONSTRAINT "DraftReports_ReportId_TenantId_Unique" UNIQUE ("ReportId", "TenantId");