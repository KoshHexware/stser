﻿CREATE TABLE IF NOT EXISTS public."TenantCacheInfo" (
  "Id" serial PRIMARY KEY,
  "TenantId" uuid UNIQUE NOT NULL,
  "CreatedOnUtc" timestamp with time zone NOT NULL,
  "CacheRefreshedAt" timestamp with time zone NOT NULL
)
WITH (
  OIDS=FALSE
);