DROP INDEX IF EXISTS RecentReports_ReportId_TenantId_Idx;

-- Add unique composite index on recentreport table for ReportId and TenantId columns
CREATE UNIQUE INDEX IF NOT EXISTS RecentReports_ReportId_TenantId_Idx ON public."RecentReports" ("ReportId", "UserId", "TenantId");
