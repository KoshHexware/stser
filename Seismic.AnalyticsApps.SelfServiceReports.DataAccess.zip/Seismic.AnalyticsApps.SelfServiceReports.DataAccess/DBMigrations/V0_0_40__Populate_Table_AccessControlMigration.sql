﻿DO $$
BEGIN
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'TenantCacheInfo' AND table_schema = 'public')
           AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'Reports' AND table_schema = 'public') THEN
            INSERT INTO public."AccessControlMigration" ("TenantId", "Status")
            SELECT DISTINCT "tenant_id", 'NotNeeded' as Status
            FROM (
                SELECT "TenantId" AS tenant_id FROM public."TenantCacheInfo"
                UNION
                SELECT "TenantId" AS tenant_id FROM public."Reports"
            ) AS merged_tenants
            WHERE tenant_id IS NOT NULL
            ON CONFLICT ("TenantId") DO NOTHING;
            UPDATE public."AccessControlMigration" SET "Status" = 'Needed';
        END IF;
END $$;