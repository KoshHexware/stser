﻿ALTER TABLE public."TenantCacheInfo"
ADD COLUMN "IsRunning" boolean NOT NULL DEFAULT false;