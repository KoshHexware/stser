﻿ALTER TABLE public."SharedReportWithUser"
ALTER COLUMN "UserId" DROP NOT NULL;

ALTER TABLE public."SharedReportWithUser"
ADD COLUMN "UserGroupId" TEXT NULL;