CREATE INDEX IF NOT EXISTS "IX_RecentReports_ReportId_UserId_TenantId" ON "public"."RecentReports"("ReportId", "UserId", "TenantId");
CREATE INDEX IF NOT EXISTS "IX_RecentReports_UserId_TenantId" ON "public"."RecentReports"("UserId", "TenantId");
CREATE INDEX IF NOT EXISTS "IX_Reports_ReportId_TenantId" ON "public"."Reports"("ReportId", "TenantId");
CREATE INDEX IF NOT EXISTS "IX_Reports_ReportName_TenantId" ON "public"."Reports"("ReportName", "TenantId");
