ALTER TABLE public."Reports"
ADD COLUMN "Teamsites" jsonb NOT NULL DEFAULT '[]'::jsonb;