﻿DO $$
BEGIN
        IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'TenantCacheInfo' AND table_schema = 'public')
            THEN
            INSERT INTO public."TenantOrgCacheInfo" ("TenantId", "CreatedOnUtc", "CacheRefreshedAt", "ModifiedOnUtc", "IsDeleted", "IsRunning")
            SELECT DISTINCT "TenantId",
            NOW() AS "CreatedOnUtc",
            NOW() - INTERVAL '20 minutes' AS "CacheRefreshedAt",
            NOW() AS "ModifiedOnUtc",
            false AS "IsDeleted",
            false AS "IsRunning"
            FROM public."TenantCacheInfo"
        WHERE "TenantId" IS NOT NULL
        ON CONFLICT ("TenantId") DO NOTHING;
        END IF;
END $$;