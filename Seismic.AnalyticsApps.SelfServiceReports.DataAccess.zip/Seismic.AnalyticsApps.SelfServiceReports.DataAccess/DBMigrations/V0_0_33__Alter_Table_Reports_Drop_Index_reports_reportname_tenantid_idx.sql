-- Drop the existing index if it exists
DROP INDEX IF EXISTS "reports_reportname_tenantid_idx";