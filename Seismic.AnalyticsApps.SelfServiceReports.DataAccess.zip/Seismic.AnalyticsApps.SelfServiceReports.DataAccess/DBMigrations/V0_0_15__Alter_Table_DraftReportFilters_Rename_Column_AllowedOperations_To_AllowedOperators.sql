ALTER TABLE public."DraftReportFilters"
RENAME COLUMN "AllowedOperations" TO "AllowedOperators";