﻿CREATE TABLE IF NOT EXISTS public."Reports" (
  "Id" bigserial PRIMARY KEY,
  "ReportName" TEXT NOT NULL,
  "TemplateName" TEXT NOT NULL,
  "OwnerUserId" TEXT NOT NULL,
  "Description" TEXT NOT NULL,
  "ReportType" TEXT NOT NULL CHECK ("ReportType" IN ('System', 'Custom')),
  "LastViewed" TIMESTAMPTZ NULL,
  "LastUpdated" TIMESTAMPTZ NOT NULL,
  "CreatedOnUtc" TIMESTAMPTZ NOT NULL,
  "ModifiedOnUtc" TIMESTAMPTZ NOT NULL,
  "IsDeleted" boolean NOT NULL DEFAULT false,
  "DeletedOnUtc" TIMESTAMPTZ NULL
);