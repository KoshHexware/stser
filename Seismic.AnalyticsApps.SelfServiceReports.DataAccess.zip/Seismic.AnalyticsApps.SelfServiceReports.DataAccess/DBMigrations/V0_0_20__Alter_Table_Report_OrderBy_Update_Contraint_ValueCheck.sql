ALTER TABLE public."Reports"
DROP CONSTRAINT IF EXISTS "Reports_OrderBy_check",
ADD CONSTRAINT "Reports_OrderBy_check" CHECK ("OrderBy" IN ('ASC', 'DESC', 'ASC nulls last', 'ASC nulls first', 'DESC nulls first','DESC nulls last'));
