﻿CREATE TABLE IF NOT EXISTS public."Reports" (
  "Id" bigserial PRIMARY KEY,
  "ReportId" uuid NOT NULL UNIQUE,
  "BaseReportId" uuid NOT NULL,
  "ReportName" text NOT NULL,
  "Description" text NOT NULL,
  "Domain" text NOT NULL,
  "OwnerUserId" text NOT NULL,
  "TenantId" uuid NOT NULL,
  "CreatedOnUtc" timestamp with time zone NOT NULL,
  "ModifiedOnUtc" timestamp with time zone NOT NULL,
  "IsDeleted" boolean NOT NULL DEFAULT false,
  "DeletedOnUtc" timestamp with time zone NULL
);

CREATE TABLE IF NOT EXISTS public."RecentReports" (
  "Id" bigserial PRIMARY KEY,
  "ReportId" uuid NOT NULL,
  "UserId" VARCHAR(36) NOT NULL,
  "OpenDate" timestamp with time zone NOT NULL,
  "TenantId" uuid NOT NULL,
  "CreatedOnUtc" timestamp with time zone NOT NULL,
  "ModifiedOnUtc" timestamp with time zone NOT NULL,
  "IsDeleted" boolean NOT NULL DEFAULT false,
  "DeletedOnUtc" timestamp with time zone NULL,
  UNIQUE ("ReportId", "UserId")
);