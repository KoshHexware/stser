﻿using Microsoft.EntityFrameworkCore;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Extension;
using Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using Serilog;
using System.Reflection;
using System.Text.Json;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

public class SsrsContext(DbContextOptions<SsrsContext> options,
    ILogger logger) : DbContext(options), ISsrsContext
{
    private readonly ILogger _logger = logger?.ForContext<SsrsContext>() ?? throw new ArgumentNullException(nameof(logger));

    public DbSet<RecentReport> RecentReports { get; set; }

    public DbSet<DraftReport> DraftReports { get; set; }

    public DbSet<Report> Reports { get; set; }

    public DbSet<TenantCacheInfo> TenantCacheInfo { get; set; }

    public DbSet<DraftReportFilter> DraftReportFilters { get; set; }

    public DbSet<UserSettings> UserSettings { get; set; }

    public DbSet<SharedReportWithUser> SharedReportWithUser { get; set; }

    public DbSet<DataAreaAccess> DataAreaAccess { get; set; }
    public DbSet<AccessControlMigration> AccessControlMigration { get; set; }

    public DbSet<TenantOrgCacheInfo> TenantOrgCacheInfo { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        modelBuilder.Entity<TenantCacheInfo>();

        modelBuilder.Entity<Report>()
             .HasQueryFilter(m => !m.IsDeleted)
            .Property(r => r.Fields)
            .HasConversion(
                v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                v => JsonSerializer.Deserialize<List<ReportField>>(v, JsonSerializerCustomOptions.Default)
            );

        modelBuilder.Entity<Report>()
             .HasQueryFilter(m => !m.IsDeleted)
            .Property(r => r.Filters)
            .HasConversion(
                v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                v => JsonSerializer.Deserialize<List<ReportFilter>>(v, JsonSerializerCustomOptions.Default)
            );

        modelBuilder.Entity<Report>()
            .Property(p => p.Teamsites)
            .HasConversion(
                v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                v => JsonSerializer.Deserialize<string[]>(v, JsonSerializerCustomOptions.Default)
            );

        modelBuilder.Entity<Report>()
        .Property(r => r.OrderBy)
        .HasConversion(
            v => v.GetDisplayName(),
            v => EnumExtension.GetEnumValueFromDisplayName<OrderType>(v)
        );

        modelBuilder.Entity<DraftReport>()
            .HasQueryFilter(m => !m.IsDeleted);

        modelBuilder.Entity<DraftReportFilter>(entity =>
        {
            entity.Property(r => r.AllowedOperators)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                    v => JsonSerializer.Deserialize<List<FilterOperation>>(v, JsonSerializerCustomOptions.Default)
                );

            entity.Property(r => r.DomainValues)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                    v => JsonSerializer.Deserialize<List<string>>(v, JsonSerializerCustomOptions.Default)
                );

            entity.Property(r => r.DataType)
                .HasConversion(
                    v => v.ToString(),
                    v => (DataType)System.Enum.Parse(typeof(DataType), v)
                );

            entity.Property(r => r.FilterType)
                .HasConversion(
                    v => v.ToString(),
                    v => (FilterType)System.Enum.Parse(typeof(FilterType), v)
                );

        });
         
        modelBuilder.Entity<AccessControlMigration>()
      .HasQueryFilter(m => !m.IsDeleted);
        modelBuilder.Entity<AccessControlMigration>(entity =>
        {
            entity.Property(a => a.Status)
                .HasConversion(
                    v => v.ToString(),
                    v => (AccessControlStatus)System.Enum.Parse(typeof(AccessControlStatus), v)
                );
        });
            modelBuilder.Entity<DataAreaAccess>()
       .HasQueryFilter(m => !m.IsDeleted);        

        modelBuilder.Entity<DataAreaAccess>(entity =>
        {
            entity.Property(p => p.UserIds)
           .HasConversion(
               v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
               v => JsonSerializer.Deserialize<string[]>(v, JsonSerializerCustomOptions.Default)
           );

            entity.Property(p => p.UserGroupIds)
           .HasConversion(
               v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
               v => JsonSerializer.Deserialize<string[]>(v, JsonSerializerCustomOptions.Default)
           );
            entity.Property(r => r.AccessType)
                .HasConversion(
                    v => v.ToString(),
                    v => (AccessType)System.Enum.Parse(typeof(AccessType), v)
                );

        });       

        modelBuilder.Entity<UserSettings>()
            .ToTable("UserSettings", "public")
            .HasQueryFilter(m => !m.IsDeleted)
            .HasIndex(u => u.UserId)
            .IsUnique();

        modelBuilder.Entity<UserSettings>()
            .Property(r => r.Teamsites)
            .HasConversion(
                v => JsonSerializer.Serialize(v, JsonSerializerCustomOptions.Default),
                v => JsonSerializer.Deserialize<string[]>(v, JsonSerializerCustomOptions.Default)
            );

        modelBuilder.Entity<SharedReportWithUser>()
            .ToTable("SharedReportWithUser", "public")
            .HasQueryFilter(m => !m.IsDeleted);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
    }

    public void WarmUp()
    {
        // trigger internal service provider and model build
        _ = this.Model;
        _logger.Information("Database warmup complete");
    }

    public async Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
    {
        return await this.Database.CanConnectAsync(cancellationToken);
    }

    public void SetCommandTimeout(TimeSpan timeout) => Database.SetCommandTimeout(timeout);

    public IQueryable<TEntity> FromSqlRaw<TEntity>(string sql, params object[] parameters) where TEntity : class =>
        this.Set<TEntity>().FromSqlRaw(sql, parameters);

    public Task<int> ExecuteSqlRawAsync(string sql, params object[] parameters) =>
        this.Database.ExecuteSqlRawAsync(sql, parameters);
}
