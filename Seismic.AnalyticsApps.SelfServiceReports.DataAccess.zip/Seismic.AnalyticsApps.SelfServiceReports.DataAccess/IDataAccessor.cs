﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess
{
    public interface IDataAccessor
    {
        Task<RecentReport?> GetRecentReportAsync(Guid reportId, string userId, Guid tenantId);

        Task<IEnumerable<RecentReportModel>> GetRecentReportsAsync(string userId, Guid tenantId);

        Task<Report?> GetReportAsync(Guid reportId, Guid tenantId);

        Task<Report?> GetReportByNameAsync(string reportName, Guid tenantId, string userId);

        /// <summary>
        /// Get custom reports by system report id
        /// </summary>
        /// <param name="reportId"></param>
        /// <param name="tenantId"></param>
        /// <returns></returns>
        Task<IEnumerable<Report>> GetAllReportsBySystemReportIdAsync(Guid systemReportId, Guid tenantId);

        Task<IEnumerable<ReportModel>> GetAllReportsAsync(Guid tenantId, string userId, string? searchText, bool ownedReportsOnly = false);

        Task<RecentReport> AddRecentReportAsync(RecentReport report);

        Task<RecentReport> UpdateRecentReportAsync(RecentReport report);

        /// <summary>
        /// Update multiple recent reports
        /// </summary>
        /// <param name="reports"></param>
        /// <returns></returns>
        Task<IEnumerable<RecentReport>> UpdateRecentReportsAsync(IEnumerable<RecentReport> reports);

        Task<IEnumerable<RecentReport>> GetRecentReportsForUserByReportIdsAsync(string userId, Guid tenantId, List<Guid> reportIds);

        Task<IEnumerable<RecentReport>> GetRecentReportsByReportIdsAsync(Guid tenantId, List<Guid> reportIds);

        Task<Report> SaveReportAsync(Report report);

        Task<Report> UpdateReportAsync(Report reportEntity);

        /// <summary>
        /// Update multiple reports
        /// </summary>
        /// <param name="reports"></param>
        /// <returns></returns>
        Task<IEnumerable<Report>> UpdateReportsAsync(IEnumerable<Report> reports);

        Task<IEnumerable<DraftReport>> GetAllDraftReports(Guid tenantId, string? searchText);

        Task<bool> IsDraftReportNameUniqueAsync(Guid tenantId, string reportName, Guid? reportId = null);

        Task<DraftReport?> GetDraftReportById(Guid reportId, Guid tenantId);

        Task<DraftReport> SaveDraftReportAsync(DraftReport draftReport);

        Task<DraftReport> UpdateDraftReportAsync(DraftReport draftReport);

        // draft report filters
        Task<IEnumerable<DraftReportFilter>> GetDraftReportFilters(Guid tenantId);

        Task<DraftReportFilter?> GetDraftReportFilterByName(Guid tenantId, string filterName);

        void UpdateDraftReportFilter(DraftReportFilter draftReportFilters);

        void AddDraftReportFilter(DraftReportFilter draftReportFilters);

        Task<int> SaveChangesAsync();

        Task DeleteRecentReportAsync(IEnumerable<RecentReport> recentReports);

        Task DeleteDraftReportAsync(DraftReport draftReport);

        Task DeleteDraftReportFilterAsync(DraftReportFilter draftReportFilter);

        Task<List<Guid>> GetAllTenants();

        Task<List<string>> GetAllReportOwnerUsers(Guid tenantId);

        Task<UserSettings?> GetUserSettingsAsync(Guid tenantId, string userId);

        Task<UserSettings> AddUserSettingsAsync(UserSettings userTeamsites);

        Task<UserSettings> UpdateUserSettingsAsync(UserSettings userTeamsites);

        Task<SharedReportWithUser> SaveSharedReportWithUserAsync(SharedReportWithUser shareReport, bool saveChanges = false);

        Task<List<string>> GetSharedReportUsersAsync(Guid reportId, Guid tenantId);

        Task<List<SharedReportWithUser>> GetSharedReportWithUsersAndGroupsAsync(Guid reportId, Guid tenantId);

        Task<SharedReportWithUser?> GetSharedReportWithUserAsync(Guid reportId, string userId, Guid tenantId, List<string> userGroupIds);

        Task<SharedReportWithUser?> GetSharedReportWithUsersAsync(Guid reportId, string userId, Guid tenantId);

        Task<SharedReportWithUser?> GetSharedReportWithUserGroupAsync(Guid reportId, string userGroupId, Guid tenantId);

        Task<SharedReportWithUser> UpdateSharedReportAsync(SharedReportWithUser sharedReport, bool saveChanges = false);

        Task<bool> IsReportShared(Guid reportId, string userId, Guid tenantId);

        Task<bool> IsReportSharedWithUser(Guid reportId, string userId, Guid tenantId);

        Task<bool> IsReportSharedWithUserGroup(Guid reportId, string userGroupId, Guid tenantId);

        Task<List<SharedReport>> GetSharedReportsForUserAsync(string? searchText, string userId, Guid tenantId, List<string> userGroupIds);

        Task<List<Report>> GetAllCustomReportsForTheTenant(Guid tenantId);

        Task<IEnumerable<DataAreaAccess>> GetAllDataAreasAccessAsync(Guid tenantId);

        Task<DataAreaAccess> UpdateDataAreaAccess(DataAreaAccess daaEntity);

        Task<IEnumerable<DataAreaAccess>> GetAllDataAreasAccessByIdsAsync(Guid tenantId, Guid[] dataAreaIds);

        Task<IEnumerable<DataAreaAccess>> UpdateDataAreaAccessRange(IEnumerable<DataAreaAccess> dataAreaAccesses);

        Task<DataAreaAccess> AddDataAreaAccessAsync(DataAreaAccess dataAreaAccess);

        Task<IEnumerable<DataAreaAccess>> AddDataAreaAccessRangeAsync(IEnumerable<DataAreaAccess> dataAreaAccesses);
        
        Task<IEnumerable<AccessControlMigration>> GetExistingAccessControlAsync(CancellationToken stoppingToken);
        Task<IEnumerable<AccessControlMigration>> GetExistingAccessControlWithLockAsync(CancellationToken stoppingToken);
        Task<IEnumerable<AccessControlMigration>> UpdateAccessControlMigrationRange(IEnumerable<AccessControlMigration> accessControlMigrations, CancellationToken stoppingToken);

        Task<List<TenantCacheInfo>> GetAllObslateTenantCacheInfo();

        Task<TenantCacheInfo> GetAndClaimTenantCacheInfoJobAsync(CancellationToken stoppingToken);

        Task<List<TenantOrgCacheInfo>> GetAllObslateTenantOrgCacheInfo();

        Task<TenantOrgCacheInfo> GetAndClaimTenantOrgCacheInfoJobAsync(CancellationToken stoppingToken);
    }
}
