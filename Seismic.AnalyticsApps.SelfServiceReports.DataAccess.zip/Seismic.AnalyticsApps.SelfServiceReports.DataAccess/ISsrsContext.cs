﻿using Microsoft.EntityFrameworkCore;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

public interface ISsrsContext
{
   

    DbSet<TEntity> Set<TEntity>() where TEntity : class;

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    void WarmUp();

    Task<bool> CanConnectAsync(CancellationToken cancellationToken = default);

    void SetCommandTimeout(TimeSpan timeout);

    IQueryable<TEntity> FromSqlRaw<TEntity>(string sql, params object[] parameters) where TEntity : class;

    Task<int> ExecuteSqlRawAsync(string sql, params object[] parameters);
}
