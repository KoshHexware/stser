﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public class RecentReport : BaseEntity
    {
        public Guid ReportId { get; set; }
        
        public required string UserId { get; set; }

        public DateTime OpenDate { get; set; }
    }
}
