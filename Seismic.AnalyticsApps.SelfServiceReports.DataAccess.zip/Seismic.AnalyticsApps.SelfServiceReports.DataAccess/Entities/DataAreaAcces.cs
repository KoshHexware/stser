﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
     
    public class DataAreaAccess : BaseEntity
    {
               
        [Required]
        public Guid DataAreaId { get; set; }
        
        [Column(TypeName = "jsonb")]
        public string[] UserIds { get; set; }
        
        [Column(TypeName = "jsonb")]
        public string[] UserGroupIds { get; set; }
        
        [Required]
        public AccessType AccessType { get; set; } = AccessType.NoAccess; // Included | Excluded | All | NoAccess

        [Required]
        public string CreatedBy { get; set; }

        [Required]
        public string ModifiedBy{ get; set; }

        public string? DeletedBy { get; set; }
    }
}
