﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using System.ComponentModel.DataAnnotations;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

public class AccessControlMigration : BaseEntity
{

    [Required]
    public AccessControlStatus Status { get; set; } = AccessControlStatus.NotNeeded; // Needed | NotNeeded | Completed
    
}
