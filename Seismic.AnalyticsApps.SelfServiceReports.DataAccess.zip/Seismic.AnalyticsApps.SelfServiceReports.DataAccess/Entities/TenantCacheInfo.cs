﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;

public class TenantCacheInfo : BaseEntity
{
    public DateTime CacheRefreshedAt { get; set; }

    public bool IsRunning { get; set; }
}