﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public class Report : BaseEntity
    {
        public Guid ReportId { get; set; }

        public Guid SystemReportId { get; set; }

        public required string ReportName { get; set; }

        public required string Description { get; set; }

        public string? Domain { get; set; }

        public required string OwnerUserId { get; set; }

        [Column(TypeName = "jsonb")]
        public required List<ReportField> Fields { get; set; }

        [Column(TypeName = "jsonb")]
        public List<ReportFilter>? Filters { get; set; }

        public string? OrderByField { get; set; }

        public OrderType OrderBy { get; set; }

        [Column(TypeName = "jsonb")]
        public required string[] Teamsites { get; set; }
    }

    public class ReportField
    {
        public required string Name { get; set; }

        public bool IsDefault { get; set; }

        /// <summary>
        /// This parameter will be true only if the field is a user property or custom property
        /// </summary>
        public bool? IsProperty { get; set; }

        public PropertyType? PropertyType { get; set; }

        /// <summary>
        /// user property or custom property id
        /// </summary>
        public string? PropertyId { get; set; }
    }

    public enum FormatterType
    {
        [EnumMember(Value = "none")]
        [Display(Name = "none")]
        NONE,

        [EnumMember(Value = "email-formatter")]
        [Display(Name = "email-formatter")]
        EMAIL_FORMATTER,

        [EnumMember(Value = "url-formatter")]
        [Display(Name = "url-formatter")]
        URL_FORMATTER,

        [EnumMember(Value = "number-formatter")]
        [Display(Name = "number-formatter")]
        NUMBER_FORMATTER,

        [EnumMember(Value = "rate-formatter")]
        [Display(Name = "rate-formatter")]
        RATE_FORMATTER
    }

    public enum DataType { Text, Integer, Decimal, DateTime, Boolean, Date, Csv }

    //Do not change the order of the enum values
    public enum Operation
    {
        Equals,
        NotEquals,
        GreaterThan,
        LessThan,
        GreaterThanOrEqual,
        LessThanOrEqual,
        Contains,
        StartsWith,
        EndsWith,
        Between,
        In,
        IsNull,
        IsNotNull,
        None
    }

    public class ReportFilter
    {
        public required string FilterName { get; set; }

        public Operation Operation { get; set; }

        public string[]? Values { get; set; }

        /// <summary>
        /// This parameter will be true only if the field is a user property or custom property
        /// </summary>
        public bool? IsProperty { get; set; }

        public PropertyType? PropertyType { get; set; }

        /// <summary>
        /// user property or custom property id
        /// </summary>
        public string? PropertyId { get; set; }
    }

    public enum PropertyType
    {
        None,
        UserProperty,
        ContentCustomProperty
    }

}
