﻿using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public class SharedReportWithUser : BaseEntity
    {
        public Guid ReportId { get; set; }

        public string? UserId { get; set; }

        public string? UserGroupId { get; set; }

        public DateTime SharedAtUtc { get; set; }
    }

    public class SharedReport
    {
        public Guid ReportId { get; set; }

        public Guid SystemReportId { get; set; }

        public string ReportName { get; set; }

        public string Description { get; set; }

        public string? Domain { get; set; }

        public string OwnerUserId { get; set; }

        public List<ReportField> Fields { get; set; }

        public List<ReportFilter>? Filters { get; set; }

        public string? OrderByField { get; set; }

        public OrderType OrderBy { get; set; }

        public DateTime SharedAtUtc { get; set; }

        public DateTime OpenDate { get; set; }

        public string UserId { get; set; }

        public long Id { get; set; }

        public Guid TenantId { get; set; }

        public DateTime CreatedOnUtc { get; set; }

        public DateTime ModifiedOnUtc { get; set; }

    }
}
