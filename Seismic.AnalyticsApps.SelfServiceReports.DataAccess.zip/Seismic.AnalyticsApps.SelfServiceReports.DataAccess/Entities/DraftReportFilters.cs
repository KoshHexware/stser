﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public class DraftReportFilter : BaseEntity
    {
        [Required]
        public required string FilterName { get; set; }

        public required string QueryParam { get; set; }

        public required string UxLabel { get; set; }

        public required string UxDescription { get; set; }

        public string? Category { get; set; }

        public DataType DataType { get; set; }

        [Column(TypeName = "jsonb")]
        public required List<FilterOperation> AllowedOperators { get; set; }

        public required FilterType FilterType { get; set; }

        public string? FilterPicklistQuery { get; set; }

        public bool IsRequired { get; set; }

        [Column(TypeName = "jsonb")]
        public List<string>? DomainValues { get; set; }

        public string? EnableRelativeUserFilterField { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class FilterOperation
    {
        public required string Name { get; set; }

        public required string UxLabel { get; set; }
    }

    public enum FilterType { freetext = 0,  picklist, domainOfValues }
}