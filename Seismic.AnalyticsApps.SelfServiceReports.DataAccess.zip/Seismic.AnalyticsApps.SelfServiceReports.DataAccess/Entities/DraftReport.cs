﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public class DraftReport : BaseEntity
    {
        public Guid ReportId { get; set; }
        public required string ReportName { get; set; }
        public required string Description { get; set; }
        public required string Template { get; set; }
    }
}
