﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities;
public class UserSettings : BaseEntity
{
    [Required]
    public string UserId { get; set; }

    [Column(TypeName = "jsonb")]
    public string[]? Teamsites { get; set; }

    public string? ReportsFilterOption { get; set; }

    public string? OrderField { get; set; }

    public string? OrderBy { get; set; }
}