﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Entities
{
    public abstract class BaseEntity
    {
        public long Id { get; set; }

        public Guid TenantId { get; set; }

        public DateTime CreatedOnUtc { get; set; }

        public DateTime ModifiedOnUtc { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime? DeletedOnUtc { get; set; }
    }
}
