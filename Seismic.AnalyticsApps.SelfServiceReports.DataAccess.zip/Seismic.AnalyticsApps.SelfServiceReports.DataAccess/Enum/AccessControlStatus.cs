﻿
namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum;

public enum AccessControlStatus
{
    Needed,
    NotNeeded,
    Completed
}

public static class AccessControlStatusExtensions
{
    public static string ToDisplayString(this AccessControlStatus option)
    {
        return option switch
        {
            AccessControlStatus.Needed => "Needed",
            AccessControlStatus.NotNeeded => "Not needed",
            AccessControlStatus.Completed => "Completed",
            _ => option.ToString()
        };
    }
}
