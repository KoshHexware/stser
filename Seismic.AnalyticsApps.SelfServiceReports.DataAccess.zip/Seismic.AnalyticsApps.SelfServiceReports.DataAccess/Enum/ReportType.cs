﻿namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum
{
    public enum ReportType
    {
        System,
        Custom
    }
}
