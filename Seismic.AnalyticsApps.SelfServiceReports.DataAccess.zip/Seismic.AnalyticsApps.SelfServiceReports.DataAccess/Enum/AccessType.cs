﻿using System.ComponentModel.DataAnnotations;


namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum
{
    public enum AccessType
    {
        [Display(Name = "Anyone can access any report")]
        All,

        [Display(Name = "Only invited people")]
        Included,

        [Display(Name = "Anyone except excluded people for some reports")]
        Excluded,

        [Display(Name = "No access")]
        NoAccess,

       
    }


}
