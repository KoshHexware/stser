﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Runtime.Serialization;


namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Enum
{
    public static class EnumHelper
    {
        public static string ToDisplayName(this System.Enum value)
        {
            var field = value.GetType().GetField(value.ToString());

            if (field == null)
                return value.ToString();

            // Try EnumMember attribute first
            var enumMemberAttr = field.GetCustomAttribute<EnumMemberAttribute>();
            if (enumMemberAttr?.Value != null)
                return enumMemberAttr.Value;

            // Fall back to Display attribute
            var displayAttr = field.GetCustomAttribute<DisplayAttribute>();
            if (displayAttr?.Name != null)
                return displayAttr.Name;

            return value.ToString();
        }
    }
}
