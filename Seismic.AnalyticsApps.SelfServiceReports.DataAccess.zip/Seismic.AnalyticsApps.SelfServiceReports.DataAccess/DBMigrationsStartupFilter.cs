﻿using EvolveDb;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Npgsql;
using Serilog;
using System.Reflection;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

public class DBMigrationsStartupFilter(ILogger logger, string connString) : IStartupFilter
{
    private readonly ILogger _logger = logger?.ForContext<DBMigrationsStartupFilter>() ?? throw new ArgumentNullException(nameof(logger));
    private readonly string _dbConnString = connString;

    public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next)
    {
        _logger.Information("Starting evolve migrations.");
        if (string.IsNullOrWhiteSpace(_dbConnString))
        {
            _logger.Information("Evolve migrations skipped, empty connection string.");
            return next;
        }

        try
        {
            var sqlLocation = $"{Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)}/DBMigrations";

            using var connection = new NpgsqlConnection(_dbConnString);

            var evolve = new Evolve(connection, msg => _logger.ForContext<Evolve>().Warning(msg))
            {
                Locations = [sqlLocation],
                IsEraseDisabled = false,
            };
            evolve.Migrate();
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Database migration failed. Error:{error}", ex.Message);
            throw;
        }

        _logger.Information("Evolve migrations finished.");

        return next;
    }
}

