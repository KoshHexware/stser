﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

[ExcludeFromCodeCoverage]
public class DBOptions(string cs)
{
    public string ConnectionString { get; set; } = cs;
}