﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Filters
{
    public class RequiredAccessLevelAttribute(params AccessLevel[] requiredAccessLevels) : CustomAttributeBase, IAsyncAuthorizationFilter
    {
        private readonly IEnumerable<AccessLevel> _requiredAccessLevels = requiredAccessLevels;

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            if (ShouldSkip(context))
            {
                return;
            }

            var contextProvider = context.HttpContext.RequestServices.GetService<ISeismicContextProvider>();
            var permissionService = context.HttpContext.RequestServices.GetService<IPermissionService>();
            var logger = context.HttpContext.RequestServices.GetService<Serilog.ILogger>() ?? Serilog.Log.Logger;

            var seismicContext = contextProvider?.GetContext();

            if (seismicContext == null)
            {
                ValidationFailed(context, "RequiredAccessLevelForbidden", "No context.");
                return;
            }

            if (seismicContext.UserId == null)
            {
                ValidationFailed(context, "RequiredAccessLevelForbidden", "No user in bearer token.");
                return;
            }

            if (permissionService == null)
            {
                context.Result = new StatusCodeResult(500); // Internal Server Error
                return;
            }

            var access = await permissionService.GetContextUserAccess(false);

            if (!_requiredAccessLevels.Contains(access))
            {
                logger.Warning("User {UserId} does not have required access. Required: {RequiredAccessLevel}, Actual: {Access}.", seismicContext.UserId, string.Join(", ", _requiredAccessLevels), access);
                ValidationFailed(context, "RequiredAccessLevelForbidden", "Permissions denied.");
            }
        }
    }
}
