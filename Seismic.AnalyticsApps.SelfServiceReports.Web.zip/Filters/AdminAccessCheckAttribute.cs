﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Filters
{
    public class AdminAccessCheckAttribute : CustomAttributeBase, IAsyncAuthorizationFilter
    {
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            if (ShouldSkip(context))
            {
                return;
            }

            var contextProvider = context.HttpContext.RequestServices.GetService<ISeismicContextProvider>();
            var permissionService = context.HttpContext.RequestServices.GetService<IPermissionService>();
            var logger = context.HttpContext.RequestServices.GetService<Serilog.ILogger>() ?? Serilog.Log.Logger;
            
            var seismicContext = contextProvider?.GetContext();

            if (seismicContext == null)
            {
                ValidationFailed(context, "RequiredAccessLevelForbidden", "No context.");
                return;
            }

            if (seismicContext.UserId == null)
            {
                ValidationFailed(context, "RequiredAccessLevelForbidden", "No user in bearer token.");
                return;
            }

            if (permissionService == null)
            {
                context.Result = new StatusCodeResult(500); // Internal Server Error
                return;
            }

            var access = await permissionService.HasAdminAccess(false);

            if (!access)
            {
                logger.Warning("User {UserId} does not have admin access.", seismicContext.UserId);
                ValidationFailed(context, "RequiredAccessLevelForbidden", "Permissions denied.");
            }

            return;
        }
    }
}
