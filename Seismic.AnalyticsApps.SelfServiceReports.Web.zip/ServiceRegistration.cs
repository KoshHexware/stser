﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Probes;
using Seismic.Common.ServiceFoundation;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web;

public static class ServiceRegistration
{
    public static IServiceCollection AddDB(this IServiceCollection services)
    {
        if (IsBackgroundWorkload())
        {
            services.TryAddEnumerable(ServiceDescriptor.Singleton<IStartupFilter, DBMigrationsStartupFilter>(p =>
            {
                var seismicInstance = p.GetRequiredService<ISeismicInstance>();
                return new DBMigrationsStartupFilter(p.GetRequiredService<ILogger>(), p.GetRequiredService<DBOptions>().ConnectionString);
            }));
        }

        services.AddDbContextPool<SsrsContext>((serviceProvider, options) =>
        {
            var dbOptions = serviceProvider.GetRequiredService<DBOptions>();
            options.UseNpgsql(dbOptions.ConnectionString, o => o.EnableRetryOnFailure(2));
        });
        services.AddDbContext<SsrsContext>();
        services.AddScoped<ISsrsContext>(p => p.GetRequiredService<SsrsContext>());
        return services;
    }

    public static void AddAPICommonHealthProbes(this IServiceCollection services)
    {
        services
            .AddHealthChecks()
            .AddCheck<EFCoreStartupProbe>("api-ef-startup", HealthStatus.Unhealthy, ["startup"]);
        services
            .AddHealthChecks()
            .AddCheck<RedisStartupProbe>("api-redis-startup", HealthStatus.Unhealthy, ["startup"]);
    }

    public static bool IsBackgroundWorkload()
    {
        var backgroundWorkload = GetBackgroundWorkload();
        return backgroundWorkload == BackgroundWorkloadConstants.CONTROLLER_BACKGROUND_WORKLOAD;
    }


    public static string GetBackgroundWorkload()
    {
        var backgroundWorkload = BackgroundWorkloadConstants.WORKER_BACKGROUND_WORKLOAD;
        var fromEnv = Environment.GetEnvironmentVariable("BACKGROUND_WORKLOAD");
        if (fromEnv == BackgroundWorkloadConstants.WORKER_BACKGROUND_WORKLOAD ||
            fromEnv == BackgroundWorkloadConstants.CONTROLLER_BACKGROUND_WORKLOAD)
        {
            backgroundWorkload = fromEnv;
        }

        return backgroundWorkload;
    }
}