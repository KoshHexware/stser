using Microsoft.AspNetCore;
using Seismic.AnalyticsApps.SelfServiceReports.Web;

WebHost.CreateDefaultBuilder(args).ConfigureKestrel(serverOptions =>
{
    // Increase the maximum request line size (default is 8 KB)
    serverOptions.Limits.MaxRequestLineSize = 64 * 1024; // 64 KB
    serverOptions.Limits.MaxResponseBufferSize = null; // no limit
    // Increase the maximum request headers total size (default is 32 KB)
    serverOptions.Limits.MaxRequestHeadersTotalSize = 64 * 1024; // 64 KB
}).UseStartup<Startup>().UseUrls("http://*:5000").Build().Run();