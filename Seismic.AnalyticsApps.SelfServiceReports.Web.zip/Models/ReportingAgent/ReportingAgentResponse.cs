﻿using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportingAgent;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models.ReportingAgent
{
    
   
    public class ApiErrorResponse
    {
        public required bool Success { get; set; }=false;
        public List<ApiError>? Errors { get; set; }  // optional, only on error
        public required object Data { get; set; } = null!;
    }

}
