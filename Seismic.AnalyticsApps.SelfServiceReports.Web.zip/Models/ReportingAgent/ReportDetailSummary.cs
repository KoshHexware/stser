﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models.ReportingAgent
{
    public class ReportDetailSummary
    {
        public string ReportName { get; set; }
        public string ReportDescription { get; set; }
        public List<string> DefaultFields { get; set; }
        public List<string> Metrics { get; set; }

    }
}
