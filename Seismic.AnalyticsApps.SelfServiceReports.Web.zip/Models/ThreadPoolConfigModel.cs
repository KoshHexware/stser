﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models
{
    [ExcludeFromCodeCoverage]
    public class ThreadPoolConfigModel
    {
        public int MinWorkerThreads { get; set; }

        public int MinIocpThreads { get; set; }
    }
}
