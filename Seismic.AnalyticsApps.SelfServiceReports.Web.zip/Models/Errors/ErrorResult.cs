﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;

public class ErrorResult : ObjectResult
{
    public ErrorResult(ModelStateDictionary modelState, string title, string? traceId)
        : this(new ErrorResponseModel(modelState, title, traceId))
    {
    }

    public ErrorResult(ErrorResponseModel errorResponseModel)
        : base(errorResponseModel)
    {
        StatusCode = StatusCodes.Status400BadRequest;
    }
}
