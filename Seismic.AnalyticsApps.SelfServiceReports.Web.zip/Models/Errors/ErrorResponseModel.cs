﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;

public class ErrorResponseModel(string title, string? traceId, string? detail = null)
{
    public string? TraceId { get; set; } = traceId;
    public string Title { get; set; } = title;
    public string? Detail { get; set; } = detail;
    public IEnumerable<ErrorMessageInfo>? Errors { get; set; }

    public ErrorResponseModel(ModelStateDictionary modelState, string title, string? traceId, string? detail = null) :
        this(title, traceId, detail)
    {
        var errors = new List<ErrorMessageInfo>();
        foreach (var state in modelState)
        {
            foreach (var error in state.Value.Errors)
            {
                errors.Add(new ErrorMessageInfo(state.Key, error.ErrorMessage));
            }
        }

        Errors = errors;
    }

    public ErrorResponseModel(IEnumerable<ErrorMessageInfo> errors, string title, string? traceId, string? detail = null)
        : this(title, traceId, detail)
    {
        Errors = errors;
    }
}
