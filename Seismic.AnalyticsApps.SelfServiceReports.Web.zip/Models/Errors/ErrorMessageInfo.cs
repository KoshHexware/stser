﻿namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;

public class ErrorMessageInfo(string key, string message)
{
    public string Key { get; set; } = key;
    public string Message { get; set; } = message;
}
