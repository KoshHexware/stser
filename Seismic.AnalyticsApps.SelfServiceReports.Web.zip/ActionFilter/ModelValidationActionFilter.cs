﻿using Microsoft.AspNetCore.Mvc.Filters;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.ActionFilter;

public class ModelValidationActionFilter : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext actionContext)
    {
        if (!actionContext.ModelState.IsValid)
        {
            actionContext.Result = new ErrorResult(actionContext.ModelState,
                ValidationConstants.API_VALIDATION_ERROR_TITLE, null);
        }
    }
}
