﻿using Seismic.AnalyticsApps.SelfServiceReports.Common;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Extensions;

public static class HttpContextExtensions
{
    public static string GetCorrelationId(this HttpContext context)
    {
        string? sCorrelationId = null;
        if (context.Items.TryGetValue(CorrelationConstants.CORRELATION_ID, out var correlationId))
        {
            if (correlationId != null)
            {
                sCorrelationId = correlationId.ToString();
            }
        }

        if (sCorrelationId == null)
        {
            var correlationIdFromHeader = context.Request.Headers[CorrelationConstants.HEADER_CORRELATION_ID];
            if (correlationIdFromHeader.Count > 0)
            {
                sCorrelationId = correlationIdFromHeader.First();
                context.Items[CorrelationConstants.CORRELATION_ID] = sCorrelationId;
            }
        }

        sCorrelationId ??= Guid.NewGuid().ToString();

        return sCorrelationId;
    }
}
