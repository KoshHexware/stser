﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Seismic.Common.ServiceFoundation.Abstraction;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Probes;

public class RedisStartupProbe(IServiceScopeFactory factory) : IHealthCheck
{
    private readonly IServiceScopeFactory _factory = factory;

    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context,
        CancellationToken cancellationToken = new CancellationToken())
    {
        using (var scope = _factory.CreateScope())
        {
            var cache = scope.ServiceProvider.GetRequiredService<ISeismicRedisCache>();
            _ = cache.Get("test-key");
        }

        return Task.FromResult(HealthCheckResult.Healthy());
    }
}