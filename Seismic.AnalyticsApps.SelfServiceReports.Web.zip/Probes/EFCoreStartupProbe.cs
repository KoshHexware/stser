﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Probes;

public class EFCoreStartupProbe(IServiceScopeFactory factory) : IHealthCheck
{
    private readonly IServiceScopeFactory _factory = factory;

    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context,
        CancellationToken cancellationToken = new CancellationToken())
    {
        using (var scope = _factory.CreateScope())
        {
            var dbContext = scope.ServiceProvider.GetRequiredService<ISsrsContext>();
            dbContext.WarmUp();
        }

        return Task.FromResult(HealthCheckResult.Healthy());
    }
}