﻿using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.OpenApi.Models;
using Seismic.Analytics.DataAccess.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess.Snowflake;
using Seismic.AnalyticsApps.SelfServiceReports.Services;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Middleware;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;
using Seismic.Common.ServiceFoundation;
using Seismic.Common.ServiceFoundation.Extensions;
using Seismic.Common.ServiceFoundation.Extensions.DotnetExtension;
using Seismic.Platform.BlobStorageService.Client.Configuration;
using Seismic.Platform.BlobStorageService.Client.Dto;
using Seismic.Platform.BlobStorageService.Client.Extensions;
using System.Diagnostics;
using System.Net.Mime;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using ILogger = Serilog.ILogger;


namespace Seismic.AnalyticsApps.SelfServiceReports.Web;

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services
            .AddLogging(config => config.ClearProviders()) // clear out the default logging
            .ConfigureSeismicWeb(
                serviceCollectionForEnv =>
                    serviceCollectionForEnv
                        .AddOutboundHttpLogging()
                        .AddSnowflakeSdk("self-service-reports-service")
            )
            .AddSeismicCorsPolicy("https://localhost:5000")
            .AddSeismicSwaggerGen("self service reports", "self service reports", "v1", (p) =>
            {
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                p.IncludeXmlComments(xmlPath);

                
                p.SwaggerDoc("public", new OpenApiInfo { Title = "Self service report API", Version = "v1" });
                p.SwaggerDoc("internal", new OpenApiInfo { Title = "Self service report internal API", Version = "v1" });
            })
            .AddInstanceExtension("redis", RedisHelper.FromConfig)
            .AddInstanceExtension("db", PgDbHelper.FromConfig)
            .AddEnvExtension("launch_darkly", ExtensionHelper.JObjectExtension<LaunchDarklyOption>())
            .AddEnvExtension("thread_pool", ExtensionHelper.JObjectExtension<ThreadPoolConfigModel>())

            .AddMvc(option => { option.EnableEndpointRouting = false; })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
            })
            .ConfigureApiBehaviorOptions(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var result = new ErrorResult(context.ModelState, ValidationConstants.API_VALIDATION_ERROR_TITLE,
                        context.HttpContext.GetCorrelationId());
                    result.ContentTypes.Add(MediaTypeNames.Application.Json);
                    return result;
                };
            });

        // TODO: Add DB and Redis cache
        services.AddMemoryCache();
        services.AddBlobStorageServiceClient(new ClientAppMetadata("ssrs", "1.0"), new BaseBlobStorageServiceClientOptions());

        services.AddDB();
        services.AddMapper();
        services.AddBusinessServices(ServiceRegistration.IsBackgroundWorkload());
        services.AddRedisCache();
        services.AddHealthReadinessAndStartupChecks();
        services.AddOutboundHttpLogging();


        // setup fluent validation
        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        services.AddFluentValidationAutoValidation(p =>
            p.DisableDataAnnotationsValidation = true);
        services.AddAPICommonHealthProbes();

        services.AddSnowflakeDataServices();
        services.AddHttpContextAccessor();
    }

    public void Configure(IApplicationBuilder app)
    {
        ConfigureThreadPool(app);

        var seismicInstance = app.ApplicationServices.GetService<ISeismicInstance>();
        // Warm up SystemReportRepository singleton at startup
        var logger = app.ApplicationServices.GetService<ILogger>();
        try
        {
            logger?.Information("Initializing SystemReportRepository...");
            var systemReportsRepo = app.ApplicationServices.GetRequiredService<ISystemReportsRepository>();
            logger?.Information("SystemReportRepository initialized successfully");
        }
        catch (Exception ex)
        {
            logger?.Error(ex, "Failed to initialize SystemReportRepository at startup");
            throw new InvalidOperationException("SystemReportRepository initialization failed", ex);
        }
        app.UseMiddleware<ExceptionMiddleware>();
        app.UseMiddleware<CorrelationMiddleware>();
        var options = new SeismicApplicationOptions();
        app.DecorateLogs()
            .UseBasicHealthcheck()
            .LogRequests(options.LoggingFilter);
        app.WhenInEnvs(seismicInstance, p => p.ServeSwagger(options.SwaggerUIEnabled, false,
               options.SwaggerAdditionalConfig),
           "local", "dev", "qa");
        app.AddAboutEndpoint();
        app.UseAuthentication()
            .DecorateNewRelicTransactions()
            .UseCors(options.CorsPolicyName)
            .UseMvc();
        app.ConfigureAppShutdown(); // default shutdown delay to prevent nginx related rolling updates issue in k8
        app.ConfigureAppShutdown(() =>
        {
            StopBackgroundWorkload(app.ApplicationServices);
        }); // custom shutdown code will be executed first

        app.Use(KestrelLoggingMiddleware.LoggingKestrelInboundRequest);

        app.UseSwagger();
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint("/swagger/public/swagger.json", "Self service report API");
            c.SwaggerEndpoint("/swagger/internal/swagger.json", "Self service report internal API");
            c.RoutePrefix = string.Empty;
            c.DefaultModelsExpandDepth(-1);
        });


    }

    private static void StopBackgroundWorkload(IServiceProvider serviceProvider)
    {
        var logger = serviceProvider.GetService<ILogger>();
        logger?.Information("Background workload stop started");
        var cancellationSource = new CancellationTokenSource();
        var tasks = new List<Task>();

        if (ServiceRegistration.IsBackgroundWorkload())
        {
            serviceProvider.GetServices<IHostedService>()
                .Where(p => p is BackgroundService)
                .Select(p => (BackgroundService)p)
                .ToList()
                .ForEach(p => tasks.Add(p.StopAsync(cancellationSource.Token)));
        }

        cancellationSource.CancelAfter(BackgroundWorkloadConstants.GRACEFUL_SHUTDOWN_TIMEOUT_MS);
        Task.WhenAll(tasks);
        logger?.Information("Background workload stop finished");
    }

    private static void ConfigureThreadPool(IApplicationBuilder builder)
    {
        var logger = builder.ApplicationServices.GetService<ILogger>();
        var threadPoolModel = builder.ApplicationServices.GetService<ThreadPoolConfigModel>();

        if(threadPoolModel == null || threadPoolModel.MinIocpThreads <= 0 || threadPoolModel.MinWorkerThreads <= 0)
        {
            logger?.Warning("ThreadPoolConfigModel is not configured or invalid, not configuring thread pool.");
            return;
        }

        logger?.Information("Available memory; {NumberOfBytes} bytes.", Process.GetCurrentProcess().PrivateMemorySize64);

        var minIOThreads = threadPoolModel.MinIocpThreads;
        var minWorkerThreads = threadPoolModel.MinWorkerThreads;

        ThreadPool.GetMinThreads(out var minWorkerDefaultThreadCount, out var minIODefaultThreadCount);
        logger?.Information("Min Worker Default threads: {MinWorkerDefaultThreadCount}, Min IOCP Default threads: {MinIODefaultThreadCount}", minWorkerDefaultThreadCount, minIODefaultThreadCount);

        if (minIOThreads <= 0)
        {
            minIOThreads = minIODefaultThreadCount;
        }
        if (minWorkerThreads <= 0)
        {
            minWorkerThreads = minWorkerDefaultThreadCount;
        }

        if (ThreadPool.SetMinThreads(minWorkerThreads, minIOThreads))
        {
            logger?.Information("Min Worker threads updated to: {MinWorkerThreads}, Min IOCP threads updated to: {MinIOThreads}", minWorkerThreads, minIOThreads);
        }
        else
        {
            logger?.Error("ConfigureThreadPool Error. minWorkerDefault:{MinWorkerDefaultThreadCount}, minIODefaultThreadCount:{MinIODefaultThreadCount}, minWorkerThreads:{MinWorkerThreads}, minIOThreads:{MinIOThreads}", minWorkerDefaultThreadCount, minIODefaultThreadCount, minWorkerThreads, minIOThreads);
        }
    }

}
