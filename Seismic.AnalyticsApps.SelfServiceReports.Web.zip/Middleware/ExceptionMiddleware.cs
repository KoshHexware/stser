﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Models.Errors;
using Seismic.Common.ServiceFoundation;
using System.Net;
using System.Net.Mime;
using System.Text.Json;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Middleware;

public class ExceptionMiddleware(RequestDelegate next,
    ILogger logger,
    ISeismicInstance seismicInstance,
    IOptions<JsonOptions> jsonOptions)
{
    private readonly RequestDelegate _next = next;
    private readonly ILogger _logger = logger.ForContext<ExceptionMiddleware>();
    private readonly ISeismicInstance _seismicInstance = seismicInstance;
    private readonly IOptions<JsonOptions> _jsonOptions = jsonOptions;

    private readonly IEnumerable<string>
        _probeRelativeURLs = ["/readiness", "/startup", "/health"];

    public async Task InvokeAsync(HttpContext httpContext)
    {
        try
        {
            await _next(httpContext);
        }
        catch (BadHttpRequestException ex)
            when (ex.Message.StartsWith("Request body too large"))
        {
            await HandleRequestBodyLargeExceptionAsync(httpContext, ex);
        }
        catch (ForbiddenException ex)
        {
            await HandleForbiddenExceptionAsync(httpContext, ex);
        }
        catch (BadRequestException ex)
        {
            await HandleBadRequestExceptionAsync(httpContext, ex);
        }
        catch (NotFoundException ex)
        {
            await HandleNotFoundExceptionAsync(httpContext, ex);
        }
        catch (Exception ex)
        {
            if (HandleRequestAbortedInProbes(httpContext))
            {
                return;
            }

            await HandleExceptionAsync(httpContext, ex);
        }
    }

    private bool HandleRequestAbortedInProbes(HttpContext httpContext)
    {
        if (httpContext.RequestAborted.IsCancellationRequested)
        {
            if (_probeRelativeURLs.Contains(httpContext.Request.Path.Value))
            {
                return true;
            }
        }

        return false;
    }

    private async Task HandleRequestBodyLargeExceptionAsync(HttpContext context, BadHttpRequestException exception)
    {
        _logger.Error(exception, "API validation error");
        var errorResponseModel = new ErrorResponseModel(exception.Message, context.GetCorrelationId());
        await WriteResponseErrorMessageAsync(context, HttpStatusCode.BadRequest, errorResponseModel);
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        _logger.Error(exception, $"Unexpected exception error. {exception.Message}.{exception.InnerException?.Message}");
        string detail = $"{exception.Message}.{exception.InnerException?.Message}";
        var returnStackTraceToEnvs = new[] { "local", "dev", "qa" };
        if (returnStackTraceToEnvs.Contains(_seismicInstance.SeismicEnv))
        {
            detail += $"{exception.Message} {exception.StackTrace}";
        }

        var errorResponseModel = new ErrorResponseModel(ValidationConstants.GENERIC_ERROR_TITLE,
            context.GetCorrelationId(), detail);
        await WriteResponseErrorMessageAsync(context, HttpStatusCode.InternalServerError, errorResponseModel);
    }

    private async Task WriteResponseErrorMessageAsync(HttpContext context, HttpStatusCode statusCode,
        ErrorResponseModel errorResponseModel)
    {
        context.Response.ContentType = MediaTypeNames.Application.Json;
        context.Response.StatusCode = (int)statusCode;
        await context.Response.WriteAsync(JsonSerializer.Serialize(errorResponseModel,
            _jsonOptions.Value.JsonSerializerOptions));
    }

    private async Task HandleForbiddenExceptionAsync(HttpContext context, ForbiddenException exception)
    {
        _logger.Error(exception, "Forbidden access error");
        var errorResponseModel = new ErrorResponseModel(exception.Message, context.GetCorrelationId());
        await WriteResponseErrorMessageAsync(context, HttpStatusCode.Forbidden, errorResponseModel);
    }

    private async Task HandleBadRequestExceptionAsync(HttpContext context, BadRequestException exception)
    {
        _logger.Error(exception, $"Bad request error. {exception.Message}");
        var errorResponseModel = new ErrorResponseModel(exception.Message, context.GetCorrelationId());
        await WriteResponseErrorMessageAsync(context, HttpStatusCode.BadRequest, errorResponseModel);
    }

    private async Task HandleNotFoundExceptionAsync(HttpContext context, NotFoundException exception)
    {
        _logger.Error(exception, $"Not found error. {exception.Message}");
        var errorResponseModel = new ErrorResponseModel(exception.Message, context.GetCorrelationId());
        await WriteResponseErrorMessageAsync(context, HttpStatusCode.NotFound, errorResponseModel);
    }
}