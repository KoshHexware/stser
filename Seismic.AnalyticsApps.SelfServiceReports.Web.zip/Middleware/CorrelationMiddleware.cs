﻿using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Extensions;
using Serilog.Context;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Middleware;
public class CorrelationMiddleware(RequestDelegate next)
{
    private readonly RequestDelegate _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        var correlationId = context.GetCorrelationId();
        context.Response.OnStarting(state =>
        {
            if (state is HttpContext httpContext)
            {
                httpContext.Response.Headers.Append(CorrelationConstants.HEADER_CORRELATION_ID, correlationId);
            }

            return Task.CompletedTask;
        }, context);

        // Add correlation id in log context
        using (LogContext.PushProperty(CorrelationConstants.CORRELATION_ID, correlationId))
        using (LogContext.PushProperty(LoggingConstants.GIT_SHA, Environment.GetEnvironmentVariable("COMMIT_HASH")))
        {
            await _next(context);
        }
    }
}
