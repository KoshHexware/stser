﻿using Newtonsoft.Json.Linq;
using Npgsql;
using Seismic.AnalyticsApps.SelfServiceReports.DataAccess;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Helpers
{
    public static class PgDbHelper
    {
        public static DBOptions FromConfig(JObject keyValuePair)
        {
            var connection = new NpgsqlConnectionStringBuilder()
            {
                Host = keyValuePair.Value<string>("host"),
                Database = keyValuePair.Value<string>("database"),
                Username = keyValuePair.Value<string>("username"),
                Password = keyValuePair.Value<string>("password"),
                Port = keyValuePair.Value<int?>("port") ?? 5432,
                SslMode = Enum.TryParse<SslMode>(keyValuePair.Value<string>("ssl_mode"), out var result) ? result : SslMode.Disable,
                RootCertificate = keyValuePair.Value<string>("root_cert"),
                SslCertificate = keyValuePair.Value<string>("ssl_cert"),
                SslKey = keyValuePair.Value<string>("ssl_key"),
            };

            return new DBOptions(connection.ConnectionString);
        }
    }
}
