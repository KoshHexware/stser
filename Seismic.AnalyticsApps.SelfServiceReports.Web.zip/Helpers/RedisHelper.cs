﻿using Newtonsoft.Json.Linq;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Cache.Models;
using StackExchange.Redis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Helpers
{
    public static class RedisHelper
    {
        public static RedisOptions FromConfig(JObject keyValuePair)
        {
            var configurationOptions = new ConfigurationOptions
            {
                EndPoints = { $"{keyValuePair.Value<string>("host")}:{keyValuePair.Value<int?>("port") ?? 6379}" },
                Ssl = keyValuePair.Value<bool?>("ssl") ?? false,
                ConnectTimeout = keyValuePair.Value<int?>("connect_timeout") ?? 5000,
                AsyncTimeout = keyValuePair.Value<int?>("async_timeout") ?? 2000,
                SyncTimeout = keyValuePair.Value<int?>("sync_timeout") ?? 2000,
                AbortOnConnectFail = keyValuePair.Value<bool?>("abortConnect") ?? true,
            };

            if (keyValuePair.ContainsKey("username"))
            {
                configurationOptions.User = keyValuePair.Value<string>("username");
            }
            if (keyValuePair.ContainsKey("password"))
            {
                configurationOptions.Password = keyValuePair.Value<string>("password");
            }

            var connectionString = configurationOptions.ToString();

            string? certificate = null;
            if (keyValuePair.ContainsKey("certificate"))
            {
                certificate = keyValuePair.Value<string>("certificate");
            }

            return new RedisOptions(connectionString, certificate);
        }
    }

}
