﻿using CsvHelper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Newrelic;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Extensions;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Filters;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [RequiredScopes("library")]
    [ApiExplorerSettings(GroupName = "public")]
    public class ReportController(IReportService _reportService, IReportRunner _reportRunner,
        ISeismicContextProvider _contextProvider, ILogger logger, INewRelicCustomEventHelper _newRelicCustomEventHelper) : Controller
    {
        private readonly ILogger _logger = (logger?.ForContext<ReportController>() ?? logger) ?? throw new ArgumentNullException(nameof(logger));

        private const string REPORT_NAME_REGEX = @"\s+";

        [HttpGet]
        [Route("api/v1/reports/all")]
        [ProducesResponseType<PagedList<Report>>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetReports([FromQuery] string? reportType, [FromQuery] string? searchText,
            [FromQuery] int take, [FromQuery] int skip, [FromQuery] string? orderField, [FromQuery] string? orderBy, [FromQuery] bool includeDrafts = true)
        {
            var context = _contextProvider.GetContext();
            var result = await _reportService.GetAllReports(context.TenantIdentifier.TenantUniqueId, context.UserId, reportType, searchText, take, skip, orderField, orderBy, includeDrafts);
            return Ok(result);
        }

        /// <summary>
        /// Returns a list of system and owned reports name and id based on the search text and flags for drafts and ownership.
        /// </summary>
        /// <param name="searchText"></param>
        /// <param name="includeDrafts"></param>
        /// <param name="ownedReportsOnly">If false then response will include all custom reports of the tenant. and system reports.</param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1/reports/owned")]
        [ProducesResponseType<List<ReportIdNameModel>>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetSystemAndOwnedReports([FromQuery] string? searchText = null, [FromQuery] bool includeDrafts = true, [FromQuery] bool ownedReportsOnly = true)
        {
            var context = _contextProvider.GetContext();
            var result = await _reportService.GetSystemAndOwnedReports(context.TenantIdentifier.TenantUniqueId, context.UserId, searchText, includeDrafts, ownedReportsOnly);
            return Ok(result);
        }

        [HttpGet]
        [Route("api/v1/report/{reportId}")]
        [ProducesResponseType<Report>(200)]
        [ProducesResponseType(404)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetReport([FromRoute] Guid reportId, [FromQuery] bool addToRecent = false)
        {
            var context = _contextProvider.GetContext();

            var result = await _reportService.GetReportById(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId);

            if (addToRecent)
            {
                await _reportService.AddToRecentReports(result.Id, DateTime.UtcNow, context.UserId, context.TenantIdentifier.TenantUniqueId);
            }

            return Ok(result);
        }

        /// <summary>
        /// Executes a report with the specified parameters.
        /// </summary>
        /// <param name="reportId">The ID of the report to execute.</param>
        /// <param name="filters">A JSON string representing the filters. Example: [{"FilterName":"userEmail","Operation":"Contains","Values":["seismic.com"]}]</param>
        /// <param name="fields">The fields to include in the report. Example: [{"name":"Region","isProperty":true,"propertyType":"UserProperty","propertyId":"2cb4fd20-37ce-4b18-a1b8-77b4f44a665f"}]</param>
        /// <param name="skip">The number of records to skip.</param>
        /// <param name="take">The number of records to take.</param>
        /// <param name="orderField">The field to order by.</param>
        /// <param name="orderBy">The order direction (asc/desc).</param>
        /// <param name="teamsiteIds">The selected teamsites. should be in user accessible teamsites. Example: ["teamsiteId"]</param>
        /// <param name="isSavedReport">The flag which checks if the report being executed is saved or a analysis of the report only</param>
        /// <returns>The result of the report execution.</returns>
        [HttpGet]
        [Route("api/v1/report/execute/{reportId}")]
        [ProducesResponseType<ReportResult>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> ExecuteReport([FromRoute] Guid reportId, [FromQuery] string? filters, [FromQuery] string? fields, [FromQuery] int skip, [FromQuery] int take, [FromQuery] string? orderField, [FromQuery] string? orderBy, [FromQuery] string? teamsiteIds, [FromQuery] bool isSavedReport = true)
        {
            if (fields == null || fields.Length == 0)
            {
                return BadRequest("Fields are required");
            }
            var sw = Stopwatch.StartNew();
            var context = _contextProvider.GetContext();
            var report = await _reportService.GetReportById(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId);
            var result = await _reportRunner.RunReport(reportId, context.TenantIdentifier.TenantUniqueId, skip, take, context.UserId, filters, fields, orderField, orderBy, teamsiteIds, report.ShowTeamsitePicker);
            sw.Stop();

            var filtersMetadata = report?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = context.TenantIdentifier.TenantUniqueId,
                UserId = context.UserId,
                ReportId = report.Id,
                SystemReportId = report.SystemReportId,
                ReportName = report.ReportName,
                SystemReportName = report.SystemReportName ?? string.Empty,
                IsSystemReport = report.OwnerUserId == ReportConstants.SYSTEM_DEFAULT_USER,
                Operation = NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_EXECUTE,
                Filters = string.Join(",", report.AppliedFilters?.Select(f => f.FilterName) ?? []),
                FiltersJson = Services.Helpers.FilterHashHelper.GetFilterHashValues(report.AppliedFilters, filtersMetadata),
                Fields = string.Join(",", report.RequestedFields.Select(f => f.Name)),
                SortField = report.OrderField,
                SortOrder = report.OrderBy.ToString(),
                CorrelationId = HttpContext.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = report.OwnerUserId,
                RequestDuration = sw.ElapsedMilliseconds,
                IsSavedReport = isSavedReport
            };
            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
            return Ok(result);
        }

        /// <summary>
        /// Returns the query sql and query parameters.
        /// </summary>
        /// <param name="reportId"></param>
        /// <param name="filters"></param>
        /// <param name="fields"></param>
        /// <param name="skip"></param>
        /// <param name="take"></param>
        /// <param name="orderField"></param>
        /// <param name="orderBy"></param>
        /// <param name="teamsiteIds">The selected teamsites. should be in user accessible teamsites. Example: ["teamsiteId"]</param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1/report/query/{reportId}")]
        [ProducesResponseType<ReportResult>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> QueryForReport([FromRoute] Guid reportId, [FromQuery] string? filters, [FromQuery] string? fields, [FromQuery] int skip, [FromQuery] int take, [FromQuery] string? orderField, [FromQuery] string? orderBy, [FromQuery] string? teamsiteIds)
        {
            if (fields == null || fields.Length == 0)
            {
                return BadRequest("Fields are required");
            }

            var context = _contextProvider.GetContext();
            var result = await _reportRunner.GetQuery(reportId, context.TenantIdentifier.TenantUniqueId, skip, take, context.UserId, filters, fields, orderField, orderBy, teamsiteIds);
            return Ok(result);
        }

        /// <summary>
        /// Exports a csv of specified parameters
        /// </summary>
        /// <param name="reportId"></param>
        /// <param name="filters"></param>
        /// <param name="fields"></param>
        /// <param name="orderField"></param>
        /// <param name="orderBy"></param>
        /// <param name="timezoneId"></param>
        /// <param name="teamsiteIds">The selected teamsites. should be in user accessible teamsites. Example: ["teamsiteId"]</param>
        /// <param name="isSavedReport">The flag which checks if the report being executed is saved or a analysis of the report only</param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1/report/export/{reportId}")]
        [ProducesResponseType(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task ExportReport([FromRoute] Guid reportId, [FromQuery] string? filters, [FromQuery] string? fields, [FromQuery] string? orderField, [FromQuery] string? orderBy, [FromQuery] string? timezoneId, [FromQuery] string? teamsiteIds, [FromQuery] bool isSavedReport = true, [FromQuery] bool isDrillIn = false)
        {
            if (fields == null || fields.Length == 0)
            {
                Response.StatusCode = 400;
                await Response.WriteAsync("Fields are required");
                return;
            }
            var sw = Stopwatch.StartNew();
            var context = _contextProvider.GetContext();
            var report = await _reportService.GetReportById(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId);

            var result = await _reportRunner.ExportReport(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId, filters, fields, orderField, orderBy, timezoneId, teamsiteIds, report.ShowTeamsitePicker, isDrillIn);

            var sanitizedReportName = Regex.Replace(report.ReportName, REPORT_NAME_REGEX, "_");
            var fileName = $"{sanitizedReportName}_{DateTime.UtcNow:yyyyMMddHHmmss}.csv";
            fileName = fileName.Replace("\r\n", "").Replace("\n", "").Replace("\r", "");
            fileName = fileName.ToSanitizedString();

            Response.Headers.Append("Content-Type", "text/csv");
            Response.Headers.Append("Content-Disposition", $"attachment; filename={fileName}");

            await WriteRecords(result, report.Id, context.UserId, context.TenantIdentifier.TenantUniqueId);
            sw.Stop();

            var filtersMetadata = report?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = context.TenantIdentifier.TenantUniqueId,
                UserId = context.UserId,
                ReportId = report.Id,
                SystemReportId = report.SystemReportId,
                ReportName = report.ReportName,
                SystemReportName = report.SystemReportName ?? string.Empty,
                IsSystemReport = report.OwnerUserId == ReportConstants.SYSTEM_DEFAULT_USER,
                Operation = NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_EXPORT,
                Filters = string.Join(",", report.AppliedFilters?.Select(f => f.FilterName) ?? []),
                FiltersJson = Services.Helpers.FilterHashHelper.GetFilterHashValues(report.AppliedFilters, filtersMetadata),
                Fields = string.Join(",", report.RequestedFields.Select(f => f.Name)),
                SortField = report.OrderField,
                SortOrder = report.OrderBy.ToString(),
                CorrelationId = HttpContext.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = report.OwnerUserId,
                RequestDuration = sw.ElapsedMilliseconds,
                IsSavedReport = isSavedReport
            };
            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
        }

        [HttpGet]
        [Route("/api/v1/reports/recent")]
        [ProducesResponseType<PagedList<RecentReport>>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetRecentReports([FromQuery] string? reportType, [FromQuery] string? searchText,
            [FromQuery] int take, [FromQuery] int skip, [FromQuery] string? orderField, [FromQuery] string? orderBy)
        {
            var context = _contextProvider.GetContext();
            var recentReports = await _reportService.GetRecentReports(context.UserId, context.TenantIdentifier.TenantUniqueId, reportType, searchText, take, skip, orderField, orderBy);
            return Ok(recentReports);
        }

        [HttpPost]
        [Route("api/v1/report")]
        [ProducesResponseType(201)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> CreateReport([FromBody][Bind("SystemReportId", "ReportName", "Description", "Fields", "Filters", "OrderByField", "OrderBy", "TeamsiteIds")] ReportCreateRequest report)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request");
            }
            if (report.SystemReportId == Guid.Empty)
            {
                return BadRequest("Invalid report id");
            }
            if (report.Fields == null || report.Fields.Count == 0)
            {
                return BadRequest("Fields are required");
            }
            var context = _contextProvider.GetContext();
            var result = await _reportService.CreateReport(report, context.UserId, context.TenantIdentifier.TenantUniqueId);
            if (result != null)
            {
                await _reportService.AddToRecentReports(result.Id, DateTime.UtcNow, context.UserId, context.TenantIdentifier.TenantUniqueId);
            }
            return Created(HttpContext?.Request?.Path, result);

        }

        [HttpPut]
        [Route("api/v1/report/{reportId}")]
        [ProducesResponseType<Report>(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> UpdateReport([FromRoute] Guid reportId,
            [FromBody][Bind("Id", "ReportName", "Description", "Fields", "Filters", "OrderByField", "OrderBy", "TeamsiteIds")] ReportUpdateRequest report)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request");
            }
            if (report.Id != reportId)
            {
                return BadRequest("Report id mismatch");
            }
            if (report.Fields == null || report.Fields.Count == 0)
            {
                return BadRequest("Fields are required");
            }

            var context = _contextProvider.GetContext();
            var result = await _reportService.UpdateReport(report, context.UserId, context.TenantIdentifier.TenantUniqueId);
            return Ok(result);
        }

        [HttpDelete]
        [Route("api/v1/report/{reportId}")]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> DeleteCustomReportById([FromRoute] Guid reportId)
        {
            var context = _contextProvider.GetContext();

            await _reportService.DeleteCustomReportById(reportId, context.UserId, context.TenantIdentifier.TenantUniqueId);
            return Ok();
        }

        private async Task WriteRecords(ExportResult result, Guid reportId, string userId, Guid tenantId)
        {
            _logger.Information("Writing records to CSV started at: {Time}", DateTime.UtcNow.Ticks);

            await using var stream = Response.BodyWriter.AsStream(true);
            await using var streamWriter = new StreamWriter(stream, Encoding.UTF8);
            await using var csvWriter = new CsvWriter(streamWriter, CultureInfo.InvariantCulture, true);

            try
            {
                // Write headers
                foreach (var header in result.Columns)
                {
                    csvWriter.WriteField(header);
                }
                await csvWriter.NextRecordAsync();

                // Write data rows
                foreach (var row in result.Rows)
                {
                    foreach (var item in row)
                    {
                        var strValue = item?.ToString() ?? string.Empty;
                        strValue = strValue.Replace('\u001F', ',');
                        csvWriter.WriteField(strValue);
                    }
                    await csvWriter.NextRecordAsync();
                }

                await csvWriter.FlushAsync();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error writing CSV records for ReportId: {ReportId}, UserId: {UserId}, TenantId: {TenantId}.",
                    reportId, userId, tenantId);
                throw;
            }

            _logger.Information("Writing records to CSV ended at: {Time}", DateTime.UtcNow.Ticks);
        }

        /// <summary>
        /// Updates a report's name
        /// </summary>
        /// <param name="reportId">The ID of the report to update</param>
        /// <param name="reportName"></param>
        /// <returns>The updated report</returns>
        [HttpPatch]
        [Route("api/v1/report/{reportId}/name")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> UpdateReportName([FromRoute] Guid reportId,
            [FromBody][StringLength(100, ErrorMessage = "Name length can't be more than 100.")] string reportName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request");
            }

            var context = _contextProvider.GetContext();

            await _reportService.UpdateReportName(reportId, reportName, context.UserId, context.TenantIdentifier.TenantUniqueId);
            return Ok();
        }

        /// <summary>
        /// Updates a report's description
        /// </summary>
        /// <param name="reportId">The ID of the report to update</param>
        /// <param name="request">The request containing the updated description</param>
        /// <returns>The updated report</returns>
        [HttpPatch]
        [Route("api/v1/report/{reportId}/description")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> UpdateReportDescription([FromRoute] Guid reportId,
            [FromBody] ReportDescriptionUpdateRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request");
            }

            var context = _contextProvider.GetContext();

            await _reportService.UpdateReportDescription(reportId, request.Description, context.UserId, context.TenantIdentifier.TenantUniqueId);
            return Ok();
        }

        /// <summary>
        /// Updates the owner of a report.
        /// </summary>
        /// <param name="ReportOwnerUpdateRequest request"></param>        
        /// <returns>200 OK on success</returns>
        [HttpPut]
        [Route("api/v1/report/update/owner")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        [ApiExplorerSettings(GroupName = "internal")]
        [PlatformLevelAuthorize]
        public async Task<IActionResult> UpdateReportOwner([FromBody] ReportOwnerUpdateRequest request)
        {
            if (!ModelState.IsValid || request.ReportId == Guid.Empty || string.IsNullOrWhiteSpace(request.NewOwnerId) || request.NewOwnerId == Guid.Empty.ToString() || request.TenantId == Guid.Empty)
            {
                if (!ModelState.IsValid)
                {
                    _logger.Error("Invalid request model in UpdateReportOwner for ReportId: {ReportId}", request?.ReportId.ToString());
                }

                return BadRequest(new
                {
                    error = "Invalid request",
                    details = !ModelState.IsValid
                        ? "Model validation failed"
                        : "ReportId, NewOwnerId, and TenantId are required"
                });
            }

            await _reportService.UpdateReportOwner(request.ReportId, request.NewOwnerId, request.TenantId);
            return Ok();
        }


        /// <summary>
        /// Executes a report with the specified parameters or falls back to the report's configured values.
        /// </summary>
        /// <param name="reportId">The ID of the report to execute.</param>
        /// <param name="filters">A JSON string representing the filters. If empty, uses report's default filters. Example: [{"FilterName":"userEmail","Operation":"Contains","Values":["seismic.com"]}]</param>
        /// <param name="fields">The fields to include in the report. If empty, uses report's default fields. Example: [{"name":"Region","isProperty":true,"propertyType":"UserProperty","propertyId":"2cb4fd20-37ce-4b18-a1b8-77b4f44a665f"}]</param>
        /// <param name="skip">The number of records to skip.</param>
        /// <param name="take">The number of records to take.</param>
        /// <param name="orderField">The field to order by. If empty, uses report's default order field.</param>
        /// <param name="orderBy">The order direction (asc/desc). If empty, uses report's default order direction.</param>
        /// <param name="teamsiteIds">The selected teamsites. Should be in user accessible teamsites. Example: ["teamsiteId"]</param>
        /// <param name="isSavedReport">The flag which checks if the report being executed is saved or a analysis of the report only</param>
        /// <param name="addToRecent">Whether to add the report to recent reports.</param>
        /// <returns>The result of the report execution.</returns>
        [HttpGet]
        [Route("/api/v1/report/execute/{reportId}/withDefaults")]
        [ProducesResponseType<ReportResult>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> ExecuteReportWithDefaults([FromRoute] Guid reportId, [FromQuery] string? filters,
            [FromQuery] string? fields, [FromQuery] int? skip, [FromQuery] int? take, [FromQuery] string? orderField,
            [FromQuery] string? orderBy, [FromQuery] string? teamsiteIds, [FromQuery] bool isSavedReport = true, [FromQuery] bool addToRecent = false, [FromQuery] bool isDrillIn = false)
        {
            var sw = Stopwatch.StartNew();
            var context = _contextProvider.GetContext();
            var report = await _reportService.GetReportById(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId);

            (ReportResult result, Report executedReport) = await _reportRunner.ExecuteReportWithDefaults(report, context.TenantIdentifier.TenantUniqueId, skip, take, context.UserId, filters, fields, orderField, orderBy, teamsiteIds, report.ShowTeamsitePicker, isDrillIn);

            result.Report = executedReport; // Attach the report to the result for additional context
            var filtersMetadata = report?.StandardReportMetadata.FilterGroup?.SelectMany(x => x.Filters).ToList();

            if (addToRecent)
            {
                await _reportService.AddToRecentReports(result.Report.Id, DateTime.UtcNow, context.UserId, context.TenantIdentifier.TenantUniqueId);
            }

            sw.Stop();
            var ssrsReportEvent = new SsrsReportEvent()
            {
                TenantId = context.TenantIdentifier.TenantUniqueId,
                UserId = context.UserId,
                ReportId = executedReport.Id,
                SystemReportId = executedReport.SystemReportId,
                ReportName = executedReport.ReportName,
                SystemReportName = executedReport.SystemReportName ?? string.Empty,
                IsSystemReport = executedReport.OwnerUserId == ReportConstants.SYSTEM_DEFAULT_USER,
                Operation = NewRelicConstants.NEWRELIC_CUSTOM_EVENT_OPERATION_EXECUTE,
                Filters = string.Join(",", executedReport.AppliedFilters?.Select(f => f.FilterName) ?? []),
                FiltersJson = Services.Helpers.FilterHashHelper.GetFilterHashValues(executedReport.AppliedFilters, filtersMetadata),
                Fields = string.Join(",", executedReport.RequestedFields.Select(f => f.Name)),
                SortField = executedReport.OrderField,
                SortOrder = executedReport.OrderBy.ToString(),
                CorrelationId = HttpContext.GetCorrelationId(),
                Occurred = DateTime.UtcNow,
                OwnerId = executedReport.OwnerUserId,
                RequestDuration = sw.ElapsedMilliseconds,
                IsSavedReport = isSavedReport
            };
            _newRelicCustomEventHelper.RecordCustomEvent(NewRelicConstants.NEWRELIC_CUSTOM_EVENT_KEY, ssrsReportEvent);
            return Ok(result);
        }
    }
}
