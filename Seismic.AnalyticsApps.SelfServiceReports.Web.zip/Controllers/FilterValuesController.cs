﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Filters;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [RequiredScopes("library")]
    [ApiExplorerSettings(GroupName = "public")]
    public class FilterValuesController(IPicklistQueryService _picklistQueryService, ILogger logger, ISeismicContextProvider _seismicContextProvider) : Controller
    {
        private readonly ILogger _logger = logger.ForContext<FilterValuesController>();

        [HttpGet]
        [Route("api/v1/filter/{filterName}/values")]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.Viewer, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetFilterValues([FromRoute] string filterName,[FromQuery] Guid systemReportId, [FromQuery] string? searchTerm, [FromQuery] string? teamsiteIds)
        {
            var context = _seismicContextProvider.GetContext();
            var result = await _picklistQueryService.GetFilterValues(filterName, systemReportId, searchTerm, teamsiteIds, context.TenantIdentifier.TenantUniqueId);
            return Ok(result);
        }

    }
}
