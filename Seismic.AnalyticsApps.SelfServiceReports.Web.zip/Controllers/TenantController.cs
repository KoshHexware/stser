﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Platform.Authentication.Filter.CustomAttribute;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [RequiredScopes("library")]
    [ApiExplorerSettings(GroupName = "public")]
    public class TenantController(ITenantService _tenantService) : BaseApiController
    {
        [HttpGet]
        [Route("/api/v1/tenant/hasAccess")]
        public async Task<IActionResult> CheckTenantAccess()
        {
            var access = await _tenantService.CheckHasAccess();
            return Ok(access);
        }
    }
}
