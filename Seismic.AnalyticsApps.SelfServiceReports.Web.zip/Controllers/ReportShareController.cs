﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.UMS;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Filters;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [RequiredScopes("library")]
    [ApiExplorerSettings(GroupName = "public")]
    public class ReportShareController(ISeismicContextProvider _seismicContextProvider, IReportShareService _reportShareService, ITenantService _tenantService) : BaseApiController
    {
        /// <summary>
        /// Get users that have access to SSRS
        /// </summary>
        /// <param name="searchKeyword">The keyword to search for users</param>
        /// <returns>Returns the list of users that have access of ssrs</returns>
        [HttpGet]
        [Route("/api/v1/share/users")]
        [ProducesResponseType<List<Services.Models.UMS.UserInfoModel>>(200)]
        public async Task<IActionResult> GetUsers([FromQuery] string? searchKeyword)
        {
            var context = _seismicContextProvider.GetContext();
            var result = await _reportShareService.GetSsrAccessibleUsers(searchKeyword, context.TenantIdentifier.TenantUniqueId);
            return Ok(result);
        }

        /// <summary>
        /// Get shared report user list
        /// </summary>
        /// <param name="reportId">The ID of the report</param>
        /// <returns>Returns the list of users with whom the report is shared</returns>
        [HttpGet]
        [Route("/api/v1/share/report/{reportId}")]
        [ProducesResponseType<List<Services.Models.UMS.UserInfoModel>>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetSharedReportUserList([FromRoute] Guid reportId)
        {
            var context = _seismicContextProvider.GetContext();
            var isWinterReleaseEnabled = await _tenantService.CheckSsrWinterFy26ReleaseLDFlagEnabled();
            if (isWinterReleaseEnabled)
            {
                var res = await _reportShareService.GetSharedReportUserAndUserGroupList(reportId, context.TenantIdentifier.TenantUniqueId);
                return Ok(res);
            }

            var result = await _reportShareService.GetSharedReportUserList(reportId, context.TenantIdentifier.TenantUniqueId);
            return Ok(result);
        }

        /// <summary>
        /// Share report with the passed request body userIds
        /// </summary>
        /// <param name="reportId">The ID of the report to be shared</param>
        /// <param name="request">The request containing user IDs to share or remove sharing</param>
        /// <returns>Returns no content</returns>
        [HttpPost]
        [Route("/api/v1/share/report/{reportId}")]
        [ProducesResponseType(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> ShareReport([FromRoute] Guid reportId, [FromBody] ShareReportRequest request)
        {
            var context = _seismicContextProvider.GetContext();
            var isWinterReleaseEnabled = await _tenantService.CheckSsrWinterFy26ReleaseLDFlagEnabled();
            if (isWinterReleaseEnabled)
            {
                await _reportShareService.CreateOrUpdateSharedReportWithUsersAndGroups(reportId, request, context.UserId, context.TenantIdentifier.TenantUniqueId);
                return Ok();
            }
            await _reportShareService.CreateOrUpdateSharedReport(reportId, request, context.UserId, context.TenantIdentifier.TenantUniqueId);
            return Ok();
        }

        /// <summary>
        /// Get report owner details
        /// </summary>
        /// <param name="reportId">The ID of the report</param>
        /// <returns>Return the owner details of the report</returns>
        [HttpGet]
        [Route("/api/v1/share/report/{reportId}/owner")]
        [ProducesResponseType<UserInfoModel>(200)]
        [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
        public async Task<IActionResult> GetReportOwnerDetails([FromRoute] Guid reportId)
        {
            var context = _seismicContextProvider.GetContext();
            var result = await _reportShareService.GetReportOwnerDetails(reportId, context.TenantIdentifier.TenantUniqueId, context.UserId);
            return Ok(result);
        }
    }
}
