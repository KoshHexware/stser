﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using ILogger = Serilog.ILogger;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.DataArea;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Enum;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Filters;


namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [RequiredScopes("library")]
    [ApiExplorerSettings(GroupName = "public")]
    public class DataAreasController : Controller
    {
        private readonly IDataAreasService _dataAreasService;
        private readonly ISeismicContextProvider _contextProvider;
        private readonly ILogger _logger;

        public DataAreasController(
            IDataAreasService dataAreasService,
            ISeismicContextProvider contextProvider,
            ILogger logger)
        {
            _dataAreasService = dataAreasService;
            _contextProvider = contextProvider;
            _logger = logger.ForContext<DataAreasController>();
        }

        /// <summary>
        /// This api return the list of data areas
        /// </summary>
        /// <param name="searchText">This is search text to filter out data areas</param>
        /// <param name="dataAreaIds">This is the ID of the data area</param>
        /// <param name="domains">A JSON string representing the domains</param>
        /// <param name="userOruserGroupIds">A JSON string representing the user or user group IDs</param>
        /// <returns>This is the list of data area access models</returns>
        [AdminAccessCheck]
        [HttpGet("api/v1/admin/dataAreas")]
        public async Task<ActionResult<List<DataAreaAccessModel>>> GetAllDataAreas([FromQuery] string? searchText, [FromQuery] string? dataAreaIds, [FromQuery] string? domains, [FromQuery] string? userOruserGroupIds)
        {
            try
            {
                var context = _contextProvider.GetContext();
                var result = await _dataAreasService.GetAllDataAreasAccess(context.TenantIdentifier.TenantUniqueId, searchText, dataAreaIds, domains, userOruserGroupIds);
                return Ok(result);
            }
            catch (Exception ex)
            {
                var context = _contextProvider.GetContext();
                _logger.Error(ex, "Error in GetAllDataAreas for tenantId: {TenantId}", context.TenantIdentifier.TenantUniqueId);
                return StatusCode(500, "An error occurred while retrieving data areas.");
            }
        }


        [AdminAccessCheck]
        [HttpPut("api/v1/admin/dataAreasAccess")]
        public async Task<ActionResult<List<DataAreaAccessModel>>> UpdateAccessForAllDataAreas([FromBody] AccessType dataAccessType)
        {
            try
            {
                var context = _contextProvider.GetContext();
                var result = await _dataAreasService.UpdateAccessForAllDataAreas(dataAccessType, context.UserId, context.TenantIdentifier.TenantUniqueId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                var context = _contextProvider.GetContext();
                _logger.Error(ex, "Error in UpdateAccessForAllDataAreas for tenantId: {TenantId}, userId: {UserId}", context.TenantIdentifier.TenantUniqueId, context.UserId);
                return StatusCode(500, "An error occurred while updating data area access.");
            }
        }

        [AdminAccessCheck]
        [HttpPut("api/v1/admin/dataAreas")]
        public async Task<ActionResult<List<DataAreaAccessModel>>> UpdateDataAreas([FromBody] List<DataAreaAccessModel> lstDataAreas )
        {
            try
            {
                var context = _contextProvider.GetContext();
                var result = await _dataAreasService.UpdateDataAreas(lstDataAreas, context.UserId, context.TenantIdentifier.TenantUniqueId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                var context = _contextProvider.GetContext();
                _logger.Error(ex, "Error in UpdateDataAreas for tenantId: {TenantId}, userId: {UserId}", context.TenantIdentifier.TenantUniqueId, context.UserId);
                return StatusCode(500, "An error occurred while updating data areas.");
            }
        }

        [AdminAccessCheck]
        [HttpPut("api/v1/admin/remove/access/all")]
        public async Task<ActionResult<bool>> ResetAllAccess()
        {
            try
            {
                var context = _contextProvider.GetContext();
                var result = await _dataAreasService.ResetAllAccess( context.UserId, context.TenantIdentifier.TenantUniqueId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                var context = _contextProvider.GetContext();
                _logger.Error(ex, "Error in ResetAllDataAreaAccess for tenantId: {TenantId}", context.TenantIdentifier.TenantUniqueId);
                return StatusCode(500, "An error occurred while revoking all data area access.");
            }
        }


    }
}
