﻿using Fluid;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Constants;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Template;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [ApiExplorerSettings(GroupName = "internal")]
    public class DraftReportsController(IDraftReportService _draftReportService, 
        ISeismicContextProvider _contextProvider, ILogger logger) : Controller
    {
        private readonly ILogger _logger = logger.ForContext<DraftReportsController>();

        /// <summary>
        /// Get all draft reports
        /// </summary>
        /// <param name="searchText">text to filter</param>
        /// <returns></returns>
        [HttpGet]
        [Route("/api/v1/draft/reports/all")]
        [ProducesResponseType<List<DraftReport>>(200)]
        [RequiredScopes(ScopeConcatType.OR, "library", "draft_reports_read", "draft_reports_write")]
        public async Task<IActionResult> GetDraftReports([FromQuery] string? searchText)
        {
            var context = _contextProvider.GetContext();
            if (!await IsFeatureEnabled(context)) return Forbid();

            var result = await _draftReportService.GetAllDraftReports(context.TenantIdentifier.TenantUniqueId, searchText);
            return Ok(result);
        }

        /// <summary>
        /// Get a draft report by id
        /// </summary>
        /// <param name="draftReportId"></param>
        /// <returns>The yaml file for the report</returns>
        [HttpGet]
        [Route("api/v1/draft/report/{draftReportId}")]
        [ProducesResponseType<FileStreamResult>(StatusCodes.Status200OK, "application/x-yaml")]
        [RequiredScopes(ScopeConcatType.OR, "library", "draft_reports_read", "draft_reports_write")]
        public async Task<IActionResult> GetDraftReportYamlById([FromRoute] Guid draftReportId)
        {
            var context = _contextProvider.GetContext();
            if (!await IsFeatureEnabled(context)) return Forbid();

            var draftReport = await _draftReportService.GetDraftReportYamlById(draftReportId, context.TenantIdentifier.TenantUniqueId);

            if(draftReport == null)
            {
                _logger.Error("Report not found - reportId:{reportId}", draftReportId);
                return NotFound();
            }

            var memoryStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(draftReport.Template))
            {
                Position = 0
            };

            return File(memoryStream, "application/x-yaml", $"{draftReport?.ReportName}.yaml");
        }

        /// <summary>
        /// Create a draft report by uploading a yaml file
        /// </summary>
        /// <param name="yamlFile">the yaml file to upload</param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1/draft/report")]
        [ProducesResponseType(201)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> CreateDraftReport(IFormFile? yamlFile)
        {
            try
            {
                var context = _contextProvider.GetContext();
                if (!await IsFeatureEnabled(context)) return Forbid();

                if (yamlFile == null)
                {
                    _logger.Error("No yaml file uploaded");
                    return BadRequest("Yaml file is required");
                }

                var (draftReport, fileText) = await ParseYaml(yamlFile);

                var reportId = await _draftReportService.CreateDraftReport(draftReport, fileText, context.TenantIdentifier.TenantUniqueId);
                return Created( HttpContext.Request.Path , reportId);
            }
            catch (BadRequestException e)
            {
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Update a draft report
        /// </summary>
        /// <param name="draftReportId">the id of the draft report</param>
        /// <param name="yamlFile">the yaml file of the report</param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/v1/draft/report/{draftReportId}")]
        [ProducesResponseType(200)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> UpdateDraftReport([FromRoute] Guid draftReportId, IFormFile? yamlFile)
        {
            var context = _contextProvider.GetContext();
            if (!await IsFeatureEnabled(context)) return Forbid();
            
            if (draftReportId == Guid.Empty)
            {
                _logger.Error("Invalid report id");
                return BadRequest("Invalid report id");
            }

            if (yamlFile == null)
            {
                _logger.Error("No yaml file uploaded");
                return BadRequest();
            }

            try
            {
                var (draftReport, fileText) = await ParseYaml(yamlFile);
                await _draftReportService.UpdateDraftReport(draftReportId, draftReport, fileText, context.TenantIdentifier.TenantUniqueId);
                return Ok();
            }
            catch (BadRequestException e)
            {
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Delete a draft report by id
        /// </summary>
        /// <param name="draftReportId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("api/v1/draft/report/{draftReportId}")]
        [ProducesResponseType(200)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> DeleteDraftReport([FromRoute] Guid draftReportId)
        {
            var context = _contextProvider.GetContext();
            if (!await IsFeatureEnabled(context)) return Forbid();

            await _draftReportService.DeleteDraftReport(draftReportId, context.TenantIdentifier.TenantUniqueId);
            return Ok();
        }


        private static async Task<(CreateDraftReport draftReport, string fileText)> ParseYaml(IFormFile file)
        {
            try
            {
                using var fs = file.OpenReadStream();
                using var sr = new StreamReader(fs);
                var fileText = await sr.ReadToEndAsync();
                var report = YamlHelper.Deserialize<ReportDefinitionMetadata>(fileText);

                if (report.ReportId == Guid.Empty)
                {
                    // For developer convenience, assign a new random Guid
                    report.ReportId = Guid.NewGuid();
                }

                var draftReport =  new CreateDraftReport() 
                {
                    ReportId = report.ReportId,
                    ReportName = report.ReportName,
                    Description = report.Description
                };

                ValidateQuery(report);

                return (draftReport, fileText);
            }
            catch (YamlDotNet.Core.YamlException ex)
            {
                throw new BadRequestException($"Invalid YAML Start: {ex.Start} End: {ex.End}");
            }
            catch (Exception ex)
            {
                if (ex is BadRequestException)
                    throw;

                throw new BadRequestException($"Error while creating DraftReport from yaml: {ex.Message}");
            }
        }

        private static void ValidateQuery(ReportDefinitionMetadata report)
        {
            try
            {
                if(string.IsNullOrWhiteSpace(report.QueryTemplate))
                {
                    throw new BadRequestException("QueryTemplate is required");
                }
                var _ = new ReportDefinitionQuery(report);
            }
            catch(ParseException pex)
            {
                throw new BadRequestException($"Invalid query template YAML.Error: {pex.Message}");
            }
        }

        private static async Task<Boolean> IsFeatureEnabled(ISeismicContext context) => await context.IsToggleEnabled(LDConstants.SelfServiceDraftReportsKey, false);


    }
}
