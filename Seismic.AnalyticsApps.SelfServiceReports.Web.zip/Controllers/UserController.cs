﻿using Microsoft.AspNetCore.Mvc;
using Polly;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Filters;
using Seismic.Common.ServiceFoundation;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers;

[ApiExplorerSettings(GroupName = "public")]
public class UserController(IPermissionService _permissionsService, ISeismicContextProvider _seismicContextProvider,
    IUserService _userService, IOrgHierarchyService _orgHierarchyService, ITenantService _tenantService) : BaseApiController
{
    [HttpGet]
    [Route("/api/v1/hasAccess")]
    [ProducesResponseType<bool>(200)]
    public async Task<IActionResult> AccessCheck([FromQuery] bool forceRefresh = false)
    {
        var access = await _permissionsService.CheckContextUserAccess(forceRefresh);
        // Add entry for tenant for cache refresh.
        if (access)
        {
            var context = _seismicContextProvider.GetContext();
            await _tenantService.AddTenant(context.TenantIdentifier.TenantUniqueId);
        }
        return Ok(access);
    }

    [HttpGet]
    [Route("/api/v1/access")]
    [ProducesResponseType<AccessLevel>(200)]
    public async Task<IActionResult> CheckUserAccess([FromQuery] bool forceRefresh = false)
    {
        var access = await _permissionsService.GetContextUserAccess(forceRefresh);
        // Add entry for tenant for cache refresh.
        if (access != AccessLevel.None)
        {
            var context = _seismicContextProvider.GetContext();
            await _tenantService.AddTenant(context.TenantIdentifier.TenantUniqueId);
        }
        return Ok(access);
    }

    [HttpGet]
    [Route("/api/v1/user/settings")]
    [ProducesResponseType<UserSettings>(200)]
    public async Task<IActionResult> GetUserSettings()
    {
        var context = _seismicContextProvider.GetContext();

        var teamsites = await _userService.GetUserSettingsAsync(context.TenantIdentifier.TenantUniqueId, context.UserId);

        var tenantSettings = await _orgHierarchyService.GetTenantOrgHierarchySettings(context.TenantIdentifier.TenantUniqueId);
        teamsites.TenantSettings = tenantSettings;

        return Ok(teamsites);
    }

    /// <summary>
    /// Create or Update user teamsites
    /// </summary>
    /// <param name="teamsiteIds"></param>
    /// <returns></returns>
    [HttpPatch]
    [Route("api/v1/user/teamsites")]
    [ProducesResponseType<List<Teamsites>>(200)]
    [RequiredAccessLevel(AccessLevel.Editor, AccessLevel.CustomReportEditor)]
    public async Task<IActionResult> UpdateUserTeamsites([FromBody] string[] teamsiteIds)
    {
        var context = _seismicContextProvider.GetContext();

        var result = await _userService.UpdateUserPreferredTeamsitesAsync(context.TenantIdentifier.TenantUniqueId, context.UserId, teamsiteIds);
        return Ok(result);
    }    

    [HttpPatch]
    [Route("/api/v1/user/filterOption/{filterOption}")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> UpdateReportsFilterOption([FromRoute] string filterOption)
    {
        var context = _seismicContextProvider.GetContext();

        await _userService.CreateOrUpdateReportsFilterOption(context.TenantIdentifier.TenantUniqueId, context.UserId, filterOption);
        return Ok();
    }
}
