﻿using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using Seismic.Platform.Matrix.Client;
using ILogger = Serilog.ILogger;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{

    [ApiController, Route("entitlements")]
    public class EntitlementsMigrationController(ISeismicInstance _seismicInstance, IMatrixClient _matrixClient,
        ILogger _logger, IEntitlementsMigrationService _entitlementsMigrationService) : Controller
    {
        [HttpGet("{tenantId}/migration-info")]
        [PlatformLevelAuthorize]
        public async Task<ActionResult> GetMigrationInfo(Guid tenantId, CancellationToken cancel)
        {
            var tenant = await _matrixClient.GetTenantAsync(tenantId);
            if (tenant is null)
            {
                _logger.Error("Tenant not found for tenant:{tenantId}", tenantId);
                return BadRequest($"Tenant not found for tenant: {tenantId}");
            }
            var context = await _seismicInstance.CreateAnonymousContext(tenantId.ToString());
            var platformToken = await context.GetPlatformToken();

            var toReturn = await _entitlementsMigrationService.GetMigrationInfoForTenant(tenantId, platformToken);

            return Ok(toReturn);
        }
    }
}