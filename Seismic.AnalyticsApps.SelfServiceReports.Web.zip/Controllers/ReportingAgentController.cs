﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportingAgent;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.ReportRunner;
using Seismic.AnalyticsApps.SelfServiceReports.Web.Models.ReportingAgent;
using Seismic.Common.ServiceFoundation;
using ILogger = Serilog.ILogger;
namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [ApiController]
    public class ReportingAgentController(IReportingAgentService _reportingAgentService,
        ISeismicContextProvider _contextProvider, ILogger logger) : Controller
    {
        private readonly ILogger _logger = logger.ForContext<ReportingAgentController>();

        [HttpGet]
        [Route("agent/v1/reports")]
        [ProducesResponseType(typeof(ApiResponse<List<StandardReport>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse),StatusCodes.Status403Forbidden)]       
        [Produces("application/json")]
        public async Task<ActionResult<ApiResponse<List<StandardReport>>>> GetReportsAsync()       
        {
            _logger.Information("Gets all the standard reports, with minimal details");
            var context = _contextProvider.GetContext();
            Guid tenantId = context.TenantIdentifier.TenantUniqueId;
            string userId = context.UserId;
            List<ApiError> err = new();
            ApiResponse<List<StandardReport>> apiRes = new() { Success = false, Data = new List<StandardReport>(), Errors = err };

            try
            {
                var apiResponse = await _reportingAgentService.GetAllStandardReportsAsync(tenantId, userId);
                if (!apiResponse.Success)
                {
                    err.AddRange(apiRes.Errors);
                    apiRes.Success = false;
                    apiRes.Errors = err;
                    apiRes.Data = null;
                    return BadRequest(apiRes);
                }
                apiRes.Success = true;
                apiRes.Data = apiResponse.Data;
                apiRes.Errors = null;
                return StatusCode(StatusCodes.Status200OK, apiRes);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error in get available standard reports for tenantId: {TenantId}, userId: {UserId}", tenantId, userId);
                err.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = "" });
                apiRes.Success = false;
                apiRes.Errors = err;
                apiRes.Data = null;
                return StatusCode(StatusCodes.Status403Forbidden, apiRes);
            }
          
        }

        [HttpGet("agent/v1/reports/detailed")]
        [ProducesResponseType(typeof(ActionResult<ApiResponse<List<ReportDetail>>>), StatusCodes.Status200OK)]       
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<ApiResponse<List<ReportDetail>>> GetReportDetails([FromQuery] List<string> reportNames,[FromQuery] bool listCustomProperties = false)
        {
            var context = _contextProvider.GetContext();
            Guid tenantId = context.TenantIdentifier.TenantUniqueId;
            string userId = context.UserId;           
            List<ApiError> err = new(); // Simplified collection initialization
            ApiResponse<List<ReportDetail>> apiRes = new() { Success = false, Data = new List<ReportDetail>(), Errors = err };

            try
            {
                apiRes = await _reportingAgentService.FetchMetadataByReportNameAsync(tenantId, reportNames, userId, listCustomProperties);
                
            }
            catch (Exception ex)
            {
                err.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = "" });
                apiRes.Success = false;
                apiRes.Errors = err;
                apiRes.Data = null;
            }
            return apiRes;
        }

        [HttpGet("agent/v1/reports/{reportName}/filterValues")]
        [ProducesResponseType(typeof(ApiResponse<List<FilterDetail>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>),StatusCodes.Status404NotFound)]
        [Produces("application/json")]
         public async Task<ApiResponse<List<FilterDetail>>> GetFilterValues(Guid reportId,string reportName,[FromQuery] List<string> filterNames,[FromQuery] string searchTerm = null)
        {

            var context = _contextProvider.GetContext();
            Guid tenantId = context.TenantIdentifier.TenantUniqueId;
            string userId = context.UserId;
            
            List<ApiError> err = new(); // Simplified collection initialization
            ApiResponse<List<FilterDetail>> apiRes = new ApiResponse<List<FilterDetail>> { Success=false, Data = new List<FilterDetail>(), Errors=err };
            try
            {
                var filterValues = await _reportingAgentService.GetFilterDomainValuesAsync(tenantId, userId,reportId, reportName, filterNames, searchTerm);
                apiRes.Success = true;
                apiRes.Data = filterValues;
                apiRes.Errors = null;
            }
            catch (Exception ex)
            {
                err.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace, Suggestion = "" });
                apiRes.Success = false;
                apiRes.Errors = err;
                apiRes.Data = null;
            }
            return apiRes;
        }

        [HttpPost("agent/v1/reports/{reportName}/execute")]
        [ProducesResponseType(typeof(ActionResult<ExecuteApiResponse<List<RowData>>>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(ActionResult<ApiErrorResponse>), StatusCodes.Status404NotFound)]        
        [Produces("application/json")]
        public async Task<ExecuteApiResponse<List<RowData>>> ExecuteReport(Guid reportId,string reportName, [FromBody] ExecuteReportRequest request,[FromQuery] int skip = 0, [FromQuery] int take = 3)
        {
            var context = _contextProvider.GetContext();
            Guid tenantId = context.TenantIdentifier.TenantUniqueId;
            string userId = context.UserId;
            List<string> fNames = new();
            string sTerm = "test";
            List<ApiError> err = new(); // Simplified collection initialization
            ExecuteApiResponse<List<RowData>> apiRes = new()
            {
                Success = false,
                Errors = err,
                Fields = new List<ColumnField>(),
                Data = null,
                Pagination = new Pagination()
            };
            try
            {
                List<string> teamsiteIds = null;
                var apiResResult = await _reportingAgentService.ExecuteReportAsync(tenantId, reportId, "Content view", userId, request.Fields, request.AdditionalFilters, request.SortBy.FieldName, request.SortBy.SortOrder, "", take, skip, false);
                //apiRes = new() { Success = true, Errors = err, Fields = apiResResult.Fields, Data = apiResResult.Rows, Pagination = apiResResult.Pagination };
            }
            catch (Exception ex)
            {
                err.Add(new ApiError { ErrorMessage = ex.Message, WithValue = ex.StackTrace ?? string.Empty, Suggestion = "" });
                apiRes.Success = false;
                apiRes.Errors = err;
                apiRes.Data = null;
            }
            return apiRes;
        }
    }
}
