﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Common;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Exceptions;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Helpers;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models.Draft.Filters;
using Seismic.Common.ServiceFoundation;
using Seismic.Platform.Authentication.Filter.CustomAttribute;
using System.Web;
using ILogger = Serilog.ILogger;


namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [ApiController]
    [ApiExplorerSettings(GroupName = "internal")]
    public class DraftReportFiltersController(IDraftReportFiltersService _draftReportFiltersService, 
        ISeismicContextProvider _contextProvider, ILogger logger) : Controller
    {
        private readonly ILogger _logger = logger.ForContext<DraftReportFiltersController>();

        /// <summary>
        /// Get all draft report filters
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1/draft/filters/all")]
        [ProducesResponseType<List<DraftFilterModel>>(200)]
        [RequiredScopes(ScopeConcatType.OR, "library", "draft_reports_read", "draft_reports_write")]
        public async Task<IActionResult> GetDraftFilters()
        {
            var filters = await _draftReportFiltersService.GetDraftFiltersAsync();
            return Ok(filters);
        }

        /// <summary>
        /// Get draft report filter by name
        /// </summary>
        /// <param name="filterName">The name of the filter to get</param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1/draft/filter/{filterName}")]
        [ProducesResponseType<FileStreamResult>(StatusCodes.Status200OK, "application/x-yaml")]
        [RequiredScopes(ScopeConcatType.OR, "library", "draft_reports_read", "draft_reports_write")]
        public async Task<IActionResult> GetDraftFilter([FromRoute] string filterName)
        {
            var filterList = await _draftReportFiltersService.GetDraftFilterByNameAsync(filterName);
            if (filterList == null || filterList.Filters == null || filterList.Filters.Count == 0)
            {
                _logger.Error("Filter not found - filterName:{filterName}", filterName.ToSanitizedString());
                return NotFound();
            }

            var yaml = YamlHelper.Serialize(filterList);
            var memoryStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(yaml))
            {
                Position = 0
            };

            return File(memoryStream, "application/x-yaml", $"{filterList.Filters.FirstOrDefault()?.FilterName}.yaml");
        }

        /// <summary>
        /// Update a draft report filter by name
        /// </summary>
        /// <param name="filterName">The name of the filter to update</param>
        /// <param name="yamlFile"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/v1/draft/filter/{filterName}")]
        [ProducesResponseType(200)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> UpdateDraftFilters([FromRoute] string filterName, IFormFile yamlFile)
        {
            try
            {
                var draftReportFilters = await ParseYaml(yamlFile);

                if(draftReportFilters == null || draftReportFilters.Filters == null || draftReportFilters.Filters.Count == 0)
                {
                    _logger.Error("No filters found in yaml file - filterName:{filterName}", filterName.ToSanitizedString());
                    return BadRequest();
                }
                await _draftReportFiltersService.UpdateDraftFilterAsync(filterName, draftReportFilters.Filters.First());
                return Ok();
            }
            catch (BadRequestException e)
            {
                return BadRequest(e.Message);
            }
        }


        /// <summary>
        /// Update multiple draft report filters
        /// </summary>
        /// <param name="yamlFile"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/v1/draft/filters")]
        [ProducesResponseType(200)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> UpdateDraftFilters(IFormFile yamlFile)
        {
            try
            {
                var draftReportFilters = await ParseYaml(yamlFile);

                if (draftReportFilters == null || draftReportFilters.Filters == null || draftReportFilters.Filters.Count == 0)
                {
                    _logger.Error("No filters found in yaml file.");
                    return BadRequest();
                }
                await _draftReportFiltersService.UpdateDraftFiltersAsync(draftReportFilters);
                return Ok();
            }
            catch (BadRequestException e)
            {
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Create a draft report filter
        /// </summary>
        /// <param name="yamlFile">yaml file with filter definition</param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1/draft/filter")]
        [ProducesResponseType(201)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> CreateDraftFilters(IFormFile yamlFile)
        {
            var context = _contextProvider.GetContext();

            try
            {
                var draftReportFilters = await ParseYaml(yamlFile);
                var createdFilter = await _draftReportFiltersService.CreateDraftFilterAsync(draftReportFilters);
                var createdFilters = createdFilter.Filters.Select(f => f.FilterName).ToList();
                return CreatedAtAction(nameof(CreateDraftFilters), createdFilters, createdFilter);
            }
            catch (BadRequestException e)
            {
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Delete a draft report filter by name
        /// </summary>
        /// <param name="filterName">The name of the filter to delete</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("api/v1/draft/filter/{filterName}")]
        [ProducesResponseType(200)]
        [RequiredScopes("draft_reports_write")]
        public async Task<IActionResult> DeleteDraftFilters([FromRoute] string filterName)
        {
            await _draftReportFiltersService.DeleteDraftFilterAsync(filterName);
            return Ok();
        }

        private static async Task<DraftFilterModel> ParseYaml(IFormFile file)
        {
            try
            {
                using var fs = file.OpenReadStream();
                using var sr = new StreamReader(fs);
                var fileText = await sr.ReadToEndAsync();
                return YamlHelper.Deserialize<DraftFilterModel>(fileText);
            }
            catch (YamlDotNet.Core.YamlException ex)
            {
                throw new BadRequestException($"Invalid YAML Start: {ex.Start} End: {ex.End}");
            }
            catch (Exception ex)
            {
                throw new BadRequestException($"Error while creating DraftFilter from yaml: {ex.Message}");
            }
        }

    }
}
