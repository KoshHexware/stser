﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Web.ActionFilter;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers;

[ApiController]
[Authorize]
[ModelValidationActionFilter]
public abstract class BaseApiController : ControllerBase
{
}
