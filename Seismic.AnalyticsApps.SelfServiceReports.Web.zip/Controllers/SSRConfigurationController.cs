﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Interfaces;
using Seismic.AnalyticsApps.SelfServiceReports.Services.Models;
using Seismic.Common.ServiceFoundation;

namespace Seismic.AnalyticsApps.SelfServiceReports.Web.Controllers
{
    [Authorize]
    [ApiExplorerSettings(GroupName = "public")]
    public class SSRConfigurationController(ISSRConfigurationService _ssrConfigurationService, ISeismicContextProvider _contextProvider) : ControllerBase
    {
        [HttpGet]
        [Route("/api/v1/userConfig")]
        [ProducesResponseType<SSRUserConfiguration>(200)]
        public async Task<IActionResult> GetSSRConfiguration()
        {
            var context = _contextProvider.GetContext();
            var result = await _ssrConfigurationService.GetSSRConfigurationAsync(context.TenantIdentifier.TenantUniqueId, context.UserId);
            return Ok(result);
        }
    }
}
