﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common;

[ExcludeFromCodeCoverage]
public static class BackgroundWorkloadConstants
{
    public const string CONTROLLER_BACKGROUND_WORKLOAD = "controller";
    public const string WORKER_BACKGROUND_WORKLOAD = "worker";

    public const int GRACEFUL_SHUTDOWN_TIMEOUT_MS = 10000;
}
