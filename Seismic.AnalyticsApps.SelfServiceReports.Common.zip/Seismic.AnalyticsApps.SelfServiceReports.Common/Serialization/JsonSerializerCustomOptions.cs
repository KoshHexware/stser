﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common.Serialization;

[ExcludeFromCodeCoverage]
public static class JsonSerializerCustomOptions
{
    /// <summary>
    /// Default serializer, should be reused in services and clients to avoid performance bottle neck.
    /// Disconnected from MVC <see cref="Microsoft.Extensions.Options.IOptions{JsonOptions}"/>
    /// Reference - https://learn.microsoft.com/en-us/dotnet/standard/serialization/system-text-json/configure-options
    /// </summary>
    public static readonly JsonSerializerOptions Default = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        ReferenceHandler = ReferenceHandler.Preserve
    };

    public static readonly JsonSerializerOptions IgnorePropertyNameAndEnumCase = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        ReferenceHandler = ReferenceHandler.Preserve,
        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) },
        PropertyNameCaseInsensitive = true
    };
}