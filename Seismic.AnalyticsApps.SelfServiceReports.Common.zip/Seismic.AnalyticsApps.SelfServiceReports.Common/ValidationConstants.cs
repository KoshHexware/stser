﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common
{
    [ExcludeFromCodeCoverage]
    public static class ValidationConstants
    {
        public const string API_VALIDATION_ERROR_TITLE = "One or more validation errors occurred.";
        public const string GENERIC_ERROR_TITLE = "Internal Server Error.";
    }
}
