﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common.Extension
{
    public static class EnumExtension
    {
        public static string GetDisplayName(this Enum enumValue)
        {
            return enumValue.GetType()
                            .GetMember(enumValue.ToString())
                            .First()
                            .GetCustomAttribute<DisplayAttribute>()?
                            .GetName() ?? enumValue.ToString();
        }

        public static T? GetEnumValueFromDisplayName<T>(string? displayName) where T : Enum
        {
            var type = typeof(T);
            foreach (var field in type.GetFields())
            {
                var attribute = field.GetCustomAttribute<DisplayAttribute>();
                if (attribute != null && string.Equals(attribute.Name, displayName, StringComparison.OrdinalIgnoreCase))
                {
                    return (T?)field.GetValue(null);
                }
            }
            throw new ArgumentException($"No enum value with display name '{displayName}' found in {type.Name}");
        }
    }
}
