﻿using System.Diagnostics.CodeAnalysis;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common;

[ExcludeFromCodeCoverage]
public static class CorrelationConstants
{
    public const string CORRELATION_ID = "CorrelationId";
    public const string HEADER_CORRELATION_ID = "X-Seismic-CorrelationId";
}
