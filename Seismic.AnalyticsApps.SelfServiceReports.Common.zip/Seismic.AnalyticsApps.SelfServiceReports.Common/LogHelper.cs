﻿using System.Web;

namespace Seismic.AnalyticsApps.SelfServiceReports.Common
{
    public static class LogHelper
    {
        public static string ToSanitizedString(this string input)
        {
            return HttpUtility.UrlEncode(input).Replace(Environment.NewLine, "").Replace("\n", "").Replace("\r", "");
        }
    }
}
